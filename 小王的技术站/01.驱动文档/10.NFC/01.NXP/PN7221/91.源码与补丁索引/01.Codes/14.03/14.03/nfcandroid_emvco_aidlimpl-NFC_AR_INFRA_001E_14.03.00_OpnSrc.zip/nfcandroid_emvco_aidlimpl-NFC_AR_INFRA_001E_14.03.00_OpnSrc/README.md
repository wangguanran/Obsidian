# nfcandroid_emvco_aidlimpl
AOSP based Nxp’s EMVCo CL L1 Library, EMVCo CT library  and HAL

#### Git Repository

| DESCRIPTION        | CHECKOUT COMMAND          |
| :-------------: |:-------------:| 
| nfcandroid_emvco_aidlimpl | git@github.com:nxp-nfc-infra/nfcandroid_emvco_aidlimpl.git |

#### Supported Version on "br_ar_14_comm_infra_dev" branch
| Android Version        | NXP Release          | NXP Tag  |
| :-------------: |:---------------------:| :-----:|
| android-14.0.0_r4              |  14.02.00 (PN7xxx) |  NFC_AR_INFRA_001E_14.02.00_OpnSrc |
| android-14.0.0_r4              |  14.03.00 (PN7xxx) |  NFC_AR_INFRA_001E_14.03.00_OpnSrc |






