# SPDX-License-Identifier: GPL-2.0
# !/bin/bash
KERNEL_SRC="${ROOT_DIR}/${KERNEL_DIR}"

BASE_DIR=$(dirname "${0}")/..
FILES_DIR="${BASE_DIR}/files"
PATCHES_DIR="${BASE_DIR}/patches/${TARGET_KERNEL_USE}"

# Apply source preparation
"${BASE_DIR}/scripts/prepare.sh"

# Copy source files and apply integration patches
[ ! -d "${KERNEL_SRC}" ] && exit 1
[ ! -d "${FILES_DIR}" ] || cp -r "${FILES_DIR}"/* "${KERNEL_SRC}" || exit $?
[ ! -f "${PATCHES_DIR}/integrate"/*.patch ] || git -C "${KERNEL_SRC}" apply "${PATCHES_DIR}/integrate"/*.patch || exit $?
