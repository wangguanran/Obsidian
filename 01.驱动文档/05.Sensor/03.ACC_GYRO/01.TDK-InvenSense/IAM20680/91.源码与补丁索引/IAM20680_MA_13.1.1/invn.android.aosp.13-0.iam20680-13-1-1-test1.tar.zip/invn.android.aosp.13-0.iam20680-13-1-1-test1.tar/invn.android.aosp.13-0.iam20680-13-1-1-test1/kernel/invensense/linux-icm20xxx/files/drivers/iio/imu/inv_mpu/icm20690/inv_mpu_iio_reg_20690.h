/*
 * Copyright (C) 2017-2020 InvenSense, Inc.
 *
 * This software is licensed under the terms of the GNU General Public
 * License version 2, as published by the Free Software Foundation, and
 * may be copied, distributed, and modified under those terms.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#ifndef _INV_MPU_IIO_REG_20690_H_
#define _INV_MPU_IIO_REG_20690_H_

/*register and associated bit definition*/
#define REG_SELF_TEST1			0x00
#define REG_SELF_TEST2			0x01
#define REG_SELF_TEST3			0x02

#define REG_PRODUCT_ID			0xC

#define REG_SELF_TEST4			0x0D
#define REG_SELF_TEST5			0x0E
#define REG_SELF_TEST6			0x0F

#define REG_XG_OFFS_USR_H		0x13
#define REG_YG_OFFS_USR_H		0x15
#define REG_ZG_OFFS_USR_H		0x17

#define REG_SAMPLE_RATE_DIV		0x19

#define REG_CONFIG			0x1A
#define BIT_FIFO_COUNT_REC		0x80
#define EXT_SYNC_SET			8

#define REG_GYRO_CONFIG			0x1B
#define BITS_SELF_TEST_EN		0xE0
#define SHIFT_GYRO_FS_SEL		0x02

#define REG_ACCEL_CONFIG		0x1C
#define SHIFT_ACCEL_FS			0x03

#define REG_ACCEL_CONFIG_2		0x1D
#define BIT_FIFO_SIZE_1K		0xC0
#define BIT_ACCEL_FCHOCIE_B		0x08

#define REG_LP_MODE_CTRL		0x1E
#define BIT_GYRO_CYCLE_EN		0x80

#define REG_ACCEL_WOM_THR		0x1F
#define REG_ACCEL_WOM_X_THR		0x20
#define REG_ACCEL_WOM_Y_THR		0x21
#define REG_ACCEL_WOM_Z_THR		0x22

#define REG_FIFO_EN			0x23
#define BITS_TEMP_FIFO_EN		0x80
#define BITS_GYRO_FIFO_EN		0x70
#define BIT_ACCEL_FIFO_EN		0x08
#define BIT_SLV_0_FIFO_EN		0x01

#define REG_I2C_MST_CTRL		0x24
#define BIT_WAIT_FOR_ES			0x40

#define REG_I2C_SLV0_ADDR		0x25
#define REG_I2C_SLV0_REG		0x26
#define REG_I2C_SLV0_CTRL		0x27
#define REG_I2C_SLV1_ADDR		0x28
#define REG_I2C_SLV1_REG		0x29
#define REG_I2C_SLV1_CTRL		0x2A
#define REG_I2C_SLV2_ADDR		0x2B
#define REG_I2C_SLV2_REG		0x2C
#define REG_I2C_SLV2_CTRL		0x2D

#define REG_ACCEL_XOUT_H_SH		0x3B

#define REG_GYRO_XOUT_H_SH		0x43

#define REG_AMA_CTRL_NEW_1		0x2E
#define BIT_ODR_DELAY_TIME_EN		0x80

#define REG_I2C_SLV4_CTRL		0x34

#define REG_FSYNC_INT			0x36
#define BIT_FSYNC_INT			0x80

#define REG_INT_PIN_CFG			0x37

#define REG_INT_ENABLE			0x38
#define BIT_WOM_X_INT_EN		0x80
#define BIT_WOM_Y_INT_EN		0x40
#define BIT_WOM_Z_INT_EN		0x20
#define BIT_WOM_ALL_INT_EN		0xE0
#define BIT_FIFO_OFLOW_EN		0x10
#define BIT_DATA_RDY_EN			0x01

#define REG_DMP_INT_STATUS		0x39

#define REG_INT_STATUS			0x3A
#define BIT_WOM_INT			0xE0

#define REG_RAW_ACCEL			0x3B

#define REG_TEMP_OUT_H			0x41

#define REG_EXT_SLV_SENS_DATA_00	0x49

#define REG_ODR_DLY_CNT_HI		0x5F
#define ODR_DLY_REG_COUNT		2

#define REG_FIFO_WM_TH_HI		0x5E
#define REG_FIFO_WM_TH			0x61

#define REG_I2C_SLV0_DO			0x63
#define REG_I2C_SLV1_DO			0x64
#define REG_I2C_SLV2_DO			0x65

#define REG_I2C_MST_DELAY_CTRL		0x67
#define BIT_DELAY_ES_SHADOW		0x80
#define BIT_I2C_SLV1_DELAY_EN		0x02
#define BIT_I2C_SLV0_DELAY_EN		0x01

#define REG_SIGNAL_PATH_RESET		0x68
#define OIS_GYRO_FS_SHIFT		5
#define OIS_FCHOICE_10			0x10

#define REG_ACCEL_INTEL_CTRL		0x69
#define BIT_ACCEL_INTEL_EN		0x80
#define BIT_ACCEL_INTEL_MODE		0x40
#define BIT_ACCEL_FCHOICE_OIS_B		0x30 /* 11: ODR 4kHz */

#define REG_USER_CTRL			0x6A
#define BIT_COND_RST			0x01
#define BIT_FIFO_RST			0x04
#define BIT_DMP_RST			0x08
#define BIT_I2C_IF_DIS			0x10
#define BIT_I2C_MST_EN			0x20
#define BIT_FIFO_EN			0x40
#define BIT_DMP_EN			0x80

#define REG_PWR_MGMT_1			0x6B
#define BIT_H_RESET			0x80
#define BIT_SLEEP			0x40
#define BIT_LP_EN			0x20
#define BIT_CLK_PLL			0x01
#define BIT_CLK_MASK			0x07

#define REG_PWR_MGMT_2			0x6C
#define BIT_PWR_ACCEL_STBY		0x38
#define BIT_PWR_GYRO_STBY		0x07
#define BIT_PWR_ALL_OFF			0x3F
#define BIT_FIFO_LP_EN			0x80

#define REG_MEM_BANK_SEL		0x6D
#define REG_MEM_START_ADDR		0x6E
#define REG_MEM_R_W			0x6F

#define REG_USER_CTRL_NEW		0x70
#define BIT_OIS_ENABLE			0x2

#define REG_FIFO_COUNT_H		0x72
#define REG_FIFO_R_W			0x74
#define REG_WHO_AM_I			0x75

#define REG_XA_OFFS_H			0x77
#define REG_YA_OFFS_H			0x7A
#define REG_ZA_OFFS_H			0x7D
#define REG_XA_OFFS_L_TC		0x7

/* self test definition */
#define REG_6500_XG_ST_DATA		0x0
#define REG_6500_XA_ST_DATA		0xD
#define REG_6500_ACCEL_CONFIG2		0x1D

#define INV_MPU_BIT_SLV_EN		0x80
#define INV_MPU_BIT_BYTE_SW		0x40
#define INV_MPU_BIT_REG_DIS		0x20
#define INV_MPU_BIT_GRP			0x10
#define INV_MPU_BIT_I2C_READ		0x80

/* data output control reg 2 */
#define ACCEL_ACCURACY_SET		0x4000
#define GYRO_ACCURACY_SET		0x2000
#define CPASS_ACCURACY_SET		0x1000
#define FSYNC_SET			0x0800
#define FLIP_PICKUP_SET			0x0400
#define BATCH_MODE_EN			0x0100
#define ACT_RECOG_SET			0x0080
#define SECOND_SEN_OFF_SET		0x0040

#define INV_FSYNC_TEMP_BIT		0x1

#define ACCEL_COVARIANCE		0

/* dummy definitions */
#define BANK_SEL_0			0x00
#define BANK_SEL_1			0x10
#define BANK_SEL_2			0x20
#define BANK_SEL_3			0x30

/* data definitions */
#define BYTES_PER_SENSOR		6
#define BYTES_FOR_TEMP			2
#define BYTES_FOR_COMPASS		10
#define FIFO_COUNT_BYTE			2
#define INV_RAW_DATA_BYTES		6
#define MAX_FIFO_PACKET_READ		6
#define HARDWARE_FIFO_SIZE		1024
#define FIFO_SIZE			(HARDWARE_FIFO_SIZE * 7 / 8)
#define POWER_UP_TIME			100
#define REG_UP_TIME_USEC		5000
#define DMP_RESET_TIME			20
#define GYRO_ENGINE_UP_TIME		50
#define MPU_MEM_BANK_SIZE		256
#define IIO_BUFFER_BYTES		8
#define HEADERED_NORMAL_BYTES		8
#define HEADERED_Q_BYTES		16
#define LEFT_OVER_BYTES			128
#define BASE_SAMPLE_RATE		1000
#define DRY_RUN_TIME			50
#define EIS_DIVIDER			1
#define INV_ICM20690_GYRO_START_TIME	80
#define INV_ICM20690_ACCEL_START_TIME	10
#define MODE_1K_INIT_SAMPLE		5
#define MODE_VR_INIT_SAMPLE		5
#define FIRST_DROP_SAMPL_MS		40

#ifdef BIAS_CONFIDENCE_HIGH
#define DEFAULT_ACCURACY		3
#else
#define DEFAULT_ACCURACY		1
#endif

enum inv_filter_e {
	INV_FILTER_256HZ_NOLPF2 = 0,
	INV_FILTER_188HZ,
	INV_FILTER_98HZ,
	INV_FILTER_42HZ,
	INV_FILTER_20HZ,
	INV_FILTER_10HZ,
	INV_FILTER_5HZ,
	INV_FILTER_2100HZ_NOLPF,
	NUM_FILTER
};

enum inv_avg_filter_e {
	BIT_AVG_FILTER_500HZ = 0x00,	// 1x
	BIT_AVG_FILTER_200HZ = 0x20,	// 4x
	BIT_AVG_FILTER_100HZ = 0x40,	// 16x
	BIT_AVG_FILTER_50HZ = 0x50,	// 32x
	BIT_AVG_FILTER_30HZ = 0x60	// 64x
};

#define MPU_DEFAULT_DMP_FREQ		200
#define PEDOMETER_FREQ			(MPU_DEFAULT_DMP_FREQ >> 2)
#define SENSOR_FUSION_MIN_RATE		100
#define GESTURE_ACCEL_RATE		50
#define ESI_GYRO_RATE			200
#define MODE_VR_RATE			500

#define MIN_MST_ODR_CONFIG		4
#define MAX_MST_ODR_CONFIG		5
#define MIN_COMPASS_RATE		4
#define MAX_COMPASS_RATE		100
#define MAX_MST_NON_COMPASS_ODR_CONFIG	7
#define THREE_AXES			3
#define NINE_ELEM			(THREE_AXES * THREE_AXES)
#define MPU_TEMP_SHIFT			16
#define DMP_DIVIDER			(BASE_SAMPLE_RATE / MPU_DEFAULT_DMP_FREQ)
#define MAX_5_BIT_VALUE			0x1F
#define BAD_COMPASS_DATA		0x7FFF
#define BAD_CAL_COMPASS_DATA		0x7FFF0000
#define DEFAULT_BATCH_RATE		400
#define DEFAULT_BATCH_TIME		(MSEC_PER_SEC / DEFAULT_BATCH_RATE)
#define NINEQ_DEFAULT_COMPASS_RATE	25

#define DATA_AKM_99_BYTES_DMP		10
#define DATA_AKM_89_BYTES_DMP		9
#define DATA_ALS_BYTES_DMP		8
#define TEMPERATURE_SCALE		3340827L
#define TEMPERATURE_OFFSET		1376256L
#define SECONDARY_INIT_WAIT		100
#define AK99XX_SHIFT			23
#define AK89XX_SHIFT			22

/* data limit definitions */
#define MIN_FIFO_RATE			4
#define MAX_FIFO_RATE			MPU_DEFAULT_DMP_FREQ
#define MAX_DMP_OUTPUT_RATE		MPU_DEFAULT_DMP_FREQ

#define MAX_MPU_MEM			8192
#define MAX_PRS_RATE			281
/* initial rate is important. For non-DMP mode, it is set as 4 1000/256*/
#define MPU_INIT_SENSOR_RATE		4

/* temperature */
#define TEMP_SENSITIVITY		32680	// 326.8 LSB/degC * 100
#define TEMP_OFFSET			2500	// 25 degC * 100

/* enum for sensor
   The sequence is important.
   It represents the order of apperance from DMP */
enum INV_SENSORS {
	SENSOR_ACCEL = 0,
	SENSOR_TEMP,
	SENSOR_GYRO,
	SENSOR_COMPASS,
	SENSOR_NUM_MAX,
	SENSOR_INVALID,
};

enum inv_devices {
	ICM20608D,
	ICM20789,
	ICM20690,
	ICM20602,
	IAM20680,
	ICM42600,
	ICM42686,
	ICM42688,
	ICM40609D,
	ICM43600,
	ICM45600,
	INV_NUM_PARTS,
};
#endif
