/*
 * Copyright (C) 2017-2020 InvenSense, Inc.
 *
 * This software is licensed under the terms of the GNU General Public
 * License version 2, as published by the Free Software Foundation, and
 * may be copied, distributed, and modified under those terms.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#include <linux/kernel.h>
#include <linux/device.h>
#include <linux/module.h>
#include <linux/slab.h>
#include <linux/i2c.h>
#include <linux/pm.h>
#include <linux/crc8.h>
#include <linux/atomic.h>
#include <linux/spinlock.h>
#include <linux/delay.h>
#include <linux/hrtimer.h>
#include <linux/ktime.h>
#ifdef CONFIG_RTC_INTF_ALARM
#include <linux/android_alarm.h>
#endif
#include <linux/irqreturn.h>
#include <linux/math64.h>
#include <linux/version.h>
#include <linux/iio/iio.h>
#include <linux/iio/buffer.h>
#include <linux/iio/trigger.h>
#include <linux/iio/trigger_consumer.h>
#include <linux/iio/triggered_buffer.h>
#include <linux/iio/sysfs.h>
#include <linux/regulator/consumer.h>
#include <linux/version.h>

/* hack for using icp101xx standalone inside icm20789 */
/* #define ICP101XX_STANDALONE_ICM20789 */

#ifdef CONFIG_RTC_INTF_ALARM
static inline s64 icp101xx_get_time(void)
{
	ktime_t ts;

	/* Workaround for some platform on which monotonic clock and
	 * Android SystemClock has a gap.
	 * Use ktime_to_timespec(alarm_get_elapsed_realtime()) instead of
	 * get_monotonic_boottime() for these platform
	 */
	ts = ktime_to_timespec(alarm_get_elapsed_realtime());

	return timespec_to_ns(ts);
}
#else
static inline s64 icp101xx_get_time(void)
{
#if LINUX_VERSION_CODE < KERNEL_VERSION(4, 19, 0)
	/* kernel ~4.18 */
	struct timespec ts;
	get_monotonic_boottime(&ts);

	return timespec_to_ns(&ts);
#elif LINUX_VERSION_CODE < KERNEL_VERSION(5, 3, 0)
	/* kernel 4.19~5.2 */
	return ktime_get_boot_ns();
#else
	/* kernel 5.3~ */
	return ktime_get_boottime_ns();
#endif
}
#endif

#define ICP101XX_ID_REG_GET(_reg)	((_reg) & 0x003F)
#define ICP101XX_ID_REG			0x08
#define ICP101XX_RESPONSE_WORD_LENGTH	3
#define ICP101XX_CRC8_WORD_LENGTH	2
#define ICP101XX_CRC8_POLYNOMIAL		0x31
#define ICP101XX_CRC8_INIT		0xFF

enum icp101xx_chip {
	ICP101XX,
};

enum icp101xx_mode {
	ICP101XX_MODE_1,	// LP mode
	ICP101XX_MODE_2,	// N mode
	ICP101XX_MODE_3,	// LN mode
	ICP101XX_MODE_4,	// ULN mode
	ICP101XX_MODE_NB,
};

enum icp101xx_attributes {
	ICP101XX_ATTR_SAMP_AVAIL_FREQ,
	ICP101XX_ATTR_MODE,
	ICP101XX_ATTR_CALIBDATA,
};

enum icp101xx_channel {
	ICP101XX_CHANNEL_PRESSURE,
	ICP101XX_CHANNEL_TEMPERATURE,
	ICP101XX_CHANNEL_TIMESTAMP,
};

struct icp101xx_state {
	struct i2c_client *client;
	enum icp101xx_chip chip;
	struct regulator *vdd;
	atomic_t mode;
	struct iio_trigger *trig;
	struct hrtimer timer;
	ktime_t period;
	spinlock_t period_lock;
	int16_t cal[4];
};

struct icp101xx_command {
	__be16 cmd;
	unsigned long wait_us;
	unsigned long wait_max_us;
	size_t response_word_nb;
};

static const struct icp101xx_command icp101xx_cmd_soft_reset = {
	.cmd = cpu_to_be16(0x805D),
	.wait_us = 0,
	.response_word_nb = 0,
};
static const struct icp101xx_command icp101xx_cmd_read_id = {
	.cmd = cpu_to_be16(0xEFC8),
	.wait_us = 0,
	.response_word_nb = 1,
};
static const struct icp101xx_command icp101xx_cmd_read_otp = {
	.cmd = cpu_to_be16(0xC7F7),
	.wait_us = 0,
	.response_word_nb = 1,
};
static const struct icp101xx_command icp101xx_cmd_measure[] = {
	[ICP101XX_MODE_1] = {
		.cmd = cpu_to_be16(0x401A),
		.wait_us = 1800,
		.wait_max_us = 2000,
		.response_word_nb = 3,
	},
	[ICP101XX_MODE_2] = {
		.cmd = cpu_to_be16(0x48A3),
		.wait_us = 6400,
		.wait_max_us = 6600,
		.response_word_nb = 3,
	},
	[ICP101XX_MODE_3] = {
		.cmd = cpu_to_be16(0x5059),
		.wait_us = 23800,
		.wait_max_us = 24000,
		.response_word_nb = 3,
	},
	[ICP101XX_MODE_4] = {
		.cmd = cpu_to_be16(0x58E0),
		.wait_us = 88000,
		.wait_max_us = 88200,
		.response_word_nb = 3,
	},
};

static const uint8_t icp101xx_switch_mode_otp[] = {0xC5, 0x95, 0x00, 0x66, 0x9c};

static const char *icp101xx_mode_strings[] = {
	[ICP101XX_MODE_1] = "1",
	[ICP101XX_MODE_2] = "2",
	[ICP101XX_MODE_3] = "3",
	[ICP101XX_MODE_4] = "4",
};

static const unsigned icp101xx_min_freq = 1;
static const unsigned icp101xx_max_freq[] = {
	[ICP101XX_MODE_1] = 200,
	[ICP101XX_MODE_2] = 150,
	[ICP101XX_MODE_3] = 30,
	[ICP101XX_MODE_4] = 11,
};

DECLARE_CRC8_TABLE(icp101xx_crc8_table);

static inline int icp101xx_i2c_xfer(struct i2c_adapter *adap,
				   struct i2c_msg *msgs, int num)
{
	int ret;

	ret = i2c_transfer(adap, msgs, num);
	if (ret < 0)
		return ret;

	if (ret == num)
		ret = 0;
	else
		ret = -EIO;

	return ret;
}

#ifdef ICP101XX_STANDALONE_ICM20789
static int icp101xx_hack_icm20789(struct i2c_client *client)
{
#define I2C_ADDR		0x68
#define REG_WHO_AM_I		0x75
#define REG_PWR_MGMT_1		0x6B
#define BIT_H_RESET		0x80
#define BIT_SLEEP		0x40
#define BIT_CLK_PLL		0x01
#define REG_USER_CTRL		0x6A
#define REG_INT_PIN_CFG		0x37
#define BIT_INT_LEVEL		0x80
#define BIT_INT_OPEN		0x40
#define BIT_BYPASS_EN		0x02
	uint8_t msg[2];
	struct i2c_msg write_reg[] = {
		{
			.addr = I2C_ADDR,
			.flags = 0,
			.len = 2,
			.buf = msg,
		},
	};
	struct i2c_msg read_reg[] = {
		{
			.addr = I2C_ADDR,
			.flags = 0,
			.len = 1,
			.buf = &msg[0],
		}, {
			.addr = I2C_ADDR,
			.flags = I2C_M_RD,
			.len = 1,
			.buf = &msg[1],
		},
	};
	int ret;

	/* verify whoami */
	msg[0] = REG_WHO_AM_I;
	ret = icp101xx_i2c_xfer(client->adapter, read_reg, ARRAY_SIZE(read_reg));
	if (ret < 0)
		return ret;
	dev_info(&client->dev, "icm20789 whoami: %#x\n", msg[1]);

	/* reset and power on */
	msg[0] = REG_PWR_MGMT_1;
	msg[1] = BIT_H_RESET;
	ret = icp101xx_i2c_xfer(client->adapter, write_reg, ARRAY_SIZE(write_reg));
	if (ret < 0)
		return ret;
	msleep(100);
	msg[0] = REG_PWR_MGMT_1;
	msg[1] = BIT_CLK_PLL;
	ret = icp101xx_i2c_xfer(client->adapter, write_reg, ARRAY_SIZE(write_reg));
	if (ret < 0)
		return ret;
	msleep(100);
	msg[0] = REG_USER_CTRL;
	msg[1] = 0;
	ret = icp101xx_i2c_xfer(client->adapter, write_reg, ARRAY_SIZE(write_reg));
	if (ret < 0)
		return ret;

	/* enable i2c bypass mode and open drain interrupt */
	msg[0] = REG_INT_PIN_CFG;
	msg[1] = BIT_INT_LEVEL | BIT_INT_OPEN | BIT_BYPASS_EN;
	ret = icp101xx_i2c_xfer(client->adapter, write_reg, ARRAY_SIZE(write_reg));
	if (ret < 0)
		return ret;

	/* put chip to sleep */
	msg[0] = REG_PWR_MGMT_1;
	msg[1] = BIT_SLEEP;
	ret = icp101xx_i2c_xfer(client->adapter, write_reg, ARRAY_SIZE(write_reg));
	if (ret < 0)
		return ret;

	return 0;
}
#endif

static int icp101xx_set_power(struct icp101xx_state *st, bool on)
{
	int ret;

	if (on) {
		ret = regulator_enable(st->vdd);
		if (ret)
			return ret;
		msleep(100);
	} else {
		ret = regulator_disable(st->vdd);
		if (ret)
			return ret;
	}

	return 0;
}

static int icp101xx_send_cmd(struct icp101xx_state *st,
			    const struct icp101xx_command *cmd,
			    __be16 *buf, size_t buf_len)
{
	struct i2c_client *client = st->client;
	size_t size = cmd->response_word_nb * ICP101XX_RESPONSE_WORD_LENGTH;
	uint8_t data[16];
	uint8_t *ptr;
	uint8_t *buf_ptr = (uint8_t *)buf;
	struct i2c_msg msgs[2] = {
		{
			.addr = st->client->addr,
			.flags = 0,
			.len = 2,
			.buf = (uint8_t *)&cmd->cmd,
		}, {
			.addr = st->client->addr,
			.flags = I2C_M_RD,
			.len = size,
			.buf = data,
		},
	};
	uint8_t crc;
	unsigned i;
	int ret;

	if (size > sizeof(data))
		return -EINVAL;

	if (cmd->response_word_nb > 0 &&
			(buf == NULL || buf_len < (cmd->response_word_nb * 2)))
		return -EINVAL;

	dev_dbg(&st->client->dev, "sending cmd %#x\n", be16_to_cpu(cmd->cmd));

	if (cmd->response_word_nb > 0 && cmd->wait_us == 0) {
		/* direct command-response without waiting */
		ret = icp101xx_i2c_xfer(client->adapter, msgs, ARRAY_SIZE(msgs));
		if (ret)
			return ret;
	} else {
		/* transfer command write */
		ret = icp101xx_i2c_xfer(client->adapter, &msgs[0], 1);
		if (ret)
			return ret;
		if (cmd->wait_us > 0)
			usleep_range(cmd->wait_us, cmd->wait_max_us);
		/* transfer response read if needed */
		if (cmd->response_word_nb > 0) {
			ret = icp101xx_i2c_xfer(client->adapter, &msgs[1], 1);
			if (ret)
				return ret;
		} else {
			return 0;
		}
	}

	/* process read words with crc checking */
	for (i = 0; i < cmd->response_word_nb; ++i) {
		ptr = &data[i * ICP101XX_RESPONSE_WORD_LENGTH];
		crc = crc8(icp101xx_crc8_table, ptr, ICP101XX_CRC8_WORD_LENGTH,
			   ICP101XX_CRC8_INIT);
		if (crc != ptr[ICP101XX_CRC8_WORD_LENGTH]) {
			dev_err(&client->dev, "crc error, recv=%#x calc=%#x\n",
				ptr[ICP101XX_CRC8_WORD_LENGTH], crc);
			return -EIO;
		}
		*buf_ptr++ = ptr[0];
		*buf_ptr++ = ptr[1];
	}

	return 0;
}

static int icp101xx_read_cal_otp(struct icp101xx_state *st)
{
	__be16 val;
	int i;
	int ret;

	/* switch into OTP read mode */
	ret = i2c_master_send(st->client, icp101xx_switch_mode_otp,
			      ARRAY_SIZE(icp101xx_switch_mode_otp));
	if (ret < 0)
		return ret;
	if (ret != ARRAY_SIZE(icp101xx_switch_mode_otp))
		return -EIO;

	/* read 4 calibration values */
	for (i = 0; i < 4; ++i) {
		ret = icp101xx_send_cmd(st, &icp101xx_cmd_read_otp,
				       &val, sizeof(val));
		if (ret)
			return ret;
		st->cal[i] = be16_to_cpu(val);
		dev_dbg(&st->client->dev, "cal #%d=%#x\n", i, st->cal[i]);
	}

	return 0;
}

static int icp101xx_init_chip(struct icp101xx_state *st)
{
	__be16 val;
	uint16_t id;
	int ret;

	/* read and check id */
	ret = icp101xx_send_cmd(st, &icp101xx_cmd_read_id, &val, sizeof(val));
	if (ret)
		return ret;
	id = be16_to_cpu(val);
	dev_info(&st->client->dev, "id reg=%#x\n", id);
	if (ICP101XX_ID_REG_GET(id) != ICP101XX_ID_REG) {
		dev_err(&st->client->dev, "invalid id\n");
		return -ENODEV;
	}

	/* read calibration data from OTP */
	ret = icp101xx_read_cal_otp(st);
	if (ret)
		return ret;

	/* reset chip */
	ret = icp101xx_send_cmd(st, &icp101xx_cmd_soft_reset, NULL, 0);
	if (ret)
		return ret;

	return 0;
}

static irqreturn_t icp101xx_read_measurement(int irq, void *p)
{
	struct iio_poll_func *pf = p;
	struct iio_dev *indio_dev = pf->indio_dev;
	struct icp101xx_state *st = iio_priv(indio_dev);
	struct {
		__be16 measures[3];
		uint16_t padding;
		int64_t ts;
	} __packed data;
	int ret;

	ret = icp101xx_send_cmd(st, &icp101xx_cmd_measure[atomic_read(&st->mode)],
			       data.measures, sizeof(data.measures));
	if (ret) {
		dev_err(&st->client->dev, "measure command error %d\n", ret);
		goto error_out;
	}

	data.padding = 0;
	data.ts = icp101xx_get_time();
	ret = iio_push_to_buffers(indio_dev, (uint8_t *)&data);
	if (ret)
		dev_err(&st->client->dev, "iio push error %d\n", ret);

error_out:
	iio_trigger_notify_done(indio_dev->trig);
	return IRQ_HANDLED;
}

static enum hrtimer_restart icp101xx_timer_handler(struct hrtimer *timer)
{
	struct icp101xx_state *st = container_of(timer, struct icp101xx_state,
						timer);
	ktime_t period;
	unsigned long flags;

	spin_lock_irqsave(&st->period_lock, flags);
	period = st->period;
	spin_unlock_irqrestore(&st->period_lock, flags);
	hrtimer_forward_now(timer, period);

	iio_trigger_poll(st->trig);

	return HRTIMER_RESTART;
}

static int icp101xx_trig_set_state(struct iio_trigger *trig, bool state)
{
	struct iio_dev *indio_dev = iio_trigger_get_drvdata(trig);
	struct icp101xx_state *st = iio_priv(indio_dev);
	ktime_t period;
	unsigned long flags;

	if (state) {
		spin_lock_irqsave(&st->period_lock, flags);
		period = st->period;
		spin_unlock_irqrestore(&st->period_lock, flags);
		hrtimer_start(&st->timer, period, HRTIMER_MODE_REL);
	} else {
		hrtimer_cancel(&st->timer);
	}

	return 0;
}

static const struct iio_trigger_ops icp101xx_trigger_ops = {
#if LINUX_VERSION_CODE < KERNEL_VERSION(4, 15, 0)
	.owner = THIS_MODULE,
#endif
	.set_trigger_state = icp101xx_trig_set_state,
};

static int icp101xx_read_raw(struct iio_dev *indio_dev,
			    struct iio_chan_spec const *chan,
			    int *val, int *val2, long mask)
{
	struct icp101xx_state *st = iio_priv(indio_dev);
	__be16 measures[3];
	int ret;

	switch (mask) {
	case IIO_CHAN_INFO_RAW:
		mutex_lock(&indio_dev->mlock);
		if (iio_buffer_enabled(indio_dev)) {
			ret = -EBUSY;
			goto out_info_raw;
		}
		ret = icp101xx_send_cmd(st, &icp101xx_cmd_measure[atomic_read(&st->mode)],
				       measures, sizeof(measures));
		if (ret)
			goto out_info_raw;
		switch (chan->type) {
		case IIO_PRESSURE:
			*val = (be16_to_cpu(measures[0]) << 8) |
					(be16_to_cpu(measures[1]) >> 8);
			ret = IIO_VAL_INT;
			break;
		case IIO_TEMP:
			*val = be16_to_cpu(measures[2]);
			ret = IIO_VAL_INT;
			break;
		default:
			ret = -EINVAL;
			break;
		};
out_info_raw:
		mutex_unlock(&indio_dev->mlock);
		break;
	case IIO_CHAN_INFO_SCALE:
		switch (chan->type) {
		case IIO_PRESSURE:
			*val = 1;
			ret = IIO_VAL_INT;
			break;
		case IIO_TEMP:
			*val = 1;
			ret = IIO_VAL_INT;
			break;
		default:
			ret = -EINVAL;
			break;
		}
		break;
	case IIO_CHAN_INFO_OFFSET:
		switch (chan->type) {
		case IIO_PRESSURE:
			*val = 0;
			ret = IIO_VAL_INT;
			break;
		case IIO_TEMP:
			*val = 0;
			ret = IIO_VAL_INT;
			break;
		default:
			ret = -EINVAL;
			break;
		}
		break;
	default:
		ret = -EINVAL;
		break;
	}

	return ret;
}

static int icp101xx_validate_trigger(struct iio_dev *indio_dev,
				    struct iio_trigger *trig)
{
	struct icp101xx_state *st = iio_priv(indio_dev);

	if (st->trig != trig)
		return -EINVAL;

	return 0;
}

static ssize_t icp101xx_attr_show(struct device *dev,
				 struct device_attribute *attr, char *buf)
{
	struct icp101xx_state *st = iio_priv(dev_to_iio_dev(dev));
	struct iio_dev_attr *this_attr = to_iio_dev_attr(attr);

	switch (this_attr->address) {
	case ICP101XX_ATTR_SAMP_AVAIL_FREQ:
		return scnprintf(buf, PAGE_SIZE, "%u-%u\n", icp101xx_min_freq,
				 icp101xx_max_freq[atomic_read(&st->mode)]);
	case ICP101XX_ATTR_MODE:
		return scnprintf(buf, PAGE_SIZE, "%s\n",
				 icp101xx_mode_strings[atomic_read(&st->mode)]);
	case ICP101XX_ATTR_CALIBDATA:
		return scnprintf(buf, PAGE_SIZE, "%d,%d,%d,%d\n",
				 st->cal[0], st->cal[1],
				 st->cal[2], st->cal[3]);
	default:
		return -EINVAL;
	}
}

static ssize_t icp101xx_attr_store(struct device *dev,
				  struct device_attribute *attr,
				  const char *buf, size_t count)
{
	struct iio_dev *indio_dev = dev_to_iio_dev(dev);
	struct icp101xx_state *st = iio_priv(indio_dev);
	struct iio_dev_attr *this_attr = to_iio_dev_attr(attr);
	unsigned val;
	int64_t min_period;
	int ret;
	unsigned long flags;

	switch (this_attr->address) {
	case ICP101XX_ATTR_MODE:
		for (val = 0; val < ICP101XX_MODE_NB; ++val) {
			if (sysfs_streq(buf, icp101xx_mode_strings[val]))
				break;
		}
		if (val >= ICP101XX_MODE_NB)
			return -EINVAL;
		min_period = div_u64(NSEC_PER_SEC, icp101xx_max_freq[val]);
		mutex_lock(&indio_dev->mlock);
		if (!iio_buffer_enabled(indio_dev)) {
			/* first ensure period is aligned with new mode */
			spin_lock_irqsave(&st->period_lock, flags);
			if (ktime_to_ns(st->period) < min_period)
				st->period = ns_to_ktime(min_period);
			spin_unlock_irqrestore(&st->period_lock, flags);
			/* switch mode */
			atomic_set(&st->mode, val);
			ret = 0;
		} else {
			ret = -EBUSY;
		}
		mutex_unlock(&indio_dev->mlock);
		if (ret)
			return ret;
		break;
	default:
		return -EINVAL;
	}

	return count;
}

static ssize_t icp101xx_period_show(struct device *dev,
				   struct device_attribute *attr, char *buf)
{
	struct icp101xx_state *st = iio_priv(dev_to_iio_dev(dev));
	ktime_t period;
	uint32_t period_us;
	unsigned long flags;

	spin_lock_irqsave(&st->period_lock, flags);
	period = st->period;
	spin_unlock_irqrestore(&st->period_lock, flags);
	period_us = div_u64(ktime_to_ns(period), 1000UL);

	return scnprintf(buf, PAGE_SIZE, "%lu\n", USEC_PER_SEC / period_us);
}

static ssize_t icp101xx_period_store(struct device *dev,
				    struct device_attribute *attr,
				    const char *buf, size_t count)
{
	struct icp101xx_state *st = iio_priv(dev_to_iio_dev(dev));
	int32_t sampling_frequency;
	ktime_t period;
	unsigned long flags;

	if (kstrtoint(buf, 10, &sampling_frequency))
		return -EINVAL;
	if (sampling_frequency < icp101xx_min_freq ||
			sampling_frequency > icp101xx_max_freq[atomic_read(&st->mode)])
		return -EINVAL;

	period = ns_to_ktime(div_u64(NSEC_PER_SEC, sampling_frequency));
	spin_lock_irqsave(&st->period_lock, flags);
	st->period = period;
	spin_unlock_irqrestore(&st->period_lock, flags);

	if (hrtimer_active(&st->timer)) {
		hrtimer_cancel(&st->timer);
		hrtimer_start(&st->timer, period, HRTIMER_MODE_REL);
	}

	return count;
}

static IIO_DEV_ATTR_SAMP_FREQ(S_IRUGO | S_IWUSR, icp101xx_period_show,
			      icp101xx_period_store);
static IIO_DEVICE_ATTR(sampling_frequency_available, S_IRUGO, icp101xx_attr_show,
		       NULL, ICP101XX_ATTR_SAMP_AVAIL_FREQ);
static IIO_DEVICE_ATTR(mode, S_IRUGO | S_IWUSR, icp101xx_attr_show,
		       icp101xx_attr_store, ICP101XX_ATTR_MODE);
static IIO_DEVICE_ATTR(calibdata, S_IRUGO, icp101xx_attr_show, NULL,
		       ICP101XX_ATTR_CALIBDATA);

static struct attribute *icp101xx_attributes[] = {
	&iio_dev_attr_sampling_frequency.dev_attr.attr,
	&iio_dev_attr_sampling_frequency_available.dev_attr.attr,
	&iio_dev_attr_mode.dev_attr.attr,
	&iio_dev_attr_calibdata.dev_attr.attr,
	NULL,
};

static const struct attribute_group icp101xx_attribute_group = {
	.attrs = icp101xx_attributes,
};

static const struct iio_info icp101xx_info = {
#if LINUX_VERSION_CODE < KERNEL_VERSION(4, 15, 0)
	.driver_module = THIS_MODULE,
#endif
	.read_raw = icp101xx_read_raw,
	.attrs = &icp101xx_attribute_group,
	.validate_trigger = icp101xx_validate_trigger,
};

static const struct iio_chan_spec icp101xx_channels[] = {
	{
		.type = IIO_PRESSURE,
		.info_mask_separate = BIT(IIO_CHAN_INFO_RAW),
		.info_mask_shared_by_type = BIT(IIO_CHAN_INFO_OFFSET) |
				BIT(IIO_CHAN_INFO_SCALE),
		.scan_index = ICP101XX_CHANNEL_PRESSURE,
		.scan_type = {
			.sign = 'u',
			.realbits = 24,
			.storagebits = 32,
			.shift = 8,
			.endianness = IIO_BE,
		},
	}, {
		.type = IIO_TEMP,
		.info_mask_separate = BIT(IIO_CHAN_INFO_RAW),
		.info_mask_shared_by_type = BIT(IIO_CHAN_INFO_OFFSET) |
				BIT(IIO_CHAN_INFO_SCALE),
		.scan_index = ICP101XX_CHANNEL_TEMPERATURE,
		.scan_type = {
			.sign = 'u',
			.realbits = 16,
			.storagebits = 32,
			.shift = 16,
			.endianness = IIO_BE,
		},
	},
	IIO_CHAN_SOFT_TIMESTAMP(ICP101XX_CHANNEL_TIMESTAMP),
};

static int icp101xx_probe(struct i2c_client *client,
			 const struct i2c_device_id *id)
{
	struct iio_dev *indio_dev;
	struct icp101xx_state *st;
	int ret;

	if (!i2c_check_functionality(client->adapter, I2C_FUNC_I2C)) {
		dev_err(&client->dev, "plain i2c transactions not supported\n");
		return -ENODEV;
	}
	/* has to be done before the first I2C communication */
	crc8_populate_msb(icp101xx_crc8_table, ICP101XX_CRC8_POLYNOMIAL);

#ifdef ICP101XX_STANDALONE_ICM20789
	/* icp101xx standalone use inside icm20789 hack */
	ret = icp101xx_hack_icm20789(client);
	if (ret) {
		dev_err(&client->dev, "icm20789 hack error %d\n", ret);
		return ret;
	}
#endif

#if LINUX_VERSION_CODE < KERNEL_VERSION(5, 9, 0)
	indio_dev = iio_device_alloc(sizeof(*st));
#else
	indio_dev = iio_device_alloc(&client->dev, sizeof(*st));
#endif
	if (indio_dev == NULL) {
		dev_err(&client->dev, "memory allocation failed\n");
		return -ENOMEM;
	}
	i2c_set_clientdata(client, indio_dev);
	indio_dev->dev.parent = &client->dev;
	indio_dev->name = id->name;
	indio_dev->channels = icp101xx_channels;
	indio_dev->num_channels = ARRAY_SIZE(icp101xx_channels);
	indio_dev->info = &icp101xx_info;

	st = iio_priv(indio_dev);
	st->client = client;
	st->chip = id->driver_data;
	hrtimer_init(&st->timer, CLOCK_BOOTTIME, HRTIMER_MODE_REL);
	st->timer.function = icp101xx_timer_handler;
	spin_lock_init(&st->period_lock);
	atomic_set(&st->mode, ICP101XX_MODE_1);
	st->period = ns_to_ktime(NSEC_PER_SEC / 5UL);

	st->vdd = regulator_get(&client->dev, "vdd");
	if (IS_ERR(st->vdd)) {
		ret = PTR_ERR(st->vdd);
		goto error_free_device;
	}

	ret = icp101xx_set_power(st, true);
	if (ret) {
		dev_err(&client->dev, "set power on error %d\n", ret);
		goto error_free_regulator;
	}

	ret = icp101xx_init_chip(st);
	if (ret) {
		dev_err(&client->dev, "init chip error %d\n", ret);
		goto error_power_off;
	}

	ret = iio_triggered_buffer_setup(indio_dev, NULL,
					 icp101xx_read_measurement, NULL);
	if (ret) {
		dev_err(&client->dev, "iio triggered buffer error %d\n", ret);
		goto error_power_off;
	}

	st->trig = iio_trigger_alloc(
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 13, 0)
				     &client->dev,
#endif
				     "%s-dev%d", indio_dev->name,
#if LINUX_VERSION_CODE < KERNEL_VERSION(5, 14, 0)
				     indio_dev->id);
#else
				     iio_device_id(indio_dev));
#endif
	if (st->trig == NULL) {
		ret = -ENOMEM;
		dev_err(&client->dev, "iio trigger alloc error\n");
		goto error_free_buffer;
	}
	st->trig->dev.parent = &client->dev;
	st->trig->ops = &icp101xx_trigger_ops;
	iio_trigger_set_drvdata(st->trig, indio_dev);

	ret = iio_trigger_register(st->trig);
	if (ret) {
		dev_err(&client->dev, "iio trigger register error %d\n", ret);
		goto error_free_trigger;
	}
	iio_trigger_get(st->trig);
	indio_dev->trig = st->trig;

	ret = iio_device_register(indio_dev);
	if (ret) {
		dev_err(&client->dev, "iio device register error %d\n", ret);
		goto error_unregister_trigger;
	}

	return 0;

error_unregister_trigger:
	iio_trigger_unregister(st->trig);
error_free_trigger:
	iio_trigger_free(st->trig);
error_free_buffer:
	iio_triggered_buffer_cleanup(indio_dev);
error_power_off:
	icp101xx_set_power(st, false);
error_free_regulator:
	regulator_put(st->vdd);
error_free_device:
	iio_device_free(indio_dev);
	return ret;
}

static int icp101xx_remove(struct i2c_client *client)
{
	struct iio_dev *indio_dev = i2c_get_clientdata(client);
	struct icp101xx_state *st = iio_priv(indio_dev);

	iio_device_unregister(indio_dev);
	iio_trigger_unregister(st->trig);
	iio_trigger_free(st->trig);
	iio_triggered_buffer_cleanup(indio_dev);
	icp101xx_set_power(st, false);
	regulator_put(st->vdd);
	iio_device_free(indio_dev);

	return 0;
}

#ifdef CONFIG_PM_SLEEP
static int icp101xx_suspend(struct device *dev)
{
	struct iio_dev *indio_dev = i2c_get_clientdata(to_i2c_client(dev));
	struct icp101xx_state *st = iio_priv(indio_dev);

	mutex_lock(&indio_dev->mlock);
	if (iio_buffer_enabled(indio_dev))
		hrtimer_cancel(&st->timer);
	mutex_unlock(&indio_dev->mlock);

	icp101xx_set_power(st, false);

	return 0;
}

static int icp101xx_resume(struct device *dev)
{
	struct iio_dev *indio_dev = i2c_get_clientdata(to_i2c_client(dev));
	struct icp101xx_state *st = iio_priv(indio_dev);
	int ret;

	ret = icp101xx_set_power(st, true);
	if (ret)
		return ret;

	mutex_lock(&indio_dev->mlock);
	if (iio_buffer_enabled(indio_dev))
		hrtimer_start(&st->timer, ns_to_ktime(0), HRTIMER_MODE_REL);
	mutex_unlock(&indio_dev->mlock);

	return 0;
}
#endif

static UNIVERSAL_DEV_PM_OPS(icp101xx_pm, icp101xx_suspend, icp101xx_resume, NULL);

static const struct of_device_id icp101xx_of_match[] = {
	{
		.compatible = "invensense,icp101xx",
		.data = (void *)ICP101XX,
	},
	{ }
};
MODULE_DEVICE_TABLE(of, icp101xx_of_match);

static const struct i2c_device_id icp101xx_id[] = {
	{ "icp101xx", ICP101XX },
	{ }
};
MODULE_DEVICE_TABLE(i2c, icp101xx_id);

static struct i2c_driver icp101xx_driver = {
	.driver = {
		.owner = THIS_MODULE,
		.name = "icp101xx",
		.pm = &icp101xx_pm,
		.of_match_table = of_match_ptr(icp101xx_of_match),
	},
	.probe = icp101xx_probe,
	.remove = icp101xx_remove,
	.id_table = icp101xx_id,
};
module_i2c_driver(icp101xx_driver);

MODULE_AUTHOR("Invensense Corporation");
MODULE_DESCRIPTION("Invensense ICP101XX driver");
MODULE_LICENSE("GPL");
