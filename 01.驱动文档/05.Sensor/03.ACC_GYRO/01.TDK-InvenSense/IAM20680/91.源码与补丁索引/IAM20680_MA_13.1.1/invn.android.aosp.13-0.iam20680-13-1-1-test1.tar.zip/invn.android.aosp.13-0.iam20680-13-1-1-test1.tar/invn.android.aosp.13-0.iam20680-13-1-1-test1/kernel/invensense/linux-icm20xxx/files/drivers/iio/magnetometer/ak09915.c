/*
 * AK09915 3-axis compass driver
 * Copyright (c) 2018, InvenSense Corp.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms and conditions of the GNU General Public License,
 * version 2, as published by the Free Software Foundation.
 *
 * This program is distributed in the hope it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 * more details.
 */

#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/types.h>
#include <linux/slab.h>
#include <linux/spinlock.h>
#include <linux/delay.h>
#include <linux/hrtimer.h>
#include <linux/i2c.h>
#include <linux/pm.h>
#include <linux/of.h>
#include <linux/err.h>
#include <linux/version.h>
#include <linux/iio/iio.h>
#include <linux/iio/buffer.h>
#include <linux/iio/trigger.h>
#include <linux/iio/trigger_consumer.h>
#include <linux/iio/triggered_buffer.h>
#include <linux/iio/sysfs.h>
#include <linux/regulator/consumer.h>

/* Register definitions */
#define AK09915_REG_WIA1	0x00        /* Company ID */
#define AK09915_REG_WIA2	0x01        /* Device ID */
#define AK09915_REG_ST1		0x10        /* Status 1 */
#define AK09915_REG_HXL		0x11        /* Measurement data: X-axis data */
#define AK09915_REG_HXH		0x12        /* Measurement data: X-axis data */
#define AK09915_REG_HYL		0x13        /* Measurement data: Y-axis data */
#define AK09915_REG_HYH		0x14        /* Measurement data: Y-axis data */
#define AK09915_REG_HZL		0x15        /* Measurement data: Z-axis data */
#define AK09915_REG_HZH		0x16        /* Measurement data: Z-axis data */
#define AK09915_REG_TMPS	0x17        /* Dummy register */
#define AK09915_REG_ST2		0x18        /* Status 2: Data status */
#define AK09915_REG_CNTL1	0x30        /* Control 1: Function Control */
#define AK09915_REG_CNTL2	0x31        /* Control 2: Function Control */
#define AK09915_REG_CNTL3	0x32        /* Control 3: Function Control */

/* Register helper values */
#define AK09915_COMPANY_ID		0x48	/* Company ID for AKM */
#define AK09915_DEVICE_ID		0x10	/* Device ID for AK09915 */
#define AK09918_DEVICE_ID		0x0C	/* Device ID for AK09918 */
#define AK09915_ST1_BIT_DRDY		0x01	/* Data Ready bit */
#define AK09915_ST1_BIT_DOR		0x02	/* Data Overrun bit */
#define AK09915_ST2_BIT_HOFL		0x08	/* Magnetic Sensor Overflow bit */
#define AK09915_CNTL2_MODE_POWER_DOWN	0x00	/* Power-down mode */
#define AK09915_CNTL2_MODE_SINGLE	0x01	/* Single measurement mode */
#define AK09915_CNTL2_MODE_SELF_TEST	0x10	/* Self-test mode */
#define AK09915_CNTL3_BIT_SRST		0x01	/* Soft reset bit */
#define AK09915_DATA_SIZE		8	/* Size of data registers to read */

/* 0.15 uT resoluton to micro Gauss */
#define AK09915_RAW_TO_MICRO_GAUSS	1500

#define AK09915_MEASURE_TIME_US		8200

#define AK09915_MAX_CONVERSION_TIMEOUT_MS	50
#define AK09915_CONVERSION_DONE_POLL_TIME_MS	5

#define AK09915_MIN_FREQ_HZ			1
#define AK09915_MAX_FREQ_HZ			100
#define AK09915_DEFAULT_SAMPLING_PERIOD_NS	(NSEC_PER_SEC / 5)

/* compatibility for kernel < 4.9 */
#ifndef IIO_MOUNT_MATRIX

/**
 * struct iio_mount_matrix - iio mounting matrix
 * @rotation: 3 dimensional space rotation matrix defining sensor alignment with
 *            main hardware
 */
struct iio_mount_matrix {
	const char *rotation[9];
};

typedef const struct iio_mount_matrix *
	(iio_get_mount_matrix_t)(const struct iio_dev *indio_dev,
				 const struct iio_chan_spec *chan);

/**
 * IIO_MOUNT_MATRIX() - Initialize mount matrix extended channel attribute
 * @_shared:	Whether the attribute is shared between all channels
 * @_get:	Pointer to an iio_get_mount_matrix_t accessor
 */
#define IIO_MOUNT_MATRIX(_shared, _get) \
{ \
	.name = "mount_matrix", \
	.shared = (_shared), \
	.read = iio_show_mount_matrix, \
	.private = (uintptr_t)(_get), \
}

static const struct iio_mount_matrix iio_mount_idmatrix = {
	.rotation = {
		"1", "0", "0",
		"0", "1", "0",
		"0", "0", "1"
	}
};

static int iio_setup_mount_idmatrix(const struct device *dev,
				    struct iio_mount_matrix *matrix)
{
	*matrix = iio_mount_idmatrix;
	dev_info(dev, "mounting matrix not found: using identity...\n");
	return 0;
}

static ssize_t iio_show_mount_matrix(struct iio_dev *indio_dev, uintptr_t priv,
				     const struct iio_chan_spec *chan,
				     char *buf)
{
	const struct iio_mount_matrix *mtx = ((iio_get_mount_matrix_t *)
					      priv)(indio_dev, chan);

	if (IS_ERR(mtx))
		return PTR_ERR(mtx);

	if (!mtx)
		mtx = &iio_mount_idmatrix;

	return snprintf(buf, PAGE_SIZE, "%s, %s, %s; %s, %s, %s; %s, %s, %s\n",
			mtx->rotation[0], mtx->rotation[1], mtx->rotation[2],
			mtx->rotation[3], mtx->rotation[4], mtx->rotation[5],
			mtx->rotation[6], mtx->rotation[7], mtx->rotation[8]);
}

/**
 * of_iio_read_mount_matrix() - retrieve iio device mounting matrix from
 *                              device-tree "mount-matrix" property
 * @dev:	device the mounting matrix property is assigned to
 * @propname:	device specific mounting matrix property name
 * @matrix:	where to store retrieved matrix
 *
 * If device is assigned no mounting matrix property, a default 3x3 identity
 * matrix will be filled in.
 *
 * Return: 0 if success, or a negative error code on failure.
 */
#ifdef CONFIG_OF
int of_iio_read_mount_matrix(const struct device *dev,
			     const char *propname,
			     struct iio_mount_matrix *matrix)
{
	if (dev->of_node) {
		int err = of_property_read_string_array(dev->of_node,
				propname, matrix->rotation,
				ARRAY_SIZE(iio_mount_idmatrix.rotation));

		if (err == ARRAY_SIZE(iio_mount_idmatrix.rotation))
			return 0;

		if (err >= 0)
			/* Invalid number of matrix entries. */
			return -EINVAL;

		if (err != -EINVAL)
			/* Invalid matrix declaration format. */
			return err;
	}

	/* Matrix was not declared at all: fallback to identity. */
	return iio_setup_mount_idmatrix(dev, matrix);
}
#else
int of_iio_read_mount_matrix(const struct device *dev,
			     const char *propname,
			     struct iio_mount_matrix *matrix)
{
	return iio_setup_mount_idmatrix(dev, matrix);
}
#endif

#endif

#if LINUX_VERSION_CODE < KERNEL_VERSION(5, 1, 0)
static inline int iio_read_mount_matrix(struct device *dev, const char *propname,
					struct iio_mount_matrix *matrix)
{
	return of_iio_read_mount_matrix(dev, propname, matrix);
}
#endif

struct ak09915_data {
	struct i2c_client *client;
	struct mutex lock;
	struct regulator *vdd;
	struct regulator *vid;
	struct iio_trigger *trig;
	struct hrtimer timer;
	ktime_t period;
	spinlock_t period_lock;
	struct iio_mount_matrix orientation;
};

static const int ak09915_index_to_reg[] = {
	AK09915_REG_HXL, AK09915_REG_HYL, AK09915_REG_HZL,
};

static int ak09915_set_power(struct ak09915_data *data, bool on)
{
	int ret;

	if (on) {
		ret = regulator_enable(data->vdd);
		if (ret)
			return ret;
		ret = regulator_enable(data->vid);
		if (ret) {
			regulator_disable(data->vdd);
			return ret;
		}
		msleep(60);
	} else {
		ret = regulator_disable(data->vid);
		if (ret)
			dev_err(&data->client->dev, "error %d disabling vid", ret);
		ret = regulator_disable(data->vdd);
		if (ret)
			dev_err(&data->client->dev, "error %d disabling vdd", ret);
	}

	return 0;
}

static int ak09915_set_mode(struct ak09915_data *data, u8 mode)
{
	int ret;
	bool wait;

	/* when transitioning to power-down mode, wait at least 100µs */
	if (mode == AK09915_CNTL2_MODE_POWER_DOWN)
		wait = true;
	else
		wait = false;

	ret = i2c_smbus_write_byte_data(data->client, AK09915_REG_CNTL2, mode);
	if (ret < 0) {
		dev_err(&data->client->dev, "set mode error\n");
		return ret;
	}

	if (wait)
		usleep_range(100, 200);

	return ret;
}

static int ak09915_verify_chip_id(struct i2c_client *client)
{
	u8 wia_val[2];
	int ret;

	ret = i2c_smbus_read_i2c_block_data(client, AK09915_REG_WIA1,
					    2, wia_val);
	if (ret < 0) {
		dev_err(&client->dev, "error reading WIA\n");
		return ret;
	}

	dev_dbg(&client->dev, "WIA %02x %02x\n", wia_val[0], wia_val[1]);

	if (wia_val[0] != AK09915_COMPANY_ID ||
			(wia_val[1] != AK09915_DEVICE_ID && wia_val[1] != AK09918_DEVICE_ID)) {
		dev_err(&client->dev, "device ak0991x not found\n");
		return -ENODEV;
	}

	return 0;
}

static int wait_conversion_complete_polled(struct ak09915_data *data)
{
	struct i2c_client *client = data->client;
	u8 read_status;
	u32 timeout_ms = AK09915_MAX_CONVERSION_TIMEOUT_MS;
	int ret;

	/* Wait for the conversion to complete. */
	while (timeout_ms) {
		msleep_interruptible(AK09915_CONVERSION_DONE_POLL_TIME_MS);
		ret = i2c_smbus_read_byte_data(client, AK09915_REG_ST1);
		if (ret < 0) {
			dev_err(&client->dev, "Error in reading ST1\n");
			return ret;
		}
		read_status = ret & AK09915_ST1_BIT_DRDY;
		if (read_status)
			break;
		timeout_ms -= AK09915_CONVERSION_DONE_POLL_TIME_MS;
	}
	if (!timeout_ms) {
		dev_err(&client->dev, "conversion timeout happened\n");
		return -EIO;
	}

	return read_status;
}

static irqreturn_t ak09915_store_time(int irq, void *p)
{
	struct iio_poll_func *pf = p;

#if LINUX_VERSION_CODE < KERNEL_VERSION(5, 3, 0)
	pf->timestamp = ktime_get_boot_ns();
#else
	pf->timestamp = ktime_get_boottime_ns();
#endif
	return IRQ_WAKE_THREAD;
}

static irqreturn_t ak09915_trigger_handler(int irq, void *handle)
{
	struct iio_poll_func *pf = handle;
	struct iio_dev *indio_dev = pf->indio_dev;
	struct ak09915_data *data = iio_priv(indio_dev);
	struct i2c_client *client = data->client;
	struct {
		__le16 measures[3];
		uint8_t tmps;
		uint8_t st2;
		int64_t ts;
	} __packed buffer;
	uint8_t st1;
	int ret;

	mutex_lock(&data->lock);

	/* launch single measurement and wait */
	ret = ak09915_set_mode(data, AK09915_CNTL2_MODE_SINGLE);
	if (ret < 0)
		goto fn_exit;
	usleep_range(AK09915_MEASURE_TIME_US, AK09915_MEASURE_TIME_US + 200);

	/* read and check status */
	ret = i2c_smbus_read_byte_data(client, AK09915_REG_ST1);
	if (ret < 0) {
		dev_err(&client->dev, "status read error %d\n", ret);
		goto fn_exit;
	}
	st1 = ret;
	if (!(st1 & AK09915_ST1_BIT_DRDY)) {
		dev_err(&client->dev, "data not ready\n");
		goto fn_exit;
	}
	if (st1 & AK09915_ST1_BIT_DOR)
		dev_info(&client->dev, "data overrun\n");

	/* read data and check data status */
	ret = i2c_smbus_read_i2c_block_data(client, AK09915_REG_HXL,
					    AK09915_DATA_SIZE, (uint8_t *)&buffer);
	if (ret < 0) {
		dev_err(&client->dev, "data read error %d\n", ret);
		goto fn_exit;
	}
	if (buffer.st2 & AK09915_ST2_BIT_HOFL)
		dev_info(&client->dev, "sensor overflow\n");

	mutex_unlock(&data->lock);

	/* push to iio buffer */
	buffer.ts = pf->timestamp + AK09915_MEASURE_TIME_US * 1000LL;
	iio_push_to_buffers(indio_dev, (uint8_t *)&buffer);

	iio_trigger_notify_done(indio_dev->trig);
	return IRQ_HANDLED;

fn_exit:
	mutex_unlock(&data->lock);
	iio_trigger_notify_done(indio_dev->trig);
	return IRQ_HANDLED;
}

static enum hrtimer_restart ak09915_trig_hrtimer_handler(struct hrtimer *timer)
{
	struct ak09915_data *data = container_of(timer, struct ak09915_data,
						 timer);
	struct iio_dev *indio_dev = i2c_get_clientdata(data->client);

	hrtimer_forward_now(timer, data->period);
	iio_trigger_poll(indio_dev->trig);

	return HRTIMER_RESTART;
}

static int ak09915_trig_set_state(struct iio_trigger *trig, bool state)
{
	struct iio_dev *indio_dev = iio_trigger_get_drvdata(trig);
	struct ak09915_data *data = iio_priv(indio_dev);

	if (state) {
		hrtimer_start(&data->timer, data->period, HRTIMER_MODE_REL);
	} else {
		hrtimer_cancel(&data->timer);
		mutex_lock(&data->lock);
		ak09915_set_mode(data, AK09915_CNTL2_MODE_POWER_DOWN);
		mutex_unlock(&data->lock);
	}

	return 0;
}

static int ak09915_read_axis(struct iio_dev *indio_dev, int index, int *val)
{
	struct ak09915_data *data = iio_priv(indio_dev);
	struct i2c_client *client = data->client;
	int ret;

	mutex_lock(&data->lock);

	ret = ak09915_set_mode(data, AK09915_CNTL2_MODE_SINGLE);
	if (ret < 0)
		goto fn_exit;

	ret = wait_conversion_complete_polled(data);
	if (ret < 0)
		goto fn_exit;

	/* Read data */
	ret = i2c_smbus_read_word_data(client, ak09915_index_to_reg[index]);
	if (ret < 0) {
		dev_err(&client->dev, "Read axis data fails\n");
		goto fn_exit;
	}

	mutex_unlock(&data->lock);

	/* Clamp to valid range. */
	*val = sign_extend32(clamp_t(s16, ret, -32752, 32752), 16);

	return IIO_VAL_INT;

fn_exit:
	mutex_unlock(&data->lock);

	return ret;
}

static int ak09915_read_raw(struct iio_dev *indio_dev,
			    struct iio_chan_spec const *chan,
			    int *val, int *val2,
			    long mask)
{
	int ret;

	switch (mask) {
	case IIO_CHAN_INFO_RAW:
		mutex_lock(&indio_dev->mlock);
		if (iio_buffer_enabled(indio_dev)) {
			mutex_unlock(&indio_dev->mlock);
			return -EBUSY;
		}
		ret = ak09915_read_axis(indio_dev, chan->address, val);
		mutex_unlock(&indio_dev->mlock);
		return ret;
	case IIO_CHAN_INFO_SCALE:
		*val = 0;
		*val2 = AK09915_RAW_TO_MICRO_GAUSS;
		return IIO_VAL_INT_PLUS_MICRO;
	}

	return -EINVAL;
}

static const struct iio_mount_matrix *
ak09915_get_mount_matrix(const struct iio_dev *indio_dev,
			 const struct iio_chan_spec *chan)
{
	return &((struct ak09915_data *)iio_priv(indio_dev))->orientation;
}

static const struct iio_chan_spec_ext_info ak09915_ext_info[] = {
	IIO_MOUNT_MATRIX(IIO_SHARED_BY_DIR, ak09915_get_mount_matrix),
	{ },
};

static ssize_t ak09915_period_show(struct device *dev,
				   struct device_attribute *attr, char *buf)
{
	struct ak09915_data *data = iio_priv(dev_to_iio_dev(dev));
	ktime_t period;
	unsigned long freq;

	spin_lock(&data->period_lock);
	period = data->period;
	spin_unlock(&data->period_lock);
	/* maximum period is 1s = 1000000000ns, 32 bits sufficient */
	freq = (uint32_t)NSEC_PER_SEC / (uint32_t)ktime_to_ns(period);

	return scnprintf(buf, PAGE_SIZE, "%lu\n", freq);
}

static ssize_t ak09915_period_store(struct device *dev,
				    struct device_attribute *attr,
				    const char *buf, size_t count)
{
	struct iio_dev *indio_dev = dev_to_iio_dev(dev);
	struct ak09915_data *data = iio_priv(indio_dev);
	unsigned int sampling_frequency;
	ktime_t period;

	if (kstrtouint(buf, 10, &sampling_frequency))
		return -EINVAL;
	if (sampling_frequency < AK09915_MIN_FREQ_HZ ||
			sampling_frequency > AK09915_MAX_FREQ_HZ)
		return -EINVAL;

	period = ns_to_ktime(NSEC_PER_SEC / sampling_frequency);

	mutex_lock(&indio_dev->mlock);

	if (iio_buffer_enabled(indio_dev))
		hrtimer_cancel(&data->timer);

	spin_lock(&data->period_lock);
	data->period = period;
	spin_unlock(&data->period_lock);

	if (iio_buffer_enabled(indio_dev))
		hrtimer_start(&data->timer, period, HRTIMER_MODE_REL);

	mutex_unlock(&indio_dev->mlock);

	return count;
}

static IIO_DEV_ATTR_SAMP_FREQ(0644, ak09915_period_show, ak09915_period_store);

static struct attribute *ak09915_attributes[] = {
	&iio_dev_attr_sampling_frequency.dev_attr.attr,
	NULL,
};

static const struct attribute_group ak09915_attribute_group = {
	.attrs = ak09915_attributes,
};

static const struct iio_info ak09915_info = {
	.read_raw = &ak09915_read_raw,
	.attrs = &ak09915_attribute_group,
#if LINUX_VERSION_CODE < KERNEL_VERSION(4, 15, 0)
	.driver_module = THIS_MODULE,
#endif
};

static const struct iio_trigger_ops ak09915_trigger_ops = {
#if LINUX_VERSION_CODE < KERNEL_VERSION(4, 15, 0)
	.owner = THIS_MODULE,
#endif
	.set_trigger_state = ak09915_trig_set_state,
};

#define AK09915_CHANNEL_MAG(modifier, index)				\
	{								\
		.type = IIO_MAGN,					\
		.modified = 1,						\
		.channel2 = modifier,					\
		.info_mask_separate = BIT(IIO_CHAN_INFO_RAW) |		\
				BIT(IIO_CHAN_INFO_SCALE),		\
		.address = index,					\
		.scan_index = index,					\
		.scan_type = {						\
			.sign = 's',					\
			.realbits = 16,					\
			.storagebits = 16,				\
			.shift = 0,					\
			.endianness = IIO_LE,				\
		},							\
		.ext_info = ak09915_ext_info,				\
	}

static const struct iio_chan_spec ak09915_channels[] = {
	AK09915_CHANNEL_MAG(IIO_MOD_X, 0),
	AK09915_CHANNEL_MAG(IIO_MOD_Y, 1),
	AK09915_CHANNEL_MAG(IIO_MOD_Z, 2),
	IIO_CHAN_SOFT_TIMESTAMP(3),
};

static int ak09915_probe(struct i2c_client *client,
			 const struct i2c_device_id *id)
{
	struct iio_dev *indio_dev;
	struct ak09915_data *data;
	int ret;

#if LINUX_VERSION_CODE < KERNEL_VERSION(5, 9, 0)
	indio_dev = iio_device_alloc(sizeof(*data));
#else
	indio_dev = iio_device_alloc(&client->dev, sizeof(*data));
#endif
	if (indio_dev == NULL)
		return -ENOMEM;

	indio_dev->dev.parent = &client->dev;
	indio_dev->name = id->name;
	indio_dev->channels = ak09915_channels;
	indio_dev->num_channels = ARRAY_SIZE(ak09915_channels);
	indio_dev->info = &ak09915_info;
	i2c_set_clientdata(client, indio_dev);

	data = iio_priv(indio_dev);
	data->client = client;
	mutex_init(&data->lock);
	hrtimer_init(&data->timer, CLOCK_BOOTTIME, HRTIMER_MODE_REL);
	data->timer.function = ak09915_trig_hrtimer_handler;
	data->period = ns_to_ktime(AK09915_DEFAULT_SAMPLING_PERIOD_NS);
	spin_lock_init(&data->period_lock);

	data->vdd = regulator_get(&client->dev, "vdd");
	if (IS_ERR(data->vdd)) {
		ret = PTR_ERR(data->vdd);
		goto error_free_device;
	}

	data->vid = regulator_get(&client->dev, "vid");
	if (IS_ERR(data->vid)) {
		ret = PTR_ERR(data->vid);
		goto error_free_regulator_vdd;
	}

	ret = ak09915_set_power(data, true);
	if (ret)
		goto error_free_regulators;

	ret = ak09915_verify_chip_id(client);
	if (ret)
		goto error_free_power_off;

	ret = iio_read_mount_matrix(&client->dev,
#if LINUX_VERSION_CODE < KERNEL_VERSION(5, 14, 0)
				    "mount-matrix",
#endif
				    &data->orientation);
	if (ret)
		goto error_free_power_off;

	ret = iio_triggered_buffer_setup(indio_dev, ak09915_store_time,
					 ak09915_trigger_handler, NULL);
	if (ret) {
		dev_err(&client->dev, "iio triggered buffer error %d\n", ret);
		goto error_free_power_off;
	}

	data->trig = iio_trigger_alloc(
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 13, 0)
				       &client->dev,
#endif
				       "%s-hrtimer%d", indio_dev->name,
#if LINUX_VERSION_CODE < KERNEL_VERSION(5, 14, 0)
				       indio_dev->id);
#else
				       iio_device_id(indio_dev));
#endif
	if (data->trig == NULL) {
		ret = -ENOMEM;
		dev_err(&client->dev, "iio trigger alloc error\n");
		goto error_free_buffer;
	}
	data->trig->dev.parent = &client->dev;
	data->trig->ops = &ak09915_trigger_ops;
	iio_trigger_set_drvdata(data->trig, indio_dev);

	ret = iio_trigger_register(data->trig);
	if (ret) {
		dev_err(&client->dev, "iio trigger register error %d\n", ret);
		goto error_free_trigger;
	}
	iio_trigger_get(data->trig);
	indio_dev->trig = data->trig;

	ret = iio_device_register(indio_dev);
	if (ret) {
		dev_err(&client->dev, "iio device register error %d\n", ret);
		goto error_unregister_trigger;
	}

	return 0;

error_unregister_trigger:
	iio_trigger_unregister(data->trig);
error_free_trigger:
	iio_trigger_free(data->trig);
error_free_buffer:
	iio_triggered_buffer_cleanup(indio_dev);
error_free_power_off:
	ak09915_set_power(data, false);
error_free_regulators:
	regulator_put(data->vid);
error_free_regulator_vdd:
	regulator_put(data->vdd);
error_free_device:
	iio_device_free(indio_dev);
	return ret;
}

static int ak09915_remove(struct i2c_client *client)
{
	struct iio_dev *indio_dev = i2c_get_clientdata(client);
	struct ak09915_data *data = iio_priv(indio_dev);

	iio_device_unregister(indio_dev);
	iio_trigger_unregister(data->trig);
	iio_trigger_free(data->trig);
	iio_triggered_buffer_cleanup(indio_dev);
	ak09915_set_power(data, false);
	regulator_put(data->vid);
	regulator_put(data->vdd);
	iio_device_free(indio_dev);

	return 0;
}

#ifdef CONFIG_PM_SLEEP
static int ak09915_suspend(struct device *dev)
{
	struct iio_dev *indio_dev = i2c_get_clientdata(to_i2c_client(dev));
	struct ak09915_data *data = iio_priv(indio_dev);

	mutex_lock(&indio_dev->mlock);
	if (iio_buffer_enabled(indio_dev))
		ak09915_trig_set_state(data->trig, false);
	mutex_unlock(&indio_dev->mlock);

	ak09915_set_power(data, false);

	return 0;
}

static int ak09915_resume(struct device *dev)
{
	struct iio_dev *indio_dev = i2c_get_clientdata(to_i2c_client(dev));
	struct ak09915_data *data = iio_priv(indio_dev);
	int ret;

	ret = ak09915_set_power(data, true);
	if (ret)
		return ret;

	mutex_lock(&indio_dev->mlock);
	if (iio_buffer_enabled(indio_dev))
		ak09915_trig_set_state(data->trig, true);
	mutex_unlock(&indio_dev->mlock);

	return 0;
}
#endif

static UNIVERSAL_DEV_PM_OPS(ak09915_pm, ak09915_suspend, ak09915_resume, NULL);

static const struct i2c_device_id ak09915_id[] = {
	{"ak09915", 0},
	{"ak09918", 0},
	{}
};
MODULE_DEVICE_TABLE(i2c, ak09915_id);

static const struct of_device_id ak09915_of_match[] = {
	{ .compatible = "asahi-kasei,ak09915", },
	{ .compatible = "asahi-kasei,ak09918", },
	{}
};
MODULE_DEVICE_TABLE(of, ak09915_of_match);

static struct i2c_driver ak09915_driver = {
	.driver = {
		.name = "ak09915",
		.pm = &ak09915_pm,
		.of_match_table = of_match_ptr(ak09915_of_match),
	},
	.probe = ak09915_probe,
	.remove = ak09915_remove,
	.id_table = ak09915_id,
};
module_i2c_driver(ak09915_driver);

MODULE_AUTHOR("Jean-Baptiste Maneyrol <jean-baptiste.maneyrol@tdk.com>");
MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("AK09915 Compass driver");
