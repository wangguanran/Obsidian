# SPDX-License-Identifier: GPL-2.0
# !/bin/bash
KERNEL_SRC="${ROOT_DIR}/${KERNEL_DIR}"
CONFIG_FILE="arch/${ARCH}/configs/${DEFCONFIG}"
DTS_FILE="arch/${ARCH}/boot/dts/${DTS}"

BASE_DIR=$(dirname "${0}")/..
PATCHES_DIR="${BASE_DIR}/patches/${TARGET_KERNEL_USE}"
CONFIG_DIR="${BASE_DIR}/config"
DTS_DIR="${BASE_DIR}/dts"

# Apply kernel patches
[ ! -d "${KERNEL_SRC}" ] && exit 1
[ ! -f "${PATCHES_DIR}"/*.patch ] || git -C "${KERNEL_SRC}" apply "${PATCHES_DIR}"/*.patch || exit $?

# Add required kernel and chips configuration
cat "${CONFIG_DIR}/kernel.cfg" >> "${KERNEL_SRC}/${CONFIG_FILE}" || exit $?
cat "${CONFIG_DIR}/${INVENSENSE_CHIP}.cfg" >> "${KERNEL_SRC}/${CONFIG_FILE}" || exit $?
for _chip in ${INVENSENSE_SENSORS}
do
	cat "${CONFIG_DIR}/${_chip}.cfg" >> "${KERNEL_SRC}/${CONFIG_FILE}" || exit $?
done

# Add DTS file for device, chip and sensors
[ ! -f "${KERNEL_SRC}/${DTS_FILE}" ] && exit 0
DTS_PATH="${KERNEL_SRC}"/$(dirname "${DTS_FILE}")/invensense
mkdir -p "${DTS_PATH}"
cp -r "${DTS_DIR}"/* "${DTS_PATH}"
cat >> "${KERNEL_SRC}/${DTS_FILE}" << EOF
#include "invensense/device/${TARGET_PRODUCT}-bus.dtsi"
#include "invensense/${INVENSENSE_CHIP}.dtsi"
#include "invensense/device/${TARGET_PRODUCT}-int.dtsi"
EOF
for _chip in ${INVENSENSE_SENSORS}
do
cat >> "${KERNEL_SRC}/${DTS_FILE}" << EOF
#include "invensense/${_chip}.dtsi"
EOF
done
for _aux in ${INVENSENSE_AUX_SENSORS}
do
cat >> "${KERNEL_SRC}/${DTS_FILE}" << EOF
#include "invensense/aux/${_aux}.dtsi"
EOF
done
