/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein
 * is confidential and proprietary to MediaTek Inc. and/or its licensors.
 * Without the prior written permission of MediaTek inc. and/or its licensors,
 * any reproduction, modification, use or disclosure of MediaTek Software,
 * and information contained herein, in whole or in part, shall be strictly prohibited.
 */
/* MediaTek Inc. (C) 2020. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER ON
 * AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 * NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 * SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 * SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES TO LOOK ONLY TO SUCH
 * THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. RECEIVER EXPRESSLY ACKNOWLEDGES
 * THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES
 * CONTAINED IN MEDIATEK SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK
 * SOFTWARE RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND
 * CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE,
 * AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE MEDIATEK SOFTWARE AT ISSUE,
 * OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY RECEIVER TO
 * MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek Software")
 * have been modified by MediaTek Inc. All revisions are subject to any receiver's
 * applicable license agreements with MediaTek Inc.
 */

/********************************************************************************************
 *     LEGAL DISCLAIMER
 *
 *     (Header of MediaTek Software/Firmware Release or Documentation)
 *
 *     BY OPENING OR USING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *     THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE") RECEIVED
 *     FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON AN "AS-IS" BASIS
 *     ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES, EXPRESS OR IMPLIED,
 *     INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 *     A PARTICULAR PURPOSE OR NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY
 *     WHATSOEVER WITH RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 *     INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND BUYER AGREES TO LOOK
 *     ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. MEDIATEK SHALL ALSO
 *     NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE RELEASES MADE TO BUYER'S SPECIFICATION
 *     OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *     BUYER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND CUMULATIVE LIABILITY WITH
 *     RESPECT TO THE MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION,
 *     TO REVISE OR REPLACE THE MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE
 *     FEES OR SERVICE CHARGE PAID BY BUYER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 *     THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE WITH THE LAWS
 *     OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF LAWS PRINCIPLES.
 ************************************************************************************************/
#include "camera_custom_nvram.h"
#include "gc13a0mipiraw_Face_Capture.h"

const ISP_NVRAM_MULTI_CCM_STRUCT gc13a0mipiraw_CCM_0006 = {
        .CCM_CT_valid_NUM = 5,
    .CCM_Coef = {1, 2, 2},
    .CCM_Reg=
    {
        {.set={//CT_00
            0x1FAC0200, 0x00000054, 0x029C1F33, 0x00000031, 0x1CC01F50, 0x000005F0
        }},
        {.set={//CT_01
            0x1FD002A1, 0x00001F8F, 0x03521F0E, 0x00001FA0, 0x1DF91F6B, 0x0000049C
        }},
        {.set={//CT_02
            0x1EC803AA, 0x00001F8E, 0x03171F62, 0x00001F87, 0x1E4E1FE4, 0x000003CE
        }},
        {.set={//CT_03
            0x1EE90377, 0x00001FA0, 0x03081F68, 0x00001F90, 0x1E6F1FEF, 0x000003A2
        }},
        {.set={//CT_04
            0x1EBD0383, 0x00001FC0, 0x032E1F9D, 0x00001F35, 0x1EB3000A, 0x00000343
        }},
        {.set={//CT_05
            0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000
        }},
        {.set={//CT_06
            0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000
        }},
        {.set={//CT_07
            0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000
        }},
        {.set={//CT_08
            0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000
        }},
        {.set={//CT_09
            0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000
        }}
    },
    .AWBGain=
    {
        {//CT_00
            439,  // i4R
            512,  // i4G
            1441  // i4B
        },
        {//CT_01
            550,  // i4R
            512,  // i4G
            1199  // i4B
        },
        {//CT_02
            772,  // i4R
            512,  // i4G
            1112  // i4B
        },
        {//CT_03
            753,  // i4R
            512,  // i4G
            1080  // i4B
        },
        {//CT_04
            948,  // i4R
            512,  // i4G
            727  // i4B
        },
        {//CT_05
            512,  // i4R
            512,  // i4G
            512  // i4B
        },
        {//CT_06
            512,  // i4R
            512,  // i4G
            512  // i4B
        },
        {//CT_07
            512,  // i4R
            512,  // i4G
            512  // i4B
        },
        {//CT_08
            512,  // i4R
            512,  // i4G
            512  // i4B
        },
        {//CT_09
            512,  // i4R
            512,  // i4G
            512  // i4B
        }
    },

};
const ISP_NVRAM_MULTI_CCM_STRUCT gc13a0mipiraw_CCM_0007 = {
        .CCM_CT_valid_NUM = 5,
    .CCM_Coef = {1, 2, 2},
    .CCM_Reg=
    {
        {.set={//CT_00
            0x1F930280, 0x00001FED, 0x02951F37, 0x00000034, 0x1D821FA3, 0x000004DB
        }},
        {.set={//CT_01
            0x1F4202DB, 0x00001FE3, 0x02B51F5E, 0x00001FED, 0x1E471FED, 0x000003CC
        }},
        {.set={//CT_02
            0x1F02031D, 0x00001FE1, 0x02931F91, 0x00001FDC, 0x1EEF000C, 0x00000305
        }},
        {.set={//CT_03
            0x1F4602DE, 0x00001FDC, 0x02891F8A, 0x00001FED, 0x1F0A0007, 0x000002EF
        }},
        {.set={//CT_04
            0x1EE5031F, 0x00001FFC, 0x02C61FB6, 0x00001F84, 0x1F0A0013, 0x000002E3
        }},
        {.set={//CT_05
            0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000
        }},
        {.set={//CT_06
            0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000
        }},
        {.set={//CT_07
            0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000
        }},
        {.set={//CT_08
            0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000
        }},
        {.set={//CT_09
            0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000
        }}
    },
    .AWBGain=
    {
        {//CT_00
            476,  // i4R
            512,  // i4G
            1982  // i4B
        },
        {//CT_01
            617,  // i4R
            512,  // i4G
            1554  // i4B
        },
        {//CT_02
            861,  // i4R
            512,  // i4G
            1300  // i4B
        },
        {//CT_03
            837,  // i4R
            512,  // i4G
            1256  // i4B
        },
        {//CT_04
            1143,  // i4R
            512,  // i4G
            778  // i4B
        },
        {//CT_05
            512,  // i4R
            512,  // i4G
            512  // i4B
        },
        {//CT_06
            512,  // i4R
            512,  // i4G
            512  // i4B
        },
        {//CT_07
            512,  // i4R
            512,  // i4G
            512  // i4B
        },
        {//CT_08
            512,  // i4R
            512,  // i4G
            512  // i4B
        },
        {//CT_09
            512,  // i4R
            512,  // i4G
            512  // i4B
        }
    },

};
const ISP_NVRAM_MULTI_CCM_STRUCT gc13a0mipiraw_CCM_0008 = {
        .CCM_CT_valid_NUM = 5,
    .CCM_Coef = {1, 2, 2},
    .CCM_Reg=
    {
        {.set={//CT_00
            0x1FA40282, 0x00001FDA, 0x02C11F23, 0x0000001C, 0x1D911F92, 0x000004DD
        }},
        {.set={//CT_01
            0x1F5D02DD, 0x00001FC6, 0x02D11F4D, 0x00001FE2, 0x1E251FEC, 0x000003EF
        }},
        {.set={//CT_02
            0x1EEC0338, 0x00001FDC, 0x02BB1F79, 0x00001FCC, 0x1EDF0005, 0x0000031C
        }},
        {.set={//CT_03
            0x1F220327, 0x00001FB7, 0x02B11F7E, 0x00001FD1, 0x1EE80004, 0x00000314
        }},
        {.set={//CT_04
            0x1F0E0330, 0x00001FC2, 0x02E91FA3, 0x00001F74, 0x1F000007, 0x000002F9
        }},
        {.set={//CT_05
            0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000
        }},
        {.set={//CT_06
            0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000
        }},
        {.set={//CT_07
            0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000
        }},
        {.set={//CT_08
            0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000
        }},
        {.set={//CT_09
            0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000
        }}
    },
    .AWBGain=
    {
        {//CT_00
            477,  // i4R
            512,  // i4G
            1982  // i4B
        },
        {//CT_01
            617,  // i4R
            512,  // i4G
            1555  // i4B
        },
        {//CT_02
            861,  // i4R
            512,  // i4G
            1300  // i4B
        },
        {//CT_03
            837,  // i4R
            512,  // i4G
            1256  // i4B
        },
        {//CT_04
            1142,  // i4R
            512,  // i4G
            777  // i4B
        },
        {//CT_05
            512,  // i4R
            512,  // i4G
            512  // i4B
        },
        {//CT_06
            512,  // i4R
            512,  // i4G
            512  // i4B
        },
        {//CT_07
            512,  // i4R
            512,  // i4G
            512  // i4B
        },
        {//CT_08
            512,  // i4R
            512,  // i4G
            512  // i4B
        },
        {//CT_09
            512,  // i4R
            512,  // i4G
            512  // i4B
        }
    },

};
const ISP_NVRAM_MULTI_CCM_STRUCT gc13a0mipiraw_CCM_0009 = {
        .CCM_CT_valid_NUM = 5,
    .CCM_Coef = {1, 2, 2},
    .CCM_Reg=
    {
        {.set={//CT_00
            0x1F7F0309, 0x00001F78, 0x02AD1F36, 0x0000001D, 0x1D321FA5, 0x00000529
        }},
        {.set={//CT_01
            0x1EF70306, 0x00000003, 0x02AE1F45, 0x0000000D, 0x1D4B1FF3, 0x000004C2
        }},
        {.set={//CT_02
            0x1EEE0359, 0x00001FB9, 0x02DD1F62, 0x00001FC1, 0x1EBE0004, 0x0000033E
        }},
        {.set={//CT_03
            0x1F0C0335, 0x00001FBF, 0x02CC1F6E, 0x00001FC6, 0x1ED80004, 0x00000324
        }},
        {.set={//CT_04
            0x1EC90381, 0x00001FB6, 0x031B1FA3, 0x00001F42, 0x1EDC0014, 0x00000310
        }},
        {.set={//CT_05
            0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000
        }},
        {.set={//CT_06
            0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000
        }},
        {.set={//CT_07
            0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000
        }},
        {.set={//CT_08
            0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000
        }},
        {.set={//CT_09
            0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000
        }}
    },
    .AWBGain=
    {
        {//CT_00
            476,  // i4R
            512,  // i4G
            1982  // i4B
        },
        {//CT_01
            617,  // i4R
            512,  // i4G
            1553  // i4B
        },
        {//CT_02
            861,  // i4R
            512,  // i4G
            1300  // i4B
        },
        {//CT_03
            837,  // i4R
            512,  // i4G
            1257  // i4B
        },
        {//CT_04
            1142,  // i4R
            512,  // i4G
            777  // i4B
        },
        {//CT_05
            512,  // i4R
            512,  // i4G
            512  // i4B
        },
        {//CT_06
            512,  // i4R
            512,  // i4G
            512  // i4B
        },
        {//CT_07
            512,  // i4R
            512,  // i4G
            512  // i4B
        },
        {//CT_08
            512,  // i4R
            512,  // i4G
            512  // i4B
        },
        {//CT_09
            512,  // i4R
            512,  // i4G
            512  // i4B
        }
    },

};
const ISP_NVRAM_MULTI_CCM_STRUCT gc13a0mipiraw_CCM_0010 = {
        .CCM_CT_valid_NUM = 5,
    .CCM_Coef = {1, 2, 2},
    .CCM_Reg=
    {
        {.set={//CT_00
            0x1F5102D1, 0x00001FDE, 0x02BE1F20, 0x00000022, 0x1C2C1FB5, 0x0000061F
        }},
        {.set={//CT_01
            0x1F06033E, 0x00001FBC, 0x032E1F26, 0x00001FAC, 0x1DDB1FDC, 0x00000449
        }},
        {.set={//CT_02
            0x1EC70366, 0x00001FD3, 0x02C41F69, 0x00001FD3, 0x1EA90005, 0x00000352
        }},
        {.set={//CT_03
            0x1EFC0346, 0x00001FBE, 0x02BC1F6E, 0x00001FD6, 0x1ED31FFF, 0x0000032E
        }},
        {.set={//CT_04
            0x1EA80371, 0x00001FE7, 0x02F21F9F, 0x00001F6F, 0x1ECC000D, 0x00000327
        }},
        {.set={//CT_05
            0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000
        }},
        {.set={//CT_06
            0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000
        }},
        {.set={//CT_07
            0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000
        }},
        {.set={//CT_08
            0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000
        }},
        {.set={//CT_09
            0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000
        }}
    },
    .AWBGain=
    {
        {//CT_00
            477,  // i4R
            512,  // i4G
            1982  // i4B
        },
        {//CT_01
            617,  // i4R
            512,  // i4G
            1553  // i4B
        },
        {//CT_02
            861,  // i4R
            512,  // i4G
            1300  // i4B
        },
        {//CT_03
            836,  // i4R
            512,  // i4G
            1256  // i4B
        },
        {//CT_04
            1142,  // i4R
            512,  // i4G
            777  // i4B
        },
        {//CT_05
            512,  // i4R
            512,  // i4G
            512  // i4B
        },
        {//CT_06
            512,  // i4R
            512,  // i4G
            512  // i4B
        },
        {//CT_07
            512,  // i4R
            512,  // i4G
            512  // i4B
        },
        {//CT_08
            512,  // i4R
            512,  // i4G
            512  // i4B
        },
        {//CT_09
            512,  // i4R
            512,  // i4G
            512  // i4B
        }
    },

};
const ISP_NVRAM_MULTI_CCM_STRUCT gc13a0mipiraw_CCM_0011 = {
        .CCM_CT_valid_NUM = 5,
    .CCM_Coef = {1, 2, 2},
    .CCM_Reg=
    {
        {.set={//CT_00
            0x1E86039E, 0x00001FDC, 0x02711F56, 0x00000039, 0x1BD61FD2, 0x00000658
        }},
        {.set={//CT_01
            0x1E6A03D7, 0x00001FBF, 0x02BB1F59, 0x00001FEC, 0x1CB60026, 0x00000524
        }},
        {.set={//CT_02
            0x1E7603B0, 0x00001FDA, 0x02CD1F6B, 0x00001FC8, 0x1E530012, 0x0000039B
        }},
        {.set={//CT_03
            0x1EBF0370, 0x00001FD1, 0x02E61F5B, 0x00001FBF, 0x1EAD1FFF, 0x00000354
        }},
        {.set={//CT_04
            0x1EB1039A, 0x00001FB5, 0x03161F9C, 0x00001F4E, 0x1EC0000D, 0x00000333
        }},
        {.set={//CT_05
            0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000
        }},
        {.set={//CT_06
            0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000
        }},
        {.set={//CT_07
            0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000
        }},
        {.set={//CT_08
            0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000
        }},
        {.set={//CT_09
            0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000, 0x00000000
        }}
    },
    .AWBGain=
    {
        {//CT_00
            477,  // i4R
            512,  // i4G
            1984  // i4B
        },
        {//CT_01
            617,  // i4R
            512,  // i4G
            1553  // i4B
        },
        {//CT_02
            861,  // i4R
            512,  // i4G
            1300  // i4B
        },
        {//CT_03
            836,  // i4R
            512,  // i4G
            1256  // i4B
        },
        {//CT_04
            1142,  // i4R
            512,  // i4G
            778  // i4B
        },
        {//CT_05
            512,  // i4R
            512,  // i4G
            512  // i4B
        },
        {//CT_06
            512,  // i4R
            512,  // i4G
            512  // i4B
        },
        {//CT_07
            512,  // i4R
            512,  // i4G
            512  // i4B
        },
        {//CT_08
            512,  // i4R
            512,  // i4G
            512  // i4B
        },
        {//CT_09
            512,  // i4R
            512,  // i4G
            512  // i4B
        }
    },

};
