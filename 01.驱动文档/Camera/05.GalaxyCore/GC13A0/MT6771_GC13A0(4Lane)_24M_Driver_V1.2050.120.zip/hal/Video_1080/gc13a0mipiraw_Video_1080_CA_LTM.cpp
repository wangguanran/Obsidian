/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein
 * is confidential and proprietary to MediaTek Inc. and/or its licensors.
 * Without the prior written permission of MediaTek inc. and/or its licensors,
 * any reproduction, modification, use or disclosure of MediaTek Software,
 * and information contained herein, in whole or in part, shall be strictly prohibited.
 */
/* MediaTek Inc. (C) 2019. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER ON
 * AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 * NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 * SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 * SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES TO LOOK ONLY TO SUCH
 * THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. RECEIVER EXPRESSLY ACKNOWLEDGES
 * THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES
 * CONTAINED IN MEDIATEK SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK
 * SOFTWARE RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND
 * CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE,
 * AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE MEDIATEK SOFTWARE AT ISSUE,
 * OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY RECEIVER TO
 * MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek Software")
 * have been modified by MediaTek Inc. All revisions are subject to any receiver's
 * applicable license agreements with MediaTek Inc.
 */

/********************************************************************************************
 *     LEGAL DISCLAIMER
 *
 *     (Header of MediaTek Software/Firmware Release or Documentation)
 *
 *     BY OPENING OR USING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *     THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE") RECEIVED
 *     FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON AN "AS-IS" BASIS
 *     ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES, EXPRESS OR IMPLIED,
 *     INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 *     A PARTICULAR PURPOSE OR NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY
 *     WHATSOEVER WITH RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 *     INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND BUYER AGREES TO LOOK
 *     ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. MEDIATEK SHALL ALSO
 *     NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE RELEASES MADE TO BUYER'S SPECIFICATION
 *     OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *     BUYER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND CUMULATIVE LIABILITY WITH
 *     RESPECT TO THE MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION,
 *     TO REVISE OR REPLACE THE MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE
 *     FEES OR SERVICE CHARGE PAID BY BUYER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 *     THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE WITH THE LAWS
 *     OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF LAWS PRINCIPLES.
 ************************************************************************************************/
#include "camera_custom_nvram.h"
#include "gc13a0mipiraw_Video_1080.h"

const FEATURE_NVRAM_CA_LTM_T gc13a0mipiraw_CA_LTM_0002 = {
        .ISO = {
10,0,100,200,400,800,1200,2400,4800,9600,96000,0,0,0,0,0    },
    .LV = {
1,20,2,5,10,15,0,0,0,0,0,0,0,0,0,0    },
    .CA_LTM_ALLTUNINGREG =
    {
        { //0
            // CA_LTM_INITUNINGRE
            {
                24,  // ca_ltm_s_lower
                32,  // ca_ltm_s_upper
                48,  // ca_ltm_y_lower
                176,  // ca_ltm_y_upper
                88,  // ca_ltm_h_lower
                88,  // ca_ltm_h_upper
                1,  // ca_ltm_max_hist_mode
                2,  // ca_ltm_bitplus_contour_range_th
                64,  // ca_ltm_bitplus_contour_range_slope
                3,  // ca_ltm_bitplus_diff_count_th
                42,  // ca_ltm_bitplus_diff_count_slope
                0,  // ca_ltm_bitplus_pxl_diff_th
                64,  // ca_ltm_bitplus_pxl_diff_slope
                0,  // ca_ltm_pxl_diff_th_for_flat_pxl
                128,  // ca_ltm_pxl_diff_slope_for_flat_pxl
                0,  // ca_ltm_pxl_diff_th
                16  // ca_ltm_pxl_diff_slope
            },
            // CA_LTM_TUNINGREG
            {
                1,  // ca_ltm_fw_en
                1,  // ca_ltm_curve_en
                1,  // ca_ltm_gain_flt_en
                1,  // ca_ltm_iir_force_range
                20,  // bADLWeight1
                44,  // bADLWeight2
                0,  // bADLWeight3
                16,  // bBSDCGain
                128,  // bBSACGain
                0,  // bBSLevel
                16,  // bMIDDCGain
                64,  // bMIDACGain
                16,  // bWSDCGain
                128,  // bWSACGain
                0,  // bWSLevel
                0,  // ca_ltm_dync_spike_wgt_min
                255,  // ca_ltm_dync_spike_wgt_max
                144,  // ca_ltm_dync_spike_th
                64,  // ca_ltm_dync_spike_slope
                2,  // bSpikeBlendmethod
                72,  // bSkinWgtSlope
                2,  // bSkinBlendmethod
                8,  // ca_ltm_dync_flt_coef_min
                32,  // ca_ltm_dync_flt_coef_max
                4,  // ca_ltm_dync_flt_ovr_pxl_th
                50,  // ca_ltm_dync_flt_ovr_pxl_slope
                0,  // LLPValue
                0,  // LLPRatio
                255,  // APLCompRatioLow
                255,  // APLCompRatioHigh
                300,  // FltConfSlope
                0,  // FltConfTh
                3,  // BlkHistCountRatio
                224,  // BinIdxDiffSlope
                0,  // BinIdxDiffTh
                32,  // BinIdxDiffWgtOft
                16,  // APLTh
                128,  // APLSlope
                256,  // APLWgtOft
                16,  // APL2Th
                128,  // APL2Slope
                256,  // APL2WgtOft
                256,  // APL2WgtMax
                1,  // BlkSpaFltEn
                1,  // BlkSpaFltType
                0,  // LoadBlkCurveEn
                0  // SaveBlkCurveEn
            },
            // CA_LTM_ADAPTTUNINGREG
            {
                1,  // Enabled
                255,  // Strength
                0,  // AdaptiveMethod
                0,  // AdaptiveType
                0  // CustomParametersSearchMode
            }
        },
        { //1
            // CA_LTM_INITUNINGRE
            {
                24,  // ca_ltm_s_lower
                32,  // ca_ltm_s_upper
                48,  // ca_ltm_y_lower
                176,  // ca_ltm_y_upper
                88,  // ca_ltm_h_lower
                88,  // ca_ltm_h_upper
                1,  // ca_ltm_max_hist_mode
                2,  // ca_ltm_bitplus_contour_range_th
                64,  // ca_ltm_bitplus_contour_range_slope
                3,  // ca_ltm_bitplus_diff_count_th
                42,  // ca_ltm_bitplus_diff_count_slope
                0,  // ca_ltm_bitplus_pxl_diff_th
                64,  // ca_ltm_bitplus_pxl_diff_slope
                0,  // ca_ltm_pxl_diff_th_for_flat_pxl
                128,  // ca_ltm_pxl_diff_slope_for_flat_pxl
                0,  // ca_ltm_pxl_diff_th
                16  // ca_ltm_pxl_diff_slope
            },
            // CA_LTM_TUNINGREG
            {
                1,  // ca_ltm_fw_en
                1,  // ca_ltm_curve_en
                1,  // ca_ltm_gain_flt_en
                1,  // ca_ltm_iir_force_range
                20,  // bADLWeight1
                44,  // bADLWeight2
                0,  // bADLWeight3
                16,  // bBSDCGain
                128,  // bBSACGain
                0,  // bBSLevel
                16,  // bMIDDCGain
                64,  // bMIDACGain
                16,  // bWSDCGain
                128,  // bWSACGain
                0,  // bWSLevel
                0,  // ca_ltm_dync_spike_wgt_min
                255,  // ca_ltm_dync_spike_wgt_max
                144,  // ca_ltm_dync_spike_th
                64,  // ca_ltm_dync_spike_slope
                2,  // bSpikeBlendmethod
                72,  // bSkinWgtSlope
                2,  // bSkinBlendmethod
                8,  // ca_ltm_dync_flt_coef_min
                32,  // ca_ltm_dync_flt_coef_max
                4,  // ca_ltm_dync_flt_ovr_pxl_th
                50,  // ca_ltm_dync_flt_ovr_pxl_slope
                0,  // LLPValue
                0,  // LLPRatio
                255,  // APLCompRatioLow
                255,  // APLCompRatioHigh
                300,  // FltConfSlope
                0,  // FltConfTh
                3,  // BlkHistCountRatio
                224,  // BinIdxDiffSlope
                0,  // BinIdxDiffTh
                32,  // BinIdxDiffWgtOft
                16,  // APLTh
                128,  // APLSlope
                256,  // APLWgtOft
                16,  // APL2Th
                128,  // APL2Slope
                256,  // APL2WgtOft
                256,  // APL2WgtMax
                1,  // BlkSpaFltEn
                1,  // BlkSpaFltType
                0,  // LoadBlkCurveEn
                0  // SaveBlkCurveEn
            },
            // CA_LTM_ADAPTTUNINGREG
            {
                1,  // Enabled
                255,  // Strength
                0,  // AdaptiveMethod
                0,  // AdaptiveType
                0  // CustomParametersSearchMode
            }
        },
        { //2
            // CA_LTM_INITUNINGRE
            {
                24,  // ca_ltm_s_lower
                32,  // ca_ltm_s_upper
                48,  // ca_ltm_y_lower
                176,  // ca_ltm_y_upper
                88,  // ca_ltm_h_lower
                88,  // ca_ltm_h_upper
                1,  // ca_ltm_max_hist_mode
                2,  // ca_ltm_bitplus_contour_range_th
                64,  // ca_ltm_bitplus_contour_range_slope
                3,  // ca_ltm_bitplus_diff_count_th
                42,  // ca_ltm_bitplus_diff_count_slope
                0,  // ca_ltm_bitplus_pxl_diff_th
                64,  // ca_ltm_bitplus_pxl_diff_slope
                0,  // ca_ltm_pxl_diff_th_for_flat_pxl
                128,  // ca_ltm_pxl_diff_slope_for_flat_pxl
                0,  // ca_ltm_pxl_diff_th
                16  // ca_ltm_pxl_diff_slope
            },
            // CA_LTM_TUNINGREG
            {
                1,  // ca_ltm_fw_en
                1,  // ca_ltm_curve_en
                1,  // ca_ltm_gain_flt_en
                1,  // ca_ltm_iir_force_range
                20,  // bADLWeight1
                44,  // bADLWeight2
                0,  // bADLWeight3
                16,  // bBSDCGain
                128,  // bBSACGain
                0,  // bBSLevel
                16,  // bMIDDCGain
                64,  // bMIDACGain
                16,  // bWSDCGain
                128,  // bWSACGain
                0,  // bWSLevel
                0,  // ca_ltm_dync_spike_wgt_min
                255,  // ca_ltm_dync_spike_wgt_max
                144,  // ca_ltm_dync_spike_th
                64,  // ca_ltm_dync_spike_slope
                2,  // bSpikeBlendmethod
                72,  // bSkinWgtSlope
                2,  // bSkinBlendmethod
                8,  // ca_ltm_dync_flt_coef_min
                32,  // ca_ltm_dync_flt_coef_max
                4,  // ca_ltm_dync_flt_ovr_pxl_th
                50,  // ca_ltm_dync_flt_ovr_pxl_slope
                0,  // LLPValue
                0,  // LLPRatio
                255,  // APLCompRatioLow
                255,  // APLCompRatioHigh
                300,  // FltConfSlope
                0,  // FltConfTh
                3,  // BlkHistCountRatio
                224,  // BinIdxDiffSlope
                0,  // BinIdxDiffTh
                32,  // BinIdxDiffWgtOft
                16,  // APLTh
                128,  // APLSlope
                256,  // APLWgtOft
                16,  // APL2Th
                128,  // APL2Slope
                256,  // APL2WgtOft
                256,  // APL2WgtMax
                1,  // BlkSpaFltEn
                1,  // BlkSpaFltType
                0,  // LoadBlkCurveEn
                0  // SaveBlkCurveEn
            },
            // CA_LTM_ADAPTTUNINGREG
            {
                1,  // Enabled
                255,  // Strength
                0,  // AdaptiveMethod
                0,  // AdaptiveType
                0  // CustomParametersSearchMode
            }
        },
        { //3
            // CA_LTM_INITUNINGRE
            {
                24,  // ca_ltm_s_lower
                32,  // ca_ltm_s_upper
                48,  // ca_ltm_y_lower
                176,  // ca_ltm_y_upper
                88,  // ca_ltm_h_lower
                88,  // ca_ltm_h_upper
                1,  // ca_ltm_max_hist_mode
                2,  // ca_ltm_bitplus_contour_range_th
                64,  // ca_ltm_bitplus_contour_range_slope
                3,  // ca_ltm_bitplus_diff_count_th
                42,  // ca_ltm_bitplus_diff_count_slope
                0,  // ca_ltm_bitplus_pxl_diff_th
                64,  // ca_ltm_bitplus_pxl_diff_slope
                0,  // ca_ltm_pxl_diff_th_for_flat_pxl
                128,  // ca_ltm_pxl_diff_slope_for_flat_pxl
                0,  // ca_ltm_pxl_diff_th
                16  // ca_ltm_pxl_diff_slope
            },
            // CA_LTM_TUNINGREG
            {
                1,  // ca_ltm_fw_en
                1,  // ca_ltm_curve_en
                1,  // ca_ltm_gain_flt_en
                1,  // ca_ltm_iir_force_range
                20,  // bADLWeight1
                44,  // bADLWeight2
                0,  // bADLWeight3
                16,  // bBSDCGain
                128,  // bBSACGain
                0,  // bBSLevel
                16,  // bMIDDCGain
                64,  // bMIDACGain
                16,  // bWSDCGain
                128,  // bWSACGain
                0,  // bWSLevel
                0,  // ca_ltm_dync_spike_wgt_min
                255,  // ca_ltm_dync_spike_wgt_max
                144,  // ca_ltm_dync_spike_th
                64,  // ca_ltm_dync_spike_slope
                2,  // bSpikeBlendmethod
                72,  // bSkinWgtSlope
                2,  // bSkinBlendmethod
                8,  // ca_ltm_dync_flt_coef_min
                32,  // ca_ltm_dync_flt_coef_max
                4,  // ca_ltm_dync_flt_ovr_pxl_th
                50,  // ca_ltm_dync_flt_ovr_pxl_slope
                0,  // LLPValue
                0,  // LLPRatio
                255,  // APLCompRatioLow
                255,  // APLCompRatioHigh
                300,  // FltConfSlope
                0,  // FltConfTh
                3,  // BlkHistCountRatio
                224,  // BinIdxDiffSlope
                0,  // BinIdxDiffTh
                32,  // BinIdxDiffWgtOft
                16,  // APLTh
                128,  // APLSlope
                256,  // APLWgtOft
                16,  // APL2Th
                128,  // APL2Slope
                256,  // APL2WgtOft
                256,  // APL2WgtMax
                1,  // BlkSpaFltEn
                1,  // BlkSpaFltType
                0,  // LoadBlkCurveEn
                0  // SaveBlkCurveEn
            },
            // CA_LTM_ADAPTTUNINGREG
            {
                1,  // Enabled
                255,  // Strength
                0,  // AdaptiveMethod
                0,  // AdaptiveType
                0  // CustomParametersSearchMode
            }
        },
        { //4
            // CA_LTM_INITUNINGRE
            {
                24,  // ca_ltm_s_lower
                32,  // ca_ltm_s_upper
                48,  // ca_ltm_y_lower
                176,  // ca_ltm_y_upper
                88,  // ca_ltm_h_lower
                88,  // ca_ltm_h_upper
                1,  // ca_ltm_max_hist_mode
                2,  // ca_ltm_bitplus_contour_range_th
                64,  // ca_ltm_bitplus_contour_range_slope
                3,  // ca_ltm_bitplus_diff_count_th
                42,  // ca_ltm_bitplus_diff_count_slope
                0,  // ca_ltm_bitplus_pxl_diff_th
                64,  // ca_ltm_bitplus_pxl_diff_slope
                0,  // ca_ltm_pxl_diff_th_for_flat_pxl
                128,  // ca_ltm_pxl_diff_slope_for_flat_pxl
                0,  // ca_ltm_pxl_diff_th
                16  // ca_ltm_pxl_diff_slope
            },
            // CA_LTM_TUNINGREG
            {
                1,  // ca_ltm_fw_en
                1,  // ca_ltm_curve_en
                1,  // ca_ltm_gain_flt_en
                1,  // ca_ltm_iir_force_range
                20,  // bADLWeight1
                44,  // bADLWeight2
                0,  // bADLWeight3
                16,  // bBSDCGain
                128,  // bBSACGain
                0,  // bBSLevel
                16,  // bMIDDCGain
                64,  // bMIDACGain
                16,  // bWSDCGain
                128,  // bWSACGain
                0,  // bWSLevel
                0,  // ca_ltm_dync_spike_wgt_min
                255,  // ca_ltm_dync_spike_wgt_max
                144,  // ca_ltm_dync_spike_th
                64,  // ca_ltm_dync_spike_slope
                2,  // bSpikeBlendmethod
                72,  // bSkinWgtSlope
                2,  // bSkinBlendmethod
                8,  // ca_ltm_dync_flt_coef_min
                32,  // ca_ltm_dync_flt_coef_max
                4,  // ca_ltm_dync_flt_ovr_pxl_th
                50,  // ca_ltm_dync_flt_ovr_pxl_slope
                0,  // LLPValue
                0,  // LLPRatio
                255,  // APLCompRatioLow
                255,  // APLCompRatioHigh
                300,  // FltConfSlope
                0,  // FltConfTh
                3,  // BlkHistCountRatio
                224,  // BinIdxDiffSlope
                0,  // BinIdxDiffTh
                32,  // BinIdxDiffWgtOft
                16,  // APLTh
                128,  // APLSlope
                256,  // APLWgtOft
                16,  // APL2Th
                128,  // APL2Slope
                256,  // APL2WgtOft
                256,  // APL2WgtMax
                1,  // BlkSpaFltEn
                1,  // BlkSpaFltType
                0,  // LoadBlkCurveEn
                0  // SaveBlkCurveEn
            },
            // CA_LTM_ADAPTTUNINGREG
            {
                1,  // Enabled
                255,  // Strength
                0,  // AdaptiveMethod
                0,  // AdaptiveType
                0  // CustomParametersSearchMode
            }
        },
        { //5
            // CA_LTM_INITUNINGRE
            {
                24,  // ca_ltm_s_lower
                32,  // ca_ltm_s_upper
                48,  // ca_ltm_y_lower
                176,  // ca_ltm_y_upper
                88,  // ca_ltm_h_lower
                88,  // ca_ltm_h_upper
                1,  // ca_ltm_max_hist_mode
                2,  // ca_ltm_bitplus_contour_range_th
                64,  // ca_ltm_bitplus_contour_range_slope
                3,  // ca_ltm_bitplus_diff_count_th
                42,  // ca_ltm_bitplus_diff_count_slope
                0,  // ca_ltm_bitplus_pxl_diff_th
                64,  // ca_ltm_bitplus_pxl_diff_slope
                0,  // ca_ltm_pxl_diff_th_for_flat_pxl
                128,  // ca_ltm_pxl_diff_slope_for_flat_pxl
                0,  // ca_ltm_pxl_diff_th
                16  // ca_ltm_pxl_diff_slope
            },
            // CA_LTM_TUNINGREG
            {
                1,  // ca_ltm_fw_en
                1,  // ca_ltm_curve_en
                1,  // ca_ltm_gain_flt_en
                1,  // ca_ltm_iir_force_range
                20,  // bADLWeight1
                44,  // bADLWeight2
                0,  // bADLWeight3
                16,  // bBSDCGain
                128,  // bBSACGain
                0,  // bBSLevel
                16,  // bMIDDCGain
                64,  // bMIDACGain
                16,  // bWSDCGain
                128,  // bWSACGain
                0,  // bWSLevel
                0,  // ca_ltm_dync_spike_wgt_min
                255,  // ca_ltm_dync_spike_wgt_max
                144,  // ca_ltm_dync_spike_th
                64,  // ca_ltm_dync_spike_slope
                2,  // bSpikeBlendmethod
                72,  // bSkinWgtSlope
                2,  // bSkinBlendmethod
                8,  // ca_ltm_dync_flt_coef_min
                32,  // ca_ltm_dync_flt_coef_max
                4,  // ca_ltm_dync_flt_ovr_pxl_th
                50,  // ca_ltm_dync_flt_ovr_pxl_slope
                0,  // LLPValue
                0,  // LLPRatio
                255,  // APLCompRatioLow
                255,  // APLCompRatioHigh
                300,  // FltConfSlope
                0,  // FltConfTh
                3,  // BlkHistCountRatio
                224,  // BinIdxDiffSlope
                0,  // BinIdxDiffTh
                32,  // BinIdxDiffWgtOft
                16,  // APLTh
                128,  // APLSlope
                256,  // APLWgtOft
                16,  // APL2Th
                128,  // APL2Slope
                256,  // APL2WgtOft
                256,  // APL2WgtMax
                1,  // BlkSpaFltEn
                1,  // BlkSpaFltType
                0,  // LoadBlkCurveEn
                0  // SaveBlkCurveEn
            },
            // CA_LTM_ADAPTTUNINGREG
            {
                1,  // Enabled
                255,  // Strength
                0,  // AdaptiveMethod
                0,  // AdaptiveType
                0  // CustomParametersSearchMode
            }
        },
        { //6
            // CA_LTM_INITUNINGRE
            {
                24,  // ca_ltm_s_lower
                32,  // ca_ltm_s_upper
                48,  // ca_ltm_y_lower
                176,  // ca_ltm_y_upper
                88,  // ca_ltm_h_lower
                88,  // ca_ltm_h_upper
                1,  // ca_ltm_max_hist_mode
                2,  // ca_ltm_bitplus_contour_range_th
                64,  // ca_ltm_bitplus_contour_range_slope
                3,  // ca_ltm_bitplus_diff_count_th
                42,  // ca_ltm_bitplus_diff_count_slope
                0,  // ca_ltm_bitplus_pxl_diff_th
                64,  // ca_ltm_bitplus_pxl_diff_slope
                0,  // ca_ltm_pxl_diff_th_for_flat_pxl
                128,  // ca_ltm_pxl_diff_slope_for_flat_pxl
                0,  // ca_ltm_pxl_diff_th
                16  // ca_ltm_pxl_diff_slope
            },
            // CA_LTM_TUNINGREG
            {
                1,  // ca_ltm_fw_en
                1,  // ca_ltm_curve_en
                1,  // ca_ltm_gain_flt_en
                1,  // ca_ltm_iir_force_range
                20,  // bADLWeight1
                44,  // bADLWeight2
                0,  // bADLWeight3
                16,  // bBSDCGain
                128,  // bBSACGain
                0,  // bBSLevel
                16,  // bMIDDCGain
                64,  // bMIDACGain
                16,  // bWSDCGain
                128,  // bWSACGain
                0,  // bWSLevel
                0,  // ca_ltm_dync_spike_wgt_min
                255,  // ca_ltm_dync_spike_wgt_max
                144,  // ca_ltm_dync_spike_th
                64,  // ca_ltm_dync_spike_slope
                2,  // bSpikeBlendmethod
                72,  // bSkinWgtSlope
                2,  // bSkinBlendmethod
                8,  // ca_ltm_dync_flt_coef_min
                32,  // ca_ltm_dync_flt_coef_max
                4,  // ca_ltm_dync_flt_ovr_pxl_th
                50,  // ca_ltm_dync_flt_ovr_pxl_slope
                0,  // LLPValue
                0,  // LLPRatio
                255,  // APLCompRatioLow
                255,  // APLCompRatioHigh
                300,  // FltConfSlope
                0,  // FltConfTh
                3,  // BlkHistCountRatio
                224,  // BinIdxDiffSlope
                0,  // BinIdxDiffTh
                32,  // BinIdxDiffWgtOft
                16,  // APLTh
                128,  // APLSlope
                256,  // APLWgtOft
                16,  // APL2Th
                128,  // APL2Slope
                256,  // APL2WgtOft
                256,  // APL2WgtMax
                1,  // BlkSpaFltEn
                1,  // BlkSpaFltType
                0,  // LoadBlkCurveEn
                0  // SaveBlkCurveEn
            },
            // CA_LTM_ADAPTTUNINGREG
            {
                1,  // Enabled
                255,  // Strength
                0,  // AdaptiveMethod
                0,  // AdaptiveType
                0  // CustomParametersSearchMode
            }
        },
        { //7
            // CA_LTM_INITUNINGRE
            {
                24,  // ca_ltm_s_lower
                32,  // ca_ltm_s_upper
                48,  // ca_ltm_y_lower
                176,  // ca_ltm_y_upper
                88,  // ca_ltm_h_lower
                88,  // ca_ltm_h_upper
                1,  // ca_ltm_max_hist_mode
                2,  // ca_ltm_bitplus_contour_range_th
                64,  // ca_ltm_bitplus_contour_range_slope
                3,  // ca_ltm_bitplus_diff_count_th
                42,  // ca_ltm_bitplus_diff_count_slope
                0,  // ca_ltm_bitplus_pxl_diff_th
                64,  // ca_ltm_bitplus_pxl_diff_slope
                0,  // ca_ltm_pxl_diff_th_for_flat_pxl
                128,  // ca_ltm_pxl_diff_slope_for_flat_pxl
                0,  // ca_ltm_pxl_diff_th
                16  // ca_ltm_pxl_diff_slope
            },
            // CA_LTM_TUNINGREG
            {
                1,  // ca_ltm_fw_en
                1,  // ca_ltm_curve_en
                1,  // ca_ltm_gain_flt_en
                1,  // ca_ltm_iir_force_range
                20,  // bADLWeight1
                44,  // bADLWeight2
                0,  // bADLWeight3
                16,  // bBSDCGain
                128,  // bBSACGain
                0,  // bBSLevel
                16,  // bMIDDCGain
                64,  // bMIDACGain
                16,  // bWSDCGain
                128,  // bWSACGain
                0,  // bWSLevel
                0,  // ca_ltm_dync_spike_wgt_min
                255,  // ca_ltm_dync_spike_wgt_max
                144,  // ca_ltm_dync_spike_th
                64,  // ca_ltm_dync_spike_slope
                2,  // bSpikeBlendmethod
                72,  // bSkinWgtSlope
                2,  // bSkinBlendmethod
                8,  // ca_ltm_dync_flt_coef_min
                32,  // ca_ltm_dync_flt_coef_max
                4,  // ca_ltm_dync_flt_ovr_pxl_th
                50,  // ca_ltm_dync_flt_ovr_pxl_slope
                0,  // LLPValue
                0,  // LLPRatio
                255,  // APLCompRatioLow
                255,  // APLCompRatioHigh
                300,  // FltConfSlope
                0,  // FltConfTh
                3,  // BlkHistCountRatio
                224,  // BinIdxDiffSlope
                0,  // BinIdxDiffTh
                32,  // BinIdxDiffWgtOft
                16,  // APLTh
                128,  // APLSlope
                256,  // APLWgtOft
                16,  // APL2Th
                128,  // APL2Slope
                256,  // APL2WgtOft
                256,  // APL2WgtMax
                1,  // BlkSpaFltEn
                1,  // BlkSpaFltType
                0,  // LoadBlkCurveEn
                0  // SaveBlkCurveEn
            },
            // CA_LTM_ADAPTTUNINGREG
            {
                1,  // Enabled
                255,  // Strength
                0,  // AdaptiveMethod
                0,  // AdaptiveType
                0  // CustomParametersSearchMode
            }
        },
        { //8
            // CA_LTM_INITUNINGRE
            {
                24,  // ca_ltm_s_lower
                32,  // ca_ltm_s_upper
                48,  // ca_ltm_y_lower
                176,  // ca_ltm_y_upper
                88,  // ca_ltm_h_lower
                88,  // ca_ltm_h_upper
                1,  // ca_ltm_max_hist_mode
                2,  // ca_ltm_bitplus_contour_range_th
                64,  // ca_ltm_bitplus_contour_range_slope
                3,  // ca_ltm_bitplus_diff_count_th
                42,  // ca_ltm_bitplus_diff_count_slope
                0,  // ca_ltm_bitplus_pxl_diff_th
                64,  // ca_ltm_bitplus_pxl_diff_slope
                0,  // ca_ltm_pxl_diff_th_for_flat_pxl
                128,  // ca_ltm_pxl_diff_slope_for_flat_pxl
                0,  // ca_ltm_pxl_diff_th
                16  // ca_ltm_pxl_diff_slope
            },
            // CA_LTM_TUNINGREG
            {
                1,  // ca_ltm_fw_en
                1,  // ca_ltm_curve_en
                1,  // ca_ltm_gain_flt_en
                1,  // ca_ltm_iir_force_range
                20,  // bADLWeight1
                44,  // bADLWeight2
                0,  // bADLWeight3
                16,  // bBSDCGain
                128,  // bBSACGain
                0,  // bBSLevel
                16,  // bMIDDCGain
                64,  // bMIDACGain
                16,  // bWSDCGain
                128,  // bWSACGain
                0,  // bWSLevel
                0,  // ca_ltm_dync_spike_wgt_min
                255,  // ca_ltm_dync_spike_wgt_max
                144,  // ca_ltm_dync_spike_th
                64,  // ca_ltm_dync_spike_slope
                2,  // bSpikeBlendmethod
                72,  // bSkinWgtSlope
                2,  // bSkinBlendmethod
                8,  // ca_ltm_dync_flt_coef_min
                32,  // ca_ltm_dync_flt_coef_max
                4,  // ca_ltm_dync_flt_ovr_pxl_th
                50,  // ca_ltm_dync_flt_ovr_pxl_slope
                0,  // LLPValue
                0,  // LLPRatio
                255,  // APLCompRatioLow
                255,  // APLCompRatioHigh
                300,  // FltConfSlope
                0,  // FltConfTh
                3,  // BlkHistCountRatio
                224,  // BinIdxDiffSlope
                0,  // BinIdxDiffTh
                32,  // BinIdxDiffWgtOft
                16,  // APLTh
                128,  // APLSlope
                256,  // APLWgtOft
                16,  // APL2Th
                128,  // APL2Slope
                256,  // APL2WgtOft
                256,  // APL2WgtMax
                1,  // BlkSpaFltEn
                1,  // BlkSpaFltType
                0,  // LoadBlkCurveEn
                0  // SaveBlkCurveEn
            },
            // CA_LTM_ADAPTTUNINGREG
            {
                1,  // Enabled
                255,  // Strength
                0,  // AdaptiveMethod
                0,  // AdaptiveType
                0  // CustomParametersSearchMode
            }
        },
        { //9
            // CA_LTM_INITUNINGRE
            {
                24,  // ca_ltm_s_lower
                32,  // ca_ltm_s_upper
                48,  // ca_ltm_y_lower
                176,  // ca_ltm_y_upper
                88,  // ca_ltm_h_lower
                88,  // ca_ltm_h_upper
                1,  // ca_ltm_max_hist_mode
                2,  // ca_ltm_bitplus_contour_range_th
                64,  // ca_ltm_bitplus_contour_range_slope
                3,  // ca_ltm_bitplus_diff_count_th
                42,  // ca_ltm_bitplus_diff_count_slope
                0,  // ca_ltm_bitplus_pxl_diff_th
                64,  // ca_ltm_bitplus_pxl_diff_slope
                0,  // ca_ltm_pxl_diff_th_for_flat_pxl
                128,  // ca_ltm_pxl_diff_slope_for_flat_pxl
                0,  // ca_ltm_pxl_diff_th
                16  // ca_ltm_pxl_diff_slope
            },
            // CA_LTM_TUNINGREG
            {
                1,  // ca_ltm_fw_en
                1,  // ca_ltm_curve_en
                1,  // ca_ltm_gain_flt_en
                1,  // ca_ltm_iir_force_range
                20,  // bADLWeight1
                44,  // bADLWeight2
                0,  // bADLWeight3
                16,  // bBSDCGain
                128,  // bBSACGain
                0,  // bBSLevel
                16,  // bMIDDCGain
                64,  // bMIDACGain
                16,  // bWSDCGain
                128,  // bWSACGain
                0,  // bWSLevel
                0,  // ca_ltm_dync_spike_wgt_min
                255,  // ca_ltm_dync_spike_wgt_max
                144,  // ca_ltm_dync_spike_th
                64,  // ca_ltm_dync_spike_slope
                2,  // bSpikeBlendmethod
                72,  // bSkinWgtSlope
                2,  // bSkinBlendmethod
                8,  // ca_ltm_dync_flt_coef_min
                32,  // ca_ltm_dync_flt_coef_max
                4,  // ca_ltm_dync_flt_ovr_pxl_th
                50,  // ca_ltm_dync_flt_ovr_pxl_slope
                0,  // LLPValue
                0,  // LLPRatio
                255,  // APLCompRatioLow
                255,  // APLCompRatioHigh
                300,  // FltConfSlope
                0,  // FltConfTh
                3,  // BlkHistCountRatio
                224,  // BinIdxDiffSlope
                0,  // BinIdxDiffTh
                32,  // BinIdxDiffWgtOft
                16,  // APLTh
                128,  // APLSlope
                256,  // APLWgtOft
                16,  // APL2Th
                128,  // APL2Slope
                256,  // APL2WgtOft
                256,  // APL2WgtMax
                1,  // BlkSpaFltEn
                1,  // BlkSpaFltType
                0,  // LoadBlkCurveEn
                0  // SaveBlkCurveEn
            },
            // CA_LTM_ADAPTTUNINGREG
            {
                1,  // Enabled
                255,  // Strength
                0,  // AdaptiveMethod
                0,  // AdaptiveType
                0  // CustomParametersSearchMode
            }
        },
        { //10
            // CA_LTM_INITUNINGRE
            {
                24,  // ca_ltm_s_lower
                32,  // ca_ltm_s_upper
                48,  // ca_ltm_y_lower
                176,  // ca_ltm_y_upper
                88,  // ca_ltm_h_lower
                88,  // ca_ltm_h_upper
                1,  // ca_ltm_max_hist_mode
                2,  // ca_ltm_bitplus_contour_range_th
                64,  // ca_ltm_bitplus_contour_range_slope
                3,  // ca_ltm_bitplus_diff_count_th
                42,  // ca_ltm_bitplus_diff_count_slope
                0,  // ca_ltm_bitplus_pxl_diff_th
                64,  // ca_ltm_bitplus_pxl_diff_slope
                0,  // ca_ltm_pxl_diff_th_for_flat_pxl
                128,  // ca_ltm_pxl_diff_slope_for_flat_pxl
                0,  // ca_ltm_pxl_diff_th
                16  // ca_ltm_pxl_diff_slope
            },
            // CA_LTM_TUNINGREG
            {
                1,  // ca_ltm_fw_en
                1,  // ca_ltm_curve_en
                1,  // ca_ltm_gain_flt_en
                1,  // ca_ltm_iir_force_range
                20,  // bADLWeight1
                44,  // bADLWeight2
                0,  // bADLWeight3
                16,  // bBSDCGain
                128,  // bBSACGain
                0,  // bBSLevel
                16,  // bMIDDCGain
                64,  // bMIDACGain
                16,  // bWSDCGain
                128,  // bWSACGain
                0,  // bWSLevel
                0,  // ca_ltm_dync_spike_wgt_min
                255,  // ca_ltm_dync_spike_wgt_max
                144,  // ca_ltm_dync_spike_th
                64,  // ca_ltm_dync_spike_slope
                2,  // bSpikeBlendmethod
                72,  // bSkinWgtSlope
                2,  // bSkinBlendmethod
                8,  // ca_ltm_dync_flt_coef_min
                32,  // ca_ltm_dync_flt_coef_max
                4,  // ca_ltm_dync_flt_ovr_pxl_th
                50,  // ca_ltm_dync_flt_ovr_pxl_slope
                0,  // LLPValue
                0,  // LLPRatio
                255,  // APLCompRatioLow
                255,  // APLCompRatioHigh
                300,  // FltConfSlope
                0,  // FltConfTh
                3,  // BlkHistCountRatio
                224,  // BinIdxDiffSlope
                0,  // BinIdxDiffTh
                32,  // BinIdxDiffWgtOft
                16,  // APLTh
                128,  // APLSlope
                256,  // APLWgtOft
                16,  // APL2Th
                128,  // APL2Slope
                256,  // APL2WgtOft
                256,  // APL2WgtMax
                1,  // BlkSpaFltEn
                1,  // BlkSpaFltType
                0,  // LoadBlkCurveEn
                0  // SaveBlkCurveEn
            },
            // CA_LTM_ADAPTTUNINGREG
            {
                1,  // Enabled
                255,  // Strength
                0,  // AdaptiveMethod
                0,  // AdaptiveType
                0  // CustomParametersSearchMode
            }
        },
        { //11
            // CA_LTM_INITUNINGRE
            {
                24,  // ca_ltm_s_lower
                32,  // ca_ltm_s_upper
                48,  // ca_ltm_y_lower
                176,  // ca_ltm_y_upper
                88,  // ca_ltm_h_lower
                88,  // ca_ltm_h_upper
                1,  // ca_ltm_max_hist_mode
                2,  // ca_ltm_bitplus_contour_range_th
                64,  // ca_ltm_bitplus_contour_range_slope
                3,  // ca_ltm_bitplus_diff_count_th
                42,  // ca_ltm_bitplus_diff_count_slope
                0,  // ca_ltm_bitplus_pxl_diff_th
                64,  // ca_ltm_bitplus_pxl_diff_slope
                0,  // ca_ltm_pxl_diff_th_for_flat_pxl
                128,  // ca_ltm_pxl_diff_slope_for_flat_pxl
                0,  // ca_ltm_pxl_diff_th
                16  // ca_ltm_pxl_diff_slope
            },
            // CA_LTM_TUNINGREG
            {
                1,  // ca_ltm_fw_en
                1,  // ca_ltm_curve_en
                1,  // ca_ltm_gain_flt_en
                1,  // ca_ltm_iir_force_range
                20,  // bADLWeight1
                44,  // bADLWeight2
                0,  // bADLWeight3
                16,  // bBSDCGain
                128,  // bBSACGain
                0,  // bBSLevel
                16,  // bMIDDCGain
                64,  // bMIDACGain
                16,  // bWSDCGain
                128,  // bWSACGain
                0,  // bWSLevel
                0,  // ca_ltm_dync_spike_wgt_min
                255,  // ca_ltm_dync_spike_wgt_max
                144,  // ca_ltm_dync_spike_th
                64,  // ca_ltm_dync_spike_slope
                2,  // bSpikeBlendmethod
                72,  // bSkinWgtSlope
                2,  // bSkinBlendmethod
                8,  // ca_ltm_dync_flt_coef_min
                32,  // ca_ltm_dync_flt_coef_max
                4,  // ca_ltm_dync_flt_ovr_pxl_th
                50,  // ca_ltm_dync_flt_ovr_pxl_slope
                0,  // LLPValue
                0,  // LLPRatio
                255,  // APLCompRatioLow
                255,  // APLCompRatioHigh
                300,  // FltConfSlope
                0,  // FltConfTh
                3,  // BlkHistCountRatio
                224,  // BinIdxDiffSlope
                0,  // BinIdxDiffTh
                32,  // BinIdxDiffWgtOft
                16,  // APLTh
                128,  // APLSlope
                256,  // APLWgtOft
                16,  // APL2Th
                128,  // APL2Slope
                256,  // APL2WgtOft
                256,  // APL2WgtMax
                1,  // BlkSpaFltEn
                1,  // BlkSpaFltType
                0,  // LoadBlkCurveEn
                0  // SaveBlkCurveEn
            },
            // CA_LTM_ADAPTTUNINGREG
            {
                1,  // Enabled
                255,  // Strength
                0,  // AdaptiveMethod
                0,  // AdaptiveType
                0  // CustomParametersSearchMode
            }
        },
        { //12
            // CA_LTM_INITUNINGRE
            {
                24,  // ca_ltm_s_lower
                32,  // ca_ltm_s_upper
                48,  // ca_ltm_y_lower
                176,  // ca_ltm_y_upper
                88,  // ca_ltm_h_lower
                88,  // ca_ltm_h_upper
                1,  // ca_ltm_max_hist_mode
                2,  // ca_ltm_bitplus_contour_range_th
                64,  // ca_ltm_bitplus_contour_range_slope
                3,  // ca_ltm_bitplus_diff_count_th
                42,  // ca_ltm_bitplus_diff_count_slope
                0,  // ca_ltm_bitplus_pxl_diff_th
                64,  // ca_ltm_bitplus_pxl_diff_slope
                0,  // ca_ltm_pxl_diff_th_for_flat_pxl
                128,  // ca_ltm_pxl_diff_slope_for_flat_pxl
                0,  // ca_ltm_pxl_diff_th
                16  // ca_ltm_pxl_diff_slope
            },
            // CA_LTM_TUNINGREG
            {
                1,  // ca_ltm_fw_en
                1,  // ca_ltm_curve_en
                1,  // ca_ltm_gain_flt_en
                1,  // ca_ltm_iir_force_range
                20,  // bADLWeight1
                44,  // bADLWeight2
                0,  // bADLWeight3
                16,  // bBSDCGain
                128,  // bBSACGain
                0,  // bBSLevel
                16,  // bMIDDCGain
                64,  // bMIDACGain
                16,  // bWSDCGain
                128,  // bWSACGain
                0,  // bWSLevel
                0,  // ca_ltm_dync_spike_wgt_min
                255,  // ca_ltm_dync_spike_wgt_max
                144,  // ca_ltm_dync_spike_th
                64,  // ca_ltm_dync_spike_slope
                2,  // bSpikeBlendmethod
                72,  // bSkinWgtSlope
                2,  // bSkinBlendmethod
                8,  // ca_ltm_dync_flt_coef_min
                32,  // ca_ltm_dync_flt_coef_max
                4,  // ca_ltm_dync_flt_ovr_pxl_th
                50,  // ca_ltm_dync_flt_ovr_pxl_slope
                0,  // LLPValue
                0,  // LLPRatio
                255,  // APLCompRatioLow
                255,  // APLCompRatioHigh
                300,  // FltConfSlope
                0,  // FltConfTh
                3,  // BlkHistCountRatio
                224,  // BinIdxDiffSlope
                0,  // BinIdxDiffTh
                32,  // BinIdxDiffWgtOft
                16,  // APLTh
                128,  // APLSlope
                256,  // APLWgtOft
                16,  // APL2Th
                128,  // APL2Slope
                256,  // APL2WgtOft
                256,  // APL2WgtMax
                1,  // BlkSpaFltEn
                1,  // BlkSpaFltType
                0,  // LoadBlkCurveEn
                0  // SaveBlkCurveEn
            },
            // CA_LTM_ADAPTTUNINGREG
            {
                1,  // Enabled
                255,  // Strength
                0,  // AdaptiveMethod
                0,  // AdaptiveType
                0  // CustomParametersSearchMode
            }
        },
        { //13
            // CA_LTM_INITUNINGRE
            {
                24,  // ca_ltm_s_lower
                32,  // ca_ltm_s_upper
                48,  // ca_ltm_y_lower
                176,  // ca_ltm_y_upper
                88,  // ca_ltm_h_lower
                88,  // ca_ltm_h_upper
                1,  // ca_ltm_max_hist_mode
                2,  // ca_ltm_bitplus_contour_range_th
                64,  // ca_ltm_bitplus_contour_range_slope
                3,  // ca_ltm_bitplus_diff_count_th
                42,  // ca_ltm_bitplus_diff_count_slope
                0,  // ca_ltm_bitplus_pxl_diff_th
                64,  // ca_ltm_bitplus_pxl_diff_slope
                0,  // ca_ltm_pxl_diff_th_for_flat_pxl
                128,  // ca_ltm_pxl_diff_slope_for_flat_pxl
                0,  // ca_ltm_pxl_diff_th
                16  // ca_ltm_pxl_diff_slope
            },
            // CA_LTM_TUNINGREG
            {
                1,  // ca_ltm_fw_en
                1,  // ca_ltm_curve_en
                1,  // ca_ltm_gain_flt_en
                1,  // ca_ltm_iir_force_range
                20,  // bADLWeight1
                44,  // bADLWeight2
                0,  // bADLWeight3
                16,  // bBSDCGain
                128,  // bBSACGain
                0,  // bBSLevel
                16,  // bMIDDCGain
                64,  // bMIDACGain
                16,  // bWSDCGain
                128,  // bWSACGain
                0,  // bWSLevel
                0,  // ca_ltm_dync_spike_wgt_min
                255,  // ca_ltm_dync_spike_wgt_max
                144,  // ca_ltm_dync_spike_th
                64,  // ca_ltm_dync_spike_slope
                2,  // bSpikeBlendmethod
                72,  // bSkinWgtSlope
                2,  // bSkinBlendmethod
                8,  // ca_ltm_dync_flt_coef_min
                32,  // ca_ltm_dync_flt_coef_max
                4,  // ca_ltm_dync_flt_ovr_pxl_th
                50,  // ca_ltm_dync_flt_ovr_pxl_slope
                0,  // LLPValue
                0,  // LLPRatio
                255,  // APLCompRatioLow
                255,  // APLCompRatioHigh
                300,  // FltConfSlope
                0,  // FltConfTh
                3,  // BlkHistCountRatio
                224,  // BinIdxDiffSlope
                0,  // BinIdxDiffTh
                32,  // BinIdxDiffWgtOft
                16,  // APLTh
                128,  // APLSlope
                256,  // APLWgtOft
                16,  // APL2Th
                128,  // APL2Slope
                256,  // APL2WgtOft
                256,  // APL2WgtMax
                1,  // BlkSpaFltEn
                1,  // BlkSpaFltType
                0,  // LoadBlkCurveEn
                0  // SaveBlkCurveEn
            },
            // CA_LTM_ADAPTTUNINGREG
            {
                1,  // Enabled
                255,  // Strength
                0,  // AdaptiveMethod
                0,  // AdaptiveType
                0  // CustomParametersSearchMode
            }
        },
        { //14
            // CA_LTM_INITUNINGRE
            {
                24,  // ca_ltm_s_lower
                32,  // ca_ltm_s_upper
                48,  // ca_ltm_y_lower
                176,  // ca_ltm_y_upper
                88,  // ca_ltm_h_lower
                88,  // ca_ltm_h_upper
                1,  // ca_ltm_max_hist_mode
                2,  // ca_ltm_bitplus_contour_range_th
                64,  // ca_ltm_bitplus_contour_range_slope
                3,  // ca_ltm_bitplus_diff_count_th
                42,  // ca_ltm_bitplus_diff_count_slope
                0,  // ca_ltm_bitplus_pxl_diff_th
                64,  // ca_ltm_bitplus_pxl_diff_slope
                0,  // ca_ltm_pxl_diff_th_for_flat_pxl
                128,  // ca_ltm_pxl_diff_slope_for_flat_pxl
                0,  // ca_ltm_pxl_diff_th
                16  // ca_ltm_pxl_diff_slope
            },
            // CA_LTM_TUNINGREG
            {
                1,  // ca_ltm_fw_en
                1,  // ca_ltm_curve_en
                1,  // ca_ltm_gain_flt_en
                1,  // ca_ltm_iir_force_range
                20,  // bADLWeight1
                44,  // bADLWeight2
                0,  // bADLWeight3
                16,  // bBSDCGain
                128,  // bBSACGain
                0,  // bBSLevel
                16,  // bMIDDCGain
                64,  // bMIDACGain
                16,  // bWSDCGain
                128,  // bWSACGain
                0,  // bWSLevel
                0,  // ca_ltm_dync_spike_wgt_min
                255,  // ca_ltm_dync_spike_wgt_max
                144,  // ca_ltm_dync_spike_th
                64,  // ca_ltm_dync_spike_slope
                2,  // bSpikeBlendmethod
                72,  // bSkinWgtSlope
                2,  // bSkinBlendmethod
                8,  // ca_ltm_dync_flt_coef_min
                32,  // ca_ltm_dync_flt_coef_max
                4,  // ca_ltm_dync_flt_ovr_pxl_th
                50,  // ca_ltm_dync_flt_ovr_pxl_slope
                0,  // LLPValue
                0,  // LLPRatio
                255,  // APLCompRatioLow
                255,  // APLCompRatioHigh
                300,  // FltConfSlope
                0,  // FltConfTh
                3,  // BlkHistCountRatio
                224,  // BinIdxDiffSlope
                0,  // BinIdxDiffTh
                32,  // BinIdxDiffWgtOft
                16,  // APLTh
                128,  // APLSlope
                256,  // APLWgtOft
                16,  // APL2Th
                128,  // APL2Slope
                256,  // APL2WgtOft
                256,  // APL2WgtMax
                1,  // BlkSpaFltEn
                1,  // BlkSpaFltType
                0,  // LoadBlkCurveEn
                0  // SaveBlkCurveEn
            },
            // CA_LTM_ADAPTTUNINGREG
            {
                1,  // Enabled
                255,  // Strength
                0,  // AdaptiveMethod
                0,  // AdaptiveType
                0  // CustomParametersSearchMode
            }
        },
    },

};
