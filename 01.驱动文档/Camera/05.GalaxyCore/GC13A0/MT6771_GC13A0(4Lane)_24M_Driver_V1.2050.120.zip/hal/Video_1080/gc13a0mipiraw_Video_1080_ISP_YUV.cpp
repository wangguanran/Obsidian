/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein
 * is confidential and proprietary to MediaTek Inc. and/or its licensors.
 * Without the prior written permission of MediaTek inc. and/or its licensors,
 * any reproduction, modification, use or disclosure of MediaTek Software,
 * and information contained herein, in whole or in part, shall be strictly prohibited.
 */
/* MediaTek Inc. (C) 2019. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER ON
 * AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 * NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 * SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 * SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES TO LOOK ONLY TO SUCH
 * THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. RECEIVER EXPRESSLY ACKNOWLEDGES
 * THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES
 * CONTAINED IN MEDIATEK SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK
 * SOFTWARE RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND
 * CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE,
 * AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE MEDIATEK SOFTWARE AT ISSUE,
 * OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY RECEIVER TO
 * MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek Software")
 * have been modified by MediaTek Inc. All revisions are subject to any receiver's
 * applicable license agreements with MediaTek Inc.
 */

/********************************************************************************************
 *     LEGAL DISCLAIMER
 *
 *     (Header of MediaTek Software/Firmware Release or Documentation)
 *
 *     BY OPENING OR USING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *     THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE") RECEIVED
 *     FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON AN "AS-IS" BASIS
 *     ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES, EXPRESS OR IMPLIED,
 *     INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 *     A PARTICULAR PURPOSE OR NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY
 *     WHATSOEVER WITH RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 *     INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND BUYER AGREES TO LOOK
 *     ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. MEDIATEK SHALL ALSO
 *     NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE RELEASES MADE TO BUYER'S SPECIFICATION
 *     OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *     BUYER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND CUMULATIVE LIABILITY WITH
 *     RESPECT TO THE MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION,
 *     TO REVISE OR REPLACE THE MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE
 *     FEES OR SERVICE CHARGE PAID BY BUYER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 *     THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE WITH THE LAWS
 *     OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF LAWS PRINCIPLES.
 ************************************************************************************************/
#include "camera_custom_nvram.h"
#include "gc13a0mipiraw_Video_1080.h"

const ISP_NVRAM_UDM_T gc13a0mipiraw_UDM_0100 = {
        .intp_crs  ={.bits={.UDM_CDG_SL=4, .UDM_CDG_OFST=20, .UDM_CDG_RAT=16, .UDM_CD_KNL=0, .rsv_18=0, .UDM_BYP=0, .UDM_MN_MODE=0}},
    .intp_nat  ={.bits={.UDM_HL_OFST=63, .UDM_L0_SL=6, .UDM_L0_OFST=0, .UDM_CD_SLL=3, .UDM_CD_SLC=10, .rsv_30=0}},
    .intp_aug  ={.bits={.UDM_DN_OFST=0, .UDM_L2_SL=6, .UDM_L2_OFST=0, .UDM_L1_SL=6, .UDM_L1_OFST=0}},
    .luma_lut1 ={.bits={.UDM_LM_Y2=256, .UDM_LM_Y1=384, .UDM_LM_Y0=511, .rsv_27=0}},
    .luma_lut2 ={.bits={.UDM_LM_Y5=32, .UDM_LM_Y4=64, .UDM_LM_Y3=128, .rsv_27=0}},
    .sl_ctl    ={.bits={.UDM_SL_EN=0, .UDM_SL_HR=16, .UDM_SL_Y2=255, .UDM_SL_Y1=255, .rsv_22=0}},
    .hftd_ctl  ={.bits={.UDM_CORE_TH1=0, .UDM_HD_GN2=16, .UDM_HD_GN1=16, .UDM_HT_GN2=16, .UDM_HT_GN1=16, .rsv_28=0}},
    .nr_str    ={.bits={.UDM_N2_STR=0, .UDM_N1_STR=0, .UDM_N0_STR=0, .UDM_XTK_SL=5, .UDM_XTK_OFST=32, .UDM_XTK_RAT=16}},
    .nr_act    ={.bits={.UDM_NGR=0, .UDM_NSL=5, .UDM_N2_OFST=0, .UDM_N1_OFST=0, .UDM_N0_OFST=0}},
    .hf_str    ={.bits={.UDM_CORE_TH2=0, .UDM_HI_RAT=0, .UDM_H3_GN=8, .UDM_H2_GN=15, .UDM_H1_GN=15, .UDM_HA_STR=8}},
    .hf_act1   ={.bits={.UDM_H2_UPB=220, .UDM_H2_LWB=80, .UDM_H1_UPB=100, .UDM_H1_LWB=50}},
    .hf_act2   ={.bits={.UDM_HSLL=5, .UDM_HSLR=5, .UDM_H3_UPB=255, .UDM_H3_LWB=160, .rsv_24=0}},
    .clip      ={.bits={.UDM_CLIP_TH=100, .UDM_UN_TH=32, .UDM_OV_TH=223, .rsv_24=0}},
    .dsb       ={.bits={.UDM_SC_RAT=0, .UDM_SL_RAT=0, .UDM_FL_MODE=0, .rsv_11=0}},
    .p1_act    ={.bits={.UDM_P1_UPB=85, .UDM_P1_LWB=85, .rsv_16=0}},
    .lr_rat    ={.bits={.UDM_LR_RAT=15, .rsv_4=0}},
    .hftd_ctl2 ={.bits={.UDM_HD_GN3=16, .UDM_HFRB_GN=16, .rsv_12=0}},
    .est_ctl   ={.bits={.UDM_P2_CLIP=0, .UDM_P1_BLD=0, .rsv_6=0}},
    .int_ctl   ={.bits={.UDM_INT_LTH=3, .UDM_INT_CDTH=5, .rsv_8=0}},
    .ee        ={.bits={.UDM_HPOS_GN=16, .UDM_HNEG_GN=16, .rsv_10=0}}

};
const ISP_NVRAM_UDM_T gc13a0mipiraw_UDM_0101 = {
        .intp_crs  ={.bits={.UDM_CDG_SL=4, .UDM_CDG_OFST=20, .UDM_CDG_RAT=16, .UDM_CD_KNL=0, .rsv_18=0, .UDM_BYP=0, .UDM_MN_MODE=0}},
    .intp_nat  ={.bits={.UDM_HL_OFST=63, .UDM_L0_SL=6, .UDM_L0_OFST=0, .UDM_CD_SLL=3, .UDM_CD_SLC=10, .rsv_30=0}},
    .intp_aug  ={.bits={.UDM_DN_OFST=0, .UDM_L2_SL=6, .UDM_L2_OFST=0, .UDM_L1_SL=6, .UDM_L1_OFST=0}},
    .luma_lut1 ={.bits={.UDM_LM_Y2=256, .UDM_LM_Y1=384, .UDM_LM_Y0=511, .rsv_27=0}},
    .luma_lut2 ={.bits={.UDM_LM_Y5=32, .UDM_LM_Y4=64, .UDM_LM_Y3=128, .rsv_27=0}},
    .sl_ctl    ={.bits={.UDM_SL_EN=0, .UDM_SL_HR=16, .UDM_SL_Y2=255, .UDM_SL_Y1=255, .rsv_22=0}},
    .hftd_ctl  ={.bits={.UDM_CORE_TH1=0, .UDM_HD_GN2=16, .UDM_HD_GN1=16, .UDM_HT_GN2=16, .UDM_HT_GN1=16, .rsv_28=0}},
    .nr_str    ={.bits={.UDM_N2_STR=0, .UDM_N1_STR=0, .UDM_N0_STR=0, .UDM_XTK_SL=5, .UDM_XTK_OFST=32, .UDM_XTK_RAT=16}},
    .nr_act    ={.bits={.UDM_NGR=0, .UDM_NSL=5, .UDM_N2_OFST=0, .UDM_N1_OFST=0, .UDM_N0_OFST=0}},
    .hf_str    ={.bits={.UDM_CORE_TH2=0, .UDM_HI_RAT=0, .UDM_H3_GN=8, .UDM_H2_GN=15, .UDM_H1_GN=15, .UDM_HA_STR=8}},
    .hf_act1   ={.bits={.UDM_H2_UPB=220, .UDM_H2_LWB=80, .UDM_H1_UPB=100, .UDM_H1_LWB=50}},
    .hf_act2   ={.bits={.UDM_HSLL=5, .UDM_HSLR=5, .UDM_H3_UPB=255, .UDM_H3_LWB=160, .rsv_24=0}},
    .clip      ={.bits={.UDM_CLIP_TH=100, .UDM_UN_TH=32, .UDM_OV_TH=223, .rsv_24=0}},
    .dsb       ={.bits={.UDM_SC_RAT=0, .UDM_SL_RAT=0, .UDM_FL_MODE=0, .rsv_11=0}},
    .p1_act    ={.bits={.UDM_P1_UPB=85, .UDM_P1_LWB=85, .rsv_16=0}},
    .lr_rat    ={.bits={.UDM_LR_RAT=15, .rsv_4=0}},
    .hftd_ctl2 ={.bits={.UDM_HD_GN3=16, .UDM_HFRB_GN=16, .rsv_12=0}},
    .est_ctl   ={.bits={.UDM_P2_CLIP=0, .UDM_P1_BLD=0, .rsv_6=0}},
    .int_ctl   ={.bits={.UDM_INT_LTH=3, .UDM_INT_CDTH=5, .rsv_8=0}},
    .ee        ={.bits={.UDM_HPOS_GN=16, .UDM_HNEG_GN=16, .rsv_10=0}}

};
const ISP_NVRAM_UDM_T gc13a0mipiraw_UDM_0102 = {
        .intp_crs  ={.bits={.UDM_CDG_SL=4, .UDM_CDG_OFST=20, .UDM_CDG_RAT=16, .UDM_CD_KNL=0, .rsv_18=0, .UDM_BYP=0, .UDM_MN_MODE=0}},
    .intp_nat  ={.bits={.UDM_HL_OFST=63, .UDM_L0_SL=6, .UDM_L0_OFST=0, .UDM_CD_SLL=3, .UDM_CD_SLC=10, .rsv_30=0}},
    .intp_aug  ={.bits={.UDM_DN_OFST=0, .UDM_L2_SL=6, .UDM_L2_OFST=0, .UDM_L1_SL=6, .UDM_L1_OFST=0}},
    .luma_lut1 ={.bits={.UDM_LM_Y2=256, .UDM_LM_Y1=384, .UDM_LM_Y0=511, .rsv_27=0}},
    .luma_lut2 ={.bits={.UDM_LM_Y5=32, .UDM_LM_Y4=64, .UDM_LM_Y3=128, .rsv_27=0}},
    .sl_ctl    ={.bits={.UDM_SL_EN=1, .UDM_SL_HR=16, .UDM_SL_Y2=120, .UDM_SL_Y1=200, .rsv_22=0}},
    .hftd_ctl  ={.bits={.UDM_CORE_TH1=0, .UDM_HD_GN2=16, .UDM_HD_GN1=16, .UDM_HT_GN2=16, .UDM_HT_GN1=16, .rsv_28=0}},
    .nr_str    ={.bits={.UDM_N2_STR=0, .UDM_N1_STR=0, .UDM_N0_STR=1, .UDM_XTK_SL=5, .UDM_XTK_OFST=32, .UDM_XTK_RAT=16}},
    .nr_act    ={.bits={.UDM_NGR=0, .UDM_NSL=5, .UDM_N2_OFST=0, .UDM_N1_OFST=0, .UDM_N0_OFST=30}},
    .hf_str    ={.bits={.UDM_CORE_TH2=0, .UDM_HI_RAT=0, .UDM_H3_GN=6, .UDM_H2_GN=12, .UDM_H1_GN=12, .UDM_HA_STR=8}},
    .hf_act1   ={.bits={.UDM_H2_UPB=220, .UDM_H2_LWB=70, .UDM_H1_UPB=80, .UDM_H1_LWB=50}},
    .hf_act2   ={.bits={.UDM_HSLL=5, .UDM_HSLR=5, .UDM_H3_UPB=255, .UDM_H3_LWB=160, .rsv_24=0}},
    .clip      ={.bits={.UDM_CLIP_TH=100, .UDM_UN_TH=32, .UDM_OV_TH=223, .rsv_24=0}},
    .dsb       ={.bits={.UDM_SC_RAT=0, .UDM_SL_RAT=0, .UDM_FL_MODE=0, .rsv_11=0}},
    .p1_act    ={.bits={.UDM_P1_UPB=85, .UDM_P1_LWB=85, .rsv_16=0}},
    .lr_rat    ={.bits={.UDM_LR_RAT=15, .rsv_4=0}},
    .hftd_ctl2 ={.bits={.UDM_HD_GN3=16, .UDM_HFRB_GN=16, .rsv_12=0}},
    .est_ctl   ={.bits={.UDM_P2_CLIP=0, .UDM_P1_BLD=0, .rsv_6=0}},
    .int_ctl   ={.bits={.UDM_INT_LTH=3, .UDM_INT_CDTH=5, .rsv_8=0}},
    .ee        ={.bits={.UDM_HPOS_GN=16, .UDM_HNEG_GN=16, .rsv_10=0}}

};
const ISP_NVRAM_UDM_T gc13a0mipiraw_UDM_0103 = {
        .intp_crs  ={.bits={.UDM_CDG_SL=4, .UDM_CDG_OFST=20, .UDM_CDG_RAT=16, .UDM_CD_KNL=0, .rsv_18=0, .UDM_BYP=0, .UDM_MN_MODE=0}},
    .intp_nat  ={.bits={.UDM_HL_OFST=63, .UDM_L0_SL=6, .UDM_L0_OFST=0, .UDM_CD_SLL=3, .UDM_CD_SLC=10, .rsv_30=0}},
    .intp_aug  ={.bits={.UDM_DN_OFST=0, .UDM_L2_SL=6, .UDM_L2_OFST=0, .UDM_L1_SL=6, .UDM_L1_OFST=0}},
    .luma_lut1 ={.bits={.UDM_LM_Y2=256, .UDM_LM_Y1=384, .UDM_LM_Y0=511, .rsv_27=0}},
    .luma_lut2 ={.bits={.UDM_LM_Y5=32, .UDM_LM_Y4=64, .UDM_LM_Y3=128, .rsv_27=0}},
    .sl_ctl    ={.bits={.UDM_SL_EN=1, .UDM_SL_HR=16, .UDM_SL_Y2=120, .UDM_SL_Y1=180, .rsv_22=0}},
    .hftd_ctl  ={.bits={.UDM_CORE_TH1=0, .UDM_HD_GN2=16, .UDM_HD_GN1=16, .UDM_HT_GN2=16, .UDM_HT_GN1=16, .rsv_28=0}},
    .nr_str    ={.bits={.UDM_N2_STR=0, .UDM_N1_STR=0, .UDM_N0_STR=1, .UDM_XTK_SL=5, .UDM_XTK_OFST=32, .UDM_XTK_RAT=16}},
    .nr_act    ={.bits={.UDM_NGR=0, .UDM_NSL=5, .UDM_N2_OFST=0, .UDM_N1_OFST=0, .UDM_N0_OFST=30}},
    .hf_str    ={.bits={.UDM_CORE_TH2=0, .UDM_HI_RAT=0, .UDM_H3_GN=8, .UDM_H2_GN=12, .UDM_H1_GN=15, .UDM_HA_STR=8}},
    .hf_act1   ={.bits={.UDM_H2_UPB=220, .UDM_H2_LWB=100, .UDM_H1_UPB=120, .UDM_H1_LWB=50}},
    .hf_act2   ={.bits={.UDM_HSLL=5, .UDM_HSLR=5, .UDM_H3_UPB=255, .UDM_H3_LWB=160, .rsv_24=0}},
    .clip      ={.bits={.UDM_CLIP_TH=100, .UDM_UN_TH=32, .UDM_OV_TH=223, .rsv_24=0}},
    .dsb       ={.bits={.UDM_SC_RAT=0, .UDM_SL_RAT=0, .UDM_FL_MODE=0, .rsv_11=0}},
    .p1_act    ={.bits={.UDM_P1_UPB=85, .UDM_P1_LWB=85, .rsv_16=0}},
    .lr_rat    ={.bits={.UDM_LR_RAT=15, .rsv_4=0}},
    .hftd_ctl2 ={.bits={.UDM_HD_GN3=16, .UDM_HFRB_GN=16, .rsv_12=0}},
    .est_ctl   ={.bits={.UDM_P2_CLIP=0, .UDM_P1_BLD=0, .rsv_6=0}},
    .int_ctl   ={.bits={.UDM_INT_LTH=3, .UDM_INT_CDTH=5, .rsv_8=0}},
    .ee        ={.bits={.UDM_HPOS_GN=16, .UDM_HNEG_GN=16, .rsv_10=0}}

};
const ISP_NVRAM_UDM_T gc13a0mipiraw_UDM_0104 = {
        .intp_crs  ={.bits={.UDM_CDG_SL=4, .UDM_CDG_OFST=20, .UDM_CDG_RAT=16, .UDM_CD_KNL=0, .rsv_18=0, .UDM_BYP=0, .UDM_MN_MODE=0}},
    .intp_nat  ={.bits={.UDM_HL_OFST=63, .UDM_L0_SL=6, .UDM_L0_OFST=0, .UDM_CD_SLL=3, .UDM_CD_SLC=10, .rsv_30=0}},
    .intp_aug  ={.bits={.UDM_DN_OFST=0, .UDM_L2_SL=6, .UDM_L2_OFST=0, .UDM_L1_SL=6, .UDM_L1_OFST=0}},
    .luma_lut1 ={.bits={.UDM_LM_Y2=256, .UDM_LM_Y1=384, .UDM_LM_Y0=511, .rsv_27=0}},
    .luma_lut2 ={.bits={.UDM_LM_Y5=32, .UDM_LM_Y4=64, .UDM_LM_Y3=128, .rsv_27=0}},
    .sl_ctl    ={.bits={.UDM_SL_EN=0, .UDM_SL_HR=16, .UDM_SL_Y2=255, .UDM_SL_Y1=255, .rsv_22=0}},
    .hftd_ctl  ={.bits={.UDM_CORE_TH1=0, .UDM_HD_GN2=16, .UDM_HD_GN1=16, .UDM_HT_GN2=16, .UDM_HT_GN1=16, .rsv_28=0}},
    .nr_str    ={.bits={.UDM_N2_STR=0, .UDM_N1_STR=0, .UDM_N0_STR=2, .UDM_XTK_SL=5, .UDM_XTK_OFST=32, .UDM_XTK_RAT=16}},
    .nr_act    ={.bits={.UDM_NGR=0, .UDM_NSL=5, .UDM_N2_OFST=0, .UDM_N1_OFST=0, .UDM_N0_OFST=30}},
    .hf_str    ={.bits={.UDM_CORE_TH2=0, .UDM_HI_RAT=0, .UDM_H3_GN=6, .UDM_H2_GN=12, .UDM_H1_GN=12, .UDM_HA_STR=6}},
    .hf_act1   ={.bits={.UDM_H2_UPB=220, .UDM_H2_LWB=80, .UDM_H1_UPB=100, .UDM_H1_LWB=50}},
    .hf_act2   ={.bits={.UDM_HSLL=5, .UDM_HSLR=5, .UDM_H3_UPB=255, .UDM_H3_LWB=160, .rsv_24=0}},
    .clip      ={.bits={.UDM_CLIP_TH=100, .UDM_UN_TH=32, .UDM_OV_TH=223, .rsv_24=0}},
    .dsb       ={.bits={.UDM_SC_RAT=0, .UDM_SL_RAT=0, .UDM_FL_MODE=0, .rsv_11=0}},
    .p1_act    ={.bits={.UDM_P1_UPB=85, .UDM_P1_LWB=85, .rsv_16=0}},
    .lr_rat    ={.bits={.UDM_LR_RAT=15, .rsv_4=0}},
    .hftd_ctl2 ={.bits={.UDM_HD_GN3=16, .UDM_HFRB_GN=16, .rsv_12=0}},
    .est_ctl   ={.bits={.UDM_P2_CLIP=0, .UDM_P1_BLD=0, .rsv_6=0}},
    .int_ctl   ={.bits={.UDM_INT_LTH=3, .UDM_INT_CDTH=5, .rsv_8=0}},
    .ee        ={.bits={.UDM_HPOS_GN=16, .UDM_HNEG_GN=16, .rsv_10=0}}

};
const ISP_NVRAM_UDM_T gc13a0mipiraw_UDM_0105 = {
        .intp_crs  ={.bits={.UDM_CDG_SL=4, .UDM_CDG_OFST=20, .UDM_CDG_RAT=16, .UDM_CD_KNL=0, .rsv_18=0, .UDM_BYP=0, .UDM_MN_MODE=0}},
    .intp_nat  ={.bits={.UDM_HL_OFST=63, .UDM_L0_SL=6, .UDM_L0_OFST=0, .UDM_CD_SLL=3, .UDM_CD_SLC=10, .rsv_30=0}},
    .intp_aug  ={.bits={.UDM_DN_OFST=0, .UDM_L2_SL=6, .UDM_L2_OFST=0, .UDM_L1_SL=6, .UDM_L1_OFST=0}},
    .luma_lut1 ={.bits={.UDM_LM_Y2=256, .UDM_LM_Y1=384, .UDM_LM_Y0=511, .rsv_27=0}},
    .luma_lut2 ={.bits={.UDM_LM_Y5=32, .UDM_LM_Y4=64, .UDM_LM_Y3=128, .rsv_27=0}},
    .sl_ctl    ={.bits={.UDM_SL_EN=0, .UDM_SL_HR=16, .UDM_SL_Y2=255, .UDM_SL_Y1=255, .rsv_22=0}},
    .hftd_ctl  ={.bits={.UDM_CORE_TH1=0, .UDM_HD_GN2=16, .UDM_HD_GN1=16, .UDM_HT_GN2=16, .UDM_HT_GN1=16, .rsv_28=0}},
    .nr_str    ={.bits={.UDM_N2_STR=0, .UDM_N1_STR=0, .UDM_N0_STR=0, .UDM_XTK_SL=5, .UDM_XTK_OFST=32, .UDM_XTK_RAT=16}},
    .nr_act    ={.bits={.UDM_NGR=0, .UDM_NSL=5, .UDM_N2_OFST=0, .UDM_N1_OFST=0, .UDM_N0_OFST=0}},
    .hf_str    ={.bits={.UDM_CORE_TH2=0, .UDM_HI_RAT=0, .UDM_H3_GN=0, .UDM_H2_GN=0, .UDM_H1_GN=0, .UDM_HA_STR=0}},
    .hf_act1   ={.bits={.UDM_H2_UPB=220, .UDM_H2_LWB=52, .UDM_H1_UPB=80, .UDM_H1_LWB=20}},
    .hf_act2   ={.bits={.UDM_HSLL=5, .UDM_HSLR=5, .UDM_H3_UPB=255, .UDM_H3_LWB=52, .rsv_24=0}},
    .clip      ={.bits={.UDM_CLIP_TH=100, .UDM_UN_TH=32, .UDM_OV_TH=223, .rsv_24=0}},
    .dsb       ={.bits={.UDM_SC_RAT=0, .UDM_SL_RAT=0, .UDM_FL_MODE=0, .rsv_11=0}},
    .p1_act    ={.bits={.UDM_P1_UPB=85, .UDM_P1_LWB=85, .rsv_16=0}},
    .lr_rat    ={.bits={.UDM_LR_RAT=15, .rsv_4=0}},
    .hftd_ctl2 ={.bits={.UDM_HD_GN3=16, .UDM_HFRB_GN=16, .rsv_12=0}},
    .est_ctl   ={.bits={.UDM_P2_CLIP=0, .UDM_P1_BLD=0, .rsv_6=0}},
    .int_ctl   ={.bits={.UDM_INT_LTH=3, .UDM_INT_CDTH=5, .rsv_8=0}},
    .ee        ={.bits={.UDM_HPOS_GN=16, .UDM_HNEG_GN=16, .rsv_10=0}}

};
const ISP_NVRAM_UDM_T gc13a0mipiraw_UDM_0106 = {
        .intp_crs  ={.bits={.UDM_CDG_SL=4, .UDM_CDG_OFST=20, .UDM_CDG_RAT=16, .UDM_CD_KNL=0, .rsv_18=0, .UDM_BYP=0, .UDM_MN_MODE=0}},
    .intp_nat  ={.bits={.UDM_HL_OFST=63, .UDM_L0_SL=6, .UDM_L0_OFST=0, .UDM_CD_SLL=3, .UDM_CD_SLC=10, .rsv_30=0}},
    .intp_aug  ={.bits={.UDM_DN_OFST=0, .UDM_L2_SL=6, .UDM_L2_OFST=0, .UDM_L1_SL=6, .UDM_L1_OFST=0}},
    .luma_lut1 ={.bits={.UDM_LM_Y2=256, .UDM_LM_Y1=384, .UDM_LM_Y0=511, .rsv_27=0}},
    .luma_lut2 ={.bits={.UDM_LM_Y5=32, .UDM_LM_Y4=64, .UDM_LM_Y3=128, .rsv_27=0}},
    .sl_ctl    ={.bits={.UDM_SL_EN=0, .UDM_SL_HR=16, .UDM_SL_Y2=255, .UDM_SL_Y1=255, .rsv_22=0}},
    .hftd_ctl  ={.bits={.UDM_CORE_TH1=0, .UDM_HD_GN2=16, .UDM_HD_GN1=16, .UDM_HT_GN2=16, .UDM_HT_GN1=16, .rsv_28=0}},
    .nr_str    ={.bits={.UDM_N2_STR=0, .UDM_N1_STR=0, .UDM_N0_STR=0, .UDM_XTK_SL=5, .UDM_XTK_OFST=32, .UDM_XTK_RAT=16}},
    .nr_act    ={.bits={.UDM_NGR=0, .UDM_NSL=5, .UDM_N2_OFST=0, .UDM_N1_OFST=0, .UDM_N0_OFST=0}},
    .hf_str    ={.bits={.UDM_CORE_TH2=0, .UDM_HI_RAT=0, .UDM_H3_GN=0, .UDM_H2_GN=0, .UDM_H1_GN=0, .UDM_HA_STR=0}},
    .hf_act1   ={.bits={.UDM_H2_UPB=220, .UDM_H2_LWB=52, .UDM_H1_UPB=80, .UDM_H1_LWB=20}},
    .hf_act2   ={.bits={.UDM_HSLL=5, .UDM_HSLR=5, .UDM_H3_UPB=255, .UDM_H3_LWB=52, .rsv_24=0}},
    .clip      ={.bits={.UDM_CLIP_TH=100, .UDM_UN_TH=32, .UDM_OV_TH=223, .rsv_24=0}},
    .dsb       ={.bits={.UDM_SC_RAT=0, .UDM_SL_RAT=0, .UDM_FL_MODE=0, .rsv_11=0}},
    .p1_act    ={.bits={.UDM_P1_UPB=85, .UDM_P1_LWB=85, .rsv_16=0}},
    .lr_rat    ={.bits={.UDM_LR_RAT=15, .rsv_4=0}},
    .hftd_ctl2 ={.bits={.UDM_HD_GN3=16, .UDM_HFRB_GN=16, .rsv_12=0}},
    .est_ctl   ={.bits={.UDM_P2_CLIP=0, .UDM_P1_BLD=0, .rsv_6=0}},
    .int_ctl   ={.bits={.UDM_INT_LTH=3, .UDM_INT_CDTH=5, .rsv_8=0}},
    .ee        ={.bits={.UDM_HPOS_GN=16, .UDM_HNEG_GN=16, .rsv_10=0}}

};
const ISP_NVRAM_UDM_T gc13a0mipiraw_UDM_0107 = {
        .intp_crs  ={.bits={.UDM_CDG_SL=4, .UDM_CDG_OFST=20, .UDM_CDG_RAT=16, .UDM_CD_KNL=0, .rsv_18=0, .UDM_BYP=0, .UDM_MN_MODE=0}},
    .intp_nat  ={.bits={.UDM_HL_OFST=63, .UDM_L0_SL=6, .UDM_L0_OFST=0, .UDM_CD_SLL=3, .UDM_CD_SLC=10, .rsv_30=0}},
    .intp_aug  ={.bits={.UDM_DN_OFST=0, .UDM_L2_SL=6, .UDM_L2_OFST=0, .UDM_L1_SL=6, .UDM_L1_OFST=0}},
    .luma_lut1 ={.bits={.UDM_LM_Y2=256, .UDM_LM_Y1=384, .UDM_LM_Y0=511, .rsv_27=0}},
    .luma_lut2 ={.bits={.UDM_LM_Y5=32, .UDM_LM_Y4=64, .UDM_LM_Y3=128, .rsv_27=0}},
    .sl_ctl    ={.bits={.UDM_SL_EN=0, .UDM_SL_HR=16, .UDM_SL_Y2=255, .UDM_SL_Y1=255, .rsv_22=0}},
    .hftd_ctl  ={.bits={.UDM_CORE_TH1=0, .UDM_HD_GN2=16, .UDM_HD_GN1=16, .UDM_HT_GN2=16, .UDM_HT_GN1=16, .rsv_28=0}},
    .nr_str    ={.bits={.UDM_N2_STR=0, .UDM_N1_STR=0, .UDM_N0_STR=0, .UDM_XTK_SL=5, .UDM_XTK_OFST=32, .UDM_XTK_RAT=16}},
    .nr_act    ={.bits={.UDM_NGR=0, .UDM_NSL=5, .UDM_N2_OFST=0, .UDM_N1_OFST=0, .UDM_N0_OFST=0}},
    .hf_str    ={.bits={.UDM_CORE_TH2=0, .UDM_HI_RAT=0, .UDM_H3_GN=0, .UDM_H2_GN=0, .UDM_H1_GN=0, .UDM_HA_STR=0}},
    .hf_act1   ={.bits={.UDM_H2_UPB=220, .UDM_H2_LWB=52, .UDM_H1_UPB=80, .UDM_H1_LWB=20}},
    .hf_act2   ={.bits={.UDM_HSLL=5, .UDM_HSLR=5, .UDM_H3_UPB=255, .UDM_H3_LWB=52, .rsv_24=0}},
    .clip      ={.bits={.UDM_CLIP_TH=100, .UDM_UN_TH=32, .UDM_OV_TH=223, .rsv_24=0}},
    .dsb       ={.bits={.UDM_SC_RAT=0, .UDM_SL_RAT=0, .UDM_FL_MODE=0, .rsv_11=0}},
    .p1_act    ={.bits={.UDM_P1_UPB=85, .UDM_P1_LWB=85, .rsv_16=0}},
    .lr_rat    ={.bits={.UDM_LR_RAT=15, .rsv_4=0}},
    .hftd_ctl2 ={.bits={.UDM_HD_GN3=16, .UDM_HFRB_GN=16, .rsv_12=0}},
    .est_ctl   ={.bits={.UDM_P2_CLIP=0, .UDM_P1_BLD=0, .rsv_6=0}},
    .int_ctl   ={.bits={.UDM_INT_LTH=3, .UDM_INT_CDTH=5, .rsv_8=0}},
    .ee        ={.bits={.UDM_HPOS_GN=16, .UDM_HNEG_GN=16, .rsv_10=0}}

};
const ISP_NVRAM_UDM_T gc13a0mipiraw_UDM_0108 = {
        .intp_crs  ={.bits={.UDM_CDG_SL=4, .UDM_CDG_OFST=20, .UDM_CDG_RAT=16, .UDM_CD_KNL=0, .rsv_18=0, .UDM_BYP=0, .UDM_MN_MODE=0}},
    .intp_nat  ={.bits={.UDM_HL_OFST=63, .UDM_L0_SL=6, .UDM_L0_OFST=0, .UDM_CD_SLL=3, .UDM_CD_SLC=10, .rsv_30=0}},
    .intp_aug  ={.bits={.UDM_DN_OFST=0, .UDM_L2_SL=6, .UDM_L2_OFST=0, .UDM_L1_SL=6, .UDM_L1_OFST=0}},
    .luma_lut1 ={.bits={.UDM_LM_Y2=256, .UDM_LM_Y1=384, .UDM_LM_Y0=511, .rsv_27=0}},
    .luma_lut2 ={.bits={.UDM_LM_Y5=32, .UDM_LM_Y4=64, .UDM_LM_Y3=128, .rsv_27=0}},
    .sl_ctl    ={.bits={.UDM_SL_EN=0, .UDM_SL_HR=16, .UDM_SL_Y2=255, .UDM_SL_Y1=255, .rsv_22=0}},
    .hftd_ctl  ={.bits={.UDM_CORE_TH1=0, .UDM_HD_GN2=16, .UDM_HD_GN1=16, .UDM_HT_GN2=16, .UDM_HT_GN1=16, .rsv_28=0}},
    .nr_str    ={.bits={.UDM_N2_STR=0, .UDM_N1_STR=0, .UDM_N0_STR=0, .UDM_XTK_SL=5, .UDM_XTK_OFST=32, .UDM_XTK_RAT=16}},
    .nr_act    ={.bits={.UDM_NGR=0, .UDM_NSL=5, .UDM_N2_OFST=0, .UDM_N1_OFST=0, .UDM_N0_OFST=0}},
    .hf_str    ={.bits={.UDM_CORE_TH2=0, .UDM_HI_RAT=0, .UDM_H3_GN=0, .UDM_H2_GN=0, .UDM_H1_GN=0, .UDM_HA_STR=0}},
    .hf_act1   ={.bits={.UDM_H2_UPB=220, .UDM_H2_LWB=52, .UDM_H1_UPB=80, .UDM_H1_LWB=20}},
    .hf_act2   ={.bits={.UDM_HSLL=5, .UDM_HSLR=5, .UDM_H3_UPB=255, .UDM_H3_LWB=52, .rsv_24=0}},
    .clip      ={.bits={.UDM_CLIP_TH=100, .UDM_UN_TH=32, .UDM_OV_TH=223, .rsv_24=0}},
    .dsb       ={.bits={.UDM_SC_RAT=0, .UDM_SL_RAT=0, .UDM_FL_MODE=0, .rsv_11=0}},
    .p1_act    ={.bits={.UDM_P1_UPB=85, .UDM_P1_LWB=85, .rsv_16=0}},
    .lr_rat    ={.bits={.UDM_LR_RAT=15, .rsv_4=0}},
    .hftd_ctl2 ={.bits={.UDM_HD_GN3=16, .UDM_HFRB_GN=16, .rsv_12=0}},
    .est_ctl   ={.bits={.UDM_P2_CLIP=0, .UDM_P1_BLD=0, .rsv_6=0}},
    .int_ctl   ={.bits={.UDM_INT_LTH=3, .UDM_INT_CDTH=5, .rsv_8=0}},
    .ee        ={.bits={.UDM_HPOS_GN=16, .UDM_HNEG_GN=16, .rsv_10=0}}

};
const ISP_NVRAM_UDM_T gc13a0mipiraw_UDM_0109 = {
        .intp_crs  ={.bits={.UDM_CDG_SL=4, .UDM_CDG_OFST=20, .UDM_CDG_RAT=16, .UDM_CD_KNL=0, .rsv_18=0, .UDM_BYP=0, .UDM_MN_MODE=0}},
    .intp_nat  ={.bits={.UDM_HL_OFST=63, .UDM_L0_SL=6, .UDM_L0_OFST=0, .UDM_CD_SLL=3, .UDM_CD_SLC=10, .rsv_30=0}},
    .intp_aug  ={.bits={.UDM_DN_OFST=0, .UDM_L2_SL=6, .UDM_L2_OFST=0, .UDM_L1_SL=6, .UDM_L1_OFST=0}},
    .luma_lut1 ={.bits={.UDM_LM_Y2=256, .UDM_LM_Y1=384, .UDM_LM_Y0=511, .rsv_27=0}},
    .luma_lut2 ={.bits={.UDM_LM_Y5=32, .UDM_LM_Y4=64, .UDM_LM_Y3=128, .rsv_27=0}},
    .sl_ctl    ={.bits={.UDM_SL_EN=0, .UDM_SL_HR=16, .UDM_SL_Y2=255, .UDM_SL_Y1=255, .rsv_22=0}},
    .hftd_ctl  ={.bits={.UDM_CORE_TH1=0, .UDM_HD_GN2=16, .UDM_HD_GN1=16, .UDM_HT_GN2=16, .UDM_HT_GN1=16, .rsv_28=0}},
    .nr_str    ={.bits={.UDM_N2_STR=0, .UDM_N1_STR=0, .UDM_N0_STR=0, .UDM_XTK_SL=5, .UDM_XTK_OFST=32, .UDM_XTK_RAT=16}},
    .nr_act    ={.bits={.UDM_NGR=0, .UDM_NSL=5, .UDM_N2_OFST=0, .UDM_N1_OFST=0, .UDM_N0_OFST=0}},
    .hf_str    ={.bits={.UDM_CORE_TH2=0, .UDM_HI_RAT=0, .UDM_H3_GN=0, .UDM_H2_GN=0, .UDM_H1_GN=0, .UDM_HA_STR=0}},
    .hf_act1   ={.bits={.UDM_H2_UPB=220, .UDM_H2_LWB=52, .UDM_H1_UPB=80, .UDM_H1_LWB=20}},
    .hf_act2   ={.bits={.UDM_HSLL=5, .UDM_HSLR=5, .UDM_H3_UPB=255, .UDM_H3_LWB=52, .rsv_24=0}},
    .clip      ={.bits={.UDM_CLIP_TH=100, .UDM_UN_TH=32, .UDM_OV_TH=223, .rsv_24=0}},
    .dsb       ={.bits={.UDM_SC_RAT=0, .UDM_SL_RAT=0, .UDM_FL_MODE=0, .rsv_11=0}},
    .p1_act    ={.bits={.UDM_P1_UPB=85, .UDM_P1_LWB=85, .rsv_16=0}},
    .lr_rat    ={.bits={.UDM_LR_RAT=15, .rsv_4=0}},
    .hftd_ctl2 ={.bits={.UDM_HD_GN3=16, .UDM_HFRB_GN=16, .rsv_12=0}},
    .est_ctl   ={.bits={.UDM_P2_CLIP=0, .UDM_P1_BLD=0, .rsv_6=0}},
    .int_ctl   ={.bits={.UDM_INT_LTH=3, .UDM_INT_CDTH=5, .rsv_8=0}},
    .ee        ={.bits={.UDM_HPOS_GN=16, .UDM_HNEG_GN=16, .rsv_10=0}}

};
const ISP_NVRAM_UDM_T gc13a0mipiraw_UDM_0110 = {
        .intp_crs  ={.bits={.UDM_CDG_SL=4, .UDM_CDG_OFST=20, .UDM_CDG_RAT=16, .UDM_CD_KNL=0, .rsv_18=0, .UDM_BYP=0, .UDM_MN_MODE=0}},
    .intp_nat  ={.bits={.UDM_HL_OFST=63, .UDM_L0_SL=6, .UDM_L0_OFST=0, .UDM_CD_SLL=3, .UDM_CD_SLC=10, .rsv_30=0}},
    .intp_aug  ={.bits={.UDM_DN_OFST=0, .UDM_L2_SL=6, .UDM_L2_OFST=0, .UDM_L1_SL=6, .UDM_L1_OFST=0}},
    .luma_lut1 ={.bits={.UDM_LM_Y2=256, .UDM_LM_Y1=384, .UDM_LM_Y0=511, .rsv_27=0}},
    .luma_lut2 ={.bits={.UDM_LM_Y5=32, .UDM_LM_Y4=64, .UDM_LM_Y3=128, .rsv_27=0}},
    .sl_ctl    ={.bits={.UDM_SL_EN=0, .UDM_SL_HR=16, .UDM_SL_Y2=255, .UDM_SL_Y1=255, .rsv_22=0}},
    .hftd_ctl  ={.bits={.UDM_CORE_TH1=0, .UDM_HD_GN2=16, .UDM_HD_GN1=16, .UDM_HT_GN2=16, .UDM_HT_GN1=16, .rsv_28=0}},
    .nr_str    ={.bits={.UDM_N2_STR=0, .UDM_N1_STR=0, .UDM_N0_STR=0, .UDM_XTK_SL=5, .UDM_XTK_OFST=32, .UDM_XTK_RAT=16}},
    .nr_act    ={.bits={.UDM_NGR=0, .UDM_NSL=5, .UDM_N2_OFST=0, .UDM_N1_OFST=0, .UDM_N0_OFST=0}},
    .hf_str    ={.bits={.UDM_CORE_TH2=0, .UDM_HI_RAT=0, .UDM_H3_GN=0, .UDM_H2_GN=0, .UDM_H1_GN=0, .UDM_HA_STR=0}},
    .hf_act1   ={.bits={.UDM_H2_UPB=220, .UDM_H2_LWB=52, .UDM_H1_UPB=80, .UDM_H1_LWB=20}},
    .hf_act2   ={.bits={.UDM_HSLL=5, .UDM_HSLR=5, .UDM_H3_UPB=255, .UDM_H3_LWB=52, .rsv_24=0}},
    .clip      ={.bits={.UDM_CLIP_TH=100, .UDM_UN_TH=32, .UDM_OV_TH=223, .rsv_24=0}},
    .dsb       ={.bits={.UDM_SC_RAT=0, .UDM_SL_RAT=0, .UDM_FL_MODE=0, .rsv_11=0}},
    .p1_act    ={.bits={.UDM_P1_UPB=85, .UDM_P1_LWB=85, .rsv_16=0}},
    .lr_rat    ={.bits={.UDM_LR_RAT=15, .rsv_4=0}},
    .hftd_ctl2 ={.bits={.UDM_HD_GN3=16, .UDM_HFRB_GN=16, .rsv_12=0}},
    .est_ctl   ={.bits={.UDM_P2_CLIP=0, .UDM_P1_BLD=0, .rsv_6=0}},
    .int_ctl   ={.bits={.UDM_INT_LTH=3, .UDM_INT_CDTH=5, .rsv_8=0}},
    .ee        ={.bits={.UDM_HPOS_GN=16, .UDM_HNEG_GN=16, .rsv_10=0}}

};
const ISP_NVRAM_UDM_T gc13a0mipiraw_UDM_0111 = {
        .intp_crs  ={.bits={.UDM_CDG_SL=4, .UDM_CDG_OFST=20, .UDM_CDG_RAT=16, .UDM_CD_KNL=0, .rsv_18=0, .UDM_BYP=0, .UDM_MN_MODE=0}},
    .intp_nat  ={.bits={.UDM_HL_OFST=63, .UDM_L0_SL=6, .UDM_L0_OFST=0, .UDM_CD_SLL=3, .UDM_CD_SLC=10, .rsv_30=0}},
    .intp_aug  ={.bits={.UDM_DN_OFST=0, .UDM_L2_SL=6, .UDM_L2_OFST=0, .UDM_L1_SL=6, .UDM_L1_OFST=0}},
    .luma_lut1 ={.bits={.UDM_LM_Y2=256, .UDM_LM_Y1=384, .UDM_LM_Y0=511, .rsv_27=0}},
    .luma_lut2 ={.bits={.UDM_LM_Y5=32, .UDM_LM_Y4=64, .UDM_LM_Y3=128, .rsv_27=0}},
    .sl_ctl    ={.bits={.UDM_SL_EN=0, .UDM_SL_HR=16, .UDM_SL_Y2=255, .UDM_SL_Y1=255, .rsv_22=0}},
    .hftd_ctl  ={.bits={.UDM_CORE_TH1=0, .UDM_HD_GN2=16, .UDM_HD_GN1=16, .UDM_HT_GN2=16, .UDM_HT_GN1=16, .rsv_28=0}},
    .nr_str    ={.bits={.UDM_N2_STR=0, .UDM_N1_STR=0, .UDM_N0_STR=0, .UDM_XTK_SL=5, .UDM_XTK_OFST=32, .UDM_XTK_RAT=16}},
    .nr_act    ={.bits={.UDM_NGR=0, .UDM_NSL=5, .UDM_N2_OFST=0, .UDM_N1_OFST=0, .UDM_N0_OFST=0}},
    .hf_str    ={.bits={.UDM_CORE_TH2=0, .UDM_HI_RAT=0, .UDM_H3_GN=0, .UDM_H2_GN=0, .UDM_H1_GN=0, .UDM_HA_STR=0}},
    .hf_act1   ={.bits={.UDM_H2_UPB=220, .UDM_H2_LWB=52, .UDM_H1_UPB=80, .UDM_H1_LWB=20}},
    .hf_act2   ={.bits={.UDM_HSLL=5, .UDM_HSLR=5, .UDM_H3_UPB=255, .UDM_H3_LWB=52, .rsv_24=0}},
    .clip      ={.bits={.UDM_CLIP_TH=100, .UDM_UN_TH=32, .UDM_OV_TH=223, .rsv_24=0}},
    .dsb       ={.bits={.UDM_SC_RAT=0, .UDM_SL_RAT=0, .UDM_FL_MODE=0, .rsv_11=0}},
    .p1_act    ={.bits={.UDM_P1_UPB=85, .UDM_P1_LWB=85, .rsv_16=0}},
    .lr_rat    ={.bits={.UDM_LR_RAT=15, .rsv_4=0}},
    .hftd_ctl2 ={.bits={.UDM_HD_GN3=16, .UDM_HFRB_GN=16, .rsv_12=0}},
    .est_ctl   ={.bits={.UDM_P2_CLIP=0, .UDM_P1_BLD=0, .rsv_6=0}},
    .int_ctl   ={.bits={.UDM_INT_LTH=3, .UDM_INT_CDTH=5, .rsv_8=0}},
    .ee        ={.bits={.UDM_HPOS_GN=16, .UDM_HNEG_GN=16, .rsv_10=0}}

};
const ISP_NVRAM_UDM_T gc13a0mipiraw_UDM_0112 = {
        .intp_crs  ={.bits={.UDM_CDG_SL=4, .UDM_CDG_OFST=20, .UDM_CDG_RAT=16, .UDM_CD_KNL=0, .rsv_18=0, .UDM_BYP=0, .UDM_MN_MODE=0}},
    .intp_nat  ={.bits={.UDM_HL_OFST=63, .UDM_L0_SL=6, .UDM_L0_OFST=0, .UDM_CD_SLL=3, .UDM_CD_SLC=10, .rsv_30=0}},
    .intp_aug  ={.bits={.UDM_DN_OFST=0, .UDM_L2_SL=6, .UDM_L2_OFST=0, .UDM_L1_SL=6, .UDM_L1_OFST=0}},
    .luma_lut1 ={.bits={.UDM_LM_Y2=256, .UDM_LM_Y1=384, .UDM_LM_Y0=511, .rsv_27=0}},
    .luma_lut2 ={.bits={.UDM_LM_Y5=32, .UDM_LM_Y4=64, .UDM_LM_Y3=128, .rsv_27=0}},
    .sl_ctl    ={.bits={.UDM_SL_EN=0, .UDM_SL_HR=16, .UDM_SL_Y2=255, .UDM_SL_Y1=255, .rsv_22=0}},
    .hftd_ctl  ={.bits={.UDM_CORE_TH1=0, .UDM_HD_GN2=16, .UDM_HD_GN1=16, .UDM_HT_GN2=16, .UDM_HT_GN1=16, .rsv_28=0}},
    .nr_str    ={.bits={.UDM_N2_STR=0, .UDM_N1_STR=0, .UDM_N0_STR=0, .UDM_XTK_SL=5, .UDM_XTK_OFST=32, .UDM_XTK_RAT=16}},
    .nr_act    ={.bits={.UDM_NGR=0, .UDM_NSL=5, .UDM_N2_OFST=0, .UDM_N1_OFST=0, .UDM_N0_OFST=0}},
    .hf_str    ={.bits={.UDM_CORE_TH2=0, .UDM_HI_RAT=0, .UDM_H3_GN=0, .UDM_H2_GN=0, .UDM_H1_GN=0, .UDM_HA_STR=0}},
    .hf_act1   ={.bits={.UDM_H2_UPB=220, .UDM_H2_LWB=52, .UDM_H1_UPB=80, .UDM_H1_LWB=20}},
    .hf_act2   ={.bits={.UDM_HSLL=5, .UDM_HSLR=5, .UDM_H3_UPB=255, .UDM_H3_LWB=52, .rsv_24=0}},
    .clip      ={.bits={.UDM_CLIP_TH=100, .UDM_UN_TH=32, .UDM_OV_TH=223, .rsv_24=0}},
    .dsb       ={.bits={.UDM_SC_RAT=0, .UDM_SL_RAT=0, .UDM_FL_MODE=0, .rsv_11=0}},
    .p1_act    ={.bits={.UDM_P1_UPB=85, .UDM_P1_LWB=85, .rsv_16=0}},
    .lr_rat    ={.bits={.UDM_LR_RAT=15, .rsv_4=0}},
    .hftd_ctl2 ={.bits={.UDM_HD_GN3=16, .UDM_HFRB_GN=16, .rsv_12=0}},
    .est_ctl   ={.bits={.UDM_P2_CLIP=0, .UDM_P1_BLD=0, .rsv_6=0}},
    .int_ctl   ={.bits={.UDM_INT_LTH=3, .UDM_INT_CDTH=5, .rsv_8=0}},
    .ee        ={.bits={.UDM_HPOS_GN=16, .UDM_HNEG_GN=16, .rsv_10=0}}

};
const ISP_NVRAM_UDM_T gc13a0mipiraw_UDM_0113 = {
        .intp_crs  ={.bits={.UDM_CDG_SL=4, .UDM_CDG_OFST=20, .UDM_CDG_RAT=16, .UDM_CD_KNL=0, .rsv_18=0, .UDM_BYP=0, .UDM_MN_MODE=0}},
    .intp_nat  ={.bits={.UDM_HL_OFST=63, .UDM_L0_SL=6, .UDM_L0_OFST=0, .UDM_CD_SLL=3, .UDM_CD_SLC=10, .rsv_30=0}},
    .intp_aug  ={.bits={.UDM_DN_OFST=0, .UDM_L2_SL=6, .UDM_L2_OFST=0, .UDM_L1_SL=6, .UDM_L1_OFST=0}},
    .luma_lut1 ={.bits={.UDM_LM_Y2=256, .UDM_LM_Y1=384, .UDM_LM_Y0=511, .rsv_27=0}},
    .luma_lut2 ={.bits={.UDM_LM_Y5=32, .UDM_LM_Y4=64, .UDM_LM_Y3=128, .rsv_27=0}},
    .sl_ctl    ={.bits={.UDM_SL_EN=0, .UDM_SL_HR=16, .UDM_SL_Y2=255, .UDM_SL_Y1=255, .rsv_22=0}},
    .hftd_ctl  ={.bits={.UDM_CORE_TH1=0, .UDM_HD_GN2=16, .UDM_HD_GN1=16, .UDM_HT_GN2=16, .UDM_HT_GN1=16, .rsv_28=0}},
    .nr_str    ={.bits={.UDM_N2_STR=0, .UDM_N1_STR=0, .UDM_N0_STR=0, .UDM_XTK_SL=5, .UDM_XTK_OFST=32, .UDM_XTK_RAT=16}},
    .nr_act    ={.bits={.UDM_NGR=0, .UDM_NSL=5, .UDM_N2_OFST=0, .UDM_N1_OFST=0, .UDM_N0_OFST=0}},
    .hf_str    ={.bits={.UDM_CORE_TH2=0, .UDM_HI_RAT=0, .UDM_H3_GN=0, .UDM_H2_GN=0, .UDM_H1_GN=0, .UDM_HA_STR=0}},
    .hf_act1   ={.bits={.UDM_H2_UPB=220, .UDM_H2_LWB=52, .UDM_H1_UPB=80, .UDM_H1_LWB=20}},
    .hf_act2   ={.bits={.UDM_HSLL=5, .UDM_HSLR=5, .UDM_H3_UPB=255, .UDM_H3_LWB=52, .rsv_24=0}},
    .clip      ={.bits={.UDM_CLIP_TH=100, .UDM_UN_TH=32, .UDM_OV_TH=223, .rsv_24=0}},
    .dsb       ={.bits={.UDM_SC_RAT=0, .UDM_SL_RAT=0, .UDM_FL_MODE=0, .rsv_11=0}},
    .p1_act    ={.bits={.UDM_P1_UPB=85, .UDM_P1_LWB=85, .rsv_16=0}},
    .lr_rat    ={.bits={.UDM_LR_RAT=15, .rsv_4=0}},
    .hftd_ctl2 ={.bits={.UDM_HD_GN3=16, .UDM_HFRB_GN=16, .rsv_12=0}},
    .est_ctl   ={.bits={.UDM_P2_CLIP=0, .UDM_P1_BLD=0, .rsv_6=0}},
    .int_ctl   ={.bits={.UDM_INT_LTH=3, .UDM_INT_CDTH=5, .rsv_8=0}},
    .ee        ={.bits={.UDM_HPOS_GN=16, .UDM_HNEG_GN=16, .rsv_10=0}}

};
const ISP_NVRAM_UDM_T gc13a0mipiraw_UDM_0114 = {
        .intp_crs  ={.bits={.UDM_CDG_SL=4, .UDM_CDG_OFST=20, .UDM_CDG_RAT=16, .UDM_CD_KNL=0, .rsv_18=0, .UDM_BYP=0, .UDM_MN_MODE=0}},
    .intp_nat  ={.bits={.UDM_HL_OFST=63, .UDM_L0_SL=6, .UDM_L0_OFST=0, .UDM_CD_SLL=3, .UDM_CD_SLC=10, .rsv_30=0}},
    .intp_aug  ={.bits={.UDM_DN_OFST=0, .UDM_L2_SL=6, .UDM_L2_OFST=0, .UDM_L1_SL=6, .UDM_L1_OFST=0}},
    .luma_lut1 ={.bits={.UDM_LM_Y2=256, .UDM_LM_Y1=384, .UDM_LM_Y0=511, .rsv_27=0}},
    .luma_lut2 ={.bits={.UDM_LM_Y5=32, .UDM_LM_Y4=64, .UDM_LM_Y3=128, .rsv_27=0}},
    .sl_ctl    ={.bits={.UDM_SL_EN=0, .UDM_SL_HR=16, .UDM_SL_Y2=255, .UDM_SL_Y1=255, .rsv_22=0}},
    .hftd_ctl  ={.bits={.UDM_CORE_TH1=0, .UDM_HD_GN2=16, .UDM_HD_GN1=16, .UDM_HT_GN2=16, .UDM_HT_GN1=16, .rsv_28=0}},
    .nr_str    ={.bits={.UDM_N2_STR=0, .UDM_N1_STR=0, .UDM_N0_STR=0, .UDM_XTK_SL=5, .UDM_XTK_OFST=32, .UDM_XTK_RAT=16}},
    .nr_act    ={.bits={.UDM_NGR=0, .UDM_NSL=5, .UDM_N2_OFST=0, .UDM_N1_OFST=0, .UDM_N0_OFST=0}},
    .hf_str    ={.bits={.UDM_CORE_TH2=0, .UDM_HI_RAT=0, .UDM_H3_GN=0, .UDM_H2_GN=0, .UDM_H1_GN=0, .UDM_HA_STR=0}},
    .hf_act1   ={.bits={.UDM_H2_UPB=220, .UDM_H2_LWB=52, .UDM_H1_UPB=80, .UDM_H1_LWB=20}},
    .hf_act2   ={.bits={.UDM_HSLL=5, .UDM_HSLR=5, .UDM_H3_UPB=255, .UDM_H3_LWB=52, .rsv_24=0}},
    .clip      ={.bits={.UDM_CLIP_TH=100, .UDM_UN_TH=32, .UDM_OV_TH=223, .rsv_24=0}},
    .dsb       ={.bits={.UDM_SC_RAT=0, .UDM_SL_RAT=0, .UDM_FL_MODE=0, .rsv_11=0}},
    .p1_act    ={.bits={.UDM_P1_UPB=85, .UDM_P1_LWB=85, .rsv_16=0}},
    .lr_rat    ={.bits={.UDM_LR_RAT=15, .rsv_4=0}},
    .hftd_ctl2 ={.bits={.UDM_HD_GN3=16, .UDM_HFRB_GN=16, .rsv_12=0}},
    .est_ctl   ={.bits={.UDM_P2_CLIP=0, .UDM_P1_BLD=0, .rsv_6=0}},
    .int_ctl   ={.bits={.UDM_INT_LTH=3, .UDM_INT_CDTH=5, .rsv_8=0}},
    .ee        ={.bits={.UDM_HPOS_GN=16, .UDM_HNEG_GN=16, .rsv_10=0}}

};
const ISP_NVRAM_UDM_T gc13a0mipiraw_UDM_0115 = {
        .intp_crs  ={.bits={.UDM_CDG_SL=4, .UDM_CDG_OFST=20, .UDM_CDG_RAT=16, .UDM_CD_KNL=0, .rsv_18=0, .UDM_BYP=0, .UDM_MN_MODE=0}},
    .intp_nat  ={.bits={.UDM_HL_OFST=63, .UDM_L0_SL=6, .UDM_L0_OFST=0, .UDM_CD_SLL=3, .UDM_CD_SLC=10, .rsv_30=0}},
    .intp_aug  ={.bits={.UDM_DN_OFST=0, .UDM_L2_SL=6, .UDM_L2_OFST=0, .UDM_L1_SL=6, .UDM_L1_OFST=0}},
    .luma_lut1 ={.bits={.UDM_LM_Y2=256, .UDM_LM_Y1=384, .UDM_LM_Y0=511, .rsv_27=0}},
    .luma_lut2 ={.bits={.UDM_LM_Y5=32, .UDM_LM_Y4=64, .UDM_LM_Y3=128, .rsv_27=0}},
    .sl_ctl    ={.bits={.UDM_SL_EN=0, .UDM_SL_HR=16, .UDM_SL_Y2=255, .UDM_SL_Y1=255, .rsv_22=0}},
    .hftd_ctl  ={.bits={.UDM_CORE_TH1=0, .UDM_HD_GN2=16, .UDM_HD_GN1=16, .UDM_HT_GN2=16, .UDM_HT_GN1=16, .rsv_28=0}},
    .nr_str    ={.bits={.UDM_N2_STR=0, .UDM_N1_STR=0, .UDM_N0_STR=0, .UDM_XTK_SL=5, .UDM_XTK_OFST=32, .UDM_XTK_RAT=16}},
    .nr_act    ={.bits={.UDM_NGR=0, .UDM_NSL=5, .UDM_N2_OFST=0, .UDM_N1_OFST=0, .UDM_N0_OFST=0}},
    .hf_str    ={.bits={.UDM_CORE_TH2=0, .UDM_HI_RAT=0, .UDM_H3_GN=0, .UDM_H2_GN=0, .UDM_H1_GN=0, .UDM_HA_STR=0}},
    .hf_act1   ={.bits={.UDM_H2_UPB=220, .UDM_H2_LWB=52, .UDM_H1_UPB=80, .UDM_H1_LWB=20}},
    .hf_act2   ={.bits={.UDM_HSLL=5, .UDM_HSLR=5, .UDM_H3_UPB=255, .UDM_H3_LWB=52, .rsv_24=0}},
    .clip      ={.bits={.UDM_CLIP_TH=100, .UDM_UN_TH=32, .UDM_OV_TH=223, .rsv_24=0}},
    .dsb       ={.bits={.UDM_SC_RAT=0, .UDM_SL_RAT=0, .UDM_FL_MODE=0, .rsv_11=0}},
    .p1_act    ={.bits={.UDM_P1_UPB=85, .UDM_P1_LWB=85, .rsv_16=0}},
    .lr_rat    ={.bits={.UDM_LR_RAT=15, .rsv_4=0}},
    .hftd_ctl2 ={.bits={.UDM_HD_GN3=16, .UDM_HFRB_GN=16, .rsv_12=0}},
    .est_ctl   ={.bits={.UDM_P2_CLIP=0, .UDM_P1_BLD=0, .rsv_6=0}},
    .int_ctl   ={.bits={.UDM_INT_LTH=3, .UDM_INT_CDTH=5, .rsv_8=0}},
    .ee        ={.bits={.UDM_HPOS_GN=16, .UDM_HNEG_GN=16, .rsv_10=0}}

};
const ISP_NVRAM_UDM_T gc13a0mipiraw_UDM_0116 = {
        .intp_crs  ={.bits={.UDM_CDG_SL=4, .UDM_CDG_OFST=20, .UDM_CDG_RAT=16, .UDM_CD_KNL=0, .rsv_18=0, .UDM_BYP=0, .UDM_MN_MODE=0}},
    .intp_nat  ={.bits={.UDM_HL_OFST=63, .UDM_L0_SL=6, .UDM_L0_OFST=0, .UDM_CD_SLL=3, .UDM_CD_SLC=10, .rsv_30=0}},
    .intp_aug  ={.bits={.UDM_DN_OFST=0, .UDM_L2_SL=6, .UDM_L2_OFST=0, .UDM_L1_SL=6, .UDM_L1_OFST=0}},
    .luma_lut1 ={.bits={.UDM_LM_Y2=256, .UDM_LM_Y1=384, .UDM_LM_Y0=511, .rsv_27=0}},
    .luma_lut2 ={.bits={.UDM_LM_Y5=32, .UDM_LM_Y4=64, .UDM_LM_Y3=128, .rsv_27=0}},
    .sl_ctl    ={.bits={.UDM_SL_EN=0, .UDM_SL_HR=16, .UDM_SL_Y2=255, .UDM_SL_Y1=255, .rsv_22=0}},
    .hftd_ctl  ={.bits={.UDM_CORE_TH1=0, .UDM_HD_GN2=16, .UDM_HD_GN1=16, .UDM_HT_GN2=16, .UDM_HT_GN1=16, .rsv_28=0}},
    .nr_str    ={.bits={.UDM_N2_STR=0, .UDM_N1_STR=0, .UDM_N0_STR=0, .UDM_XTK_SL=5, .UDM_XTK_OFST=32, .UDM_XTK_RAT=16}},
    .nr_act    ={.bits={.UDM_NGR=0, .UDM_NSL=5, .UDM_N2_OFST=0, .UDM_N1_OFST=0, .UDM_N0_OFST=0}},
    .hf_str    ={.bits={.UDM_CORE_TH2=0, .UDM_HI_RAT=0, .UDM_H3_GN=0, .UDM_H2_GN=0, .UDM_H1_GN=0, .UDM_HA_STR=0}},
    .hf_act1   ={.bits={.UDM_H2_UPB=220, .UDM_H2_LWB=52, .UDM_H1_UPB=80, .UDM_H1_LWB=20}},
    .hf_act2   ={.bits={.UDM_HSLL=5, .UDM_HSLR=5, .UDM_H3_UPB=255, .UDM_H3_LWB=52, .rsv_24=0}},
    .clip      ={.bits={.UDM_CLIP_TH=100, .UDM_UN_TH=32, .UDM_OV_TH=223, .rsv_24=0}},
    .dsb       ={.bits={.UDM_SC_RAT=0, .UDM_SL_RAT=0, .UDM_FL_MODE=0, .rsv_11=0}},
    .p1_act    ={.bits={.UDM_P1_UPB=85, .UDM_P1_LWB=85, .rsv_16=0}},
    .lr_rat    ={.bits={.UDM_LR_RAT=15, .rsv_4=0}},
    .hftd_ctl2 ={.bits={.UDM_HD_GN3=16, .UDM_HFRB_GN=16, .rsv_12=0}},
    .est_ctl   ={.bits={.UDM_P2_CLIP=0, .UDM_P1_BLD=0, .rsv_6=0}},
    .int_ctl   ={.bits={.UDM_INT_LTH=3, .UDM_INT_CDTH=5, .rsv_8=0}},
    .ee        ={.bits={.UDM_HPOS_GN=16, .UDM_HNEG_GN=16, .rsv_10=0}}

};
const ISP_NVRAM_UDM_T gc13a0mipiraw_UDM_0117 = {
        .intp_crs  ={.bits={.UDM_CDG_SL=4, .UDM_CDG_OFST=20, .UDM_CDG_RAT=16, .UDM_CD_KNL=0, .rsv_18=0, .UDM_BYP=0, .UDM_MN_MODE=0}},
    .intp_nat  ={.bits={.UDM_HL_OFST=63, .UDM_L0_SL=6, .UDM_L0_OFST=0, .UDM_CD_SLL=3, .UDM_CD_SLC=10, .rsv_30=0}},
    .intp_aug  ={.bits={.UDM_DN_OFST=0, .UDM_L2_SL=6, .UDM_L2_OFST=0, .UDM_L1_SL=6, .UDM_L1_OFST=0}},
    .luma_lut1 ={.bits={.UDM_LM_Y2=256, .UDM_LM_Y1=384, .UDM_LM_Y0=511, .rsv_27=0}},
    .luma_lut2 ={.bits={.UDM_LM_Y5=32, .UDM_LM_Y4=64, .UDM_LM_Y3=128, .rsv_27=0}},
    .sl_ctl    ={.bits={.UDM_SL_EN=0, .UDM_SL_HR=16, .UDM_SL_Y2=255, .UDM_SL_Y1=255, .rsv_22=0}},
    .hftd_ctl  ={.bits={.UDM_CORE_TH1=0, .UDM_HD_GN2=16, .UDM_HD_GN1=16, .UDM_HT_GN2=16, .UDM_HT_GN1=16, .rsv_28=0}},
    .nr_str    ={.bits={.UDM_N2_STR=0, .UDM_N1_STR=0, .UDM_N0_STR=0, .UDM_XTK_SL=5, .UDM_XTK_OFST=32, .UDM_XTK_RAT=16}},
    .nr_act    ={.bits={.UDM_NGR=0, .UDM_NSL=5, .UDM_N2_OFST=0, .UDM_N1_OFST=0, .UDM_N0_OFST=0}},
    .hf_str    ={.bits={.UDM_CORE_TH2=0, .UDM_HI_RAT=0, .UDM_H3_GN=0, .UDM_H2_GN=0, .UDM_H1_GN=0, .UDM_HA_STR=0}},
    .hf_act1   ={.bits={.UDM_H2_UPB=220, .UDM_H2_LWB=52, .UDM_H1_UPB=80, .UDM_H1_LWB=20}},
    .hf_act2   ={.bits={.UDM_HSLL=5, .UDM_HSLR=5, .UDM_H3_UPB=255, .UDM_H3_LWB=52, .rsv_24=0}},
    .clip      ={.bits={.UDM_CLIP_TH=100, .UDM_UN_TH=32, .UDM_OV_TH=223, .rsv_24=0}},
    .dsb       ={.bits={.UDM_SC_RAT=0, .UDM_SL_RAT=0, .UDM_FL_MODE=0, .rsv_11=0}},
    .p1_act    ={.bits={.UDM_P1_UPB=85, .UDM_P1_LWB=85, .rsv_16=0}},
    .lr_rat    ={.bits={.UDM_LR_RAT=15, .rsv_4=0}},
    .hftd_ctl2 ={.bits={.UDM_HD_GN3=16, .UDM_HFRB_GN=16, .rsv_12=0}},
    .est_ctl   ={.bits={.UDM_P2_CLIP=0, .UDM_P1_BLD=0, .rsv_6=0}},
    .int_ctl   ={.bits={.UDM_INT_LTH=3, .UDM_INT_CDTH=5, .rsv_8=0}},
    .ee        ={.bits={.UDM_HPOS_GN=16, .UDM_HNEG_GN=16, .rsv_10=0}}

};
const ISP_NVRAM_UDM_T gc13a0mipiraw_UDM_0118 = {
        .intp_crs  ={.bits={.UDM_CDG_SL=4, .UDM_CDG_OFST=20, .UDM_CDG_RAT=16, .UDM_CD_KNL=0, .rsv_18=0, .UDM_BYP=0, .UDM_MN_MODE=0}},
    .intp_nat  ={.bits={.UDM_HL_OFST=63, .UDM_L0_SL=6, .UDM_L0_OFST=0, .UDM_CD_SLL=3, .UDM_CD_SLC=10, .rsv_30=0}},
    .intp_aug  ={.bits={.UDM_DN_OFST=0, .UDM_L2_SL=6, .UDM_L2_OFST=0, .UDM_L1_SL=6, .UDM_L1_OFST=0}},
    .luma_lut1 ={.bits={.UDM_LM_Y2=256, .UDM_LM_Y1=384, .UDM_LM_Y0=511, .rsv_27=0}},
    .luma_lut2 ={.bits={.UDM_LM_Y5=32, .UDM_LM_Y4=64, .UDM_LM_Y3=128, .rsv_27=0}},
    .sl_ctl    ={.bits={.UDM_SL_EN=0, .UDM_SL_HR=16, .UDM_SL_Y2=255, .UDM_SL_Y1=255, .rsv_22=0}},
    .hftd_ctl  ={.bits={.UDM_CORE_TH1=0, .UDM_HD_GN2=16, .UDM_HD_GN1=16, .UDM_HT_GN2=16, .UDM_HT_GN1=16, .rsv_28=0}},
    .nr_str    ={.bits={.UDM_N2_STR=0, .UDM_N1_STR=0, .UDM_N0_STR=0, .UDM_XTK_SL=5, .UDM_XTK_OFST=32, .UDM_XTK_RAT=16}},
    .nr_act    ={.bits={.UDM_NGR=0, .UDM_NSL=5, .UDM_N2_OFST=0, .UDM_N1_OFST=0, .UDM_N0_OFST=0}},
    .hf_str    ={.bits={.UDM_CORE_TH2=0, .UDM_HI_RAT=0, .UDM_H3_GN=0, .UDM_H2_GN=0, .UDM_H1_GN=0, .UDM_HA_STR=0}},
    .hf_act1   ={.bits={.UDM_H2_UPB=220, .UDM_H2_LWB=52, .UDM_H1_UPB=80, .UDM_H1_LWB=20}},
    .hf_act2   ={.bits={.UDM_HSLL=5, .UDM_HSLR=5, .UDM_H3_UPB=255, .UDM_H3_LWB=52, .rsv_24=0}},
    .clip      ={.bits={.UDM_CLIP_TH=100, .UDM_UN_TH=32, .UDM_OV_TH=223, .rsv_24=0}},
    .dsb       ={.bits={.UDM_SC_RAT=0, .UDM_SL_RAT=0, .UDM_FL_MODE=0, .rsv_11=0}},
    .p1_act    ={.bits={.UDM_P1_UPB=85, .UDM_P1_LWB=85, .rsv_16=0}},
    .lr_rat    ={.bits={.UDM_LR_RAT=15, .rsv_4=0}},
    .hftd_ctl2 ={.bits={.UDM_HD_GN3=16, .UDM_HFRB_GN=16, .rsv_12=0}},
    .est_ctl   ={.bits={.UDM_P2_CLIP=0, .UDM_P1_BLD=0, .rsv_6=0}},
    .int_ctl   ={.bits={.UDM_INT_LTH=3, .UDM_INT_CDTH=5, .rsv_8=0}},
    .ee        ={.bits={.UDM_HPOS_GN=16, .UDM_HNEG_GN=16, .rsv_10=0}}

};
const ISP_NVRAM_UDM_T gc13a0mipiraw_UDM_0119 = {
        .intp_crs  ={.bits={.UDM_CDG_SL=4, .UDM_CDG_OFST=20, .UDM_CDG_RAT=16, .UDM_CD_KNL=0, .rsv_18=0, .UDM_BYP=0, .UDM_MN_MODE=0}},
    .intp_nat  ={.bits={.UDM_HL_OFST=63, .UDM_L0_SL=6, .UDM_L0_OFST=0, .UDM_CD_SLL=3, .UDM_CD_SLC=10, .rsv_30=0}},
    .intp_aug  ={.bits={.UDM_DN_OFST=0, .UDM_L2_SL=6, .UDM_L2_OFST=0, .UDM_L1_SL=6, .UDM_L1_OFST=0}},
    .luma_lut1 ={.bits={.UDM_LM_Y2=256, .UDM_LM_Y1=384, .UDM_LM_Y0=511, .rsv_27=0}},
    .luma_lut2 ={.bits={.UDM_LM_Y5=32, .UDM_LM_Y4=64, .UDM_LM_Y3=128, .rsv_27=0}},
    .sl_ctl    ={.bits={.UDM_SL_EN=0, .UDM_SL_HR=16, .UDM_SL_Y2=255, .UDM_SL_Y1=255, .rsv_22=0}},
    .hftd_ctl  ={.bits={.UDM_CORE_TH1=0, .UDM_HD_GN2=16, .UDM_HD_GN1=16, .UDM_HT_GN2=16, .UDM_HT_GN1=16, .rsv_28=0}},
    .nr_str    ={.bits={.UDM_N2_STR=0, .UDM_N1_STR=0, .UDM_N0_STR=0, .UDM_XTK_SL=5, .UDM_XTK_OFST=32, .UDM_XTK_RAT=16}},
    .nr_act    ={.bits={.UDM_NGR=0, .UDM_NSL=5, .UDM_N2_OFST=0, .UDM_N1_OFST=0, .UDM_N0_OFST=0}},
    .hf_str    ={.bits={.UDM_CORE_TH2=0, .UDM_HI_RAT=0, .UDM_H3_GN=0, .UDM_H2_GN=0, .UDM_H1_GN=0, .UDM_HA_STR=0}},
    .hf_act1   ={.bits={.UDM_H2_UPB=220, .UDM_H2_LWB=52, .UDM_H1_UPB=80, .UDM_H1_LWB=20}},
    .hf_act2   ={.bits={.UDM_HSLL=5, .UDM_HSLR=5, .UDM_H3_UPB=255, .UDM_H3_LWB=52, .rsv_24=0}},
    .clip      ={.bits={.UDM_CLIP_TH=100, .UDM_UN_TH=32, .UDM_OV_TH=223, .rsv_24=0}},
    .dsb       ={.bits={.UDM_SC_RAT=0, .UDM_SL_RAT=0, .UDM_FL_MODE=0, .rsv_11=0}},
    .p1_act    ={.bits={.UDM_P1_UPB=85, .UDM_P1_LWB=85, .rsv_16=0}},
    .lr_rat    ={.bits={.UDM_LR_RAT=15, .rsv_4=0}},
    .hftd_ctl2 ={.bits={.UDM_HD_GN3=16, .UDM_HFRB_GN=16, .rsv_12=0}},
    .est_ctl   ={.bits={.UDM_P2_CLIP=0, .UDM_P1_BLD=0, .rsv_6=0}},
    .int_ctl   ={.bits={.UDM_INT_LTH=3, .UDM_INT_CDTH=5, .rsv_8=0}},
    .ee        ={.bits={.UDM_HPOS_GN=16, .UDM_HNEG_GN=16, .rsv_10=0}}

};
const ISP_NVRAM_ANR_T gc13a0mipiraw_NBC_ANR_0180 = {
        .con1      ={.bits={.NBC_ANR_ENC=1, .NBC_ANR_ENY=1, .rsv_2=0, .NBC_ANR_Y_FLT0_IDX=0, .rsv_5=0, .NBC_ANR_Y_FLT1_IDX=0, .rsv_7=0, .NBC_ANR_Y_FLT2_IDX=2, .NBC_ANR_Y_FLT3_IDX=3, .NBC_ANR_ACT_LP_EN=0, .rsv_13=0, .NBC_ANR_TILE_EDGE=0, .NBC_ANR_LTM_LINK=1, .NBC_ANR_LTM_LUT_BYPASS=0, .rsv_22=0, .NBC_ANR_SL2_LINK=0, .rsv_25=0, .NBC_ANR_TABLE_EN=0, .NBC_ANR_TBL_PRC=0, .rsv_30=0}},
    .con2      ={.bits={.NBC_ANR_IMPL_MODE=2, .rsv_2=0, .NBC_ANR_C_SM_EDGE=1, .rsv_10=0, .NBC_ANR_FLT_C=0, .rsv_13=0, .NBC_ANR_C_SM_EDGE_TH=2, .rsv_27=0}},
    .yad1      ={.bits={.NBC_ANR_CEN_GAIN_LO_TH=0, .rsv_5=0, .NBC_ANR_CEN_GAIN_HI_TH=0, .rsv_13=0, .NBC_ANR_Y_SLOPE_V_TH=5, .NBC_ANR_Y_SLOPE_H_TH=4}},
    .yad2      ={.bits={.NBC_ANR_Y_VERT_ACT_TH=7, .rsv_5=0, .NBC_ANR_PTY_GAIN_TH=0, .rsv_13=0, .NBC_ANR_Y_VERT_SIGMA=2, .rsv_24=0}},
    .y4lut1    ={.bits={.NBC_ANR_Y_CPX1=64, .NBC_ANR_Y_CPX2=128, .NBC_ANR_Y_CPX3=192, .NBC_ANR_Y_CPX4=255}},
    .y4lut2    ={.bits={.NBC_ANR_Y_SCALE_CPY0=15, .rsv_5=0, .NBC_ANR_Y_SCALE_CPY1=16, .rsv_13=0, .NBC_ANR_Y_SCALE_CPY2=16, .rsv_21=0, .NBC_ANR_Y_SCALE_CPY3=12, .rsv_29=0}},
    .y4lut3    ={.bits={.NBC_ANR_Y_SCALE_SP0=2, .rsv_5=0, .NBC_ANR_Y_SCALE_SP1=0, .rsv_13=0, .NBC_ANR_Y_SCALE_SP2=24, .rsv_21=0, .NBC_ANR_Y_SCALE_SP3=24, .rsv_29=0}},
    .c4lut1    ={.bits={.NBC_ANR_C_CPX1=40, .NBC_ANR_C_CPX2=120, .NBC_ANR_C_CPX3=160, .rsv_24=0}},
    .c4lut2    ={.bits={.NBC_ANR_C_SCALE_CPY0=16, .rsv_5=0, .NBC_ANR_C_SCALE_CPY1=16, .rsv_13=0, .NBC_ANR_C_SCALE_CPY2=16, .rsv_21=0, .NBC_ANR_C_SCALE_CPY3=8, .rsv_29=0}},
    .c4lut3    ={.bits={.NBC_ANR_C_SCALE_SP0=0, .rsv_5=0, .NBC_ANR_C_SCALE_SP1=0, .rsv_13=0, .NBC_ANR_C_SCALE_SP2=17, .rsv_21=0, .NBC_ANR_C_SCALE_SP3=30, .rsv_29=0}},
    .a4lut2    ={.bits={.NBC_ANR_Y_ACT_CPY0=0, .NBC_ANR_Y_ACT_CPY1=0, .NBC_ANR_Y_ACT_CPY2=0, .NBC_ANR_Y_ACT_CPY3=0}},
    .a4lut3    ={.bits={.NBC_ANR_Y_ACT_SP0=0, .rsv_6=0, .NBC_ANR_Y_ACT_SP1=0, .rsv_14=0, .NBC_ANR_Y_ACT_SP2=0, .rsv_22=0, .NBC_ANR_Y_ACT_SP3=0, .rsv_30=0}},
    .l4lut1    ={.bits={.NBC_ANR_SL2_X1=64, .NBC_ANR_SL2_X2=128, .NBC_ANR_SL2_X3=192, .rsv_24=0}},
    .l4lut2    ={.bits={.NBC_ANR_SL2_GAIN0=16, .rsv_6=0, .NBC_ANR_SL2_GAIN1=20, .rsv_14=0, .NBC_ANR_SL2_GAIN2=24, .rsv_22=0, .NBC_ANR_SL2_GAIN3=28, .rsv_30=0}},
    .l4lut3    ={.bits={.NBC_ANR_SL2_SP0=8, .rsv_6=0, .NBC_ANR_SL2_SP1=8, .rsv_14=0, .NBC_ANR_SL2_SP2=8, .rsv_22=0, .NBC_ANR_SL2_SP3=8, .rsv_30=0}},
    .pty0v     ={.bits={.NBC_ANR_Y_L0_V_RNG1=1, .NBC_ANR_Y_L0_V_RNG2=2, .NBC_ANR_Y_L0_V_RNG3=3, .NBC_ANR_Y_L0_V_RNG4=5}},
    .cad       ={.bits={.rsv_0=0, .NBC_ANR_PTC_GAIN_TH=0, .rsv_13=0, .NBC_ANR_C_L_DIFF_TH=24, .rsv_24=0}},
    .pty1v     ={.bits={.NBC_ANR_Y_L1_V_RNG1=1, .NBC_ANR_Y_L1_V_RNG2=2, .NBC_ANR_Y_L1_V_RNG3=3, .NBC_ANR_Y_L1_V_RNG4=5}},
    .sl2       ={.bits={.NBC_ANR_SL2_C_GAIN=6, .NBC_ANR_SL2_SCALE_GAIN=0, .rsv_7=0}},
    .pty2v     ={.bits={.NBC_ANR_Y_L2_V_RNG1=1, .NBC_ANR_Y_L2_V_RNG2=2, .NBC_ANR_Y_L2_V_RNG3=3, .NBC_ANR_Y_L2_V_RNG4=5}},
    .pty3v     ={.bits={.NBC_ANR_Y_L3_V_RNG1=1, .NBC_ANR_Y_L3_V_RNG2=1, .NBC_ANR_Y_L3_V_RNG3=2, .NBC_ANR_Y_L3_V_RNG4=2}},
    .pty0h     ={.bits={.NBC_ANR_Y_L0_H_RNG1=1, .NBC_ANR_Y_L0_H_RNG2=2, .NBC_ANR_Y_L0_H_RNG3=3, .NBC_ANR_Y_L0_H_RNG4=4}},
    .pty1h     ={.bits={.NBC_ANR_Y_L1_H_RNG1=1, .NBC_ANR_Y_L1_H_RNG2=2, .NBC_ANR_Y_L1_H_RNG3=3, .NBC_ANR_Y_L1_H_RNG4=4}},
    .pty2h     ={.bits={.NBC_ANR_Y_L2_H_RNG1=1, .NBC_ANR_Y_L2_H_RNG2=2, .NBC_ANR_Y_L2_H_RNG3=3, .NBC_ANR_Y_L2_H_RNG4=4}},
    .t4lut1    ={.bits={.NBC_ANR_TBL_CPX1=64, .NBC_ANR_TBL_CPX2=128, .NBC_ANR_TBL_CPX3=192, .rsv_24=0}},
    .t4lut2    ={.bits={.NBC_ANR_TBL_GAIN_CPY0=1, .rsv_5=0, .NBC_ANR_TBL_GAIN_CPY1=8, .rsv_13=0, .NBC_ANR_TBL_GAIN_CPY2=16, .rsv_21=0, .NBC_ANR_TBL_GAIN_CPY3=24, .rsv_29=0}},
    .t4lut3    ={.bits={.NBC_ANR_TBL_GAIN_SP0=14, .rsv_5=0, .NBC_ANR_TBL_GAIN_SP1=15, .rsv_13=0, .NBC_ANR_TBL_GAIN_SP2=15, .rsv_21=0, .NBC_ANR_TBL_GAIN_SP3=15, .rsv_29=0}},
    .act1      ={.bits={.NBC_ANR_ACT_SL2_GAIN=8, .rsv_4=0, .NBC_ANR_ACT_DIF_HI_TH=16, .rsv_13=0, .NBC_ANR_ACT_DIF_GAIN=4, .NBC_ANR_ACT_DIF_LO_TH=16, .rsv_29=0}},
    .pty3h     ={.bits={.NBC_ANR_Y_L3_H_RNG1=1, .NBC_ANR_Y_L3_H_RNG2=1, .NBC_ANR_Y_L3_H_RNG3=1, .NBC_ANR_Y_L3_H_RNG4=2}},
    .ptcv      ={.bits={.NBC_ANR_C_V_RNG1=2, .NBC_ANR_C_V_RNG2=4, .NBC_ANR_C_V_RNG3=6, .NBC_ANR_C_V_RNG4=9}},
    .act4      ={.bits={.NBC_ANR_Y_ACT_CEN_OFT=32, .rsv_6=0, .NBC_ANR_Y_ACT_CEN_GAIN=0, .rsv_14=0, .NBC_ANR_Y_ACT_CEN_TH=32, .rsv_22=0}},
    .ptch      ={.bits={.NBC_ANR_C_H_RNG1=2, .NBC_ANR_C_H_RNG2=4, .NBC_ANR_C_H_RNG3=6, .NBC_ANR_C_H_RNG4=8}},
    .ylvl0     ={.bits={.NBC_ANR_Y_L0_RNG_RAT_TH=8, .NBC_ANR_Y_L1_RNG_RAT_TH=12, .NBC_ANR_Y_L2_RNG_RAT_TH=12, .NBC_ANR_Y_L3_RNG_RAT_TH=15, .NBC_ANR_Y_L0_RNG_RAT_SL=3, .rsv_18=0, .NBC_ANR_Y_L1_RNG_RAT_SL=3, .rsv_22=0, .NBC_ANR_Y_L2_RNG_RAT_SL=3, .rsv_26=0, .NBC_ANR_Y_L3_RNG_RAT_SL=3, .rsv_30=0}},
    .ylvl1     ={.bits={.NBC_ANR_Y_L0_HF_W=16, .rsv_5=0, .NBC_ANR_Y_L1_HF_W=16, .rsv_13=0, .NBC_ANR_Y_L2_HF_W=16, .rsv_21=0, .NBC_ANR_Y_L3_HF_W=16, .rsv_29=0}},
    .hf_cor    ={.bits={.NBC_ANR_Y_HF_CORE_TH=0, .NBC_ANR_Y_HF_CORE_SL=2, .rsv_10=0, .NBC_ANR_Y_HF_CLIP=255, .NBC_ANR_HF_BAL_MODE=1, .rsv_26=0}},
    .hf_act0   ={.bits={.NBC_ANR_Y_HF_ACT_X1=16, .NBC_ANR_Y_HF_ACT_X2=20, .NBC_ANR_Y_HF_ACT_X3=24, .NBC_ANR_Y_HF_ACT_X4=28}},
    .hf_act1   ={.bits={.NBC_ANR_Y_HF_ACT_Y0=25, .rsv_7=0, .NBC_ANR_Y_HF_ACT_Y1=25, .rsv_15=0, .NBC_ANR_Y_HF_ACT_Y2=25, .rsv_23=0, .NBC_ANR_Y_HF_ACT_Y3=25, .rsv_31=0}},
    .actc      ={.bits={.rsv_0=0, .NBC_ANR_ACT_BLD_BASE_C=48, .rsv_15=0, .NBC_ANR_C_DITH_U=8, .rsv_21=0, .NBC_ANR_C_DITH_V=8, .rsv_29=0}},
    .ylad      ={.bits={.NBC_ANR_CEN_GAIN_LO_TH_LPF=0, .rsv_5=0, .NBC_ANR_CEN_GAIN_HI_TH_LPF=0, .rsv_13=0}},
    .hf_act2   ={.bits={.NBC_ANR_Y_HF_ACT_Y4=25, .rsv_7=0, .NBC_ANR_Y_HF_ACT_SP4=0, .rsv_14=0}},
    .hf_act3   ={.bits={.NBC_ANR_Y_HF_ACT_SP0=0, .rsv_6=0, .NBC_ANR_Y_HF_ACT_SP1=0, .rsv_14=0, .NBC_ANR_Y_HF_ACT_SP2=0, .rsv_22=0, .NBC_ANR_Y_HF_ACT_SP3=0, .rsv_30=0}},
    .hf_luma0  ={.bits={.NBC_ANR_Y_HF_LUMA_X1=192, .NBC_ANR_Y_HF_LUMA_X2=224, .NBC_ANR_Y_HF_LUMA_Y0=0, .rsv_23=0, .NBC_ANR_Y_HF_LUMA_Y1=0, .rsv_31=0}},
    .hf_luma1  ={.bits={.NBC_ANR_Y_HF_LUMA_Y2=4, .rsv_7=0, .NBC_ANR_Y_HF_LUMA_SP0=0, .rsv_13=0, .NBC_ANR_Y_HF_LUMA_SP1=1, .rsv_21=0, .NBC_ANR_Y_HF_LUMA_SP2=0, .rsv_29=0}},
    .y4lut4    ={.bits={.NBC_ANR_Y_CPX5=255, .NBC_ANR_Y_CPX6=255, .NBC_ANR_Y_CPX7=255, .NBC_ANR_Y_CPX8=255}},
    .y4lut5    ={.bits={.NBC_ANR_Y_SCALE_CPY4=8, .rsv_5=0, .NBC_ANR_Y_SCALE_CPY5=8, .rsv_13=0, .NBC_ANR_Y_SCALE_CPY6=8, .rsv_21=0, .NBC_ANR_Y_SCALE_CPY7=8, .rsv_29=0}},
    .y4lut6    ={.bits={.NBC_ANR_Y_SCALE_SP4=0, .rsv_5=0, .NBC_ANR_Y_SCALE_SP5=0, .rsv_13=0, .NBC_ANR_Y_SCALE_SP6=0, .rsv_21=0, .NBC_ANR_Y_SCALE_SP7=0, .rsv_29=0}},
    .y4lut7    ={.bits={.NBC_ANR_Y_SCALE_CPY8=8, .rsv_5=0, .NBC_ANR_Y_SCALE_SP8=3, .rsv_13=0}},
    .a4lut1    ={.bits={.NBC_ANR_Y_ACT_CPX1=64, .NBC_ANR_Y_ACT_CPX2=128, .NBC_ANR_Y_ACT_CPX3=192, .rsv_24=0}}

};
const ISP_NVRAM_ANR_T gc13a0mipiraw_NBC_ANR_0181 = {
        .con1      ={.bits={.NBC_ANR_ENC=1, .NBC_ANR_ENY=1, .rsv_2=0, .NBC_ANR_Y_FLT0_IDX=0, .rsv_5=0, .NBC_ANR_Y_FLT1_IDX=0, .rsv_7=0, .NBC_ANR_Y_FLT2_IDX=2, .NBC_ANR_Y_FLT3_IDX=3, .NBC_ANR_ACT_LP_EN=0, .rsv_13=0, .NBC_ANR_TILE_EDGE=0, .NBC_ANR_LTM_LINK=1, .NBC_ANR_LTM_LUT_BYPASS=0, .rsv_22=0, .NBC_ANR_SL2_LINK=0, .rsv_25=0, .NBC_ANR_TABLE_EN=0, .NBC_ANR_TBL_PRC=0, .rsv_30=0}},
    .con2      ={.bits={.NBC_ANR_IMPL_MODE=2, .rsv_2=0, .NBC_ANR_C_SM_EDGE=1, .rsv_10=0, .NBC_ANR_FLT_C=0, .rsv_13=0, .NBC_ANR_C_SM_EDGE_TH=2, .rsv_27=0}},
    .yad1      ={.bits={.NBC_ANR_CEN_GAIN_LO_TH=0, .rsv_5=0, .NBC_ANR_CEN_GAIN_HI_TH=0, .rsv_13=0, .NBC_ANR_Y_SLOPE_V_TH=5, .NBC_ANR_Y_SLOPE_H_TH=4}},
    .yad2      ={.bits={.NBC_ANR_Y_VERT_ACT_TH=7, .rsv_5=0, .NBC_ANR_PTY_GAIN_TH=0, .rsv_13=0, .NBC_ANR_Y_VERT_SIGMA=2, .rsv_24=0}},
    .y4lut1    ={.bits={.NBC_ANR_Y_CPX1=64, .NBC_ANR_Y_CPX2=128, .NBC_ANR_Y_CPX3=192, .NBC_ANR_Y_CPX4=255}},
    .y4lut2    ={.bits={.NBC_ANR_Y_SCALE_CPY0=15, .rsv_5=0, .NBC_ANR_Y_SCALE_CPY1=16, .rsv_13=0, .NBC_ANR_Y_SCALE_CPY2=16, .rsv_21=0, .NBC_ANR_Y_SCALE_CPY3=12, .rsv_29=0}},
    .y4lut3    ={.bits={.NBC_ANR_Y_SCALE_SP0=2, .rsv_5=0, .NBC_ANR_Y_SCALE_SP1=0, .rsv_13=0, .NBC_ANR_Y_SCALE_SP2=24, .rsv_21=0, .NBC_ANR_Y_SCALE_SP3=24, .rsv_29=0}},
    .c4lut1    ={.bits={.NBC_ANR_C_CPX1=40, .NBC_ANR_C_CPX2=120, .NBC_ANR_C_CPX3=160, .rsv_24=0}},
    .c4lut2    ={.bits={.NBC_ANR_C_SCALE_CPY0=16, .rsv_5=0, .NBC_ANR_C_SCALE_CPY1=16, .rsv_13=0, .NBC_ANR_C_SCALE_CPY2=16, .rsv_21=0, .NBC_ANR_C_SCALE_CPY3=8, .rsv_29=0}},
    .c4lut3    ={.bits={.NBC_ANR_C_SCALE_SP0=0, .rsv_5=0, .NBC_ANR_C_SCALE_SP1=0, .rsv_13=0, .NBC_ANR_C_SCALE_SP2=17, .rsv_21=0, .NBC_ANR_C_SCALE_SP3=30, .rsv_29=0}},
    .a4lut2    ={.bits={.NBC_ANR_Y_ACT_CPY0=0, .NBC_ANR_Y_ACT_CPY1=0, .NBC_ANR_Y_ACT_CPY2=0, .NBC_ANR_Y_ACT_CPY3=0}},
    .a4lut3    ={.bits={.NBC_ANR_Y_ACT_SP0=0, .rsv_6=0, .NBC_ANR_Y_ACT_SP1=0, .rsv_14=0, .NBC_ANR_Y_ACT_SP2=0, .rsv_22=0, .NBC_ANR_Y_ACT_SP3=0, .rsv_30=0}},
    .l4lut1    ={.bits={.NBC_ANR_SL2_X1=64, .NBC_ANR_SL2_X2=128, .NBC_ANR_SL2_X3=192, .rsv_24=0}},
    .l4lut2    ={.bits={.NBC_ANR_SL2_GAIN0=16, .rsv_6=0, .NBC_ANR_SL2_GAIN1=20, .rsv_14=0, .NBC_ANR_SL2_GAIN2=24, .rsv_22=0, .NBC_ANR_SL2_GAIN3=28, .rsv_30=0}},
    .l4lut3    ={.bits={.NBC_ANR_SL2_SP0=8, .rsv_6=0, .NBC_ANR_SL2_SP1=8, .rsv_14=0, .NBC_ANR_SL2_SP2=8, .rsv_22=0, .NBC_ANR_SL2_SP3=8, .rsv_30=0}},
    .pty0v     ={.bits={.NBC_ANR_Y_L0_V_RNG1=1, .NBC_ANR_Y_L0_V_RNG2=2, .NBC_ANR_Y_L0_V_RNG3=3, .NBC_ANR_Y_L0_V_RNG4=5}},
    .cad       ={.bits={.rsv_0=0, .NBC_ANR_PTC_GAIN_TH=0, .rsv_13=0, .NBC_ANR_C_L_DIFF_TH=24, .rsv_24=0}},
    .pty1v     ={.bits={.NBC_ANR_Y_L1_V_RNG1=1, .NBC_ANR_Y_L1_V_RNG2=2, .NBC_ANR_Y_L1_V_RNG3=3, .NBC_ANR_Y_L1_V_RNG4=5}},
    .sl2       ={.bits={.NBC_ANR_SL2_C_GAIN=6, .NBC_ANR_SL2_SCALE_GAIN=0, .rsv_7=0}},
    .pty2v     ={.bits={.NBC_ANR_Y_L2_V_RNG1=1, .NBC_ANR_Y_L2_V_RNG2=2, .NBC_ANR_Y_L2_V_RNG3=3, .NBC_ANR_Y_L2_V_RNG4=5}},
    .pty3v     ={.bits={.NBC_ANR_Y_L3_V_RNG1=1, .NBC_ANR_Y_L3_V_RNG2=1, .NBC_ANR_Y_L3_V_RNG3=2, .NBC_ANR_Y_L3_V_RNG4=2}},
    .pty0h     ={.bits={.NBC_ANR_Y_L0_H_RNG1=1, .NBC_ANR_Y_L0_H_RNG2=2, .NBC_ANR_Y_L0_H_RNG3=3, .NBC_ANR_Y_L0_H_RNG4=4}},
    .pty1h     ={.bits={.NBC_ANR_Y_L1_H_RNG1=1, .NBC_ANR_Y_L1_H_RNG2=2, .NBC_ANR_Y_L1_H_RNG3=3, .NBC_ANR_Y_L1_H_RNG4=4}},
    .pty2h     ={.bits={.NBC_ANR_Y_L2_H_RNG1=1, .NBC_ANR_Y_L2_H_RNG2=2, .NBC_ANR_Y_L2_H_RNG3=3, .NBC_ANR_Y_L2_H_RNG4=4}},
    .t4lut1    ={.bits={.NBC_ANR_TBL_CPX1=64, .NBC_ANR_TBL_CPX2=128, .NBC_ANR_TBL_CPX3=192, .rsv_24=0}},
    .t4lut2    ={.bits={.NBC_ANR_TBL_GAIN_CPY0=1, .rsv_5=0, .NBC_ANR_TBL_GAIN_CPY1=8, .rsv_13=0, .NBC_ANR_TBL_GAIN_CPY2=16, .rsv_21=0, .NBC_ANR_TBL_GAIN_CPY3=24, .rsv_29=0}},
    .t4lut3    ={.bits={.NBC_ANR_TBL_GAIN_SP0=14, .rsv_5=0, .NBC_ANR_TBL_GAIN_SP1=15, .rsv_13=0, .NBC_ANR_TBL_GAIN_SP2=15, .rsv_21=0, .NBC_ANR_TBL_GAIN_SP3=15, .rsv_29=0}},
    .act1      ={.bits={.NBC_ANR_ACT_SL2_GAIN=8, .rsv_4=0, .NBC_ANR_ACT_DIF_HI_TH=16, .rsv_13=0, .NBC_ANR_ACT_DIF_GAIN=4, .NBC_ANR_ACT_DIF_LO_TH=16, .rsv_29=0}},
    .pty3h     ={.bits={.NBC_ANR_Y_L3_H_RNG1=1, .NBC_ANR_Y_L3_H_RNG2=1, .NBC_ANR_Y_L3_H_RNG3=1, .NBC_ANR_Y_L3_H_RNG4=2}},
    .ptcv      ={.bits={.NBC_ANR_C_V_RNG1=2, .NBC_ANR_C_V_RNG2=4, .NBC_ANR_C_V_RNG3=6, .NBC_ANR_C_V_RNG4=9}},
    .act4      ={.bits={.NBC_ANR_Y_ACT_CEN_OFT=32, .rsv_6=0, .NBC_ANR_Y_ACT_CEN_GAIN=0, .rsv_14=0, .NBC_ANR_Y_ACT_CEN_TH=32, .rsv_22=0}},
    .ptch      ={.bits={.NBC_ANR_C_H_RNG1=2, .NBC_ANR_C_H_RNG2=4, .NBC_ANR_C_H_RNG3=6, .NBC_ANR_C_H_RNG4=8}},
    .ylvl0     ={.bits={.NBC_ANR_Y_L0_RNG_RAT_TH=8, .NBC_ANR_Y_L1_RNG_RAT_TH=12, .NBC_ANR_Y_L2_RNG_RAT_TH=12, .NBC_ANR_Y_L3_RNG_RAT_TH=15, .NBC_ANR_Y_L0_RNG_RAT_SL=3, .rsv_18=0, .NBC_ANR_Y_L1_RNG_RAT_SL=3, .rsv_22=0, .NBC_ANR_Y_L2_RNG_RAT_SL=3, .rsv_26=0, .NBC_ANR_Y_L3_RNG_RAT_SL=3, .rsv_30=0}},
    .ylvl1     ={.bits={.NBC_ANR_Y_L0_HF_W=16, .rsv_5=0, .NBC_ANR_Y_L1_HF_W=16, .rsv_13=0, .NBC_ANR_Y_L2_HF_W=16, .rsv_21=0, .NBC_ANR_Y_L3_HF_W=16, .rsv_29=0}},
    .hf_cor    ={.bits={.NBC_ANR_Y_HF_CORE_TH=0, .NBC_ANR_Y_HF_CORE_SL=2, .rsv_10=0, .NBC_ANR_Y_HF_CLIP=255, .NBC_ANR_HF_BAL_MODE=1, .rsv_26=0}},
    .hf_act0   ={.bits={.NBC_ANR_Y_HF_ACT_X1=16, .NBC_ANR_Y_HF_ACT_X2=20, .NBC_ANR_Y_HF_ACT_X3=24, .NBC_ANR_Y_HF_ACT_X4=28}},
    .hf_act1   ={.bits={.NBC_ANR_Y_HF_ACT_Y0=25, .rsv_7=0, .NBC_ANR_Y_HF_ACT_Y1=25, .rsv_15=0, .NBC_ANR_Y_HF_ACT_Y2=25, .rsv_23=0, .NBC_ANR_Y_HF_ACT_Y3=25, .rsv_31=0}},
    .actc      ={.bits={.rsv_0=0, .NBC_ANR_ACT_BLD_BASE_C=48, .rsv_15=0, .NBC_ANR_C_DITH_U=8, .rsv_21=0, .NBC_ANR_C_DITH_V=8, .rsv_29=0}},
    .ylad      ={.bits={.NBC_ANR_CEN_GAIN_LO_TH_LPF=0, .rsv_5=0, .NBC_ANR_CEN_GAIN_HI_TH_LPF=0, .rsv_13=0}},
    .hf_act2   ={.bits={.NBC_ANR_Y_HF_ACT_Y4=25, .rsv_7=0, .NBC_ANR_Y_HF_ACT_SP4=0, .rsv_14=0}},
    .hf_act3   ={.bits={.NBC_ANR_Y_HF_ACT_SP0=0, .rsv_6=0, .NBC_ANR_Y_HF_ACT_SP1=0, .rsv_14=0, .NBC_ANR_Y_HF_ACT_SP2=0, .rsv_22=0, .NBC_ANR_Y_HF_ACT_SP3=0, .rsv_30=0}},
    .hf_luma0  ={.bits={.NBC_ANR_Y_HF_LUMA_X1=192, .NBC_ANR_Y_HF_LUMA_X2=224, .NBC_ANR_Y_HF_LUMA_Y0=0, .rsv_23=0, .NBC_ANR_Y_HF_LUMA_Y1=0, .rsv_31=0}},
    .hf_luma1  ={.bits={.NBC_ANR_Y_HF_LUMA_Y2=4, .rsv_7=0, .NBC_ANR_Y_HF_LUMA_SP0=0, .rsv_13=0, .NBC_ANR_Y_HF_LUMA_SP1=1, .rsv_21=0, .NBC_ANR_Y_HF_LUMA_SP2=0, .rsv_29=0}},
    .y4lut4    ={.bits={.NBC_ANR_Y_CPX5=255, .NBC_ANR_Y_CPX6=255, .NBC_ANR_Y_CPX7=255, .NBC_ANR_Y_CPX8=255}},
    .y4lut5    ={.bits={.NBC_ANR_Y_SCALE_CPY4=8, .rsv_5=0, .NBC_ANR_Y_SCALE_CPY5=8, .rsv_13=0, .NBC_ANR_Y_SCALE_CPY6=8, .rsv_21=0, .NBC_ANR_Y_SCALE_CPY7=8, .rsv_29=0}},
    .y4lut6    ={.bits={.NBC_ANR_Y_SCALE_SP4=0, .rsv_5=0, .NBC_ANR_Y_SCALE_SP5=0, .rsv_13=0, .NBC_ANR_Y_SCALE_SP6=0, .rsv_21=0, .NBC_ANR_Y_SCALE_SP7=0, .rsv_29=0}},
    .y4lut7    ={.bits={.NBC_ANR_Y_SCALE_CPY8=8, .rsv_5=0, .NBC_ANR_Y_SCALE_SP8=3, .rsv_13=0}},
    .a4lut1    ={.bits={.NBC_ANR_Y_ACT_CPX1=64, .NBC_ANR_Y_ACT_CPX2=128, .NBC_ANR_Y_ACT_CPX3=192, .rsv_24=0}}

};
const ISP_NVRAM_ANR_T gc13a0mipiraw_NBC_ANR_0182 = {
        .con1      ={.bits={.NBC_ANR_ENC=1, .NBC_ANR_ENY=1, .rsv_2=0, .NBC_ANR_Y_FLT0_IDX=0, .rsv_5=0, .NBC_ANR_Y_FLT1_IDX=0, .rsv_7=0, .NBC_ANR_Y_FLT2_IDX=2, .NBC_ANR_Y_FLT3_IDX=3, .NBC_ANR_ACT_LP_EN=0, .rsv_13=0, .NBC_ANR_TILE_EDGE=15, .NBC_ANR_LTM_LINK=1, .NBC_ANR_LTM_LUT_BYPASS=0, .rsv_22=0, .NBC_ANR_SL2_LINK=1, .rsv_25=0, .NBC_ANR_TABLE_EN=0, .NBC_ANR_TBL_PRC=0, .rsv_30=0}},
    .con2      ={.bits={.NBC_ANR_IMPL_MODE=2, .rsv_2=0, .NBC_ANR_C_SM_EDGE=1, .rsv_10=0, .NBC_ANR_FLT_C=0, .rsv_13=0, .NBC_ANR_C_SM_EDGE_TH=2, .rsv_27=0}},
    .yad1      ={.bits={.NBC_ANR_CEN_GAIN_LO_TH=0, .rsv_5=0, .NBC_ANR_CEN_GAIN_HI_TH=0, .rsv_13=0, .NBC_ANR_Y_SLOPE_V_TH=10, .NBC_ANR_Y_SLOPE_H_TH=8}},
    .yad2      ={.bits={.NBC_ANR_Y_VERT_ACT_TH=7, .rsv_5=0, .NBC_ANR_PTY_GAIN_TH=0, .rsv_13=0, .NBC_ANR_Y_VERT_SIGMA=2, .rsv_24=0}},
    .y4lut1    ={.bits={.NBC_ANR_Y_CPX1=64, .NBC_ANR_Y_CPX2=128, .NBC_ANR_Y_CPX3=192, .NBC_ANR_Y_CPX4=255}},
    .y4lut2    ={.bits={.NBC_ANR_Y_SCALE_CPY0=15, .rsv_5=0, .NBC_ANR_Y_SCALE_CPY1=16, .rsv_13=0, .NBC_ANR_Y_SCALE_CPY2=16, .rsv_21=0, .NBC_ANR_Y_SCALE_CPY3=12, .rsv_29=0}},
    .y4lut3    ={.bits={.NBC_ANR_Y_SCALE_SP0=2, .rsv_5=0, .NBC_ANR_Y_SCALE_SP1=0, .rsv_13=0, .NBC_ANR_Y_SCALE_SP2=24, .rsv_21=0, .NBC_ANR_Y_SCALE_SP3=24, .rsv_29=0}},
    .c4lut1    ={.bits={.NBC_ANR_C_CPX1=40, .NBC_ANR_C_CPX2=120, .NBC_ANR_C_CPX3=160, .rsv_24=0}},
    .c4lut2    ={.bits={.NBC_ANR_C_SCALE_CPY0=16, .rsv_5=0, .NBC_ANR_C_SCALE_CPY1=16, .rsv_13=0, .NBC_ANR_C_SCALE_CPY2=16, .rsv_21=0, .NBC_ANR_C_SCALE_CPY3=8, .rsv_29=0}},
    .c4lut3    ={.bits={.NBC_ANR_C_SCALE_SP0=0, .rsv_5=0, .NBC_ANR_C_SCALE_SP1=0, .rsv_13=0, .NBC_ANR_C_SCALE_SP2=28, .rsv_21=0, .NBC_ANR_C_SCALE_SP3=30, .rsv_29=0}},
    .a4lut2    ={.bits={.NBC_ANR_Y_ACT_CPY0=0, .NBC_ANR_Y_ACT_CPY1=0, .NBC_ANR_Y_ACT_CPY2=0, .NBC_ANR_Y_ACT_CPY3=0}},
    .a4lut3    ={.bits={.NBC_ANR_Y_ACT_SP0=0, .rsv_6=0, .NBC_ANR_Y_ACT_SP1=0, .rsv_14=0, .NBC_ANR_Y_ACT_SP2=0, .rsv_22=0, .NBC_ANR_Y_ACT_SP3=0, .rsv_30=0}},
    .l4lut1    ={.bits={.NBC_ANR_SL2_X1=64, .NBC_ANR_SL2_X2=128, .NBC_ANR_SL2_X3=192, .rsv_24=0}},
    .l4lut2    ={.bits={.NBC_ANR_SL2_GAIN0=16, .rsv_6=0, .NBC_ANR_SL2_GAIN1=20, .rsv_14=0, .NBC_ANR_SL2_GAIN2=24, .rsv_22=0, .NBC_ANR_SL2_GAIN3=28, .rsv_30=0}},
    .l4lut3    ={.bits={.NBC_ANR_SL2_SP0=8, .rsv_6=0, .NBC_ANR_SL2_SP1=8, .rsv_14=0, .NBC_ANR_SL2_SP2=8, .rsv_22=0, .NBC_ANR_SL2_SP3=8, .rsv_30=0}},
    .pty0v     ={.bits={.NBC_ANR_Y_L0_V_RNG1=3, .NBC_ANR_Y_L0_V_RNG2=5, .NBC_ANR_Y_L0_V_RNG3=8, .NBC_ANR_Y_L0_V_RNG4=11}},
    .cad       ={.bits={.rsv_0=0, .NBC_ANR_PTC_GAIN_TH=10, .rsv_13=0, .NBC_ANR_C_L_DIFF_TH=36, .rsv_24=0}},
    .pty1v     ={.bits={.NBC_ANR_Y_L1_V_RNG1=4, .NBC_ANR_Y_L1_V_RNG2=7, .NBC_ANR_Y_L1_V_RNG3=10, .NBC_ANR_Y_L1_V_RNG4=14}},
    .sl2       ={.bits={.NBC_ANR_SL2_C_GAIN=6, .NBC_ANR_SL2_SCALE_GAIN=0, .rsv_7=0}},
    .pty2v     ={.bits={.NBC_ANR_Y_L2_V_RNG1=4, .NBC_ANR_Y_L2_V_RNG2=7, .NBC_ANR_Y_L2_V_RNG3=10, .NBC_ANR_Y_L2_V_RNG4=14}},
    .pty3v     ={.bits={.NBC_ANR_Y_L3_V_RNG1=2, .NBC_ANR_Y_L3_V_RNG2=3, .NBC_ANR_Y_L3_V_RNG3=5, .NBC_ANR_Y_L3_V_RNG4=7}},
    .pty0h     ={.bits={.NBC_ANR_Y_L0_H_RNG1=3, .NBC_ANR_Y_L0_H_RNG2=5, .NBC_ANR_Y_L0_H_RNG3=7, .NBC_ANR_Y_L0_H_RNG4=10}},
    .pty1h     ={.bits={.NBC_ANR_Y_L1_H_RNG1=3, .NBC_ANR_Y_L1_H_RNG2=6, .NBC_ANR_Y_L1_H_RNG3=9, .NBC_ANR_Y_L1_H_RNG4=13}},
    .pty2h     ={.bits={.NBC_ANR_Y_L2_H_RNG1=3, .NBC_ANR_Y_L2_H_RNG2=6, .NBC_ANR_Y_L2_H_RNG3=9, .NBC_ANR_Y_L2_H_RNG4=13}},
    .t4lut1    ={.bits={.NBC_ANR_TBL_CPX1=64, .NBC_ANR_TBL_CPX2=128, .NBC_ANR_TBL_CPX3=192, .rsv_24=0}},
    .t4lut2    ={.bits={.NBC_ANR_TBL_GAIN_CPY0=1, .rsv_5=0, .NBC_ANR_TBL_GAIN_CPY1=8, .rsv_13=0, .NBC_ANR_TBL_GAIN_CPY2=16, .rsv_21=0, .NBC_ANR_TBL_GAIN_CPY3=24, .rsv_29=0}},
    .t4lut3    ={.bits={.NBC_ANR_TBL_GAIN_SP0=14, .rsv_5=0, .NBC_ANR_TBL_GAIN_SP1=15, .rsv_13=0, .NBC_ANR_TBL_GAIN_SP2=15, .rsv_21=0, .NBC_ANR_TBL_GAIN_SP3=15, .rsv_29=0}},
    .act1      ={.bits={.NBC_ANR_ACT_SL2_GAIN=8, .rsv_4=0, .NBC_ANR_ACT_DIF_HI_TH=16, .rsv_13=0, .NBC_ANR_ACT_DIF_GAIN=4, .NBC_ANR_ACT_DIF_LO_TH=16, .rsv_29=0}},
    .pty3h     ={.bits={.NBC_ANR_Y_L3_H_RNG1=2, .NBC_ANR_Y_L3_H_RNG2=3, .NBC_ANR_Y_L3_H_RNG3=4, .NBC_ANR_Y_L3_H_RNG4=6}},
    .ptcv      ={.bits={.NBC_ANR_C_V_RNG1=5, .NBC_ANR_C_V_RNG2=11, .NBC_ANR_C_V_RNG3=16, .NBC_ANR_C_V_RNG4=22}},
    .act4      ={.bits={.NBC_ANR_Y_ACT_CEN_OFT=32, .rsv_6=0, .NBC_ANR_Y_ACT_CEN_GAIN=0, .rsv_14=0, .NBC_ANR_Y_ACT_CEN_TH=32, .rsv_22=0}},
    .ptch      ={.bits={.NBC_ANR_C_H_RNG1=5, .NBC_ANR_C_H_RNG2=10, .NBC_ANR_C_H_RNG3=15, .NBC_ANR_C_H_RNG4=20}},
    .ylvl0     ={.bits={.NBC_ANR_Y_L0_RNG_RAT_TH=8, .NBC_ANR_Y_L1_RNG_RAT_TH=12, .NBC_ANR_Y_L2_RNG_RAT_TH=12, .NBC_ANR_Y_L3_RNG_RAT_TH=15, .NBC_ANR_Y_L0_RNG_RAT_SL=3, .rsv_18=0, .NBC_ANR_Y_L1_RNG_RAT_SL=3, .rsv_22=0, .NBC_ANR_Y_L2_RNG_RAT_SL=3, .rsv_26=0, .NBC_ANR_Y_L3_RNG_RAT_SL=3, .rsv_30=0}},
    .ylvl1     ={.bits={.NBC_ANR_Y_L0_HF_W=16, .rsv_5=0, .NBC_ANR_Y_L1_HF_W=16, .rsv_13=0, .NBC_ANR_Y_L2_HF_W=16, .rsv_21=0, .NBC_ANR_Y_L3_HF_W=16, .rsv_29=0}},
    .hf_cor    ={.bits={.NBC_ANR_Y_HF_CORE_TH=0, .NBC_ANR_Y_HF_CORE_SL=2, .rsv_10=0, .NBC_ANR_Y_HF_CLIP=255, .NBC_ANR_HF_BAL_MODE=1, .rsv_26=0}},
    .hf_act0   ={.bits={.NBC_ANR_Y_HF_ACT_X1=16, .NBC_ANR_Y_HF_ACT_X2=20, .NBC_ANR_Y_HF_ACT_X3=24, .NBC_ANR_Y_HF_ACT_X4=28}},
    .hf_act1   ={.bits={.NBC_ANR_Y_HF_ACT_Y0=20, .rsv_7=0, .NBC_ANR_Y_HF_ACT_Y1=20, .rsv_15=0, .NBC_ANR_Y_HF_ACT_Y2=20, .rsv_23=0, .NBC_ANR_Y_HF_ACT_Y3=20, .rsv_31=0}},
    .actc      ={.bits={.rsv_0=0, .NBC_ANR_ACT_BLD_BASE_C=64, .rsv_15=0, .NBC_ANR_C_DITH_U=8, .rsv_21=0, .NBC_ANR_C_DITH_V=8, .rsv_29=0}},
    .ylad      ={.bits={.NBC_ANR_CEN_GAIN_LO_TH_LPF=0, .rsv_5=0, .NBC_ANR_CEN_GAIN_HI_TH_LPF=0, .rsv_13=0}},
    .hf_act2   ={.bits={.NBC_ANR_Y_HF_ACT_Y4=20, .rsv_7=0, .NBC_ANR_Y_HF_ACT_SP4=0, .rsv_14=0}},
    .hf_act3   ={.bits={.NBC_ANR_Y_HF_ACT_SP0=0, .rsv_6=0, .NBC_ANR_Y_HF_ACT_SP1=0, .rsv_14=0, .NBC_ANR_Y_HF_ACT_SP2=0, .rsv_22=0, .NBC_ANR_Y_HF_ACT_SP3=0, .rsv_30=0}},
    .hf_luma0  ={.bits={.NBC_ANR_Y_HF_LUMA_X1=192, .NBC_ANR_Y_HF_LUMA_X2=224, .NBC_ANR_Y_HF_LUMA_Y0=0, .rsv_23=0, .NBC_ANR_Y_HF_LUMA_Y1=0, .rsv_31=0}},
    .hf_luma1  ={.bits={.NBC_ANR_Y_HF_LUMA_Y2=4, .rsv_7=0, .NBC_ANR_Y_HF_LUMA_SP0=0, .rsv_13=0, .NBC_ANR_Y_HF_LUMA_SP1=1, .rsv_21=0, .NBC_ANR_Y_HF_LUMA_SP2=0, .rsv_29=0}},
    .y4lut4    ={.bits={.NBC_ANR_Y_CPX5=255, .NBC_ANR_Y_CPX6=255, .NBC_ANR_Y_CPX7=255, .NBC_ANR_Y_CPX8=255}},
    .y4lut5    ={.bits={.NBC_ANR_Y_SCALE_CPY4=8, .rsv_5=0, .NBC_ANR_Y_SCALE_CPY5=8, .rsv_13=0, .NBC_ANR_Y_SCALE_CPY6=8, .rsv_21=0, .NBC_ANR_Y_SCALE_CPY7=8, .rsv_29=0}},
    .y4lut6    ={.bits={.NBC_ANR_Y_SCALE_SP4=0, .rsv_5=0, .NBC_ANR_Y_SCALE_SP5=0, .rsv_13=0, .NBC_ANR_Y_SCALE_SP6=1, .rsv_21=0, .NBC_ANR_Y_SCALE_SP7=2, .rsv_29=0}},
    .y4lut7    ={.bits={.NBC_ANR_Y_SCALE_CPY8=8, .rsv_5=0, .NBC_ANR_Y_SCALE_SP8=3, .rsv_13=0}},
    .a4lut1    ={.bits={.NBC_ANR_Y_ACT_CPX1=64, .NBC_ANR_Y_ACT_CPX2=128, .NBC_ANR_Y_ACT_CPX3=192, .rsv_24=0}}

};
const ISP_NVRAM_ANR_T gc13a0mipiraw_NBC_ANR_0183 = {
        .con1      ={.bits={.NBC_ANR_ENC=1, .NBC_ANR_ENY=1, .rsv_2=0, .NBC_ANR_Y_FLT0_IDX=0, .rsv_5=0, .NBC_ANR_Y_FLT1_IDX=0, .rsv_7=0, .NBC_ANR_Y_FLT2_IDX=2, .NBC_ANR_Y_FLT3_IDX=3, .NBC_ANR_ACT_LP_EN=0, .rsv_13=0, .NBC_ANR_TILE_EDGE=15, .NBC_ANR_LTM_LINK=1, .NBC_ANR_LTM_LUT_BYPASS=0, .rsv_22=0, .NBC_ANR_SL2_LINK=1, .rsv_25=0, .NBC_ANR_TABLE_EN=0, .NBC_ANR_TBL_PRC=0, .rsv_30=0}},
    .con2      ={.bits={.NBC_ANR_IMPL_MODE=2, .rsv_2=0, .NBC_ANR_C_SM_EDGE=1, .rsv_10=0, .NBC_ANR_FLT_C=0, .rsv_13=0, .NBC_ANR_C_SM_EDGE_TH=2, .rsv_27=0}},
    .yad1      ={.bits={.NBC_ANR_CEN_GAIN_LO_TH=0, .rsv_5=0, .NBC_ANR_CEN_GAIN_HI_TH=0, .rsv_13=0, .NBC_ANR_Y_SLOPE_V_TH=20, .NBC_ANR_Y_SLOPE_H_TH=16}},
    .yad2      ={.bits={.NBC_ANR_Y_VERT_ACT_TH=7, .rsv_5=0, .NBC_ANR_PTY_GAIN_TH=0, .rsv_13=0, .NBC_ANR_Y_VERT_SIGMA=2, .rsv_24=0}},
    .y4lut1    ={.bits={.NBC_ANR_Y_CPX1=64, .NBC_ANR_Y_CPX2=128, .NBC_ANR_Y_CPX3=192, .NBC_ANR_Y_CPX4=255}},
    .y4lut2    ={.bits={.NBC_ANR_Y_SCALE_CPY0=15, .rsv_5=0, .NBC_ANR_Y_SCALE_CPY1=16, .rsv_13=0, .NBC_ANR_Y_SCALE_CPY2=16, .rsv_21=0, .NBC_ANR_Y_SCALE_CPY3=12, .rsv_29=0}},
    .y4lut3    ={.bits={.NBC_ANR_Y_SCALE_SP0=2, .rsv_5=0, .NBC_ANR_Y_SCALE_SP1=0, .rsv_13=0, .NBC_ANR_Y_SCALE_SP2=24, .rsv_21=0, .NBC_ANR_Y_SCALE_SP3=24, .rsv_29=0}},
    .c4lut1    ={.bits={.NBC_ANR_C_CPX1=40, .NBC_ANR_C_CPX2=120, .NBC_ANR_C_CPX3=160, .rsv_24=0}},
    .c4lut2    ={.bits={.NBC_ANR_C_SCALE_CPY0=16, .rsv_5=0, .NBC_ANR_C_SCALE_CPY1=16, .rsv_13=0, .NBC_ANR_C_SCALE_CPY2=16, .rsv_21=0, .NBC_ANR_C_SCALE_CPY3=8, .rsv_29=0}},
    .c4lut3    ={.bits={.NBC_ANR_C_SCALE_SP0=0, .rsv_5=0, .NBC_ANR_C_SCALE_SP1=0, .rsv_13=0, .NBC_ANR_C_SCALE_SP2=28, .rsv_21=0, .NBC_ANR_C_SCALE_SP3=30, .rsv_29=0}},
    .a4lut2    ={.bits={.NBC_ANR_Y_ACT_CPY0=0, .NBC_ANR_Y_ACT_CPY1=0, .NBC_ANR_Y_ACT_CPY2=0, .NBC_ANR_Y_ACT_CPY3=0}},
    .a4lut3    ={.bits={.NBC_ANR_Y_ACT_SP0=0, .rsv_6=0, .NBC_ANR_Y_ACT_SP1=0, .rsv_14=0, .NBC_ANR_Y_ACT_SP2=0, .rsv_22=0, .NBC_ANR_Y_ACT_SP3=0, .rsv_30=0}},
    .l4lut1    ={.bits={.NBC_ANR_SL2_X1=64, .NBC_ANR_SL2_X2=128, .NBC_ANR_SL2_X3=192, .rsv_24=0}},
    .l4lut2    ={.bits={.NBC_ANR_SL2_GAIN0=16, .rsv_6=0, .NBC_ANR_SL2_GAIN1=20, .rsv_14=0, .NBC_ANR_SL2_GAIN2=24, .rsv_22=0, .NBC_ANR_SL2_GAIN3=28, .rsv_30=0}},
    .l4lut3    ={.bits={.NBC_ANR_SL2_SP0=8, .rsv_6=0, .NBC_ANR_SL2_SP1=8, .rsv_14=0, .NBC_ANR_SL2_SP2=8, .rsv_22=0, .NBC_ANR_SL2_SP3=8, .rsv_30=0}},
    .pty0v     ={.bits={.NBC_ANR_Y_L0_V_RNG1=2, .NBC_ANR_Y_L0_V_RNG2=4, .NBC_ANR_Y_L0_V_RNG3=6, .NBC_ANR_Y_L0_V_RNG4=9}},
    .cad       ={.bits={.rsv_0=0, .NBC_ANR_PTC_GAIN_TH=15, .rsv_13=0, .NBC_ANR_C_L_DIFF_TH=40, .rsv_24=0}},
    .pty1v     ={.bits={.NBC_ANR_Y_L1_V_RNG1=5, .NBC_ANR_Y_L1_V_RNG2=10, .NBC_ANR_Y_L1_V_RNG3=14, .NBC_ANR_Y_L1_V_RNG4=21}},
    .sl2       ={.bits={.NBC_ANR_SL2_C_GAIN=6, .NBC_ANR_SL2_SCALE_GAIN=0, .rsv_7=0}},
    .pty2v     ={.bits={.NBC_ANR_Y_L2_V_RNG1=5, .NBC_ANR_Y_L2_V_RNG2=9, .NBC_ANR_Y_L2_V_RNG3=13, .NBC_ANR_Y_L2_V_RNG4=18}},
    .pty3v     ={.bits={.NBC_ANR_Y_L3_V_RNG1=2, .NBC_ANR_Y_L3_V_RNG2=3, .NBC_ANR_Y_L3_V_RNG3=5, .NBC_ANR_Y_L3_V_RNG4=7}},
    .pty0h     ={.bits={.NBC_ANR_Y_L0_H_RNG1=2, .NBC_ANR_Y_L0_H_RNG2=4, .NBC_ANR_Y_L0_H_RNG3=6, .NBC_ANR_Y_L0_H_RNG4=8}},
    .pty1h     ={.bits={.NBC_ANR_Y_L1_H_RNG1=5, .NBC_ANR_Y_L1_H_RNG2=9, .NBC_ANR_Y_L1_H_RNG3=13, .NBC_ANR_Y_L1_H_RNG4=18}},
    .pty2h     ={.bits={.NBC_ANR_Y_L2_H_RNG1=4, .NBC_ANR_Y_L2_H_RNG2=8, .NBC_ANR_Y_L2_H_RNG3=11, .NBC_ANR_Y_L2_H_RNG4=16}},
    .t4lut1    ={.bits={.NBC_ANR_TBL_CPX1=64, .NBC_ANR_TBL_CPX2=128, .NBC_ANR_TBL_CPX3=192, .rsv_24=0}},
    .t4lut2    ={.bits={.NBC_ANR_TBL_GAIN_CPY0=1, .rsv_5=0, .NBC_ANR_TBL_GAIN_CPY1=8, .rsv_13=0, .NBC_ANR_TBL_GAIN_CPY2=16, .rsv_21=0, .NBC_ANR_TBL_GAIN_CPY3=24, .rsv_29=0}},
    .t4lut3    ={.bits={.NBC_ANR_TBL_GAIN_SP0=14, .rsv_5=0, .NBC_ANR_TBL_GAIN_SP1=15, .rsv_13=0, .NBC_ANR_TBL_GAIN_SP2=15, .rsv_21=0, .NBC_ANR_TBL_GAIN_SP3=15, .rsv_29=0}},
    .act1      ={.bits={.NBC_ANR_ACT_SL2_GAIN=8, .rsv_4=0, .NBC_ANR_ACT_DIF_HI_TH=16, .rsv_13=0, .NBC_ANR_ACT_DIF_GAIN=4, .NBC_ANR_ACT_DIF_LO_TH=16, .rsv_29=0}},
    .pty3h     ={.bits={.NBC_ANR_Y_L3_H_RNG1=2, .NBC_ANR_Y_L3_H_RNG2=3, .NBC_ANR_Y_L3_H_RNG3=4, .NBC_ANR_Y_L3_H_RNG4=6}},
    .ptcv      ={.bits={.NBC_ANR_C_V_RNG1=5, .NBC_ANR_C_V_RNG2=11, .NBC_ANR_C_V_RNG3=16, .NBC_ANR_C_V_RNG4=22}},
    .act4      ={.bits={.NBC_ANR_Y_ACT_CEN_OFT=32, .rsv_6=0, .NBC_ANR_Y_ACT_CEN_GAIN=0, .rsv_14=0, .NBC_ANR_Y_ACT_CEN_TH=32, .rsv_22=0}},
    .ptch      ={.bits={.NBC_ANR_C_H_RNG1=5, .NBC_ANR_C_H_RNG2=10, .NBC_ANR_C_H_RNG3=15, .NBC_ANR_C_H_RNG4=20}},
    .ylvl0     ={.bits={.NBC_ANR_Y_L0_RNG_RAT_TH=8, .NBC_ANR_Y_L1_RNG_RAT_TH=12, .NBC_ANR_Y_L2_RNG_RAT_TH=12, .NBC_ANR_Y_L3_RNG_RAT_TH=15, .NBC_ANR_Y_L0_RNG_RAT_SL=3, .rsv_18=0, .NBC_ANR_Y_L1_RNG_RAT_SL=3, .rsv_22=0, .NBC_ANR_Y_L2_RNG_RAT_SL=3, .rsv_26=0, .NBC_ANR_Y_L3_RNG_RAT_SL=3, .rsv_30=0}},
    .ylvl1     ={.bits={.NBC_ANR_Y_L0_HF_W=18, .rsv_5=0, .NBC_ANR_Y_L1_HF_W=18, .rsv_13=0, .NBC_ANR_Y_L2_HF_W=18, .rsv_21=0, .NBC_ANR_Y_L3_HF_W=18, .rsv_29=0}},
    .hf_cor    ={.bits={.NBC_ANR_Y_HF_CORE_TH=0, .NBC_ANR_Y_HF_CORE_SL=2, .rsv_10=0, .NBC_ANR_Y_HF_CLIP=255, .NBC_ANR_HF_BAL_MODE=1, .rsv_26=0}},
    .hf_act0   ={.bits={.NBC_ANR_Y_HF_ACT_X1=16, .NBC_ANR_Y_HF_ACT_X2=20, .NBC_ANR_Y_HF_ACT_X3=24, .NBC_ANR_Y_HF_ACT_X4=28}},
    .hf_act1   ={.bits={.NBC_ANR_Y_HF_ACT_Y0=24, .rsv_7=0, .NBC_ANR_Y_HF_ACT_Y1=24, .rsv_15=0, .NBC_ANR_Y_HF_ACT_Y2=24, .rsv_23=0, .NBC_ANR_Y_HF_ACT_Y3=24, .rsv_31=0}},
    .actc      ={.bits={.rsv_0=0, .NBC_ANR_ACT_BLD_BASE_C=64, .rsv_15=0, .NBC_ANR_C_DITH_U=8, .rsv_21=0, .NBC_ANR_C_DITH_V=8, .rsv_29=0}},
    .ylad      ={.bits={.NBC_ANR_CEN_GAIN_LO_TH_LPF=0, .rsv_5=0, .NBC_ANR_CEN_GAIN_HI_TH_LPF=0, .rsv_13=0}},
    .hf_act2   ={.bits={.NBC_ANR_Y_HF_ACT_Y4=24, .rsv_7=0, .NBC_ANR_Y_HF_ACT_SP4=0, .rsv_14=0}},
    .hf_act3   ={.bits={.NBC_ANR_Y_HF_ACT_SP0=0, .rsv_6=0, .NBC_ANR_Y_HF_ACT_SP1=0, .rsv_14=0, .NBC_ANR_Y_HF_ACT_SP2=0, .rsv_22=0, .NBC_ANR_Y_HF_ACT_SP3=0, .rsv_30=0}},
    .hf_luma0  ={.bits={.NBC_ANR_Y_HF_LUMA_X1=192, .NBC_ANR_Y_HF_LUMA_X2=224, .NBC_ANR_Y_HF_LUMA_Y0=0, .rsv_23=0, .NBC_ANR_Y_HF_LUMA_Y1=0, .rsv_31=0}},
    .hf_luma1  ={.bits={.NBC_ANR_Y_HF_LUMA_Y2=4, .rsv_7=0, .NBC_ANR_Y_HF_LUMA_SP0=0, .rsv_13=0, .NBC_ANR_Y_HF_LUMA_SP1=1, .rsv_21=0, .NBC_ANR_Y_HF_LUMA_SP2=0, .rsv_29=0}},
    .y4lut4    ={.bits={.NBC_ANR_Y_CPX5=255, .NBC_ANR_Y_CPX6=255, .NBC_ANR_Y_CPX7=255, .NBC_ANR_Y_CPX8=255}},
    .y4lut5    ={.bits={.NBC_ANR_Y_SCALE_CPY4=8, .rsv_5=0, .NBC_ANR_Y_SCALE_CPY5=8, .rsv_13=0, .NBC_ANR_Y_SCALE_CPY6=8, .rsv_21=0, .NBC_ANR_Y_SCALE_CPY7=8, .rsv_29=0}},
    .y4lut6    ={.bits={.NBC_ANR_Y_SCALE_SP4=0, .rsv_5=0, .NBC_ANR_Y_SCALE_SP5=0, .rsv_13=0, .NBC_ANR_Y_SCALE_SP6=1, .rsv_21=0, .NBC_ANR_Y_SCALE_SP7=2, .rsv_29=0}},
    .y4lut7    ={.bits={.NBC_ANR_Y_SCALE_CPY8=8, .rsv_5=0, .NBC_ANR_Y_SCALE_SP8=3, .rsv_13=0}},
    .a4lut1    ={.bits={.NBC_ANR_Y_ACT_CPX1=64, .NBC_ANR_Y_ACT_CPX2=128, .NBC_ANR_Y_ACT_CPX3=192, .rsv_24=0}}

};
const ISP_NVRAM_ANR_T gc13a0mipiraw_NBC_ANR_0184 = {
        .con1      ={.bits={.NBC_ANR_ENC=1, .NBC_ANR_ENY=1, .rsv_2=0, .NBC_ANR_Y_FLT0_IDX=0, .rsv_5=0, .NBC_ANR_Y_FLT1_IDX=0, .rsv_7=0, .NBC_ANR_Y_FLT2_IDX=2, .NBC_ANR_Y_FLT3_IDX=3, .NBC_ANR_ACT_LP_EN=0, .rsv_13=0, .NBC_ANR_TILE_EDGE=15, .NBC_ANR_LTM_LINK=1, .NBC_ANR_LTM_LUT_BYPASS=0, .rsv_22=0, .NBC_ANR_SL2_LINK=1, .rsv_25=0, .NBC_ANR_TABLE_EN=0, .NBC_ANR_TBL_PRC=0, .rsv_30=0}},
    .con2      ={.bits={.NBC_ANR_IMPL_MODE=2, .rsv_2=0, .NBC_ANR_C_SM_EDGE=1, .rsv_10=0, .NBC_ANR_FLT_C=0, .rsv_13=0, .NBC_ANR_C_SM_EDGE_TH=2, .rsv_27=0}},
    .yad1      ={.bits={.NBC_ANR_CEN_GAIN_LO_TH=1, .rsv_5=0, .NBC_ANR_CEN_GAIN_HI_TH=1, .rsv_13=0, .NBC_ANR_Y_SLOPE_V_TH=20, .NBC_ANR_Y_SLOPE_H_TH=16}},
    .yad2      ={.bits={.NBC_ANR_Y_VERT_ACT_TH=7, .rsv_5=0, .NBC_ANR_PTY_GAIN_TH=0, .rsv_13=0, .NBC_ANR_Y_VERT_SIGMA=2, .rsv_24=0}},
    .y4lut1    ={.bits={.NBC_ANR_Y_CPX1=64, .NBC_ANR_Y_CPX2=128, .NBC_ANR_Y_CPX3=192, .NBC_ANR_Y_CPX4=255}},
    .y4lut2    ={.bits={.NBC_ANR_Y_SCALE_CPY0=15, .rsv_5=0, .NBC_ANR_Y_SCALE_CPY1=16, .rsv_13=0, .NBC_ANR_Y_SCALE_CPY2=16, .rsv_21=0, .NBC_ANR_Y_SCALE_CPY3=12, .rsv_29=0}},
    .y4lut3    ={.bits={.NBC_ANR_Y_SCALE_SP0=2, .rsv_5=0, .NBC_ANR_Y_SCALE_SP1=0, .rsv_13=0, .NBC_ANR_Y_SCALE_SP2=24, .rsv_21=0, .NBC_ANR_Y_SCALE_SP3=24, .rsv_29=0}},
    .c4lut1    ={.bits={.NBC_ANR_C_CPX1=40, .NBC_ANR_C_CPX2=120, .NBC_ANR_C_CPX3=160, .rsv_24=0}},
    .c4lut2    ={.bits={.NBC_ANR_C_SCALE_CPY0=16, .rsv_5=0, .NBC_ANR_C_SCALE_CPY1=16, .rsv_13=0, .NBC_ANR_C_SCALE_CPY2=16, .rsv_21=0, .NBC_ANR_C_SCALE_CPY3=8, .rsv_29=0}},
    .c4lut3    ={.bits={.NBC_ANR_C_SCALE_SP0=0, .rsv_5=0, .NBC_ANR_C_SCALE_SP1=0, .rsv_13=0, .NBC_ANR_C_SCALE_SP2=28, .rsv_21=0, .NBC_ANR_C_SCALE_SP3=30, .rsv_29=0}},
    .a4lut2    ={.bits={.NBC_ANR_Y_ACT_CPY0=0, .NBC_ANR_Y_ACT_CPY1=0, .NBC_ANR_Y_ACT_CPY2=0, .NBC_ANR_Y_ACT_CPY3=0}},
    .a4lut3    ={.bits={.NBC_ANR_Y_ACT_SP0=0, .rsv_6=0, .NBC_ANR_Y_ACT_SP1=0, .rsv_14=0, .NBC_ANR_Y_ACT_SP2=0, .rsv_22=0, .NBC_ANR_Y_ACT_SP3=0, .rsv_30=0}},
    .l4lut1    ={.bits={.NBC_ANR_SL2_X1=64, .NBC_ANR_SL2_X2=128, .NBC_ANR_SL2_X3=192, .rsv_24=0}},
    .l4lut2    ={.bits={.NBC_ANR_SL2_GAIN0=16, .rsv_6=0, .NBC_ANR_SL2_GAIN1=20, .rsv_14=0, .NBC_ANR_SL2_GAIN2=24, .rsv_22=0, .NBC_ANR_SL2_GAIN3=28, .rsv_30=0}},
    .l4lut3    ={.bits={.NBC_ANR_SL2_SP0=8, .rsv_6=0, .NBC_ANR_SL2_SP1=8, .rsv_14=0, .NBC_ANR_SL2_SP2=8, .rsv_22=0, .NBC_ANR_SL2_SP3=8, .rsv_30=0}},
    .pty0v     ={.bits={.NBC_ANR_Y_L0_V_RNG1=2, .NBC_ANR_Y_L0_V_RNG2=4, .NBC_ANR_Y_L0_V_RNG3=6, .NBC_ANR_Y_L0_V_RNG4=9}},
    .cad       ={.bits={.rsv_0=0, .NBC_ANR_PTC_GAIN_TH=15, .rsv_13=0, .NBC_ANR_C_L_DIFF_TH=42, .rsv_24=0}},
    .pty1v     ={.bits={.NBC_ANR_Y_L1_V_RNG1=6, .NBC_ANR_Y_L1_V_RNG2=11, .NBC_ANR_Y_L1_V_RNG3=17, .NBC_ANR_Y_L1_V_RNG4=24}},
    .sl2       ={.bits={.NBC_ANR_SL2_C_GAIN=6, .NBC_ANR_SL2_SCALE_GAIN=0, .rsv_7=0}},
    .pty2v     ={.bits={.NBC_ANR_Y_L2_V_RNG1=6, .NBC_ANR_Y_L2_V_RNG2=11, .NBC_ANR_Y_L2_V_RNG3=17, .NBC_ANR_Y_L2_V_RNG4=24}},
    .pty3v     ={.bits={.NBC_ANR_Y_L3_V_RNG1=4, .NBC_ANR_Y_L3_V_RNG2=7, .NBC_ANR_Y_L3_V_RNG3=9, .NBC_ANR_Y_L3_V_RNG4=14}},
    .pty0h     ={.bits={.NBC_ANR_Y_L0_H_RNG1=2, .NBC_ANR_Y_L0_H_RNG2=4, .NBC_ANR_Y_L0_H_RNG3=6, .NBC_ANR_Y_L0_H_RNG4=8}},
    .pty1h     ={.bits={.NBC_ANR_Y_L1_H_RNG1=5, .NBC_ANR_Y_L1_H_RNG2=10, .NBC_ANR_Y_L1_H_RNG3=15, .NBC_ANR_Y_L1_H_RNG4=21}},
    .pty2h     ={.bits={.NBC_ANR_Y_L2_H_RNG1=5, .NBC_ANR_Y_L2_H_RNG2=10, .NBC_ANR_Y_L2_H_RNG3=15, .NBC_ANR_Y_L2_H_RNG4=21}},
    .t4lut1    ={.bits={.NBC_ANR_TBL_CPX1=64, .NBC_ANR_TBL_CPX2=128, .NBC_ANR_TBL_CPX3=192, .rsv_24=0}},
    .t4lut2    ={.bits={.NBC_ANR_TBL_GAIN_CPY0=1, .rsv_5=0, .NBC_ANR_TBL_GAIN_CPY1=8, .rsv_13=0, .NBC_ANR_TBL_GAIN_CPY2=16, .rsv_21=0, .NBC_ANR_TBL_GAIN_CPY3=24, .rsv_29=0}},
    .t4lut3    ={.bits={.NBC_ANR_TBL_GAIN_SP0=14, .rsv_5=0, .NBC_ANR_TBL_GAIN_SP1=15, .rsv_13=0, .NBC_ANR_TBL_GAIN_SP2=15, .rsv_21=0, .NBC_ANR_TBL_GAIN_SP3=15, .rsv_29=0}},
    .act1      ={.bits={.NBC_ANR_ACT_SL2_GAIN=8, .rsv_4=0, .NBC_ANR_ACT_DIF_HI_TH=16, .rsv_13=0, .NBC_ANR_ACT_DIF_GAIN=4, .NBC_ANR_ACT_DIF_LO_TH=16, .rsv_29=0}},
    .pty3h     ={.bits={.NBC_ANR_Y_L3_H_RNG1=3, .NBC_ANR_Y_L3_H_RNG2=6, .NBC_ANR_Y_L3_H_RNG3=8, .NBC_ANR_Y_L3_H_RNG4=12}},
    .ptcv      ={.bits={.NBC_ANR_C_V_RNG1=5, .NBC_ANR_C_V_RNG2=11, .NBC_ANR_C_V_RNG3=16, .NBC_ANR_C_V_RNG4=22}},
    .act4      ={.bits={.NBC_ANR_Y_ACT_CEN_OFT=32, .rsv_6=0, .NBC_ANR_Y_ACT_CEN_GAIN=0, .rsv_14=0, .NBC_ANR_Y_ACT_CEN_TH=32, .rsv_22=0}},
    .ptch      ={.bits={.NBC_ANR_C_H_RNG1=5, .NBC_ANR_C_H_RNG2=10, .NBC_ANR_C_H_RNG3=15, .NBC_ANR_C_H_RNG4=20}},
    .ylvl0     ={.bits={.NBC_ANR_Y_L0_RNG_RAT_TH=8, .NBC_ANR_Y_L1_RNG_RAT_TH=12, .NBC_ANR_Y_L2_RNG_RAT_TH=12, .NBC_ANR_Y_L3_RNG_RAT_TH=15, .NBC_ANR_Y_L0_RNG_RAT_SL=3, .rsv_18=0, .NBC_ANR_Y_L1_RNG_RAT_SL=3, .rsv_22=0, .NBC_ANR_Y_L2_RNG_RAT_SL=3, .rsv_26=0, .NBC_ANR_Y_L3_RNG_RAT_SL=3, .rsv_30=0}},
    .ylvl1     ={.bits={.NBC_ANR_Y_L0_HF_W=16, .rsv_5=0, .NBC_ANR_Y_L1_HF_W=16, .rsv_13=0, .NBC_ANR_Y_L2_HF_W=16, .rsv_21=0, .NBC_ANR_Y_L3_HF_W=16, .rsv_29=0}},
    .hf_cor    ={.bits={.NBC_ANR_Y_HF_CORE_TH=0, .NBC_ANR_Y_HF_CORE_SL=2, .rsv_10=0, .NBC_ANR_Y_HF_CLIP=255, .NBC_ANR_HF_BAL_MODE=1, .rsv_26=0}},
    .hf_act0   ={.bits={.NBC_ANR_Y_HF_ACT_X1=16, .NBC_ANR_Y_HF_ACT_X2=20, .NBC_ANR_Y_HF_ACT_X3=24, .NBC_ANR_Y_HF_ACT_X4=28}},
    .hf_act1   ={.bits={.NBC_ANR_Y_HF_ACT_Y0=18, .rsv_7=0, .NBC_ANR_Y_HF_ACT_Y1=18, .rsv_15=0, .NBC_ANR_Y_HF_ACT_Y2=18, .rsv_23=0, .NBC_ANR_Y_HF_ACT_Y3=18, .rsv_31=0}},
    .actc      ={.bits={.rsv_0=0, .NBC_ANR_ACT_BLD_BASE_C=64, .rsv_15=0, .NBC_ANR_C_DITH_U=8, .rsv_21=0, .NBC_ANR_C_DITH_V=8, .rsv_29=0}},
    .ylad      ={.bits={.NBC_ANR_CEN_GAIN_LO_TH_LPF=1, .rsv_5=0, .NBC_ANR_CEN_GAIN_HI_TH_LPF=1, .rsv_13=0}},
    .hf_act2   ={.bits={.NBC_ANR_Y_HF_ACT_Y4=18, .rsv_7=0, .NBC_ANR_Y_HF_ACT_SP4=0, .rsv_14=0}},
    .hf_act3   ={.bits={.NBC_ANR_Y_HF_ACT_SP0=0, .rsv_6=0, .NBC_ANR_Y_HF_ACT_SP1=0, .rsv_14=0, .NBC_ANR_Y_HF_ACT_SP2=0, .rsv_22=0, .NBC_ANR_Y_HF_ACT_SP3=0, .rsv_30=0}},
    .hf_luma0  ={.bits={.NBC_ANR_Y_HF_LUMA_X1=192, .NBC_ANR_Y_HF_LUMA_X2=224, .NBC_ANR_Y_HF_LUMA_Y0=0, .rsv_23=0, .NBC_ANR_Y_HF_LUMA_Y1=0, .rsv_31=0}},
    .hf_luma1  ={.bits={.NBC_ANR_Y_HF_LUMA_Y2=4, .rsv_7=0, .NBC_ANR_Y_HF_LUMA_SP0=0, .rsv_13=0, .NBC_ANR_Y_HF_LUMA_SP1=1, .rsv_21=0, .NBC_ANR_Y_HF_LUMA_SP2=0, .rsv_29=0}},
    .y4lut4    ={.bits={.NBC_ANR_Y_CPX5=255, .NBC_ANR_Y_CPX6=255, .NBC_ANR_Y_CPX7=255, .NBC_ANR_Y_CPX8=255}},
    .y4lut5    ={.bits={.NBC_ANR_Y_SCALE_CPY4=8, .rsv_5=0, .NBC_ANR_Y_SCALE_CPY5=8, .rsv_13=0, .NBC_ANR_Y_SCALE_CPY6=8, .rsv_21=0, .NBC_ANR_Y_SCALE_CPY7=8, .rsv_29=0}},
    .y4lut6    ={.bits={.NBC_ANR_Y_SCALE_SP4=0, .rsv_5=0, .NBC_ANR_Y_SCALE_SP5=0, .rsv_13=0, .NBC_ANR_Y_SCALE_SP6=1, .rsv_21=0, .NBC_ANR_Y_SCALE_SP7=2, .rsv_29=0}},
    .y4lut7    ={.bits={.NBC_ANR_Y_SCALE_CPY8=8, .rsv_5=0, .NBC_ANR_Y_SCALE_SP8=3, .rsv_13=0}},
    .a4lut1    ={.bits={.NBC_ANR_Y_ACT_CPX1=64, .NBC_ANR_Y_ACT_CPX2=128, .NBC_ANR_Y_ACT_CPX3=192, .rsv_24=0}}

};
const ISP_NVRAM_ANR_T gc13a0mipiraw_NBC_ANR_0185 = {
        .con1      ={.bits={.NBC_ANR_ENC=1, .NBC_ANR_ENY=1, .rsv_2=0, .NBC_ANR_Y_FLT0_IDX=0, .rsv_5=0, .NBC_ANR_Y_FLT1_IDX=0, .rsv_7=0, .NBC_ANR_Y_FLT2_IDX=2, .NBC_ANR_Y_FLT3_IDX=3, .NBC_ANR_ACT_LP_EN=0, .rsv_13=0, .NBC_ANR_TILE_EDGE=15, .NBC_ANR_LTM_LINK=1, .NBC_ANR_LTM_LUT_BYPASS=0, .rsv_22=0, .NBC_ANR_SL2_LINK=1, .rsv_25=0, .NBC_ANR_TABLE_EN=0, .NBC_ANR_TBL_PRC=0, .rsv_30=0}},
    .con2      ={.bits={.NBC_ANR_IMPL_MODE=2, .rsv_2=0, .NBC_ANR_C_SM_EDGE=1, .rsv_10=0, .NBC_ANR_FLT_C=0, .rsv_13=0, .NBC_ANR_C_SM_EDGE_TH=2, .rsv_27=0}},
    .yad1      ={.bits={.NBC_ANR_CEN_GAIN_LO_TH=0, .rsv_5=0, .NBC_ANR_CEN_GAIN_HI_TH=0, .rsv_13=0, .NBC_ANR_Y_SLOPE_V_TH=20, .NBC_ANR_Y_SLOPE_H_TH=16}},
    .yad2      ={.bits={.NBC_ANR_Y_VERT_ACT_TH=7, .rsv_5=0, .NBC_ANR_PTY_GAIN_TH=0, .rsv_13=0, .NBC_ANR_Y_VERT_SIGMA=2, .rsv_24=0}},
    .y4lut1    ={.bits={.NBC_ANR_Y_CPX1=64, .NBC_ANR_Y_CPX2=128, .NBC_ANR_Y_CPX3=192, .NBC_ANR_Y_CPX4=255}},
    .y4lut2    ={.bits={.NBC_ANR_Y_SCALE_CPY0=15, .rsv_5=0, .NBC_ANR_Y_SCALE_CPY1=16, .rsv_13=0, .NBC_ANR_Y_SCALE_CPY2=16, .rsv_21=0, .NBC_ANR_Y_SCALE_CPY3=12, .rsv_29=0}},
    .y4lut3    ={.bits={.NBC_ANR_Y_SCALE_SP0=2, .rsv_5=0, .NBC_ANR_Y_SCALE_SP1=0, .rsv_13=0, .NBC_ANR_Y_SCALE_SP2=24, .rsv_21=0, .NBC_ANR_Y_SCALE_SP3=24, .rsv_29=0}},
    .c4lut1    ={.bits={.NBC_ANR_C_CPX1=40, .NBC_ANR_C_CPX2=120, .NBC_ANR_C_CPX3=160, .rsv_24=0}},
    .c4lut2    ={.bits={.NBC_ANR_C_SCALE_CPY0=16, .rsv_5=0, .NBC_ANR_C_SCALE_CPY1=16, .rsv_13=0, .NBC_ANR_C_SCALE_CPY2=16, .rsv_21=0, .NBC_ANR_C_SCALE_CPY3=8, .rsv_29=0}},
    .c4lut3    ={.bits={.NBC_ANR_C_SCALE_SP0=0, .rsv_5=0, .NBC_ANR_C_SCALE_SP1=0, .rsv_13=0, .NBC_ANR_C_SCALE_SP2=28, .rsv_21=0, .NBC_ANR_C_SCALE_SP3=30, .rsv_29=0}},
    .a4lut2    ={.bits={.NBC_ANR_Y_ACT_CPY0=0, .NBC_ANR_Y_ACT_CPY1=0, .NBC_ANR_Y_ACT_CPY2=0, .NBC_ANR_Y_ACT_CPY3=0}},
    .a4lut3    ={.bits={.NBC_ANR_Y_ACT_SP0=0, .rsv_6=0, .NBC_ANR_Y_ACT_SP1=0, .rsv_14=0, .NBC_ANR_Y_ACT_SP2=0, .rsv_22=0, .NBC_ANR_Y_ACT_SP3=0, .rsv_30=0}},
    .l4lut1    ={.bits={.NBC_ANR_SL2_X1=64, .NBC_ANR_SL2_X2=128, .NBC_ANR_SL2_X3=192, .rsv_24=0}},
    .l4lut2    ={.bits={.NBC_ANR_SL2_GAIN0=16, .rsv_6=0, .NBC_ANR_SL2_GAIN1=20, .rsv_14=0, .NBC_ANR_SL2_GAIN2=24, .rsv_22=0, .NBC_ANR_SL2_GAIN3=28, .rsv_30=0}},
    .l4lut3    ={.bits={.NBC_ANR_SL2_SP0=8, .rsv_6=0, .NBC_ANR_SL2_SP1=8, .rsv_14=0, .NBC_ANR_SL2_SP2=8, .rsv_22=0, .NBC_ANR_SL2_SP3=8, .rsv_30=0}},
    .pty0v     ={.bits={.NBC_ANR_Y_L0_V_RNG1=2, .NBC_ANR_Y_L0_V_RNG2=4, .NBC_ANR_Y_L0_V_RNG3=6, .NBC_ANR_Y_L0_V_RNG4=9}},
    .cad       ={.bits={.rsv_0=0, .NBC_ANR_PTC_GAIN_TH=0, .rsv_13=0, .NBC_ANR_C_L_DIFF_TH=24, .rsv_24=0}},
    .pty1v     ={.bits={.NBC_ANR_Y_L1_V_RNG1=2, .NBC_ANR_Y_L1_V_RNG2=4, .NBC_ANR_Y_L1_V_RNG3=6, .NBC_ANR_Y_L1_V_RNG4=9}},
    .sl2       ={.bits={.NBC_ANR_SL2_C_GAIN=6, .NBC_ANR_SL2_SCALE_GAIN=0, .rsv_7=0}},
    .pty2v     ={.bits={.NBC_ANR_Y_L2_V_RNG1=2, .NBC_ANR_Y_L2_V_RNG2=4, .NBC_ANR_Y_L2_V_RNG3=6, .NBC_ANR_Y_L2_V_RNG4=9}},
    .pty3v     ={.bits={.NBC_ANR_Y_L3_V_RNG1=1, .NBC_ANR_Y_L3_V_RNG2=2, .NBC_ANR_Y_L3_V_RNG3=3, .NBC_ANR_Y_L3_V_RNG4=5}},
    .pty0h     ={.bits={.NBC_ANR_Y_L0_H_RNG1=2, .NBC_ANR_Y_L0_H_RNG2=4, .NBC_ANR_Y_L0_H_RNG3=6, .NBC_ANR_Y_L0_H_RNG4=8}},
    .pty1h     ={.bits={.NBC_ANR_Y_L1_H_RNG1=2, .NBC_ANR_Y_L1_H_RNG2=4, .NBC_ANR_Y_L1_H_RNG3=6, .NBC_ANR_Y_L1_H_RNG4=8}},
    .pty2h     ={.bits={.NBC_ANR_Y_L2_H_RNG1=2, .NBC_ANR_Y_L2_H_RNG2=4, .NBC_ANR_Y_L2_H_RNG3=6, .NBC_ANR_Y_L2_H_RNG4=8}},
    .t4lut1    ={.bits={.NBC_ANR_TBL_CPX1=64, .NBC_ANR_TBL_CPX2=128, .NBC_ANR_TBL_CPX3=192, .rsv_24=0}},
    .t4lut2    ={.bits={.NBC_ANR_TBL_GAIN_CPY0=1, .rsv_5=0, .NBC_ANR_TBL_GAIN_CPY1=8, .rsv_13=0, .NBC_ANR_TBL_GAIN_CPY2=16, .rsv_21=0, .NBC_ANR_TBL_GAIN_CPY3=24, .rsv_29=0}},
    .t4lut3    ={.bits={.NBC_ANR_TBL_GAIN_SP0=14, .rsv_5=0, .NBC_ANR_TBL_GAIN_SP1=15, .rsv_13=0, .NBC_ANR_TBL_GAIN_SP2=15, .rsv_21=0, .NBC_ANR_TBL_GAIN_SP3=15, .rsv_29=0}},
    .act1      ={.bits={.NBC_ANR_ACT_SL2_GAIN=8, .rsv_4=0, .NBC_ANR_ACT_DIF_HI_TH=16, .rsv_13=0, .NBC_ANR_ACT_DIF_GAIN=4, .NBC_ANR_ACT_DIF_LO_TH=16, .rsv_29=0}},
    .pty3h     ={.bits={.NBC_ANR_Y_L3_H_RNG1=1, .NBC_ANR_Y_L3_H_RNG2=2, .NBC_ANR_Y_L3_H_RNG3=3, .NBC_ANR_Y_L3_H_RNG4=4}},
    .ptcv      ={.bits={.NBC_ANR_C_V_RNG1=2, .NBC_ANR_C_V_RNG2=4, .NBC_ANR_C_V_RNG3=6, .NBC_ANR_C_V_RNG4=9}},
    .act4      ={.bits={.NBC_ANR_Y_ACT_CEN_OFT=32, .rsv_6=0, .NBC_ANR_Y_ACT_CEN_GAIN=0, .rsv_14=0, .NBC_ANR_Y_ACT_CEN_TH=32, .rsv_22=0}},
    .ptch      ={.bits={.NBC_ANR_C_H_RNG1=2, .NBC_ANR_C_H_RNG2=4, .NBC_ANR_C_H_RNG3=6, .NBC_ANR_C_H_RNG4=8}},
    .ylvl0     ={.bits={.NBC_ANR_Y_L0_RNG_RAT_TH=8, .NBC_ANR_Y_L1_RNG_RAT_TH=12, .NBC_ANR_Y_L2_RNG_RAT_TH=12, .NBC_ANR_Y_L3_RNG_RAT_TH=15, .NBC_ANR_Y_L0_RNG_RAT_SL=3, .rsv_18=0, .NBC_ANR_Y_L1_RNG_RAT_SL=3, .rsv_22=0, .NBC_ANR_Y_L2_RNG_RAT_SL=3, .rsv_26=0, .NBC_ANR_Y_L3_RNG_RAT_SL=3, .rsv_30=0}},
    .ylvl1     ={.bits={.NBC_ANR_Y_L0_HF_W=16, .rsv_5=0, .NBC_ANR_Y_L1_HF_W=8, .rsv_13=0, .NBC_ANR_Y_L2_HF_W=4, .rsv_21=0, .NBC_ANR_Y_L3_HF_W=4, .rsv_29=0}},
    .hf_cor    ={.bits={.NBC_ANR_Y_HF_CORE_TH=0, .NBC_ANR_Y_HF_CORE_SL=2, .rsv_10=0, .NBC_ANR_Y_HF_CLIP=255, .NBC_ANR_HF_BAL_MODE=1, .rsv_26=0}},
    .hf_act0   ={.bits={.NBC_ANR_Y_HF_ACT_X1=16, .NBC_ANR_Y_HF_ACT_X2=24, .NBC_ANR_Y_HF_ACT_X3=32, .NBC_ANR_Y_HF_ACT_X4=40}},
    .hf_act1   ={.bits={.NBC_ANR_Y_HF_ACT_Y0=24, .rsv_7=0, .NBC_ANR_Y_HF_ACT_Y1=24, .rsv_15=0, .NBC_ANR_Y_HF_ACT_Y2=56, .rsv_23=0, .NBC_ANR_Y_HF_ACT_Y3=56, .rsv_31=0}},
    .actc      ={.bits={.rsv_0=0, .NBC_ANR_ACT_BLD_BASE_C=48, .rsv_15=0, .NBC_ANR_C_DITH_U=8, .rsv_21=0, .NBC_ANR_C_DITH_V=8, .rsv_29=0}},
    .ylad      ={.bits={.NBC_ANR_CEN_GAIN_LO_TH_LPF=1, .rsv_5=0, .NBC_ANR_CEN_GAIN_HI_TH_LPF=6, .rsv_13=0}},
    .hf_act2   ={.bits={.NBC_ANR_Y_HF_ACT_Y4=40, .rsv_7=0, .NBC_ANR_Y_HF_ACT_SP4=0, .rsv_14=0}},
    .hf_act3   ={.bits={.NBC_ANR_Y_HF_ACT_SP0=0, .rsv_6=0, .NBC_ANR_Y_HF_ACT_SP1=31, .rsv_14=0, .NBC_ANR_Y_HF_ACT_SP2=0, .rsv_22=0, .NBC_ANR_Y_HF_ACT_SP3=48, .rsv_30=0}},
    .hf_luma0  ={.bits={.NBC_ANR_Y_HF_LUMA_X1=192, .NBC_ANR_Y_HF_LUMA_X2=224, .NBC_ANR_Y_HF_LUMA_Y0=0, .rsv_23=0, .NBC_ANR_Y_HF_LUMA_Y1=0, .rsv_31=0}},
    .hf_luma1  ={.bits={.NBC_ANR_Y_HF_LUMA_Y2=4, .rsv_7=0, .NBC_ANR_Y_HF_LUMA_SP0=0, .rsv_13=0, .NBC_ANR_Y_HF_LUMA_SP1=1, .rsv_21=0, .NBC_ANR_Y_HF_LUMA_SP2=0, .rsv_29=0}},
    .y4lut4    ={.bits={.NBC_ANR_Y_CPX5=255, .NBC_ANR_Y_CPX6=255, .NBC_ANR_Y_CPX7=255, .NBC_ANR_Y_CPX8=255}},
    .y4lut5    ={.bits={.NBC_ANR_Y_SCALE_CPY4=8, .rsv_5=0, .NBC_ANR_Y_SCALE_CPY5=8, .rsv_13=0, .NBC_ANR_Y_SCALE_CPY6=8, .rsv_21=0, .NBC_ANR_Y_SCALE_CPY7=8, .rsv_29=0}},
    .y4lut6    ={.bits={.NBC_ANR_Y_SCALE_SP4=0, .rsv_5=0, .NBC_ANR_Y_SCALE_SP5=0, .rsv_13=0, .NBC_ANR_Y_SCALE_SP6=1, .rsv_21=0, .NBC_ANR_Y_SCALE_SP7=2, .rsv_29=0}},
    .y4lut7    ={.bits={.NBC_ANR_Y_SCALE_CPY8=8, .rsv_5=0, .NBC_ANR_Y_SCALE_SP8=3, .rsv_13=0}},
    .a4lut1    ={.bits={.NBC_ANR_Y_ACT_CPX1=64, .NBC_ANR_Y_ACT_CPX2=128, .NBC_ANR_Y_ACT_CPX3=192, .rsv_24=0}}

};
const ISP_NVRAM_ANR_T gc13a0mipiraw_NBC_ANR_0186 = {
        .con1      ={.bits={.NBC_ANR_ENC=1, .NBC_ANR_ENY=1, .rsv_2=0, .NBC_ANR_Y_FLT0_IDX=0, .rsv_5=0, .NBC_ANR_Y_FLT1_IDX=0, .rsv_7=0, .NBC_ANR_Y_FLT2_IDX=2, .NBC_ANR_Y_FLT3_IDX=3, .NBC_ANR_ACT_LP_EN=0, .rsv_13=0, .NBC_ANR_TILE_EDGE=15, .NBC_ANR_LTM_LINK=1, .NBC_ANR_LTM_LUT_BYPASS=0, .rsv_22=0, .NBC_ANR_SL2_LINK=1, .rsv_25=0, .NBC_ANR_TABLE_EN=0, .NBC_ANR_TBL_PRC=0, .rsv_30=0}},
    .con2      ={.bits={.NBC_ANR_IMPL_MODE=2, .rsv_2=0, .NBC_ANR_C_SM_EDGE=1, .rsv_10=0, .NBC_ANR_FLT_C=0, .rsv_13=0, .NBC_ANR_C_SM_EDGE_TH=2, .rsv_27=0}},
    .yad1      ={.bits={.NBC_ANR_CEN_GAIN_LO_TH=0, .rsv_5=0, .NBC_ANR_CEN_GAIN_HI_TH=0, .rsv_13=0, .NBC_ANR_Y_SLOPE_V_TH=20, .NBC_ANR_Y_SLOPE_H_TH=16}},
    .yad2      ={.bits={.NBC_ANR_Y_VERT_ACT_TH=7, .rsv_5=0, .NBC_ANR_PTY_GAIN_TH=0, .rsv_13=0, .NBC_ANR_Y_VERT_SIGMA=2, .rsv_24=0}},
    .y4lut1    ={.bits={.NBC_ANR_Y_CPX1=64, .NBC_ANR_Y_CPX2=128, .NBC_ANR_Y_CPX3=192, .NBC_ANR_Y_CPX4=255}},
    .y4lut2    ={.bits={.NBC_ANR_Y_SCALE_CPY0=15, .rsv_5=0, .NBC_ANR_Y_SCALE_CPY1=16, .rsv_13=0, .NBC_ANR_Y_SCALE_CPY2=16, .rsv_21=0, .NBC_ANR_Y_SCALE_CPY3=12, .rsv_29=0}},
    .y4lut3    ={.bits={.NBC_ANR_Y_SCALE_SP0=2, .rsv_5=0, .NBC_ANR_Y_SCALE_SP1=0, .rsv_13=0, .NBC_ANR_Y_SCALE_SP2=24, .rsv_21=0, .NBC_ANR_Y_SCALE_SP3=24, .rsv_29=0}},
    .c4lut1    ={.bits={.NBC_ANR_C_CPX1=40, .NBC_ANR_C_CPX2=120, .NBC_ANR_C_CPX3=160, .rsv_24=0}},
    .c4lut2    ={.bits={.NBC_ANR_C_SCALE_CPY0=16, .rsv_5=0, .NBC_ANR_C_SCALE_CPY1=16, .rsv_13=0, .NBC_ANR_C_SCALE_CPY2=16, .rsv_21=0, .NBC_ANR_C_SCALE_CPY3=8, .rsv_29=0}},
    .c4lut3    ={.bits={.NBC_ANR_C_SCALE_SP0=0, .rsv_5=0, .NBC_ANR_C_SCALE_SP1=0, .rsv_13=0, .NBC_ANR_C_SCALE_SP2=28, .rsv_21=0, .NBC_ANR_C_SCALE_SP3=30, .rsv_29=0}},
    .a4lut2    ={.bits={.NBC_ANR_Y_ACT_CPY0=0, .NBC_ANR_Y_ACT_CPY1=0, .NBC_ANR_Y_ACT_CPY2=0, .NBC_ANR_Y_ACT_CPY3=0}},
    .a4lut3    ={.bits={.NBC_ANR_Y_ACT_SP0=0, .rsv_6=0, .NBC_ANR_Y_ACT_SP1=0, .rsv_14=0, .NBC_ANR_Y_ACT_SP2=0, .rsv_22=0, .NBC_ANR_Y_ACT_SP3=0, .rsv_30=0}},
    .l4lut1    ={.bits={.NBC_ANR_SL2_X1=64, .NBC_ANR_SL2_X2=128, .NBC_ANR_SL2_X3=192, .rsv_24=0}},
    .l4lut2    ={.bits={.NBC_ANR_SL2_GAIN0=16, .rsv_6=0, .NBC_ANR_SL2_GAIN1=20, .rsv_14=0, .NBC_ANR_SL2_GAIN2=24, .rsv_22=0, .NBC_ANR_SL2_GAIN3=28, .rsv_30=0}},
    .l4lut3    ={.bits={.NBC_ANR_SL2_SP0=8, .rsv_6=0, .NBC_ANR_SL2_SP1=8, .rsv_14=0, .NBC_ANR_SL2_SP2=8, .rsv_22=0, .NBC_ANR_SL2_SP3=8, .rsv_30=0}},
    .pty0v     ={.bits={.NBC_ANR_Y_L0_V_RNG1=2, .NBC_ANR_Y_L0_V_RNG2=4, .NBC_ANR_Y_L0_V_RNG3=6, .NBC_ANR_Y_L0_V_RNG4=9}},
    .cad       ={.bits={.rsv_0=0, .NBC_ANR_PTC_GAIN_TH=0, .rsv_13=0, .NBC_ANR_C_L_DIFF_TH=24, .rsv_24=0}},
    .pty1v     ={.bits={.NBC_ANR_Y_L1_V_RNG1=2, .NBC_ANR_Y_L1_V_RNG2=4, .NBC_ANR_Y_L1_V_RNG3=6, .NBC_ANR_Y_L1_V_RNG4=9}},
    .sl2       ={.bits={.NBC_ANR_SL2_C_GAIN=6, .NBC_ANR_SL2_SCALE_GAIN=0, .rsv_7=0}},
    .pty2v     ={.bits={.NBC_ANR_Y_L2_V_RNG1=2, .NBC_ANR_Y_L2_V_RNG2=4, .NBC_ANR_Y_L2_V_RNG3=6, .NBC_ANR_Y_L2_V_RNG4=9}},
    .pty3v     ={.bits={.NBC_ANR_Y_L3_V_RNG1=1, .NBC_ANR_Y_L3_V_RNG2=2, .NBC_ANR_Y_L3_V_RNG3=3, .NBC_ANR_Y_L3_V_RNG4=5}},
    .pty0h     ={.bits={.NBC_ANR_Y_L0_H_RNG1=2, .NBC_ANR_Y_L0_H_RNG2=4, .NBC_ANR_Y_L0_H_RNG3=6, .NBC_ANR_Y_L0_H_RNG4=8}},
    .pty1h     ={.bits={.NBC_ANR_Y_L1_H_RNG1=2, .NBC_ANR_Y_L1_H_RNG2=4, .NBC_ANR_Y_L1_H_RNG3=6, .NBC_ANR_Y_L1_H_RNG4=8}},
    .pty2h     ={.bits={.NBC_ANR_Y_L2_H_RNG1=2, .NBC_ANR_Y_L2_H_RNG2=4, .NBC_ANR_Y_L2_H_RNG3=6, .NBC_ANR_Y_L2_H_RNG4=8}},
    .t4lut1    ={.bits={.NBC_ANR_TBL_CPX1=64, .NBC_ANR_TBL_CPX2=128, .NBC_ANR_TBL_CPX3=192, .rsv_24=0}},
    .t4lut2    ={.bits={.NBC_ANR_TBL_GAIN_CPY0=1, .rsv_5=0, .NBC_ANR_TBL_GAIN_CPY1=8, .rsv_13=0, .NBC_ANR_TBL_GAIN_CPY2=16, .rsv_21=0, .NBC_ANR_TBL_GAIN_CPY3=24, .rsv_29=0}},
    .t4lut3    ={.bits={.NBC_ANR_TBL_GAIN_SP0=14, .rsv_5=0, .NBC_ANR_TBL_GAIN_SP1=15, .rsv_13=0, .NBC_ANR_TBL_GAIN_SP2=15, .rsv_21=0, .NBC_ANR_TBL_GAIN_SP3=15, .rsv_29=0}},
    .act1      ={.bits={.NBC_ANR_ACT_SL2_GAIN=8, .rsv_4=0, .NBC_ANR_ACT_DIF_HI_TH=16, .rsv_13=0, .NBC_ANR_ACT_DIF_GAIN=4, .NBC_ANR_ACT_DIF_LO_TH=16, .rsv_29=0}},
    .pty3h     ={.bits={.NBC_ANR_Y_L3_H_RNG1=1, .NBC_ANR_Y_L3_H_RNG2=2, .NBC_ANR_Y_L3_H_RNG3=3, .NBC_ANR_Y_L3_H_RNG4=4}},
    .ptcv      ={.bits={.NBC_ANR_C_V_RNG1=2, .NBC_ANR_C_V_RNG2=4, .NBC_ANR_C_V_RNG3=6, .NBC_ANR_C_V_RNG4=9}},
    .act4      ={.bits={.NBC_ANR_Y_ACT_CEN_OFT=32, .rsv_6=0, .NBC_ANR_Y_ACT_CEN_GAIN=0, .rsv_14=0, .NBC_ANR_Y_ACT_CEN_TH=32, .rsv_22=0}},
    .ptch      ={.bits={.NBC_ANR_C_H_RNG1=2, .NBC_ANR_C_H_RNG2=4, .NBC_ANR_C_H_RNG3=6, .NBC_ANR_C_H_RNG4=8}},
    .ylvl0     ={.bits={.NBC_ANR_Y_L0_RNG_RAT_TH=8, .NBC_ANR_Y_L1_RNG_RAT_TH=12, .NBC_ANR_Y_L2_RNG_RAT_TH=12, .NBC_ANR_Y_L3_RNG_RAT_TH=15, .NBC_ANR_Y_L0_RNG_RAT_SL=3, .rsv_18=0, .NBC_ANR_Y_L1_RNG_RAT_SL=3, .rsv_22=0, .NBC_ANR_Y_L2_RNG_RAT_SL=3, .rsv_26=0, .NBC_ANR_Y_L3_RNG_RAT_SL=3, .rsv_30=0}},
    .ylvl1     ={.bits={.NBC_ANR_Y_L0_HF_W=16, .rsv_5=0, .NBC_ANR_Y_L1_HF_W=8, .rsv_13=0, .NBC_ANR_Y_L2_HF_W=4, .rsv_21=0, .NBC_ANR_Y_L3_HF_W=4, .rsv_29=0}},
    .hf_cor    ={.bits={.NBC_ANR_Y_HF_CORE_TH=0, .NBC_ANR_Y_HF_CORE_SL=2, .rsv_10=0, .NBC_ANR_Y_HF_CLIP=255, .NBC_ANR_HF_BAL_MODE=1, .rsv_26=0}},
    .hf_act0   ={.bits={.NBC_ANR_Y_HF_ACT_X1=16, .NBC_ANR_Y_HF_ACT_X2=24, .NBC_ANR_Y_HF_ACT_X3=32, .NBC_ANR_Y_HF_ACT_X4=40}},
    .hf_act1   ={.bits={.NBC_ANR_Y_HF_ACT_Y0=24, .rsv_7=0, .NBC_ANR_Y_HF_ACT_Y1=24, .rsv_15=0, .NBC_ANR_Y_HF_ACT_Y2=56, .rsv_23=0, .NBC_ANR_Y_HF_ACT_Y3=56, .rsv_31=0}},
    .actc      ={.bits={.rsv_0=0, .NBC_ANR_ACT_BLD_BASE_C=48, .rsv_15=0, .NBC_ANR_C_DITH_U=8, .rsv_21=0, .NBC_ANR_C_DITH_V=8, .rsv_29=0}},
    .ylad      ={.bits={.NBC_ANR_CEN_GAIN_LO_TH_LPF=1, .rsv_5=0, .NBC_ANR_CEN_GAIN_HI_TH_LPF=6, .rsv_13=0}},
    .hf_act2   ={.bits={.NBC_ANR_Y_HF_ACT_Y4=40, .rsv_7=0, .NBC_ANR_Y_HF_ACT_SP4=0, .rsv_14=0}},
    .hf_act3   ={.bits={.NBC_ANR_Y_HF_ACT_SP0=0, .rsv_6=0, .NBC_ANR_Y_HF_ACT_SP1=31, .rsv_14=0, .NBC_ANR_Y_HF_ACT_SP2=0, .rsv_22=0, .NBC_ANR_Y_HF_ACT_SP3=48, .rsv_30=0}},
    .hf_luma0  ={.bits={.NBC_ANR_Y_HF_LUMA_X1=192, .NBC_ANR_Y_HF_LUMA_X2=224, .NBC_ANR_Y_HF_LUMA_Y0=0, .rsv_23=0, .NBC_ANR_Y_HF_LUMA_Y1=0, .rsv_31=0}},
    .hf_luma1  ={.bits={.NBC_ANR_Y_HF_LUMA_Y2=4, .rsv_7=0, .NBC_ANR_Y_HF_LUMA_SP0=0, .rsv_13=0, .NBC_ANR_Y_HF_LUMA_SP1=1, .rsv_21=0, .NBC_ANR_Y_HF_LUMA_SP2=0, .rsv_29=0}},
    .y4lut4    ={.bits={.NBC_ANR_Y_CPX5=255, .NBC_ANR_Y_CPX6=255, .NBC_ANR_Y_CPX7=255, .NBC_ANR_Y_CPX8=255}},
    .y4lut5    ={.bits={.NBC_ANR_Y_SCALE_CPY4=8, .rsv_5=0, .NBC_ANR_Y_SCALE_CPY5=8, .rsv_13=0, .NBC_ANR_Y_SCALE_CPY6=8, .rsv_21=0, .NBC_ANR_Y_SCALE_CPY7=8, .rsv_29=0}},
    .y4lut6    ={.bits={.NBC_ANR_Y_SCALE_SP4=0, .rsv_5=0, .NBC_ANR_Y_SCALE_SP5=0, .rsv_13=0, .NBC_ANR_Y_SCALE_SP6=1, .rsv_21=0, .NBC_ANR_Y_SCALE_SP7=2, .rsv_29=0}},
    .y4lut7    ={.bits={.NBC_ANR_Y_SCALE_CPY8=8, .rsv_5=0, .NBC_ANR_Y_SCALE_SP8=3, .rsv_13=0}},
    .a4lut1    ={.bits={.NBC_ANR_Y_ACT_CPX1=64, .NBC_ANR_Y_ACT_CPX2=128, .NBC_ANR_Y_ACT_CPX3=192, .rsv_24=0}}

};
const ISP_NVRAM_ANR_T gc13a0mipiraw_NBC_ANR_0187 = {
        .con1      ={.bits={.NBC_ANR_ENC=1, .NBC_ANR_ENY=1, .rsv_2=0, .NBC_ANR_Y_FLT0_IDX=0, .rsv_5=0, .NBC_ANR_Y_FLT1_IDX=0, .rsv_7=0, .NBC_ANR_Y_FLT2_IDX=2, .NBC_ANR_Y_FLT3_IDX=3, .NBC_ANR_ACT_LP_EN=0, .rsv_13=0, .NBC_ANR_TILE_EDGE=15, .NBC_ANR_LTM_LINK=1, .NBC_ANR_LTM_LUT_BYPASS=0, .rsv_22=0, .NBC_ANR_SL2_LINK=1, .rsv_25=0, .NBC_ANR_TABLE_EN=0, .NBC_ANR_TBL_PRC=0, .rsv_30=0}},
    .con2      ={.bits={.NBC_ANR_IMPL_MODE=2, .rsv_2=0, .NBC_ANR_C_SM_EDGE=1, .rsv_10=0, .NBC_ANR_FLT_C=0, .rsv_13=0, .NBC_ANR_C_SM_EDGE_TH=2, .rsv_27=0}},
    .yad1      ={.bits={.NBC_ANR_CEN_GAIN_LO_TH=0, .rsv_5=0, .NBC_ANR_CEN_GAIN_HI_TH=0, .rsv_13=0, .NBC_ANR_Y_SLOPE_V_TH=20, .NBC_ANR_Y_SLOPE_H_TH=16}},
    .yad2      ={.bits={.NBC_ANR_Y_VERT_ACT_TH=7, .rsv_5=0, .NBC_ANR_PTY_GAIN_TH=0, .rsv_13=0, .NBC_ANR_Y_VERT_SIGMA=2, .rsv_24=0}},
    .y4lut1    ={.bits={.NBC_ANR_Y_CPX1=64, .NBC_ANR_Y_CPX2=128, .NBC_ANR_Y_CPX3=192, .NBC_ANR_Y_CPX4=255}},
    .y4lut2    ={.bits={.NBC_ANR_Y_SCALE_CPY0=15, .rsv_5=0, .NBC_ANR_Y_SCALE_CPY1=16, .rsv_13=0, .NBC_ANR_Y_SCALE_CPY2=16, .rsv_21=0, .NBC_ANR_Y_SCALE_CPY3=12, .rsv_29=0}},
    .y4lut3    ={.bits={.NBC_ANR_Y_SCALE_SP0=2, .rsv_5=0, .NBC_ANR_Y_SCALE_SP1=0, .rsv_13=0, .NBC_ANR_Y_SCALE_SP2=24, .rsv_21=0, .NBC_ANR_Y_SCALE_SP3=24, .rsv_29=0}},
    .c4lut1    ={.bits={.NBC_ANR_C_CPX1=40, .NBC_ANR_C_CPX2=120, .NBC_ANR_C_CPX3=160, .rsv_24=0}},
    .c4lut2    ={.bits={.NBC_ANR_C_SCALE_CPY0=16, .rsv_5=0, .NBC_ANR_C_SCALE_CPY1=16, .rsv_13=0, .NBC_ANR_C_SCALE_CPY2=16, .rsv_21=0, .NBC_ANR_C_SCALE_CPY3=8, .rsv_29=0}},
    .c4lut3    ={.bits={.NBC_ANR_C_SCALE_SP0=0, .rsv_5=0, .NBC_ANR_C_SCALE_SP1=0, .rsv_13=0, .NBC_ANR_C_SCALE_SP2=28, .rsv_21=0, .NBC_ANR_C_SCALE_SP3=30, .rsv_29=0}},
    .a4lut2    ={.bits={.NBC_ANR_Y_ACT_CPY0=0, .NBC_ANR_Y_ACT_CPY1=0, .NBC_ANR_Y_ACT_CPY2=0, .NBC_ANR_Y_ACT_CPY3=0}},
    .a4lut3    ={.bits={.NBC_ANR_Y_ACT_SP0=0, .rsv_6=0, .NBC_ANR_Y_ACT_SP1=0, .rsv_14=0, .NBC_ANR_Y_ACT_SP2=0, .rsv_22=0, .NBC_ANR_Y_ACT_SP3=0, .rsv_30=0}},
    .l4lut1    ={.bits={.NBC_ANR_SL2_X1=64, .NBC_ANR_SL2_X2=128, .NBC_ANR_SL2_X3=192, .rsv_24=0}},
    .l4lut2    ={.bits={.NBC_ANR_SL2_GAIN0=16, .rsv_6=0, .NBC_ANR_SL2_GAIN1=20, .rsv_14=0, .NBC_ANR_SL2_GAIN2=24, .rsv_22=0, .NBC_ANR_SL2_GAIN3=28, .rsv_30=0}},
    .l4lut3    ={.bits={.NBC_ANR_SL2_SP0=8, .rsv_6=0, .NBC_ANR_SL2_SP1=8, .rsv_14=0, .NBC_ANR_SL2_SP2=8, .rsv_22=0, .NBC_ANR_SL2_SP3=8, .rsv_30=0}},
    .pty0v     ={.bits={.NBC_ANR_Y_L0_V_RNG1=2, .NBC_ANR_Y_L0_V_RNG2=4, .NBC_ANR_Y_L0_V_RNG3=6, .NBC_ANR_Y_L0_V_RNG4=9}},
    .cad       ={.bits={.rsv_0=0, .NBC_ANR_PTC_GAIN_TH=0, .rsv_13=0, .NBC_ANR_C_L_DIFF_TH=24, .rsv_24=0}},
    .pty1v     ={.bits={.NBC_ANR_Y_L1_V_RNG1=2, .NBC_ANR_Y_L1_V_RNG2=4, .NBC_ANR_Y_L1_V_RNG3=6, .NBC_ANR_Y_L1_V_RNG4=9}},
    .sl2       ={.bits={.NBC_ANR_SL2_C_GAIN=6, .NBC_ANR_SL2_SCALE_GAIN=0, .rsv_7=0}},
    .pty2v     ={.bits={.NBC_ANR_Y_L2_V_RNG1=2, .NBC_ANR_Y_L2_V_RNG2=4, .NBC_ANR_Y_L2_V_RNG3=6, .NBC_ANR_Y_L2_V_RNG4=9}},
    .pty3v     ={.bits={.NBC_ANR_Y_L3_V_RNG1=1, .NBC_ANR_Y_L3_V_RNG2=2, .NBC_ANR_Y_L3_V_RNG3=3, .NBC_ANR_Y_L3_V_RNG4=5}},
    .pty0h     ={.bits={.NBC_ANR_Y_L0_H_RNG1=2, .NBC_ANR_Y_L0_H_RNG2=4, .NBC_ANR_Y_L0_H_RNG3=6, .NBC_ANR_Y_L0_H_RNG4=8}},
    .pty1h     ={.bits={.NBC_ANR_Y_L1_H_RNG1=2, .NBC_ANR_Y_L1_H_RNG2=4, .NBC_ANR_Y_L1_H_RNG3=6, .NBC_ANR_Y_L1_H_RNG4=8}},
    .pty2h     ={.bits={.NBC_ANR_Y_L2_H_RNG1=2, .NBC_ANR_Y_L2_H_RNG2=4, .NBC_ANR_Y_L2_H_RNG3=6, .NBC_ANR_Y_L2_H_RNG4=8}},
    .t4lut1    ={.bits={.NBC_ANR_TBL_CPX1=64, .NBC_ANR_TBL_CPX2=128, .NBC_ANR_TBL_CPX3=192, .rsv_24=0}},
    .t4lut2    ={.bits={.NBC_ANR_TBL_GAIN_CPY0=1, .rsv_5=0, .NBC_ANR_TBL_GAIN_CPY1=8, .rsv_13=0, .NBC_ANR_TBL_GAIN_CPY2=16, .rsv_21=0, .NBC_ANR_TBL_GAIN_CPY3=24, .rsv_29=0}},
    .t4lut3    ={.bits={.NBC_ANR_TBL_GAIN_SP0=14, .rsv_5=0, .NBC_ANR_TBL_GAIN_SP1=15, .rsv_13=0, .NBC_ANR_TBL_GAIN_SP2=15, .rsv_21=0, .NBC_ANR_TBL_GAIN_SP3=15, .rsv_29=0}},
    .act1      ={.bits={.NBC_ANR_ACT_SL2_GAIN=8, .rsv_4=0, .NBC_ANR_ACT_DIF_HI_TH=16, .rsv_13=0, .NBC_ANR_ACT_DIF_GAIN=4, .NBC_ANR_ACT_DIF_LO_TH=16, .rsv_29=0}},
    .pty3h     ={.bits={.NBC_ANR_Y_L3_H_RNG1=1, .NBC_ANR_Y_L3_H_RNG2=2, .NBC_ANR_Y_L3_H_RNG3=3, .NBC_ANR_Y_L3_H_RNG4=4}},
    .ptcv      ={.bits={.NBC_ANR_C_V_RNG1=2, .NBC_ANR_C_V_RNG2=4, .NBC_ANR_C_V_RNG3=6, .NBC_ANR_C_V_RNG4=9}},
    .act4      ={.bits={.NBC_ANR_Y_ACT_CEN_OFT=32, .rsv_6=0, .NBC_ANR_Y_ACT_CEN_GAIN=0, .rsv_14=0, .NBC_ANR_Y_ACT_CEN_TH=32, .rsv_22=0}},
    .ptch      ={.bits={.NBC_ANR_C_H_RNG1=2, .NBC_ANR_C_H_RNG2=4, .NBC_ANR_C_H_RNG3=6, .NBC_ANR_C_H_RNG4=8}},
    .ylvl0     ={.bits={.NBC_ANR_Y_L0_RNG_RAT_TH=8, .NBC_ANR_Y_L1_RNG_RAT_TH=12, .NBC_ANR_Y_L2_RNG_RAT_TH=12, .NBC_ANR_Y_L3_RNG_RAT_TH=15, .NBC_ANR_Y_L0_RNG_RAT_SL=3, .rsv_18=0, .NBC_ANR_Y_L1_RNG_RAT_SL=3, .rsv_22=0, .NBC_ANR_Y_L2_RNG_RAT_SL=3, .rsv_26=0, .NBC_ANR_Y_L3_RNG_RAT_SL=3, .rsv_30=0}},
    .ylvl1     ={.bits={.NBC_ANR_Y_L0_HF_W=16, .rsv_5=0, .NBC_ANR_Y_L1_HF_W=8, .rsv_13=0, .NBC_ANR_Y_L2_HF_W=4, .rsv_21=0, .NBC_ANR_Y_L3_HF_W=4, .rsv_29=0}},
    .hf_cor    ={.bits={.NBC_ANR_Y_HF_CORE_TH=0, .NBC_ANR_Y_HF_CORE_SL=2, .rsv_10=0, .NBC_ANR_Y_HF_CLIP=255, .NBC_ANR_HF_BAL_MODE=1, .rsv_26=0}},
    .hf_act0   ={.bits={.NBC_ANR_Y_HF_ACT_X1=16, .NBC_ANR_Y_HF_ACT_X2=24, .NBC_ANR_Y_HF_ACT_X3=32, .NBC_ANR_Y_HF_ACT_X4=40}},
    .hf_act1   ={.bits={.NBC_ANR_Y_HF_ACT_Y0=24, .rsv_7=0, .NBC_ANR_Y_HF_ACT_Y1=24, .rsv_15=0, .NBC_ANR_Y_HF_ACT_Y2=56, .rsv_23=0, .NBC_ANR_Y_HF_ACT_Y3=56, .rsv_31=0}},
    .actc      ={.bits={.rsv_0=0, .NBC_ANR_ACT_BLD_BASE_C=48, .rsv_15=0, .NBC_ANR_C_DITH_U=8, .rsv_21=0, .NBC_ANR_C_DITH_V=8, .rsv_29=0}},
    .ylad      ={.bits={.NBC_ANR_CEN_GAIN_LO_TH_LPF=1, .rsv_5=0, .NBC_ANR_CEN_GAIN_HI_TH_LPF=6, .rsv_13=0}},
    .hf_act2   ={.bits={.NBC_ANR_Y_HF_ACT_Y4=40, .rsv_7=0, .NBC_ANR_Y_HF_ACT_SP4=0, .rsv_14=0}},
    .hf_act3   ={.bits={.NBC_ANR_Y_HF_ACT_SP0=0, .rsv_6=0, .NBC_ANR_Y_HF_ACT_SP1=31, .rsv_14=0, .NBC_ANR_Y_HF_ACT_SP2=0, .rsv_22=0, .NBC_ANR_Y_HF_ACT_SP3=48, .rsv_30=0}},
    .hf_luma0  ={.bits={.NBC_ANR_Y_HF_LUMA_X1=192, .NBC_ANR_Y_HF_LUMA_X2=224, .NBC_ANR_Y_HF_LUMA_Y0=0, .rsv_23=0, .NBC_ANR_Y_HF_LUMA_Y1=0, .rsv_31=0}},
    .hf_luma1  ={.bits={.NBC_ANR_Y_HF_LUMA_Y2=4, .rsv_7=0, .NBC_ANR_Y_HF_LUMA_SP0=0, .rsv_13=0, .NBC_ANR_Y_HF_LUMA_SP1=1, .rsv_21=0, .NBC_ANR_Y_HF_LUMA_SP2=0, .rsv_29=0}},
    .y4lut4    ={.bits={.NBC_ANR_Y_CPX5=255, .NBC_ANR_Y_CPX6=255, .NBC_ANR_Y_CPX7=255, .NBC_ANR_Y_CPX8=255}},
    .y4lut5    ={.bits={.NBC_ANR_Y_SCALE_CPY4=8, .rsv_5=0, .NBC_ANR_Y_SCALE_CPY5=8, .rsv_13=0, .NBC_ANR_Y_SCALE_CPY6=8, .rsv_21=0, .NBC_ANR_Y_SCALE_CPY7=8, .rsv_29=0}},
    .y4lut6    ={.bits={.NBC_ANR_Y_SCALE_SP4=0, .rsv_5=0, .NBC_ANR_Y_SCALE_SP5=0, .rsv_13=0, .NBC_ANR_Y_SCALE_SP6=1, .rsv_21=0, .NBC_ANR_Y_SCALE_SP7=2, .rsv_29=0}},
    .y4lut7    ={.bits={.NBC_ANR_Y_SCALE_CPY8=8, .rsv_5=0, .NBC_ANR_Y_SCALE_SP8=3, .rsv_13=0}},
    .a4lut1    ={.bits={.NBC_ANR_Y_ACT_CPX1=64, .NBC_ANR_Y_ACT_CPX2=128, .NBC_ANR_Y_ACT_CPX3=192, .rsv_24=0}}

};
const ISP_NVRAM_ANR_T gc13a0mipiraw_NBC_ANR_0188 = {
        .con1      ={.bits={.NBC_ANR_ENC=1, .NBC_ANR_ENY=1, .rsv_2=0, .NBC_ANR_Y_FLT0_IDX=0, .rsv_5=0, .NBC_ANR_Y_FLT1_IDX=0, .rsv_7=0, .NBC_ANR_Y_FLT2_IDX=2, .NBC_ANR_Y_FLT3_IDX=3, .NBC_ANR_ACT_LP_EN=0, .rsv_13=0, .NBC_ANR_TILE_EDGE=15, .NBC_ANR_LTM_LINK=1, .NBC_ANR_LTM_LUT_BYPASS=0, .rsv_22=0, .NBC_ANR_SL2_LINK=1, .rsv_25=0, .NBC_ANR_TABLE_EN=0, .NBC_ANR_TBL_PRC=0, .rsv_30=0}},
    .con2      ={.bits={.NBC_ANR_IMPL_MODE=2, .rsv_2=0, .NBC_ANR_C_SM_EDGE=1, .rsv_10=0, .NBC_ANR_FLT_C=0, .rsv_13=0, .NBC_ANR_C_SM_EDGE_TH=2, .rsv_27=0}},
    .yad1      ={.bits={.NBC_ANR_CEN_GAIN_LO_TH=0, .rsv_5=0, .NBC_ANR_CEN_GAIN_HI_TH=0, .rsv_13=0, .NBC_ANR_Y_SLOPE_V_TH=20, .NBC_ANR_Y_SLOPE_H_TH=16}},
    .yad2      ={.bits={.NBC_ANR_Y_VERT_ACT_TH=7, .rsv_5=0, .NBC_ANR_PTY_GAIN_TH=0, .rsv_13=0, .NBC_ANR_Y_VERT_SIGMA=2, .rsv_24=0}},
    .y4lut1    ={.bits={.NBC_ANR_Y_CPX1=64, .NBC_ANR_Y_CPX2=128, .NBC_ANR_Y_CPX3=192, .NBC_ANR_Y_CPX4=255}},
    .y4lut2    ={.bits={.NBC_ANR_Y_SCALE_CPY0=15, .rsv_5=0, .NBC_ANR_Y_SCALE_CPY1=16, .rsv_13=0, .NBC_ANR_Y_SCALE_CPY2=16, .rsv_21=0, .NBC_ANR_Y_SCALE_CPY3=12, .rsv_29=0}},
    .y4lut3    ={.bits={.NBC_ANR_Y_SCALE_SP0=2, .rsv_5=0, .NBC_ANR_Y_SCALE_SP1=0, .rsv_13=0, .NBC_ANR_Y_SCALE_SP2=24, .rsv_21=0, .NBC_ANR_Y_SCALE_SP3=24, .rsv_29=0}},
    .c4lut1    ={.bits={.NBC_ANR_C_CPX1=40, .NBC_ANR_C_CPX2=120, .NBC_ANR_C_CPX3=160, .rsv_24=0}},
    .c4lut2    ={.bits={.NBC_ANR_C_SCALE_CPY0=16, .rsv_5=0, .NBC_ANR_C_SCALE_CPY1=16, .rsv_13=0, .NBC_ANR_C_SCALE_CPY2=16, .rsv_21=0, .NBC_ANR_C_SCALE_CPY3=8, .rsv_29=0}},
    .c4lut3    ={.bits={.NBC_ANR_C_SCALE_SP0=0, .rsv_5=0, .NBC_ANR_C_SCALE_SP1=0, .rsv_13=0, .NBC_ANR_C_SCALE_SP2=28, .rsv_21=0, .NBC_ANR_C_SCALE_SP3=30, .rsv_29=0}},
    .a4lut2    ={.bits={.NBC_ANR_Y_ACT_CPY0=0, .NBC_ANR_Y_ACT_CPY1=0, .NBC_ANR_Y_ACT_CPY2=0, .NBC_ANR_Y_ACT_CPY3=0}},
    .a4lut3    ={.bits={.NBC_ANR_Y_ACT_SP0=0, .rsv_6=0, .NBC_ANR_Y_ACT_SP1=0, .rsv_14=0, .NBC_ANR_Y_ACT_SP2=0, .rsv_22=0, .NBC_ANR_Y_ACT_SP3=0, .rsv_30=0}},
    .l4lut1    ={.bits={.NBC_ANR_SL2_X1=64, .NBC_ANR_SL2_X2=128, .NBC_ANR_SL2_X3=192, .rsv_24=0}},
    .l4lut2    ={.bits={.NBC_ANR_SL2_GAIN0=16, .rsv_6=0, .NBC_ANR_SL2_GAIN1=20, .rsv_14=0, .NBC_ANR_SL2_GAIN2=24, .rsv_22=0, .NBC_ANR_SL2_GAIN3=28, .rsv_30=0}},
    .l4lut3    ={.bits={.NBC_ANR_SL2_SP0=8, .rsv_6=0, .NBC_ANR_SL2_SP1=8, .rsv_14=0, .NBC_ANR_SL2_SP2=8, .rsv_22=0, .NBC_ANR_SL2_SP3=8, .rsv_30=0}},
    .pty0v     ={.bits={.NBC_ANR_Y_L0_V_RNG1=2, .NBC_ANR_Y_L0_V_RNG2=4, .NBC_ANR_Y_L0_V_RNG3=6, .NBC_ANR_Y_L0_V_RNG4=9}},
    .cad       ={.bits={.rsv_0=0, .NBC_ANR_PTC_GAIN_TH=0, .rsv_13=0, .NBC_ANR_C_L_DIFF_TH=24, .rsv_24=0}},
    .pty1v     ={.bits={.NBC_ANR_Y_L1_V_RNG1=2, .NBC_ANR_Y_L1_V_RNG2=4, .NBC_ANR_Y_L1_V_RNG3=6, .NBC_ANR_Y_L1_V_RNG4=9}},
    .sl2       ={.bits={.NBC_ANR_SL2_C_GAIN=6, .NBC_ANR_SL2_SCALE_GAIN=0, .rsv_7=0}},
    .pty2v     ={.bits={.NBC_ANR_Y_L2_V_RNG1=2, .NBC_ANR_Y_L2_V_RNG2=4, .NBC_ANR_Y_L2_V_RNG3=6, .NBC_ANR_Y_L2_V_RNG4=9}},
    .pty3v     ={.bits={.NBC_ANR_Y_L3_V_RNG1=1, .NBC_ANR_Y_L3_V_RNG2=2, .NBC_ANR_Y_L3_V_RNG3=3, .NBC_ANR_Y_L3_V_RNG4=5}},
    .pty0h     ={.bits={.NBC_ANR_Y_L0_H_RNG1=2, .NBC_ANR_Y_L0_H_RNG2=4, .NBC_ANR_Y_L0_H_RNG3=6, .NBC_ANR_Y_L0_H_RNG4=8}},
    .pty1h     ={.bits={.NBC_ANR_Y_L1_H_RNG1=2, .NBC_ANR_Y_L1_H_RNG2=4, .NBC_ANR_Y_L1_H_RNG3=6, .NBC_ANR_Y_L1_H_RNG4=8}},
    .pty2h     ={.bits={.NBC_ANR_Y_L2_H_RNG1=2, .NBC_ANR_Y_L2_H_RNG2=4, .NBC_ANR_Y_L2_H_RNG3=6, .NBC_ANR_Y_L2_H_RNG4=8}},
    .t4lut1    ={.bits={.NBC_ANR_TBL_CPX1=64, .NBC_ANR_TBL_CPX2=128, .NBC_ANR_TBL_CPX3=192, .rsv_24=0}},
    .t4lut2    ={.bits={.NBC_ANR_TBL_GAIN_CPY0=1, .rsv_5=0, .NBC_ANR_TBL_GAIN_CPY1=8, .rsv_13=0, .NBC_ANR_TBL_GAIN_CPY2=16, .rsv_21=0, .NBC_ANR_TBL_GAIN_CPY3=24, .rsv_29=0}},
    .t4lut3    ={.bits={.NBC_ANR_TBL_GAIN_SP0=14, .rsv_5=0, .NBC_ANR_TBL_GAIN_SP1=15, .rsv_13=0, .NBC_ANR_TBL_GAIN_SP2=15, .rsv_21=0, .NBC_ANR_TBL_GAIN_SP3=15, .rsv_29=0}},
    .act1      ={.bits={.NBC_ANR_ACT_SL2_GAIN=8, .rsv_4=0, .NBC_ANR_ACT_DIF_HI_TH=16, .rsv_13=0, .NBC_ANR_ACT_DIF_GAIN=4, .NBC_ANR_ACT_DIF_LO_TH=16, .rsv_29=0}},
    .pty3h     ={.bits={.NBC_ANR_Y_L3_H_RNG1=1, .NBC_ANR_Y_L3_H_RNG2=2, .NBC_ANR_Y_L3_H_RNG3=3, .NBC_ANR_Y_L3_H_RNG4=4}},
    .ptcv      ={.bits={.NBC_ANR_C_V_RNG1=2, .NBC_ANR_C_V_RNG2=4, .NBC_ANR_C_V_RNG3=6, .NBC_ANR_C_V_RNG4=9}},
    .act4      ={.bits={.NBC_ANR_Y_ACT_CEN_OFT=32, .rsv_6=0, .NBC_ANR_Y_ACT_CEN_GAIN=0, .rsv_14=0, .NBC_ANR_Y_ACT_CEN_TH=32, .rsv_22=0}},
    .ptch      ={.bits={.NBC_ANR_C_H_RNG1=2, .NBC_ANR_C_H_RNG2=4, .NBC_ANR_C_H_RNG3=6, .NBC_ANR_C_H_RNG4=8}},
    .ylvl0     ={.bits={.NBC_ANR_Y_L0_RNG_RAT_TH=8, .NBC_ANR_Y_L1_RNG_RAT_TH=12, .NBC_ANR_Y_L2_RNG_RAT_TH=12, .NBC_ANR_Y_L3_RNG_RAT_TH=15, .NBC_ANR_Y_L0_RNG_RAT_SL=3, .rsv_18=0, .NBC_ANR_Y_L1_RNG_RAT_SL=3, .rsv_22=0, .NBC_ANR_Y_L2_RNG_RAT_SL=3, .rsv_26=0, .NBC_ANR_Y_L3_RNG_RAT_SL=3, .rsv_30=0}},
    .ylvl1     ={.bits={.NBC_ANR_Y_L0_HF_W=16, .rsv_5=0, .NBC_ANR_Y_L1_HF_W=8, .rsv_13=0, .NBC_ANR_Y_L2_HF_W=4, .rsv_21=0, .NBC_ANR_Y_L3_HF_W=4, .rsv_29=0}},
    .hf_cor    ={.bits={.NBC_ANR_Y_HF_CORE_TH=0, .NBC_ANR_Y_HF_CORE_SL=2, .rsv_10=0, .NBC_ANR_Y_HF_CLIP=255, .NBC_ANR_HF_BAL_MODE=1, .rsv_26=0}},
    .hf_act0   ={.bits={.NBC_ANR_Y_HF_ACT_X1=16, .NBC_ANR_Y_HF_ACT_X2=24, .NBC_ANR_Y_HF_ACT_X3=32, .NBC_ANR_Y_HF_ACT_X4=40}},
    .hf_act1   ={.bits={.NBC_ANR_Y_HF_ACT_Y0=24, .rsv_7=0, .NBC_ANR_Y_HF_ACT_Y1=24, .rsv_15=0, .NBC_ANR_Y_HF_ACT_Y2=56, .rsv_23=0, .NBC_ANR_Y_HF_ACT_Y3=56, .rsv_31=0}},
    .actc      ={.bits={.rsv_0=0, .NBC_ANR_ACT_BLD_BASE_C=48, .rsv_15=0, .NBC_ANR_C_DITH_U=8, .rsv_21=0, .NBC_ANR_C_DITH_V=8, .rsv_29=0}},
    .ylad      ={.bits={.NBC_ANR_CEN_GAIN_LO_TH_LPF=1, .rsv_5=0, .NBC_ANR_CEN_GAIN_HI_TH_LPF=6, .rsv_13=0}},
    .hf_act2   ={.bits={.NBC_ANR_Y_HF_ACT_Y4=40, .rsv_7=0, .NBC_ANR_Y_HF_ACT_SP4=0, .rsv_14=0}},
    .hf_act3   ={.bits={.NBC_ANR_Y_HF_ACT_SP0=0, .rsv_6=0, .NBC_ANR_Y_HF_ACT_SP1=31, .rsv_14=0, .NBC_ANR_Y_HF_ACT_SP2=0, .rsv_22=0, .NBC_ANR_Y_HF_ACT_SP3=48, .rsv_30=0}},
    .hf_luma0  ={.bits={.NBC_ANR_Y_HF_LUMA_X1=192, .NBC_ANR_Y_HF_LUMA_X2=224, .NBC_ANR_Y_HF_LUMA_Y0=0, .rsv_23=0, .NBC_ANR_Y_HF_LUMA_Y1=0, .rsv_31=0}},
    .hf_luma1  ={.bits={.NBC_ANR_Y_HF_LUMA_Y2=4, .rsv_7=0, .NBC_ANR_Y_HF_LUMA_SP0=0, .rsv_13=0, .NBC_ANR_Y_HF_LUMA_SP1=1, .rsv_21=0, .NBC_ANR_Y_HF_LUMA_SP2=0, .rsv_29=0}},
    .y4lut4    ={.bits={.NBC_ANR_Y_CPX5=255, .NBC_ANR_Y_CPX6=255, .NBC_ANR_Y_CPX7=255, .NBC_ANR_Y_CPX8=255}},
    .y4lut5    ={.bits={.NBC_ANR_Y_SCALE_CPY4=8, .rsv_5=0, .NBC_ANR_Y_SCALE_CPY5=8, .rsv_13=0, .NBC_ANR_Y_SCALE_CPY6=8, .rsv_21=0, .NBC_ANR_Y_SCALE_CPY7=8, .rsv_29=0}},
    .y4lut6    ={.bits={.NBC_ANR_Y_SCALE_SP4=0, .rsv_5=0, .NBC_ANR_Y_SCALE_SP5=0, .rsv_13=0, .NBC_ANR_Y_SCALE_SP6=1, .rsv_21=0, .NBC_ANR_Y_SCALE_SP7=2, .rsv_29=0}},
    .y4lut7    ={.bits={.NBC_ANR_Y_SCALE_CPY8=8, .rsv_5=0, .NBC_ANR_Y_SCALE_SP8=3, .rsv_13=0}},
    .a4lut1    ={.bits={.NBC_ANR_Y_ACT_CPX1=64, .NBC_ANR_Y_ACT_CPX2=128, .NBC_ANR_Y_ACT_CPX3=192, .rsv_24=0}}

};
const ISP_NVRAM_ANR_T gc13a0mipiraw_NBC_ANR_0189 = {
        .con1      ={.bits={.NBC_ANR_ENC=1, .NBC_ANR_ENY=1, .rsv_2=0, .NBC_ANR_Y_FLT0_IDX=0, .rsv_5=0, .NBC_ANR_Y_FLT1_IDX=0, .rsv_7=0, .NBC_ANR_Y_FLT2_IDX=2, .NBC_ANR_Y_FLT3_IDX=3, .NBC_ANR_ACT_LP_EN=0, .rsv_13=0, .NBC_ANR_TILE_EDGE=15, .NBC_ANR_LTM_LINK=1, .NBC_ANR_LTM_LUT_BYPASS=0, .rsv_22=0, .NBC_ANR_SL2_LINK=1, .rsv_25=0, .NBC_ANR_TABLE_EN=0, .NBC_ANR_TBL_PRC=0, .rsv_30=0}},
    .con2      ={.bits={.NBC_ANR_IMPL_MODE=2, .rsv_2=0, .NBC_ANR_C_SM_EDGE=1, .rsv_10=0, .NBC_ANR_FLT_C=0, .rsv_13=0, .NBC_ANR_C_SM_EDGE_TH=2, .rsv_27=0}},
    .yad1      ={.bits={.NBC_ANR_CEN_GAIN_LO_TH=0, .rsv_5=0, .NBC_ANR_CEN_GAIN_HI_TH=0, .rsv_13=0, .NBC_ANR_Y_SLOPE_V_TH=20, .NBC_ANR_Y_SLOPE_H_TH=16}},
    .yad2      ={.bits={.NBC_ANR_Y_VERT_ACT_TH=7, .rsv_5=0, .NBC_ANR_PTY_GAIN_TH=0, .rsv_13=0, .NBC_ANR_Y_VERT_SIGMA=2, .rsv_24=0}},
    .y4lut1    ={.bits={.NBC_ANR_Y_CPX1=64, .NBC_ANR_Y_CPX2=128, .NBC_ANR_Y_CPX3=192, .NBC_ANR_Y_CPX4=255}},
    .y4lut2    ={.bits={.NBC_ANR_Y_SCALE_CPY0=15, .rsv_5=0, .NBC_ANR_Y_SCALE_CPY1=16, .rsv_13=0, .NBC_ANR_Y_SCALE_CPY2=16, .rsv_21=0, .NBC_ANR_Y_SCALE_CPY3=12, .rsv_29=0}},
    .y4lut3    ={.bits={.NBC_ANR_Y_SCALE_SP0=2, .rsv_5=0, .NBC_ANR_Y_SCALE_SP1=0, .rsv_13=0, .NBC_ANR_Y_SCALE_SP2=24, .rsv_21=0, .NBC_ANR_Y_SCALE_SP3=24, .rsv_29=0}},
    .c4lut1    ={.bits={.NBC_ANR_C_CPX1=40, .NBC_ANR_C_CPX2=120, .NBC_ANR_C_CPX3=160, .rsv_24=0}},
    .c4lut2    ={.bits={.NBC_ANR_C_SCALE_CPY0=16, .rsv_5=0, .NBC_ANR_C_SCALE_CPY1=16, .rsv_13=0, .NBC_ANR_C_SCALE_CPY2=16, .rsv_21=0, .NBC_ANR_C_SCALE_CPY3=8, .rsv_29=0}},
    .c4lut3    ={.bits={.NBC_ANR_C_SCALE_SP0=0, .rsv_5=0, .NBC_ANR_C_SCALE_SP1=0, .rsv_13=0, .NBC_ANR_C_SCALE_SP2=28, .rsv_21=0, .NBC_ANR_C_SCALE_SP3=30, .rsv_29=0}},
    .a4lut2    ={.bits={.NBC_ANR_Y_ACT_CPY0=0, .NBC_ANR_Y_ACT_CPY1=0, .NBC_ANR_Y_ACT_CPY2=0, .NBC_ANR_Y_ACT_CPY3=0}},
    .a4lut3    ={.bits={.NBC_ANR_Y_ACT_SP0=0, .rsv_6=0, .NBC_ANR_Y_ACT_SP1=0, .rsv_14=0, .NBC_ANR_Y_ACT_SP2=0, .rsv_22=0, .NBC_ANR_Y_ACT_SP3=0, .rsv_30=0}},
    .l4lut1    ={.bits={.NBC_ANR_SL2_X1=64, .NBC_ANR_SL2_X2=128, .NBC_ANR_SL2_X3=192, .rsv_24=0}},
    .l4lut2    ={.bits={.NBC_ANR_SL2_GAIN0=16, .rsv_6=0, .NBC_ANR_SL2_GAIN1=20, .rsv_14=0, .NBC_ANR_SL2_GAIN2=24, .rsv_22=0, .NBC_ANR_SL2_GAIN3=28, .rsv_30=0}},
    .l4lut3    ={.bits={.NBC_ANR_SL2_SP0=8, .rsv_6=0, .NBC_ANR_SL2_SP1=8, .rsv_14=0, .NBC_ANR_SL2_SP2=8, .rsv_22=0, .NBC_ANR_SL2_SP3=8, .rsv_30=0}},
    .pty0v     ={.bits={.NBC_ANR_Y_L0_V_RNG1=2, .NBC_ANR_Y_L0_V_RNG2=4, .NBC_ANR_Y_L0_V_RNG3=6, .NBC_ANR_Y_L0_V_RNG4=9}},
    .cad       ={.bits={.rsv_0=0, .NBC_ANR_PTC_GAIN_TH=0, .rsv_13=0, .NBC_ANR_C_L_DIFF_TH=24, .rsv_24=0}},
    .pty1v     ={.bits={.NBC_ANR_Y_L1_V_RNG1=2, .NBC_ANR_Y_L1_V_RNG2=4, .NBC_ANR_Y_L1_V_RNG3=6, .NBC_ANR_Y_L1_V_RNG4=9}},
    .sl2       ={.bits={.NBC_ANR_SL2_C_GAIN=6, .NBC_ANR_SL2_SCALE_GAIN=0, .rsv_7=0}},
    .pty2v     ={.bits={.NBC_ANR_Y_L2_V_RNG1=2, .NBC_ANR_Y_L2_V_RNG2=4, .NBC_ANR_Y_L2_V_RNG3=6, .NBC_ANR_Y_L2_V_RNG4=9}},
    .pty3v     ={.bits={.NBC_ANR_Y_L3_V_RNG1=1, .NBC_ANR_Y_L3_V_RNG2=2, .NBC_ANR_Y_L3_V_RNG3=3, .NBC_ANR_Y_L3_V_RNG4=5}},
    .pty0h     ={.bits={.NBC_ANR_Y_L0_H_RNG1=2, .NBC_ANR_Y_L0_H_RNG2=4, .NBC_ANR_Y_L0_H_RNG3=6, .NBC_ANR_Y_L0_H_RNG4=8}},
    .pty1h     ={.bits={.NBC_ANR_Y_L1_H_RNG1=2, .NBC_ANR_Y_L1_H_RNG2=4, .NBC_ANR_Y_L1_H_RNG3=6, .NBC_ANR_Y_L1_H_RNG4=8}},
    .pty2h     ={.bits={.NBC_ANR_Y_L2_H_RNG1=2, .NBC_ANR_Y_L2_H_RNG2=4, .NBC_ANR_Y_L2_H_RNG3=6, .NBC_ANR_Y_L2_H_RNG4=8}},
    .t4lut1    ={.bits={.NBC_ANR_TBL_CPX1=64, .NBC_ANR_TBL_CPX2=128, .NBC_ANR_TBL_CPX3=192, .rsv_24=0}},
    .t4lut2    ={.bits={.NBC_ANR_TBL_GAIN_CPY0=1, .rsv_5=0, .NBC_ANR_TBL_GAIN_CPY1=8, .rsv_13=0, .NBC_ANR_TBL_GAIN_CPY2=16, .rsv_21=0, .NBC_ANR_TBL_GAIN_CPY3=24, .rsv_29=0}},
    .t4lut3    ={.bits={.NBC_ANR_TBL_GAIN_SP0=14, .rsv_5=0, .NBC_ANR_TBL_GAIN_SP1=15, .rsv_13=0, .NBC_ANR_TBL_GAIN_SP2=15, .rsv_21=0, .NBC_ANR_TBL_GAIN_SP3=15, .rsv_29=0}},
    .act1      ={.bits={.NBC_ANR_ACT_SL2_GAIN=8, .rsv_4=0, .NBC_ANR_ACT_DIF_HI_TH=16, .rsv_13=0, .NBC_ANR_ACT_DIF_GAIN=4, .NBC_ANR_ACT_DIF_LO_TH=16, .rsv_29=0}},
    .pty3h     ={.bits={.NBC_ANR_Y_L3_H_RNG1=1, .NBC_ANR_Y_L3_H_RNG2=2, .NBC_ANR_Y_L3_H_RNG3=3, .NBC_ANR_Y_L3_H_RNG4=4}},
    .ptcv      ={.bits={.NBC_ANR_C_V_RNG1=2, .NBC_ANR_C_V_RNG2=4, .NBC_ANR_C_V_RNG3=6, .NBC_ANR_C_V_RNG4=9}},
    .act4      ={.bits={.NBC_ANR_Y_ACT_CEN_OFT=32, .rsv_6=0, .NBC_ANR_Y_ACT_CEN_GAIN=0, .rsv_14=0, .NBC_ANR_Y_ACT_CEN_TH=32, .rsv_22=0}},
    .ptch      ={.bits={.NBC_ANR_C_H_RNG1=2, .NBC_ANR_C_H_RNG2=4, .NBC_ANR_C_H_RNG3=6, .NBC_ANR_C_H_RNG4=8}},
    .ylvl0     ={.bits={.NBC_ANR_Y_L0_RNG_RAT_TH=8, .NBC_ANR_Y_L1_RNG_RAT_TH=12, .NBC_ANR_Y_L2_RNG_RAT_TH=12, .NBC_ANR_Y_L3_RNG_RAT_TH=15, .NBC_ANR_Y_L0_RNG_RAT_SL=3, .rsv_18=0, .NBC_ANR_Y_L1_RNG_RAT_SL=3, .rsv_22=0, .NBC_ANR_Y_L2_RNG_RAT_SL=3, .rsv_26=0, .NBC_ANR_Y_L3_RNG_RAT_SL=3, .rsv_30=0}},
    .ylvl1     ={.bits={.NBC_ANR_Y_L0_HF_W=16, .rsv_5=0, .NBC_ANR_Y_L1_HF_W=8, .rsv_13=0, .NBC_ANR_Y_L2_HF_W=4, .rsv_21=0, .NBC_ANR_Y_L3_HF_W=4, .rsv_29=0}},
    .hf_cor    ={.bits={.NBC_ANR_Y_HF_CORE_TH=0, .NBC_ANR_Y_HF_CORE_SL=2, .rsv_10=0, .NBC_ANR_Y_HF_CLIP=255, .NBC_ANR_HF_BAL_MODE=1, .rsv_26=0}},
    .hf_act0   ={.bits={.NBC_ANR_Y_HF_ACT_X1=16, .NBC_ANR_Y_HF_ACT_X2=24, .NBC_ANR_Y_HF_ACT_X3=32, .NBC_ANR_Y_HF_ACT_X4=40}},
    .hf_act1   ={.bits={.NBC_ANR_Y_HF_ACT_Y0=24, .rsv_7=0, .NBC_ANR_Y_HF_ACT_Y1=24, .rsv_15=0, .NBC_ANR_Y_HF_ACT_Y2=56, .rsv_23=0, .NBC_ANR_Y_HF_ACT_Y3=56, .rsv_31=0}},
    .actc      ={.bits={.rsv_0=0, .NBC_ANR_ACT_BLD_BASE_C=48, .rsv_15=0, .NBC_ANR_C_DITH_U=8, .rsv_21=0, .NBC_ANR_C_DITH_V=8, .rsv_29=0}},
    .ylad      ={.bits={.NBC_ANR_CEN_GAIN_LO_TH_LPF=1, .rsv_5=0, .NBC_ANR_CEN_GAIN_HI_TH_LPF=6, .rsv_13=0}},
    .hf_act2   ={.bits={.NBC_ANR_Y_HF_ACT_Y4=40, .rsv_7=0, .NBC_ANR_Y_HF_ACT_SP4=0, .rsv_14=0}},
    .hf_act3   ={.bits={.NBC_ANR_Y_HF_ACT_SP0=0, .rsv_6=0, .NBC_ANR_Y_HF_ACT_SP1=31, .rsv_14=0, .NBC_ANR_Y_HF_ACT_SP2=0, .rsv_22=0, .NBC_ANR_Y_HF_ACT_SP3=48, .rsv_30=0}},
    .hf_luma0  ={.bits={.NBC_ANR_Y_HF_LUMA_X1=192, .NBC_ANR_Y_HF_LUMA_X2=224, .NBC_ANR_Y_HF_LUMA_Y0=0, .rsv_23=0, .NBC_ANR_Y_HF_LUMA_Y1=0, .rsv_31=0}},
    .hf_luma1  ={.bits={.NBC_ANR_Y_HF_LUMA_Y2=4, .rsv_7=0, .NBC_ANR_Y_HF_LUMA_SP0=0, .rsv_13=0, .NBC_ANR_Y_HF_LUMA_SP1=1, .rsv_21=0, .NBC_ANR_Y_HF_LUMA_SP2=0, .rsv_29=0}},
    .y4lut4    ={.bits={.NBC_ANR_Y_CPX5=255, .NBC_ANR_Y_CPX6=255, .NBC_ANR_Y_CPX7=255, .NBC_ANR_Y_CPX8=255}},
    .y4lut5    ={.bits={.NBC_ANR_Y_SCALE_CPY4=8, .rsv_5=0, .NBC_ANR_Y_SCALE_CPY5=8, .rsv_13=0, .NBC_ANR_Y_SCALE_CPY6=8, .rsv_21=0, .NBC_ANR_Y_SCALE_CPY7=8, .rsv_29=0}},
    .y4lut6    ={.bits={.NBC_ANR_Y_SCALE_SP4=0, .rsv_5=0, .NBC_ANR_Y_SCALE_SP5=0, .rsv_13=0, .NBC_ANR_Y_SCALE_SP6=1, .rsv_21=0, .NBC_ANR_Y_SCALE_SP7=2, .rsv_29=0}},
    .y4lut7    ={.bits={.NBC_ANR_Y_SCALE_CPY8=8, .rsv_5=0, .NBC_ANR_Y_SCALE_SP8=3, .rsv_13=0}},
    .a4lut1    ={.bits={.NBC_ANR_Y_ACT_CPX1=64, .NBC_ANR_Y_ACT_CPX2=128, .NBC_ANR_Y_ACT_CPX3=192, .rsv_24=0}}

};
const ISP_NVRAM_ANR_T gc13a0mipiraw_NBC_ANR_0190 = {
        .con1      ={.bits={.NBC_ANR_ENC=1, .NBC_ANR_ENY=1, .rsv_2=0, .NBC_ANR_Y_FLT0_IDX=0, .rsv_5=0, .NBC_ANR_Y_FLT1_IDX=0, .rsv_7=0, .NBC_ANR_Y_FLT2_IDX=2, .NBC_ANR_Y_FLT3_IDX=3, .NBC_ANR_ACT_LP_EN=0, .rsv_13=0, .NBC_ANR_TILE_EDGE=15, .NBC_ANR_LTM_LINK=1, .NBC_ANR_LTM_LUT_BYPASS=0, .rsv_22=0, .NBC_ANR_SL2_LINK=1, .rsv_25=0, .NBC_ANR_TABLE_EN=0, .NBC_ANR_TBL_PRC=0, .rsv_30=0}},
    .con2      ={.bits={.NBC_ANR_IMPL_MODE=2, .rsv_2=0, .NBC_ANR_C_SM_EDGE=1, .rsv_10=0, .NBC_ANR_FLT_C=0, .rsv_13=0, .NBC_ANR_C_SM_EDGE_TH=2, .rsv_27=0}},
    .yad1      ={.bits={.NBC_ANR_CEN_GAIN_LO_TH=0, .rsv_5=0, .NBC_ANR_CEN_GAIN_HI_TH=0, .rsv_13=0, .NBC_ANR_Y_SLOPE_V_TH=20, .NBC_ANR_Y_SLOPE_H_TH=16}},
    .yad2      ={.bits={.NBC_ANR_Y_VERT_ACT_TH=7, .rsv_5=0, .NBC_ANR_PTY_GAIN_TH=0, .rsv_13=0, .NBC_ANR_Y_VERT_SIGMA=2, .rsv_24=0}},
    .y4lut1    ={.bits={.NBC_ANR_Y_CPX1=64, .NBC_ANR_Y_CPX2=128, .NBC_ANR_Y_CPX3=192, .NBC_ANR_Y_CPX4=255}},
    .y4lut2    ={.bits={.NBC_ANR_Y_SCALE_CPY0=15, .rsv_5=0, .NBC_ANR_Y_SCALE_CPY1=16, .rsv_13=0, .NBC_ANR_Y_SCALE_CPY2=16, .rsv_21=0, .NBC_ANR_Y_SCALE_CPY3=12, .rsv_29=0}},
    .y4lut3    ={.bits={.NBC_ANR_Y_SCALE_SP0=2, .rsv_5=0, .NBC_ANR_Y_SCALE_SP1=0, .rsv_13=0, .NBC_ANR_Y_SCALE_SP2=24, .rsv_21=0, .NBC_ANR_Y_SCALE_SP3=24, .rsv_29=0}},
    .c4lut1    ={.bits={.NBC_ANR_C_CPX1=40, .NBC_ANR_C_CPX2=120, .NBC_ANR_C_CPX3=160, .rsv_24=0}},
    .c4lut2    ={.bits={.NBC_ANR_C_SCALE_CPY0=16, .rsv_5=0, .NBC_ANR_C_SCALE_CPY1=16, .rsv_13=0, .NBC_ANR_C_SCALE_CPY2=16, .rsv_21=0, .NBC_ANR_C_SCALE_CPY3=8, .rsv_29=0}},
    .c4lut3    ={.bits={.NBC_ANR_C_SCALE_SP0=0, .rsv_5=0, .NBC_ANR_C_SCALE_SP1=0, .rsv_13=0, .NBC_ANR_C_SCALE_SP2=28, .rsv_21=0, .NBC_ANR_C_SCALE_SP3=30, .rsv_29=0}},
    .a4lut2    ={.bits={.NBC_ANR_Y_ACT_CPY0=0, .NBC_ANR_Y_ACT_CPY1=0, .NBC_ANR_Y_ACT_CPY2=0, .NBC_ANR_Y_ACT_CPY3=0}},
    .a4lut3    ={.bits={.NBC_ANR_Y_ACT_SP0=0, .rsv_6=0, .NBC_ANR_Y_ACT_SP1=0, .rsv_14=0, .NBC_ANR_Y_ACT_SP2=0, .rsv_22=0, .NBC_ANR_Y_ACT_SP3=0, .rsv_30=0}},
    .l4lut1    ={.bits={.NBC_ANR_SL2_X1=64, .NBC_ANR_SL2_X2=128, .NBC_ANR_SL2_X3=192, .rsv_24=0}},
    .l4lut2    ={.bits={.NBC_ANR_SL2_GAIN0=16, .rsv_6=0, .NBC_ANR_SL2_GAIN1=20, .rsv_14=0, .NBC_ANR_SL2_GAIN2=24, .rsv_22=0, .NBC_ANR_SL2_GAIN3=28, .rsv_30=0}},
    .l4lut3    ={.bits={.NBC_ANR_SL2_SP0=8, .rsv_6=0, .NBC_ANR_SL2_SP1=8, .rsv_14=0, .NBC_ANR_SL2_SP2=8, .rsv_22=0, .NBC_ANR_SL2_SP3=8, .rsv_30=0}},
    .pty0v     ={.bits={.NBC_ANR_Y_L0_V_RNG1=2, .NBC_ANR_Y_L0_V_RNG2=4, .NBC_ANR_Y_L0_V_RNG3=6, .NBC_ANR_Y_L0_V_RNG4=9}},
    .cad       ={.bits={.rsv_0=0, .NBC_ANR_PTC_GAIN_TH=0, .rsv_13=0, .NBC_ANR_C_L_DIFF_TH=24, .rsv_24=0}},
    .pty1v     ={.bits={.NBC_ANR_Y_L1_V_RNG1=2, .NBC_ANR_Y_L1_V_RNG2=4, .NBC_ANR_Y_L1_V_RNG3=6, .NBC_ANR_Y_L1_V_RNG4=9}},
    .sl2       ={.bits={.NBC_ANR_SL2_C_GAIN=6, .NBC_ANR_SL2_SCALE_GAIN=0, .rsv_7=0}},
    .pty2v     ={.bits={.NBC_ANR_Y_L2_V_RNG1=2, .NBC_ANR_Y_L2_V_RNG2=4, .NBC_ANR_Y_L2_V_RNG3=6, .NBC_ANR_Y_L2_V_RNG4=9}},
    .pty3v     ={.bits={.NBC_ANR_Y_L3_V_RNG1=1, .NBC_ANR_Y_L3_V_RNG2=2, .NBC_ANR_Y_L3_V_RNG3=3, .NBC_ANR_Y_L3_V_RNG4=5}},
    .pty0h     ={.bits={.NBC_ANR_Y_L0_H_RNG1=2, .NBC_ANR_Y_L0_H_RNG2=4, .NBC_ANR_Y_L0_H_RNG3=6, .NBC_ANR_Y_L0_H_RNG4=8}},
    .pty1h     ={.bits={.NBC_ANR_Y_L1_H_RNG1=2, .NBC_ANR_Y_L1_H_RNG2=4, .NBC_ANR_Y_L1_H_RNG3=6, .NBC_ANR_Y_L1_H_RNG4=8}},
    .pty2h     ={.bits={.NBC_ANR_Y_L2_H_RNG1=2, .NBC_ANR_Y_L2_H_RNG2=4, .NBC_ANR_Y_L2_H_RNG3=6, .NBC_ANR_Y_L2_H_RNG4=8}},
    .t4lut1    ={.bits={.NBC_ANR_TBL_CPX1=64, .NBC_ANR_TBL_CPX2=128, .NBC_ANR_TBL_CPX3=192, .rsv_24=0}},
    .t4lut2    ={.bits={.NBC_ANR_TBL_GAIN_CPY0=1, .rsv_5=0, .NBC_ANR_TBL_GAIN_CPY1=8, .rsv_13=0, .NBC_ANR_TBL_GAIN_CPY2=16, .rsv_21=0, .NBC_ANR_TBL_GAIN_CPY3=24, .rsv_29=0}},
    .t4lut3    ={.bits={.NBC_ANR_TBL_GAIN_SP0=14, .rsv_5=0, .NBC_ANR_TBL_GAIN_SP1=15, .rsv_13=0, .NBC_ANR_TBL_GAIN_SP2=15, .rsv_21=0, .NBC_ANR_TBL_GAIN_SP3=15, .rsv_29=0}},
    .act1      ={.bits={.NBC_ANR_ACT_SL2_GAIN=8, .rsv_4=0, .NBC_ANR_ACT_DIF_HI_TH=16, .rsv_13=0, .NBC_ANR_ACT_DIF_GAIN=4, .NBC_ANR_ACT_DIF_LO_TH=16, .rsv_29=0}},
    .pty3h     ={.bits={.NBC_ANR_Y_L3_H_RNG1=1, .NBC_ANR_Y_L3_H_RNG2=2, .NBC_ANR_Y_L3_H_RNG3=3, .NBC_ANR_Y_L3_H_RNG4=4}},
    .ptcv      ={.bits={.NBC_ANR_C_V_RNG1=2, .NBC_ANR_C_V_RNG2=4, .NBC_ANR_C_V_RNG3=6, .NBC_ANR_C_V_RNG4=9}},
    .act4      ={.bits={.NBC_ANR_Y_ACT_CEN_OFT=32, .rsv_6=0, .NBC_ANR_Y_ACT_CEN_GAIN=0, .rsv_14=0, .NBC_ANR_Y_ACT_CEN_TH=32, .rsv_22=0}},
    .ptch      ={.bits={.NBC_ANR_C_H_RNG1=2, .NBC_ANR_C_H_RNG2=4, .NBC_ANR_C_H_RNG3=6, .NBC_ANR_C_H_RNG4=8}},
    .ylvl0     ={.bits={.NBC_ANR_Y_L0_RNG_RAT_TH=8, .NBC_ANR_Y_L1_RNG_RAT_TH=12, .NBC_ANR_Y_L2_RNG_RAT_TH=12, .NBC_ANR_Y_L3_RNG_RAT_TH=15, .NBC_ANR_Y_L0_RNG_RAT_SL=3, .rsv_18=0, .NBC_ANR_Y_L1_RNG_RAT_SL=3, .rsv_22=0, .NBC_ANR_Y_L2_RNG_RAT_SL=3, .rsv_26=0, .NBC_ANR_Y_L3_RNG_RAT_SL=3, .rsv_30=0}},
    .ylvl1     ={.bits={.NBC_ANR_Y_L0_HF_W=16, .rsv_5=0, .NBC_ANR_Y_L1_HF_W=8, .rsv_13=0, .NBC_ANR_Y_L2_HF_W=4, .rsv_21=0, .NBC_ANR_Y_L3_HF_W=4, .rsv_29=0}},
    .hf_cor    ={.bits={.NBC_ANR_Y_HF_CORE_TH=0, .NBC_ANR_Y_HF_CORE_SL=2, .rsv_10=0, .NBC_ANR_Y_HF_CLIP=255, .NBC_ANR_HF_BAL_MODE=1, .rsv_26=0}},
    .hf_act0   ={.bits={.NBC_ANR_Y_HF_ACT_X1=16, .NBC_ANR_Y_HF_ACT_X2=24, .NBC_ANR_Y_HF_ACT_X3=32, .NBC_ANR_Y_HF_ACT_X4=40}},
    .hf_act1   ={.bits={.NBC_ANR_Y_HF_ACT_Y0=24, .rsv_7=0, .NBC_ANR_Y_HF_ACT_Y1=24, .rsv_15=0, .NBC_ANR_Y_HF_ACT_Y2=56, .rsv_23=0, .NBC_ANR_Y_HF_ACT_Y3=56, .rsv_31=0}},
    .actc      ={.bits={.rsv_0=0, .NBC_ANR_ACT_BLD_BASE_C=48, .rsv_15=0, .NBC_ANR_C_DITH_U=8, .rsv_21=0, .NBC_ANR_C_DITH_V=8, .rsv_29=0}},
    .ylad      ={.bits={.NBC_ANR_CEN_GAIN_LO_TH_LPF=1, .rsv_5=0, .NBC_ANR_CEN_GAIN_HI_TH_LPF=6, .rsv_13=0}},
    .hf_act2   ={.bits={.NBC_ANR_Y_HF_ACT_Y4=40, .rsv_7=0, .NBC_ANR_Y_HF_ACT_SP4=0, .rsv_14=0}},
    .hf_act3   ={.bits={.NBC_ANR_Y_HF_ACT_SP0=0, .rsv_6=0, .NBC_ANR_Y_HF_ACT_SP1=31, .rsv_14=0, .NBC_ANR_Y_HF_ACT_SP2=0, .rsv_22=0, .NBC_ANR_Y_HF_ACT_SP3=48, .rsv_30=0}},
    .hf_luma0  ={.bits={.NBC_ANR_Y_HF_LUMA_X1=192, .NBC_ANR_Y_HF_LUMA_X2=224, .NBC_ANR_Y_HF_LUMA_Y0=0, .rsv_23=0, .NBC_ANR_Y_HF_LUMA_Y1=0, .rsv_31=0}},
    .hf_luma1  ={.bits={.NBC_ANR_Y_HF_LUMA_Y2=4, .rsv_7=0, .NBC_ANR_Y_HF_LUMA_SP0=0, .rsv_13=0, .NBC_ANR_Y_HF_LUMA_SP1=1, .rsv_21=0, .NBC_ANR_Y_HF_LUMA_SP2=0, .rsv_29=0}},
    .y4lut4    ={.bits={.NBC_ANR_Y_CPX5=255, .NBC_ANR_Y_CPX6=255, .NBC_ANR_Y_CPX7=255, .NBC_ANR_Y_CPX8=255}},
    .y4lut5    ={.bits={.NBC_ANR_Y_SCALE_CPY4=8, .rsv_5=0, .NBC_ANR_Y_SCALE_CPY5=8, .rsv_13=0, .NBC_ANR_Y_SCALE_CPY6=8, .rsv_21=0, .NBC_ANR_Y_SCALE_CPY7=8, .rsv_29=0}},
    .y4lut6    ={.bits={.NBC_ANR_Y_SCALE_SP4=0, .rsv_5=0, .NBC_ANR_Y_SCALE_SP5=0, .rsv_13=0, .NBC_ANR_Y_SCALE_SP6=1, .rsv_21=0, .NBC_ANR_Y_SCALE_SP7=2, .rsv_29=0}},
    .y4lut7    ={.bits={.NBC_ANR_Y_SCALE_CPY8=8, .rsv_5=0, .NBC_ANR_Y_SCALE_SP8=3, .rsv_13=0}},
    .a4lut1    ={.bits={.NBC_ANR_Y_ACT_CPX1=64, .NBC_ANR_Y_ACT_CPX2=128, .NBC_ANR_Y_ACT_CPX3=192, .rsv_24=0}}

};
const ISP_NVRAM_ANR_T gc13a0mipiraw_NBC_ANR_0191 = {
        .con1      ={.bits={.NBC_ANR_ENC=1, .NBC_ANR_ENY=1, .rsv_2=0, .NBC_ANR_Y_FLT0_IDX=0, .rsv_5=0, .NBC_ANR_Y_FLT1_IDX=0, .rsv_7=0, .NBC_ANR_Y_FLT2_IDX=2, .NBC_ANR_Y_FLT3_IDX=3, .NBC_ANR_ACT_LP_EN=0, .rsv_13=0, .NBC_ANR_TILE_EDGE=15, .NBC_ANR_LTM_LINK=1, .NBC_ANR_LTM_LUT_BYPASS=0, .rsv_22=0, .NBC_ANR_SL2_LINK=1, .rsv_25=0, .NBC_ANR_TABLE_EN=0, .NBC_ANR_TBL_PRC=0, .rsv_30=0}},
    .con2      ={.bits={.NBC_ANR_IMPL_MODE=2, .rsv_2=0, .NBC_ANR_C_SM_EDGE=1, .rsv_10=0, .NBC_ANR_FLT_C=0, .rsv_13=0, .NBC_ANR_C_SM_EDGE_TH=2, .rsv_27=0}},
    .yad1      ={.bits={.NBC_ANR_CEN_GAIN_LO_TH=0, .rsv_5=0, .NBC_ANR_CEN_GAIN_HI_TH=0, .rsv_13=0, .NBC_ANR_Y_SLOPE_V_TH=20, .NBC_ANR_Y_SLOPE_H_TH=16}},
    .yad2      ={.bits={.NBC_ANR_Y_VERT_ACT_TH=7, .rsv_5=0, .NBC_ANR_PTY_GAIN_TH=0, .rsv_13=0, .NBC_ANR_Y_VERT_SIGMA=2, .rsv_24=0}},
    .y4lut1    ={.bits={.NBC_ANR_Y_CPX1=64, .NBC_ANR_Y_CPX2=128, .NBC_ANR_Y_CPX3=192, .NBC_ANR_Y_CPX4=255}},
    .y4lut2    ={.bits={.NBC_ANR_Y_SCALE_CPY0=15, .rsv_5=0, .NBC_ANR_Y_SCALE_CPY1=16, .rsv_13=0, .NBC_ANR_Y_SCALE_CPY2=16, .rsv_21=0, .NBC_ANR_Y_SCALE_CPY3=12, .rsv_29=0}},
    .y4lut3    ={.bits={.NBC_ANR_Y_SCALE_SP0=2, .rsv_5=0, .NBC_ANR_Y_SCALE_SP1=0, .rsv_13=0, .NBC_ANR_Y_SCALE_SP2=24, .rsv_21=0, .NBC_ANR_Y_SCALE_SP3=24, .rsv_29=0}},
    .c4lut1    ={.bits={.NBC_ANR_C_CPX1=40, .NBC_ANR_C_CPX2=120, .NBC_ANR_C_CPX3=160, .rsv_24=0}},
    .c4lut2    ={.bits={.NBC_ANR_C_SCALE_CPY0=16, .rsv_5=0, .NBC_ANR_C_SCALE_CPY1=16, .rsv_13=0, .NBC_ANR_C_SCALE_CPY2=16, .rsv_21=0, .NBC_ANR_C_SCALE_CPY3=8, .rsv_29=0}},
    .c4lut3    ={.bits={.NBC_ANR_C_SCALE_SP0=0, .rsv_5=0, .NBC_ANR_C_SCALE_SP1=0, .rsv_13=0, .NBC_ANR_C_SCALE_SP2=28, .rsv_21=0, .NBC_ANR_C_SCALE_SP3=30, .rsv_29=0}},
    .a4lut2    ={.bits={.NBC_ANR_Y_ACT_CPY0=0, .NBC_ANR_Y_ACT_CPY1=0, .NBC_ANR_Y_ACT_CPY2=0, .NBC_ANR_Y_ACT_CPY3=0}},
    .a4lut3    ={.bits={.NBC_ANR_Y_ACT_SP0=0, .rsv_6=0, .NBC_ANR_Y_ACT_SP1=0, .rsv_14=0, .NBC_ANR_Y_ACT_SP2=0, .rsv_22=0, .NBC_ANR_Y_ACT_SP3=0, .rsv_30=0}},
    .l4lut1    ={.bits={.NBC_ANR_SL2_X1=64, .NBC_ANR_SL2_X2=128, .NBC_ANR_SL2_X3=192, .rsv_24=0}},
    .l4lut2    ={.bits={.NBC_ANR_SL2_GAIN0=16, .rsv_6=0, .NBC_ANR_SL2_GAIN1=20, .rsv_14=0, .NBC_ANR_SL2_GAIN2=24, .rsv_22=0, .NBC_ANR_SL2_GAIN3=28, .rsv_30=0}},
    .l4lut3    ={.bits={.NBC_ANR_SL2_SP0=8, .rsv_6=0, .NBC_ANR_SL2_SP1=8, .rsv_14=0, .NBC_ANR_SL2_SP2=8, .rsv_22=0, .NBC_ANR_SL2_SP3=8, .rsv_30=0}},
    .pty0v     ={.bits={.NBC_ANR_Y_L0_V_RNG1=2, .NBC_ANR_Y_L0_V_RNG2=4, .NBC_ANR_Y_L0_V_RNG3=6, .NBC_ANR_Y_L0_V_RNG4=9}},
    .cad       ={.bits={.rsv_0=0, .NBC_ANR_PTC_GAIN_TH=0, .rsv_13=0, .NBC_ANR_C_L_DIFF_TH=24, .rsv_24=0}},
    .pty1v     ={.bits={.NBC_ANR_Y_L1_V_RNG1=2, .NBC_ANR_Y_L1_V_RNG2=4, .NBC_ANR_Y_L1_V_RNG3=6, .NBC_ANR_Y_L1_V_RNG4=9}},
    .sl2       ={.bits={.NBC_ANR_SL2_C_GAIN=6, .NBC_ANR_SL2_SCALE_GAIN=0, .rsv_7=0}},
    .pty2v     ={.bits={.NBC_ANR_Y_L2_V_RNG1=2, .NBC_ANR_Y_L2_V_RNG2=4, .NBC_ANR_Y_L2_V_RNG3=6, .NBC_ANR_Y_L2_V_RNG4=9}},
    .pty3v     ={.bits={.NBC_ANR_Y_L3_V_RNG1=1, .NBC_ANR_Y_L3_V_RNG2=2, .NBC_ANR_Y_L3_V_RNG3=3, .NBC_ANR_Y_L3_V_RNG4=5}},
    .pty0h     ={.bits={.NBC_ANR_Y_L0_H_RNG1=2, .NBC_ANR_Y_L0_H_RNG2=4, .NBC_ANR_Y_L0_H_RNG3=6, .NBC_ANR_Y_L0_H_RNG4=8}},
    .pty1h     ={.bits={.NBC_ANR_Y_L1_H_RNG1=2, .NBC_ANR_Y_L1_H_RNG2=4, .NBC_ANR_Y_L1_H_RNG3=6, .NBC_ANR_Y_L1_H_RNG4=8}},
    .pty2h     ={.bits={.NBC_ANR_Y_L2_H_RNG1=2, .NBC_ANR_Y_L2_H_RNG2=4, .NBC_ANR_Y_L2_H_RNG3=6, .NBC_ANR_Y_L2_H_RNG4=8}},
    .t4lut1    ={.bits={.NBC_ANR_TBL_CPX1=64, .NBC_ANR_TBL_CPX2=128, .NBC_ANR_TBL_CPX3=192, .rsv_24=0}},
    .t4lut2    ={.bits={.NBC_ANR_TBL_GAIN_CPY0=1, .rsv_5=0, .NBC_ANR_TBL_GAIN_CPY1=8, .rsv_13=0, .NBC_ANR_TBL_GAIN_CPY2=16, .rsv_21=0, .NBC_ANR_TBL_GAIN_CPY3=24, .rsv_29=0}},
    .t4lut3    ={.bits={.NBC_ANR_TBL_GAIN_SP0=14, .rsv_5=0, .NBC_ANR_TBL_GAIN_SP1=15, .rsv_13=0, .NBC_ANR_TBL_GAIN_SP2=15, .rsv_21=0, .NBC_ANR_TBL_GAIN_SP3=15, .rsv_29=0}},
    .act1      ={.bits={.NBC_ANR_ACT_SL2_GAIN=8, .rsv_4=0, .NBC_ANR_ACT_DIF_HI_TH=16, .rsv_13=0, .NBC_ANR_ACT_DIF_GAIN=4, .NBC_ANR_ACT_DIF_LO_TH=16, .rsv_29=0}},
    .pty3h     ={.bits={.NBC_ANR_Y_L3_H_RNG1=1, .NBC_ANR_Y_L3_H_RNG2=2, .NBC_ANR_Y_L3_H_RNG3=3, .NBC_ANR_Y_L3_H_RNG4=4}},
    .ptcv      ={.bits={.NBC_ANR_C_V_RNG1=2, .NBC_ANR_C_V_RNG2=4, .NBC_ANR_C_V_RNG3=6, .NBC_ANR_C_V_RNG4=9}},
    .act4      ={.bits={.NBC_ANR_Y_ACT_CEN_OFT=32, .rsv_6=0, .NBC_ANR_Y_ACT_CEN_GAIN=0, .rsv_14=0, .NBC_ANR_Y_ACT_CEN_TH=32, .rsv_22=0}},
    .ptch      ={.bits={.NBC_ANR_C_H_RNG1=2, .NBC_ANR_C_H_RNG2=4, .NBC_ANR_C_H_RNG3=6, .NBC_ANR_C_H_RNG4=8}},
    .ylvl0     ={.bits={.NBC_ANR_Y_L0_RNG_RAT_TH=8, .NBC_ANR_Y_L1_RNG_RAT_TH=12, .NBC_ANR_Y_L2_RNG_RAT_TH=12, .NBC_ANR_Y_L3_RNG_RAT_TH=15, .NBC_ANR_Y_L0_RNG_RAT_SL=3, .rsv_18=0, .NBC_ANR_Y_L1_RNG_RAT_SL=3, .rsv_22=0, .NBC_ANR_Y_L2_RNG_RAT_SL=3, .rsv_26=0, .NBC_ANR_Y_L3_RNG_RAT_SL=3, .rsv_30=0}},
    .ylvl1     ={.bits={.NBC_ANR_Y_L0_HF_W=16, .rsv_5=0, .NBC_ANR_Y_L1_HF_W=8, .rsv_13=0, .NBC_ANR_Y_L2_HF_W=4, .rsv_21=0, .NBC_ANR_Y_L3_HF_W=4, .rsv_29=0}},
    .hf_cor    ={.bits={.NBC_ANR_Y_HF_CORE_TH=0, .NBC_ANR_Y_HF_CORE_SL=2, .rsv_10=0, .NBC_ANR_Y_HF_CLIP=255, .NBC_ANR_HF_BAL_MODE=1, .rsv_26=0}},
    .hf_act0   ={.bits={.NBC_ANR_Y_HF_ACT_X1=16, .NBC_ANR_Y_HF_ACT_X2=24, .NBC_ANR_Y_HF_ACT_X3=32, .NBC_ANR_Y_HF_ACT_X4=40}},
    .hf_act1   ={.bits={.NBC_ANR_Y_HF_ACT_Y0=24, .rsv_7=0, .NBC_ANR_Y_HF_ACT_Y1=24, .rsv_15=0, .NBC_ANR_Y_HF_ACT_Y2=56, .rsv_23=0, .NBC_ANR_Y_HF_ACT_Y3=56, .rsv_31=0}},
    .actc      ={.bits={.rsv_0=0, .NBC_ANR_ACT_BLD_BASE_C=48, .rsv_15=0, .NBC_ANR_C_DITH_U=8, .rsv_21=0, .NBC_ANR_C_DITH_V=8, .rsv_29=0}},
    .ylad      ={.bits={.NBC_ANR_CEN_GAIN_LO_TH_LPF=1, .rsv_5=0, .NBC_ANR_CEN_GAIN_HI_TH_LPF=6, .rsv_13=0}},
    .hf_act2   ={.bits={.NBC_ANR_Y_HF_ACT_Y4=40, .rsv_7=0, .NBC_ANR_Y_HF_ACT_SP4=0, .rsv_14=0}},
    .hf_act3   ={.bits={.NBC_ANR_Y_HF_ACT_SP0=0, .rsv_6=0, .NBC_ANR_Y_HF_ACT_SP1=31, .rsv_14=0, .NBC_ANR_Y_HF_ACT_SP2=0, .rsv_22=0, .NBC_ANR_Y_HF_ACT_SP3=48, .rsv_30=0}},
    .hf_luma0  ={.bits={.NBC_ANR_Y_HF_LUMA_X1=192, .NBC_ANR_Y_HF_LUMA_X2=224, .NBC_ANR_Y_HF_LUMA_Y0=0, .rsv_23=0, .NBC_ANR_Y_HF_LUMA_Y1=0, .rsv_31=0}},
    .hf_luma1  ={.bits={.NBC_ANR_Y_HF_LUMA_Y2=4, .rsv_7=0, .NBC_ANR_Y_HF_LUMA_SP0=0, .rsv_13=0, .NBC_ANR_Y_HF_LUMA_SP1=1, .rsv_21=0, .NBC_ANR_Y_HF_LUMA_SP2=0, .rsv_29=0}},
    .y4lut4    ={.bits={.NBC_ANR_Y_CPX5=255, .NBC_ANR_Y_CPX6=255, .NBC_ANR_Y_CPX7=255, .NBC_ANR_Y_CPX8=255}},
    .y4lut5    ={.bits={.NBC_ANR_Y_SCALE_CPY4=8, .rsv_5=0, .NBC_ANR_Y_SCALE_CPY5=8, .rsv_13=0, .NBC_ANR_Y_SCALE_CPY6=8, .rsv_21=0, .NBC_ANR_Y_SCALE_CPY7=8, .rsv_29=0}},
    .y4lut6    ={.bits={.NBC_ANR_Y_SCALE_SP4=0, .rsv_5=0, .NBC_ANR_Y_SCALE_SP5=0, .rsv_13=0, .NBC_ANR_Y_SCALE_SP6=1, .rsv_21=0, .NBC_ANR_Y_SCALE_SP7=2, .rsv_29=0}},
    .y4lut7    ={.bits={.NBC_ANR_Y_SCALE_CPY8=8, .rsv_5=0, .NBC_ANR_Y_SCALE_SP8=3, .rsv_13=0}},
    .a4lut1    ={.bits={.NBC_ANR_Y_ACT_CPX1=64, .NBC_ANR_Y_ACT_CPX2=128, .NBC_ANR_Y_ACT_CPX3=192, .rsv_24=0}}

};
const ISP_NVRAM_ANR_T gc13a0mipiraw_NBC_ANR_0192 = {
        .con1      ={.bits={.NBC_ANR_ENC=1, .NBC_ANR_ENY=1, .rsv_2=0, .NBC_ANR_Y_FLT0_IDX=0, .rsv_5=0, .NBC_ANR_Y_FLT1_IDX=0, .rsv_7=0, .NBC_ANR_Y_FLT2_IDX=2, .NBC_ANR_Y_FLT3_IDX=3, .NBC_ANR_ACT_LP_EN=0, .rsv_13=0, .NBC_ANR_TILE_EDGE=15, .NBC_ANR_LTM_LINK=1, .NBC_ANR_LTM_LUT_BYPASS=0, .rsv_22=0, .NBC_ANR_SL2_LINK=1, .rsv_25=0, .NBC_ANR_TABLE_EN=0, .NBC_ANR_TBL_PRC=0, .rsv_30=0}},
    .con2      ={.bits={.NBC_ANR_IMPL_MODE=2, .rsv_2=0, .NBC_ANR_C_SM_EDGE=1, .rsv_10=0, .NBC_ANR_FLT_C=0, .rsv_13=0, .NBC_ANR_C_SM_EDGE_TH=2, .rsv_27=0}},
    .yad1      ={.bits={.NBC_ANR_CEN_GAIN_LO_TH=0, .rsv_5=0, .NBC_ANR_CEN_GAIN_HI_TH=0, .rsv_13=0, .NBC_ANR_Y_SLOPE_V_TH=20, .NBC_ANR_Y_SLOPE_H_TH=16}},
    .yad2      ={.bits={.NBC_ANR_Y_VERT_ACT_TH=7, .rsv_5=0, .NBC_ANR_PTY_GAIN_TH=0, .rsv_13=0, .NBC_ANR_Y_VERT_SIGMA=2, .rsv_24=0}},
    .y4lut1    ={.bits={.NBC_ANR_Y_CPX1=64, .NBC_ANR_Y_CPX2=128, .NBC_ANR_Y_CPX3=192, .NBC_ANR_Y_CPX4=255}},
    .y4lut2    ={.bits={.NBC_ANR_Y_SCALE_CPY0=15, .rsv_5=0, .NBC_ANR_Y_SCALE_CPY1=16, .rsv_13=0, .NBC_ANR_Y_SCALE_CPY2=16, .rsv_21=0, .NBC_ANR_Y_SCALE_CPY3=12, .rsv_29=0}},
    .y4lut3    ={.bits={.NBC_ANR_Y_SCALE_SP0=2, .rsv_5=0, .NBC_ANR_Y_SCALE_SP1=0, .rsv_13=0, .NBC_ANR_Y_SCALE_SP2=24, .rsv_21=0, .NBC_ANR_Y_SCALE_SP3=24, .rsv_29=0}},
    .c4lut1    ={.bits={.NBC_ANR_C_CPX1=40, .NBC_ANR_C_CPX2=120, .NBC_ANR_C_CPX3=160, .rsv_24=0}},
    .c4lut2    ={.bits={.NBC_ANR_C_SCALE_CPY0=16, .rsv_5=0, .NBC_ANR_C_SCALE_CPY1=16, .rsv_13=0, .NBC_ANR_C_SCALE_CPY2=16, .rsv_21=0, .NBC_ANR_C_SCALE_CPY3=8, .rsv_29=0}},
    .c4lut3    ={.bits={.NBC_ANR_C_SCALE_SP0=0, .rsv_5=0, .NBC_ANR_C_SCALE_SP1=0, .rsv_13=0, .NBC_ANR_C_SCALE_SP2=28, .rsv_21=0, .NBC_ANR_C_SCALE_SP3=30, .rsv_29=0}},
    .a4lut2    ={.bits={.NBC_ANR_Y_ACT_CPY0=0, .NBC_ANR_Y_ACT_CPY1=0, .NBC_ANR_Y_ACT_CPY2=0, .NBC_ANR_Y_ACT_CPY3=0}},
    .a4lut3    ={.bits={.NBC_ANR_Y_ACT_SP0=0, .rsv_6=0, .NBC_ANR_Y_ACT_SP1=0, .rsv_14=0, .NBC_ANR_Y_ACT_SP2=0, .rsv_22=0, .NBC_ANR_Y_ACT_SP3=0, .rsv_30=0}},
    .l4lut1    ={.bits={.NBC_ANR_SL2_X1=64, .NBC_ANR_SL2_X2=128, .NBC_ANR_SL2_X3=192, .rsv_24=0}},
    .l4lut2    ={.bits={.NBC_ANR_SL2_GAIN0=16, .rsv_6=0, .NBC_ANR_SL2_GAIN1=20, .rsv_14=0, .NBC_ANR_SL2_GAIN2=24, .rsv_22=0, .NBC_ANR_SL2_GAIN3=28, .rsv_30=0}},
    .l4lut3    ={.bits={.NBC_ANR_SL2_SP0=8, .rsv_6=0, .NBC_ANR_SL2_SP1=8, .rsv_14=0, .NBC_ANR_SL2_SP2=8, .rsv_22=0, .NBC_ANR_SL2_SP3=8, .rsv_30=0}},
    .pty0v     ={.bits={.NBC_ANR_Y_L0_V_RNG1=2, .NBC_ANR_Y_L0_V_RNG2=4, .NBC_ANR_Y_L0_V_RNG3=6, .NBC_ANR_Y_L0_V_RNG4=9}},
    .cad       ={.bits={.rsv_0=0, .NBC_ANR_PTC_GAIN_TH=0, .rsv_13=0, .NBC_ANR_C_L_DIFF_TH=24, .rsv_24=0}},
    .pty1v     ={.bits={.NBC_ANR_Y_L1_V_RNG1=2, .NBC_ANR_Y_L1_V_RNG2=4, .NBC_ANR_Y_L1_V_RNG3=6, .NBC_ANR_Y_L1_V_RNG4=9}},
    .sl2       ={.bits={.NBC_ANR_SL2_C_GAIN=6, .NBC_ANR_SL2_SCALE_GAIN=0, .rsv_7=0}},
    .pty2v     ={.bits={.NBC_ANR_Y_L2_V_RNG1=2, .NBC_ANR_Y_L2_V_RNG2=4, .NBC_ANR_Y_L2_V_RNG3=6, .NBC_ANR_Y_L2_V_RNG4=9}},
    .pty3v     ={.bits={.NBC_ANR_Y_L3_V_RNG1=1, .NBC_ANR_Y_L3_V_RNG2=2, .NBC_ANR_Y_L3_V_RNG3=3, .NBC_ANR_Y_L3_V_RNG4=5}},
    .pty0h     ={.bits={.NBC_ANR_Y_L0_H_RNG1=2, .NBC_ANR_Y_L0_H_RNG2=4, .NBC_ANR_Y_L0_H_RNG3=6, .NBC_ANR_Y_L0_H_RNG4=8}},
    .pty1h     ={.bits={.NBC_ANR_Y_L1_H_RNG1=2, .NBC_ANR_Y_L1_H_RNG2=4, .NBC_ANR_Y_L1_H_RNG3=6, .NBC_ANR_Y_L1_H_RNG4=8}},
    .pty2h     ={.bits={.NBC_ANR_Y_L2_H_RNG1=2, .NBC_ANR_Y_L2_H_RNG2=4, .NBC_ANR_Y_L2_H_RNG3=6, .NBC_ANR_Y_L2_H_RNG4=8}},
    .t4lut1    ={.bits={.NBC_ANR_TBL_CPX1=64, .NBC_ANR_TBL_CPX2=128, .NBC_ANR_TBL_CPX3=192, .rsv_24=0}},
    .t4lut2    ={.bits={.NBC_ANR_TBL_GAIN_CPY0=1, .rsv_5=0, .NBC_ANR_TBL_GAIN_CPY1=8, .rsv_13=0, .NBC_ANR_TBL_GAIN_CPY2=16, .rsv_21=0, .NBC_ANR_TBL_GAIN_CPY3=24, .rsv_29=0}},
    .t4lut3    ={.bits={.NBC_ANR_TBL_GAIN_SP0=14, .rsv_5=0, .NBC_ANR_TBL_GAIN_SP1=15, .rsv_13=0, .NBC_ANR_TBL_GAIN_SP2=15, .rsv_21=0, .NBC_ANR_TBL_GAIN_SP3=15, .rsv_29=0}},
    .act1      ={.bits={.NBC_ANR_ACT_SL2_GAIN=8, .rsv_4=0, .NBC_ANR_ACT_DIF_HI_TH=16, .rsv_13=0, .NBC_ANR_ACT_DIF_GAIN=4, .NBC_ANR_ACT_DIF_LO_TH=16, .rsv_29=0}},
    .pty3h     ={.bits={.NBC_ANR_Y_L3_H_RNG1=1, .NBC_ANR_Y_L3_H_RNG2=2, .NBC_ANR_Y_L3_H_RNG3=3, .NBC_ANR_Y_L3_H_RNG4=4}},
    .ptcv      ={.bits={.NBC_ANR_C_V_RNG1=2, .NBC_ANR_C_V_RNG2=4, .NBC_ANR_C_V_RNG3=6, .NBC_ANR_C_V_RNG4=9}},
    .act4      ={.bits={.NBC_ANR_Y_ACT_CEN_OFT=32, .rsv_6=0, .NBC_ANR_Y_ACT_CEN_GAIN=0, .rsv_14=0, .NBC_ANR_Y_ACT_CEN_TH=32, .rsv_22=0}},
    .ptch      ={.bits={.NBC_ANR_C_H_RNG1=2, .NBC_ANR_C_H_RNG2=4, .NBC_ANR_C_H_RNG3=6, .NBC_ANR_C_H_RNG4=8}},
    .ylvl0     ={.bits={.NBC_ANR_Y_L0_RNG_RAT_TH=8, .NBC_ANR_Y_L1_RNG_RAT_TH=12, .NBC_ANR_Y_L2_RNG_RAT_TH=12, .NBC_ANR_Y_L3_RNG_RAT_TH=15, .NBC_ANR_Y_L0_RNG_RAT_SL=3, .rsv_18=0, .NBC_ANR_Y_L1_RNG_RAT_SL=3, .rsv_22=0, .NBC_ANR_Y_L2_RNG_RAT_SL=3, .rsv_26=0, .NBC_ANR_Y_L3_RNG_RAT_SL=3, .rsv_30=0}},
    .ylvl1     ={.bits={.NBC_ANR_Y_L0_HF_W=16, .rsv_5=0, .NBC_ANR_Y_L1_HF_W=8, .rsv_13=0, .NBC_ANR_Y_L2_HF_W=4, .rsv_21=0, .NBC_ANR_Y_L3_HF_W=4, .rsv_29=0}},
    .hf_cor    ={.bits={.NBC_ANR_Y_HF_CORE_TH=0, .NBC_ANR_Y_HF_CORE_SL=2, .rsv_10=0, .NBC_ANR_Y_HF_CLIP=255, .NBC_ANR_HF_BAL_MODE=1, .rsv_26=0}},
    .hf_act0   ={.bits={.NBC_ANR_Y_HF_ACT_X1=16, .NBC_ANR_Y_HF_ACT_X2=24, .NBC_ANR_Y_HF_ACT_X3=32, .NBC_ANR_Y_HF_ACT_X4=40}},
    .hf_act1   ={.bits={.NBC_ANR_Y_HF_ACT_Y0=24, .rsv_7=0, .NBC_ANR_Y_HF_ACT_Y1=24, .rsv_15=0, .NBC_ANR_Y_HF_ACT_Y2=56, .rsv_23=0, .NBC_ANR_Y_HF_ACT_Y3=56, .rsv_31=0}},
    .actc      ={.bits={.rsv_0=0, .NBC_ANR_ACT_BLD_BASE_C=48, .rsv_15=0, .NBC_ANR_C_DITH_U=8, .rsv_21=0, .NBC_ANR_C_DITH_V=8, .rsv_29=0}},
    .ylad      ={.bits={.NBC_ANR_CEN_GAIN_LO_TH_LPF=1, .rsv_5=0, .NBC_ANR_CEN_GAIN_HI_TH_LPF=6, .rsv_13=0}},
    .hf_act2   ={.bits={.NBC_ANR_Y_HF_ACT_Y4=40, .rsv_7=0, .NBC_ANR_Y_HF_ACT_SP4=0, .rsv_14=0}},
    .hf_act3   ={.bits={.NBC_ANR_Y_HF_ACT_SP0=0, .rsv_6=0, .NBC_ANR_Y_HF_ACT_SP1=31, .rsv_14=0, .NBC_ANR_Y_HF_ACT_SP2=0, .rsv_22=0, .NBC_ANR_Y_HF_ACT_SP3=48, .rsv_30=0}},
    .hf_luma0  ={.bits={.NBC_ANR_Y_HF_LUMA_X1=192, .NBC_ANR_Y_HF_LUMA_X2=224, .NBC_ANR_Y_HF_LUMA_Y0=0, .rsv_23=0, .NBC_ANR_Y_HF_LUMA_Y1=0, .rsv_31=0}},
    .hf_luma1  ={.bits={.NBC_ANR_Y_HF_LUMA_Y2=4, .rsv_7=0, .NBC_ANR_Y_HF_LUMA_SP0=0, .rsv_13=0, .NBC_ANR_Y_HF_LUMA_SP1=1, .rsv_21=0, .NBC_ANR_Y_HF_LUMA_SP2=0, .rsv_29=0}},
    .y4lut4    ={.bits={.NBC_ANR_Y_CPX5=255, .NBC_ANR_Y_CPX6=255, .NBC_ANR_Y_CPX7=255, .NBC_ANR_Y_CPX8=255}},
    .y4lut5    ={.bits={.NBC_ANR_Y_SCALE_CPY4=8, .rsv_5=0, .NBC_ANR_Y_SCALE_CPY5=8, .rsv_13=0, .NBC_ANR_Y_SCALE_CPY6=8, .rsv_21=0, .NBC_ANR_Y_SCALE_CPY7=8, .rsv_29=0}},
    .y4lut6    ={.bits={.NBC_ANR_Y_SCALE_SP4=0, .rsv_5=0, .NBC_ANR_Y_SCALE_SP5=0, .rsv_13=0, .NBC_ANR_Y_SCALE_SP6=1, .rsv_21=0, .NBC_ANR_Y_SCALE_SP7=2, .rsv_29=0}},
    .y4lut7    ={.bits={.NBC_ANR_Y_SCALE_CPY8=8, .rsv_5=0, .NBC_ANR_Y_SCALE_SP8=3, .rsv_13=0}},
    .a4lut1    ={.bits={.NBC_ANR_Y_ACT_CPX1=64, .NBC_ANR_Y_ACT_CPX2=128, .NBC_ANR_Y_ACT_CPX3=192, .rsv_24=0}}

};
const ISP_NVRAM_ANR_T gc13a0mipiraw_NBC_ANR_0193 = {
        .con1      ={.bits={.NBC_ANR_ENC=1, .NBC_ANR_ENY=1, .rsv_2=0, .NBC_ANR_Y_FLT0_IDX=0, .rsv_5=0, .NBC_ANR_Y_FLT1_IDX=0, .rsv_7=0, .NBC_ANR_Y_FLT2_IDX=2, .NBC_ANR_Y_FLT3_IDX=3, .NBC_ANR_ACT_LP_EN=0, .rsv_13=0, .NBC_ANR_TILE_EDGE=15, .NBC_ANR_LTM_LINK=1, .NBC_ANR_LTM_LUT_BYPASS=0, .rsv_22=0, .NBC_ANR_SL2_LINK=1, .rsv_25=0, .NBC_ANR_TABLE_EN=0, .NBC_ANR_TBL_PRC=0, .rsv_30=0}},
    .con2      ={.bits={.NBC_ANR_IMPL_MODE=2, .rsv_2=0, .NBC_ANR_C_SM_EDGE=1, .rsv_10=0, .NBC_ANR_FLT_C=0, .rsv_13=0, .NBC_ANR_C_SM_EDGE_TH=2, .rsv_27=0}},
    .yad1      ={.bits={.NBC_ANR_CEN_GAIN_LO_TH=0, .rsv_5=0, .NBC_ANR_CEN_GAIN_HI_TH=0, .rsv_13=0, .NBC_ANR_Y_SLOPE_V_TH=20, .NBC_ANR_Y_SLOPE_H_TH=16}},
    .yad2      ={.bits={.NBC_ANR_Y_VERT_ACT_TH=7, .rsv_5=0, .NBC_ANR_PTY_GAIN_TH=0, .rsv_13=0, .NBC_ANR_Y_VERT_SIGMA=2, .rsv_24=0}},
    .y4lut1    ={.bits={.NBC_ANR_Y_CPX1=64, .NBC_ANR_Y_CPX2=128, .NBC_ANR_Y_CPX3=192, .NBC_ANR_Y_CPX4=255}},
    .y4lut2    ={.bits={.NBC_ANR_Y_SCALE_CPY0=15, .rsv_5=0, .NBC_ANR_Y_SCALE_CPY1=16, .rsv_13=0, .NBC_ANR_Y_SCALE_CPY2=16, .rsv_21=0, .NBC_ANR_Y_SCALE_CPY3=12, .rsv_29=0}},
    .y4lut3    ={.bits={.NBC_ANR_Y_SCALE_SP0=2, .rsv_5=0, .NBC_ANR_Y_SCALE_SP1=0, .rsv_13=0, .NBC_ANR_Y_SCALE_SP2=24, .rsv_21=0, .NBC_ANR_Y_SCALE_SP3=24, .rsv_29=0}},
    .c4lut1    ={.bits={.NBC_ANR_C_CPX1=40, .NBC_ANR_C_CPX2=120, .NBC_ANR_C_CPX3=160, .rsv_24=0}},
    .c4lut2    ={.bits={.NBC_ANR_C_SCALE_CPY0=16, .rsv_5=0, .NBC_ANR_C_SCALE_CPY1=16, .rsv_13=0, .NBC_ANR_C_SCALE_CPY2=16, .rsv_21=0, .NBC_ANR_C_SCALE_CPY3=8, .rsv_29=0}},
    .c4lut3    ={.bits={.NBC_ANR_C_SCALE_SP0=0, .rsv_5=0, .NBC_ANR_C_SCALE_SP1=0, .rsv_13=0, .NBC_ANR_C_SCALE_SP2=28, .rsv_21=0, .NBC_ANR_C_SCALE_SP3=30, .rsv_29=0}},
    .a4lut2    ={.bits={.NBC_ANR_Y_ACT_CPY0=0, .NBC_ANR_Y_ACT_CPY1=0, .NBC_ANR_Y_ACT_CPY2=0, .NBC_ANR_Y_ACT_CPY3=0}},
    .a4lut3    ={.bits={.NBC_ANR_Y_ACT_SP0=0, .rsv_6=0, .NBC_ANR_Y_ACT_SP1=0, .rsv_14=0, .NBC_ANR_Y_ACT_SP2=0, .rsv_22=0, .NBC_ANR_Y_ACT_SP3=0, .rsv_30=0}},
    .l4lut1    ={.bits={.NBC_ANR_SL2_X1=64, .NBC_ANR_SL2_X2=128, .NBC_ANR_SL2_X3=192, .rsv_24=0}},
    .l4lut2    ={.bits={.NBC_ANR_SL2_GAIN0=16, .rsv_6=0, .NBC_ANR_SL2_GAIN1=20, .rsv_14=0, .NBC_ANR_SL2_GAIN2=24, .rsv_22=0, .NBC_ANR_SL2_GAIN3=28, .rsv_30=0}},
    .l4lut3    ={.bits={.NBC_ANR_SL2_SP0=8, .rsv_6=0, .NBC_ANR_SL2_SP1=8, .rsv_14=0, .NBC_ANR_SL2_SP2=8, .rsv_22=0, .NBC_ANR_SL2_SP3=8, .rsv_30=0}},
    .pty0v     ={.bits={.NBC_ANR_Y_L0_V_RNG1=2, .NBC_ANR_Y_L0_V_RNG2=4, .NBC_ANR_Y_L0_V_RNG3=6, .NBC_ANR_Y_L0_V_RNG4=9}},
    .cad       ={.bits={.rsv_0=0, .NBC_ANR_PTC_GAIN_TH=0, .rsv_13=0, .NBC_ANR_C_L_DIFF_TH=24, .rsv_24=0}},
    .pty1v     ={.bits={.NBC_ANR_Y_L1_V_RNG1=2, .NBC_ANR_Y_L1_V_RNG2=4, .NBC_ANR_Y_L1_V_RNG3=6, .NBC_ANR_Y_L1_V_RNG4=9}},
    .sl2       ={.bits={.NBC_ANR_SL2_C_GAIN=6, .NBC_ANR_SL2_SCALE_GAIN=0, .rsv_7=0}},
    .pty2v     ={.bits={.NBC_ANR_Y_L2_V_RNG1=2, .NBC_ANR_Y_L2_V_RNG2=4, .NBC_ANR_Y_L2_V_RNG3=6, .NBC_ANR_Y_L2_V_RNG4=9}},
    .pty3v     ={.bits={.NBC_ANR_Y_L3_V_RNG1=1, .NBC_ANR_Y_L3_V_RNG2=2, .NBC_ANR_Y_L3_V_RNG3=3, .NBC_ANR_Y_L3_V_RNG4=5}},
    .pty0h     ={.bits={.NBC_ANR_Y_L0_H_RNG1=2, .NBC_ANR_Y_L0_H_RNG2=4, .NBC_ANR_Y_L0_H_RNG3=6, .NBC_ANR_Y_L0_H_RNG4=8}},
    .pty1h     ={.bits={.NBC_ANR_Y_L1_H_RNG1=2, .NBC_ANR_Y_L1_H_RNG2=4, .NBC_ANR_Y_L1_H_RNG3=6, .NBC_ANR_Y_L1_H_RNG4=8}},
    .pty2h     ={.bits={.NBC_ANR_Y_L2_H_RNG1=2, .NBC_ANR_Y_L2_H_RNG2=4, .NBC_ANR_Y_L2_H_RNG3=6, .NBC_ANR_Y_L2_H_RNG4=8}},
    .t4lut1    ={.bits={.NBC_ANR_TBL_CPX1=64, .NBC_ANR_TBL_CPX2=128, .NBC_ANR_TBL_CPX3=192, .rsv_24=0}},
    .t4lut2    ={.bits={.NBC_ANR_TBL_GAIN_CPY0=1, .rsv_5=0, .NBC_ANR_TBL_GAIN_CPY1=8, .rsv_13=0, .NBC_ANR_TBL_GAIN_CPY2=16, .rsv_21=0, .NBC_ANR_TBL_GAIN_CPY3=24, .rsv_29=0}},
    .t4lut3    ={.bits={.NBC_ANR_TBL_GAIN_SP0=14, .rsv_5=0, .NBC_ANR_TBL_GAIN_SP1=15, .rsv_13=0, .NBC_ANR_TBL_GAIN_SP2=15, .rsv_21=0, .NBC_ANR_TBL_GAIN_SP3=15, .rsv_29=0}},
    .act1      ={.bits={.NBC_ANR_ACT_SL2_GAIN=8, .rsv_4=0, .NBC_ANR_ACT_DIF_HI_TH=16, .rsv_13=0, .NBC_ANR_ACT_DIF_GAIN=4, .NBC_ANR_ACT_DIF_LO_TH=16, .rsv_29=0}},
    .pty3h     ={.bits={.NBC_ANR_Y_L3_H_RNG1=1, .NBC_ANR_Y_L3_H_RNG2=2, .NBC_ANR_Y_L3_H_RNG3=3, .NBC_ANR_Y_L3_H_RNG4=4}},
    .ptcv      ={.bits={.NBC_ANR_C_V_RNG1=2, .NBC_ANR_C_V_RNG2=4, .NBC_ANR_C_V_RNG3=6, .NBC_ANR_C_V_RNG4=9}},
    .act4      ={.bits={.NBC_ANR_Y_ACT_CEN_OFT=32, .rsv_6=0, .NBC_ANR_Y_ACT_CEN_GAIN=0, .rsv_14=0, .NBC_ANR_Y_ACT_CEN_TH=32, .rsv_22=0}},
    .ptch      ={.bits={.NBC_ANR_C_H_RNG1=2, .NBC_ANR_C_H_RNG2=4, .NBC_ANR_C_H_RNG3=6, .NBC_ANR_C_H_RNG4=8}},
    .ylvl0     ={.bits={.NBC_ANR_Y_L0_RNG_RAT_TH=8, .NBC_ANR_Y_L1_RNG_RAT_TH=12, .NBC_ANR_Y_L2_RNG_RAT_TH=12, .NBC_ANR_Y_L3_RNG_RAT_TH=15, .NBC_ANR_Y_L0_RNG_RAT_SL=3, .rsv_18=0, .NBC_ANR_Y_L1_RNG_RAT_SL=3, .rsv_22=0, .NBC_ANR_Y_L2_RNG_RAT_SL=3, .rsv_26=0, .NBC_ANR_Y_L3_RNG_RAT_SL=3, .rsv_30=0}},
    .ylvl1     ={.bits={.NBC_ANR_Y_L0_HF_W=16, .rsv_5=0, .NBC_ANR_Y_L1_HF_W=8, .rsv_13=0, .NBC_ANR_Y_L2_HF_W=4, .rsv_21=0, .NBC_ANR_Y_L3_HF_W=4, .rsv_29=0}},
    .hf_cor    ={.bits={.NBC_ANR_Y_HF_CORE_TH=0, .NBC_ANR_Y_HF_CORE_SL=2, .rsv_10=0, .NBC_ANR_Y_HF_CLIP=255, .NBC_ANR_HF_BAL_MODE=1, .rsv_26=0}},
    .hf_act0   ={.bits={.NBC_ANR_Y_HF_ACT_X1=16, .NBC_ANR_Y_HF_ACT_X2=24, .NBC_ANR_Y_HF_ACT_X3=32, .NBC_ANR_Y_HF_ACT_X4=40}},
    .hf_act1   ={.bits={.NBC_ANR_Y_HF_ACT_Y0=24, .rsv_7=0, .NBC_ANR_Y_HF_ACT_Y1=24, .rsv_15=0, .NBC_ANR_Y_HF_ACT_Y2=56, .rsv_23=0, .NBC_ANR_Y_HF_ACT_Y3=56, .rsv_31=0}},
    .actc      ={.bits={.rsv_0=0, .NBC_ANR_ACT_BLD_BASE_C=48, .rsv_15=0, .NBC_ANR_C_DITH_U=8, .rsv_21=0, .NBC_ANR_C_DITH_V=8, .rsv_29=0}},
    .ylad      ={.bits={.NBC_ANR_CEN_GAIN_LO_TH_LPF=1, .rsv_5=0, .NBC_ANR_CEN_GAIN_HI_TH_LPF=6, .rsv_13=0}},
    .hf_act2   ={.bits={.NBC_ANR_Y_HF_ACT_Y4=40, .rsv_7=0, .NBC_ANR_Y_HF_ACT_SP4=0, .rsv_14=0}},
    .hf_act3   ={.bits={.NBC_ANR_Y_HF_ACT_SP0=0, .rsv_6=0, .NBC_ANR_Y_HF_ACT_SP1=31, .rsv_14=0, .NBC_ANR_Y_HF_ACT_SP2=0, .rsv_22=0, .NBC_ANR_Y_HF_ACT_SP3=48, .rsv_30=0}},
    .hf_luma0  ={.bits={.NBC_ANR_Y_HF_LUMA_X1=192, .NBC_ANR_Y_HF_LUMA_X2=224, .NBC_ANR_Y_HF_LUMA_Y0=0, .rsv_23=0, .NBC_ANR_Y_HF_LUMA_Y1=0, .rsv_31=0}},
    .hf_luma1  ={.bits={.NBC_ANR_Y_HF_LUMA_Y2=4, .rsv_7=0, .NBC_ANR_Y_HF_LUMA_SP0=0, .rsv_13=0, .NBC_ANR_Y_HF_LUMA_SP1=1, .rsv_21=0, .NBC_ANR_Y_HF_LUMA_SP2=0, .rsv_29=0}},
    .y4lut4    ={.bits={.NBC_ANR_Y_CPX5=255, .NBC_ANR_Y_CPX6=255, .NBC_ANR_Y_CPX7=255, .NBC_ANR_Y_CPX8=255}},
    .y4lut5    ={.bits={.NBC_ANR_Y_SCALE_CPY4=8, .rsv_5=0, .NBC_ANR_Y_SCALE_CPY5=8, .rsv_13=0, .NBC_ANR_Y_SCALE_CPY6=8, .rsv_21=0, .NBC_ANR_Y_SCALE_CPY7=8, .rsv_29=0}},
    .y4lut6    ={.bits={.NBC_ANR_Y_SCALE_SP4=0, .rsv_5=0, .NBC_ANR_Y_SCALE_SP5=0, .rsv_13=0, .NBC_ANR_Y_SCALE_SP6=1, .rsv_21=0, .NBC_ANR_Y_SCALE_SP7=2, .rsv_29=0}},
    .y4lut7    ={.bits={.NBC_ANR_Y_SCALE_CPY8=8, .rsv_5=0, .NBC_ANR_Y_SCALE_SP8=3, .rsv_13=0}},
    .a4lut1    ={.bits={.NBC_ANR_Y_ACT_CPX1=64, .NBC_ANR_Y_ACT_CPX2=128, .NBC_ANR_Y_ACT_CPX3=192, .rsv_24=0}}

};
const ISP_NVRAM_ANR_T gc13a0mipiraw_NBC_ANR_0194 = {
        .con1      ={.bits={.NBC_ANR_ENC=1, .NBC_ANR_ENY=1, .rsv_2=0, .NBC_ANR_Y_FLT0_IDX=0, .rsv_5=0, .NBC_ANR_Y_FLT1_IDX=0, .rsv_7=0, .NBC_ANR_Y_FLT2_IDX=2, .NBC_ANR_Y_FLT3_IDX=3, .NBC_ANR_ACT_LP_EN=0, .rsv_13=0, .NBC_ANR_TILE_EDGE=15, .NBC_ANR_LTM_LINK=1, .NBC_ANR_LTM_LUT_BYPASS=0, .rsv_22=0, .NBC_ANR_SL2_LINK=1, .rsv_25=0, .NBC_ANR_TABLE_EN=0, .NBC_ANR_TBL_PRC=0, .rsv_30=0}},
    .con2      ={.bits={.NBC_ANR_IMPL_MODE=2, .rsv_2=0, .NBC_ANR_C_SM_EDGE=1, .rsv_10=0, .NBC_ANR_FLT_C=0, .rsv_13=0, .NBC_ANR_C_SM_EDGE_TH=2, .rsv_27=0}},
    .yad1      ={.bits={.NBC_ANR_CEN_GAIN_LO_TH=0, .rsv_5=0, .NBC_ANR_CEN_GAIN_HI_TH=0, .rsv_13=0, .NBC_ANR_Y_SLOPE_V_TH=20, .NBC_ANR_Y_SLOPE_H_TH=16}},
    .yad2      ={.bits={.NBC_ANR_Y_VERT_ACT_TH=7, .rsv_5=0, .NBC_ANR_PTY_GAIN_TH=0, .rsv_13=0, .NBC_ANR_Y_VERT_SIGMA=2, .rsv_24=0}},
    .y4lut1    ={.bits={.NBC_ANR_Y_CPX1=64, .NBC_ANR_Y_CPX2=128, .NBC_ANR_Y_CPX3=192, .NBC_ANR_Y_CPX4=255}},
    .y4lut2    ={.bits={.NBC_ANR_Y_SCALE_CPY0=15, .rsv_5=0, .NBC_ANR_Y_SCALE_CPY1=16, .rsv_13=0, .NBC_ANR_Y_SCALE_CPY2=16, .rsv_21=0, .NBC_ANR_Y_SCALE_CPY3=12, .rsv_29=0}},
    .y4lut3    ={.bits={.NBC_ANR_Y_SCALE_SP0=2, .rsv_5=0, .NBC_ANR_Y_SCALE_SP1=0, .rsv_13=0, .NBC_ANR_Y_SCALE_SP2=24, .rsv_21=0, .NBC_ANR_Y_SCALE_SP3=24, .rsv_29=0}},
    .c4lut1    ={.bits={.NBC_ANR_C_CPX1=40, .NBC_ANR_C_CPX2=120, .NBC_ANR_C_CPX3=160, .rsv_24=0}},
    .c4lut2    ={.bits={.NBC_ANR_C_SCALE_CPY0=16, .rsv_5=0, .NBC_ANR_C_SCALE_CPY1=16, .rsv_13=0, .NBC_ANR_C_SCALE_CPY2=16, .rsv_21=0, .NBC_ANR_C_SCALE_CPY3=8, .rsv_29=0}},
    .c4lut3    ={.bits={.NBC_ANR_C_SCALE_SP0=0, .rsv_5=0, .NBC_ANR_C_SCALE_SP1=0, .rsv_13=0, .NBC_ANR_C_SCALE_SP2=28, .rsv_21=0, .NBC_ANR_C_SCALE_SP3=30, .rsv_29=0}},
    .a4lut2    ={.bits={.NBC_ANR_Y_ACT_CPY0=0, .NBC_ANR_Y_ACT_CPY1=0, .NBC_ANR_Y_ACT_CPY2=0, .NBC_ANR_Y_ACT_CPY3=0}},
    .a4lut3    ={.bits={.NBC_ANR_Y_ACT_SP0=0, .rsv_6=0, .NBC_ANR_Y_ACT_SP1=0, .rsv_14=0, .NBC_ANR_Y_ACT_SP2=0, .rsv_22=0, .NBC_ANR_Y_ACT_SP3=0, .rsv_30=0}},
    .l4lut1    ={.bits={.NBC_ANR_SL2_X1=64, .NBC_ANR_SL2_X2=128, .NBC_ANR_SL2_X3=192, .rsv_24=0}},
    .l4lut2    ={.bits={.NBC_ANR_SL2_GAIN0=16, .rsv_6=0, .NBC_ANR_SL2_GAIN1=20, .rsv_14=0, .NBC_ANR_SL2_GAIN2=24, .rsv_22=0, .NBC_ANR_SL2_GAIN3=28, .rsv_30=0}},
    .l4lut3    ={.bits={.NBC_ANR_SL2_SP0=8, .rsv_6=0, .NBC_ANR_SL2_SP1=8, .rsv_14=0, .NBC_ANR_SL2_SP2=8, .rsv_22=0, .NBC_ANR_SL2_SP3=8, .rsv_30=0}},
    .pty0v     ={.bits={.NBC_ANR_Y_L0_V_RNG1=2, .NBC_ANR_Y_L0_V_RNG2=4, .NBC_ANR_Y_L0_V_RNG3=6, .NBC_ANR_Y_L0_V_RNG4=9}},
    .cad       ={.bits={.rsv_0=0, .NBC_ANR_PTC_GAIN_TH=0, .rsv_13=0, .NBC_ANR_C_L_DIFF_TH=24, .rsv_24=0}},
    .pty1v     ={.bits={.NBC_ANR_Y_L1_V_RNG1=2, .NBC_ANR_Y_L1_V_RNG2=4, .NBC_ANR_Y_L1_V_RNG3=6, .NBC_ANR_Y_L1_V_RNG4=9}},
    .sl2       ={.bits={.NBC_ANR_SL2_C_GAIN=6, .NBC_ANR_SL2_SCALE_GAIN=0, .rsv_7=0}},
    .pty2v     ={.bits={.NBC_ANR_Y_L2_V_RNG1=2, .NBC_ANR_Y_L2_V_RNG2=4, .NBC_ANR_Y_L2_V_RNG3=6, .NBC_ANR_Y_L2_V_RNG4=9}},
    .pty3v     ={.bits={.NBC_ANR_Y_L3_V_RNG1=1, .NBC_ANR_Y_L3_V_RNG2=2, .NBC_ANR_Y_L3_V_RNG3=3, .NBC_ANR_Y_L3_V_RNG4=5}},
    .pty0h     ={.bits={.NBC_ANR_Y_L0_H_RNG1=2, .NBC_ANR_Y_L0_H_RNG2=4, .NBC_ANR_Y_L0_H_RNG3=6, .NBC_ANR_Y_L0_H_RNG4=8}},
    .pty1h     ={.bits={.NBC_ANR_Y_L1_H_RNG1=2, .NBC_ANR_Y_L1_H_RNG2=4, .NBC_ANR_Y_L1_H_RNG3=6, .NBC_ANR_Y_L1_H_RNG4=8}},
    .pty2h     ={.bits={.NBC_ANR_Y_L2_H_RNG1=2, .NBC_ANR_Y_L2_H_RNG2=4, .NBC_ANR_Y_L2_H_RNG3=6, .NBC_ANR_Y_L2_H_RNG4=8}},
    .t4lut1    ={.bits={.NBC_ANR_TBL_CPX1=64, .NBC_ANR_TBL_CPX2=128, .NBC_ANR_TBL_CPX3=192, .rsv_24=0}},
    .t4lut2    ={.bits={.NBC_ANR_TBL_GAIN_CPY0=1, .rsv_5=0, .NBC_ANR_TBL_GAIN_CPY1=8, .rsv_13=0, .NBC_ANR_TBL_GAIN_CPY2=16, .rsv_21=0, .NBC_ANR_TBL_GAIN_CPY3=24, .rsv_29=0}},
    .t4lut3    ={.bits={.NBC_ANR_TBL_GAIN_SP0=14, .rsv_5=0, .NBC_ANR_TBL_GAIN_SP1=15, .rsv_13=0, .NBC_ANR_TBL_GAIN_SP2=15, .rsv_21=0, .NBC_ANR_TBL_GAIN_SP3=15, .rsv_29=0}},
    .act1      ={.bits={.NBC_ANR_ACT_SL2_GAIN=8, .rsv_4=0, .NBC_ANR_ACT_DIF_HI_TH=16, .rsv_13=0, .NBC_ANR_ACT_DIF_GAIN=4, .NBC_ANR_ACT_DIF_LO_TH=16, .rsv_29=0}},
    .pty3h     ={.bits={.NBC_ANR_Y_L3_H_RNG1=1, .NBC_ANR_Y_L3_H_RNG2=2, .NBC_ANR_Y_L3_H_RNG3=3, .NBC_ANR_Y_L3_H_RNG4=4}},
    .ptcv      ={.bits={.NBC_ANR_C_V_RNG1=2, .NBC_ANR_C_V_RNG2=4, .NBC_ANR_C_V_RNG3=6, .NBC_ANR_C_V_RNG4=9}},
    .act4      ={.bits={.NBC_ANR_Y_ACT_CEN_OFT=32, .rsv_6=0, .NBC_ANR_Y_ACT_CEN_GAIN=0, .rsv_14=0, .NBC_ANR_Y_ACT_CEN_TH=32, .rsv_22=0}},
    .ptch      ={.bits={.NBC_ANR_C_H_RNG1=2, .NBC_ANR_C_H_RNG2=4, .NBC_ANR_C_H_RNG3=6, .NBC_ANR_C_H_RNG4=8}},
    .ylvl0     ={.bits={.NBC_ANR_Y_L0_RNG_RAT_TH=8, .NBC_ANR_Y_L1_RNG_RAT_TH=12, .NBC_ANR_Y_L2_RNG_RAT_TH=12, .NBC_ANR_Y_L3_RNG_RAT_TH=15, .NBC_ANR_Y_L0_RNG_RAT_SL=3, .rsv_18=0, .NBC_ANR_Y_L1_RNG_RAT_SL=3, .rsv_22=0, .NBC_ANR_Y_L2_RNG_RAT_SL=3, .rsv_26=0, .NBC_ANR_Y_L3_RNG_RAT_SL=3, .rsv_30=0}},
    .ylvl1     ={.bits={.NBC_ANR_Y_L0_HF_W=16, .rsv_5=0, .NBC_ANR_Y_L1_HF_W=8, .rsv_13=0, .NBC_ANR_Y_L2_HF_W=4, .rsv_21=0, .NBC_ANR_Y_L3_HF_W=4, .rsv_29=0}},
    .hf_cor    ={.bits={.NBC_ANR_Y_HF_CORE_TH=0, .NBC_ANR_Y_HF_CORE_SL=2, .rsv_10=0, .NBC_ANR_Y_HF_CLIP=255, .NBC_ANR_HF_BAL_MODE=1, .rsv_26=0}},
    .hf_act0   ={.bits={.NBC_ANR_Y_HF_ACT_X1=16, .NBC_ANR_Y_HF_ACT_X2=24, .NBC_ANR_Y_HF_ACT_X3=32, .NBC_ANR_Y_HF_ACT_X4=40}},
    .hf_act1   ={.bits={.NBC_ANR_Y_HF_ACT_Y0=24, .rsv_7=0, .NBC_ANR_Y_HF_ACT_Y1=24, .rsv_15=0, .NBC_ANR_Y_HF_ACT_Y2=56, .rsv_23=0, .NBC_ANR_Y_HF_ACT_Y3=56, .rsv_31=0}},
    .actc      ={.bits={.rsv_0=0, .NBC_ANR_ACT_BLD_BASE_C=48, .rsv_15=0, .NBC_ANR_C_DITH_U=8, .rsv_21=0, .NBC_ANR_C_DITH_V=8, .rsv_29=0}},
    .ylad      ={.bits={.NBC_ANR_CEN_GAIN_LO_TH_LPF=1, .rsv_5=0, .NBC_ANR_CEN_GAIN_HI_TH_LPF=6, .rsv_13=0}},
    .hf_act2   ={.bits={.NBC_ANR_Y_HF_ACT_Y4=40, .rsv_7=0, .NBC_ANR_Y_HF_ACT_SP4=0, .rsv_14=0}},
    .hf_act3   ={.bits={.NBC_ANR_Y_HF_ACT_SP0=0, .rsv_6=0, .NBC_ANR_Y_HF_ACT_SP1=31, .rsv_14=0, .NBC_ANR_Y_HF_ACT_SP2=0, .rsv_22=0, .NBC_ANR_Y_HF_ACT_SP3=48, .rsv_30=0}},
    .hf_luma0  ={.bits={.NBC_ANR_Y_HF_LUMA_X1=192, .NBC_ANR_Y_HF_LUMA_X2=224, .NBC_ANR_Y_HF_LUMA_Y0=0, .rsv_23=0, .NBC_ANR_Y_HF_LUMA_Y1=0, .rsv_31=0}},
    .hf_luma1  ={.bits={.NBC_ANR_Y_HF_LUMA_Y2=4, .rsv_7=0, .NBC_ANR_Y_HF_LUMA_SP0=0, .rsv_13=0, .NBC_ANR_Y_HF_LUMA_SP1=1, .rsv_21=0, .NBC_ANR_Y_HF_LUMA_SP2=0, .rsv_29=0}},
    .y4lut4    ={.bits={.NBC_ANR_Y_CPX5=255, .NBC_ANR_Y_CPX6=255, .NBC_ANR_Y_CPX7=255, .NBC_ANR_Y_CPX8=255}},
    .y4lut5    ={.bits={.NBC_ANR_Y_SCALE_CPY4=8, .rsv_5=0, .NBC_ANR_Y_SCALE_CPY5=8, .rsv_13=0, .NBC_ANR_Y_SCALE_CPY6=8, .rsv_21=0, .NBC_ANR_Y_SCALE_CPY7=8, .rsv_29=0}},
    .y4lut6    ={.bits={.NBC_ANR_Y_SCALE_SP4=0, .rsv_5=0, .NBC_ANR_Y_SCALE_SP5=0, .rsv_13=0, .NBC_ANR_Y_SCALE_SP6=1, .rsv_21=0, .NBC_ANR_Y_SCALE_SP7=2, .rsv_29=0}},
    .y4lut7    ={.bits={.NBC_ANR_Y_SCALE_CPY8=8, .rsv_5=0, .NBC_ANR_Y_SCALE_SP8=3, .rsv_13=0}},
    .a4lut1    ={.bits={.NBC_ANR_Y_ACT_CPX1=64, .NBC_ANR_Y_ACT_CPX2=128, .NBC_ANR_Y_ACT_CPX3=192, .rsv_24=0}}

};
const ISP_NVRAM_ANR_T gc13a0mipiraw_NBC_ANR_0195 = {
        .con1      ={.bits={.NBC_ANR_ENC=1, .NBC_ANR_ENY=1, .rsv_2=0, .NBC_ANR_Y_FLT0_IDX=0, .rsv_5=0, .NBC_ANR_Y_FLT1_IDX=0, .rsv_7=0, .NBC_ANR_Y_FLT2_IDX=2, .NBC_ANR_Y_FLT3_IDX=3, .NBC_ANR_ACT_LP_EN=0, .rsv_13=0, .NBC_ANR_TILE_EDGE=15, .NBC_ANR_LTM_LINK=1, .NBC_ANR_LTM_LUT_BYPASS=0, .rsv_22=0, .NBC_ANR_SL2_LINK=1, .rsv_25=0, .NBC_ANR_TABLE_EN=0, .NBC_ANR_TBL_PRC=0, .rsv_30=0}},
    .con2      ={.bits={.NBC_ANR_IMPL_MODE=2, .rsv_2=0, .NBC_ANR_C_SM_EDGE=1, .rsv_10=0, .NBC_ANR_FLT_C=0, .rsv_13=0, .NBC_ANR_C_SM_EDGE_TH=2, .rsv_27=0}},
    .yad1      ={.bits={.NBC_ANR_CEN_GAIN_LO_TH=0, .rsv_5=0, .NBC_ANR_CEN_GAIN_HI_TH=0, .rsv_13=0, .NBC_ANR_Y_SLOPE_V_TH=20, .NBC_ANR_Y_SLOPE_H_TH=16}},
    .yad2      ={.bits={.NBC_ANR_Y_VERT_ACT_TH=7, .rsv_5=0, .NBC_ANR_PTY_GAIN_TH=0, .rsv_13=0, .NBC_ANR_Y_VERT_SIGMA=2, .rsv_24=0}},
    .y4lut1    ={.bits={.NBC_ANR_Y_CPX1=64, .NBC_ANR_Y_CPX2=128, .NBC_ANR_Y_CPX3=192, .NBC_ANR_Y_CPX4=255}},
    .y4lut2    ={.bits={.NBC_ANR_Y_SCALE_CPY0=15, .rsv_5=0, .NBC_ANR_Y_SCALE_CPY1=16, .rsv_13=0, .NBC_ANR_Y_SCALE_CPY2=16, .rsv_21=0, .NBC_ANR_Y_SCALE_CPY3=12, .rsv_29=0}},
    .y4lut3    ={.bits={.NBC_ANR_Y_SCALE_SP0=2, .rsv_5=0, .NBC_ANR_Y_SCALE_SP1=0, .rsv_13=0, .NBC_ANR_Y_SCALE_SP2=24, .rsv_21=0, .NBC_ANR_Y_SCALE_SP3=24, .rsv_29=0}},
    .c4lut1    ={.bits={.NBC_ANR_C_CPX1=40, .NBC_ANR_C_CPX2=120, .NBC_ANR_C_CPX3=160, .rsv_24=0}},
    .c4lut2    ={.bits={.NBC_ANR_C_SCALE_CPY0=16, .rsv_5=0, .NBC_ANR_C_SCALE_CPY1=16, .rsv_13=0, .NBC_ANR_C_SCALE_CPY2=16, .rsv_21=0, .NBC_ANR_C_SCALE_CPY3=8, .rsv_29=0}},
    .c4lut3    ={.bits={.NBC_ANR_C_SCALE_SP0=0, .rsv_5=0, .NBC_ANR_C_SCALE_SP1=0, .rsv_13=0, .NBC_ANR_C_SCALE_SP2=28, .rsv_21=0, .NBC_ANR_C_SCALE_SP3=30, .rsv_29=0}},
    .a4lut2    ={.bits={.NBC_ANR_Y_ACT_CPY0=0, .NBC_ANR_Y_ACT_CPY1=0, .NBC_ANR_Y_ACT_CPY2=0, .NBC_ANR_Y_ACT_CPY3=0}},
    .a4lut3    ={.bits={.NBC_ANR_Y_ACT_SP0=0, .rsv_6=0, .NBC_ANR_Y_ACT_SP1=0, .rsv_14=0, .NBC_ANR_Y_ACT_SP2=0, .rsv_22=0, .NBC_ANR_Y_ACT_SP3=0, .rsv_30=0}},
    .l4lut1    ={.bits={.NBC_ANR_SL2_X1=64, .NBC_ANR_SL2_X2=128, .NBC_ANR_SL2_X3=192, .rsv_24=0}},
    .l4lut2    ={.bits={.NBC_ANR_SL2_GAIN0=16, .rsv_6=0, .NBC_ANR_SL2_GAIN1=20, .rsv_14=0, .NBC_ANR_SL2_GAIN2=24, .rsv_22=0, .NBC_ANR_SL2_GAIN3=28, .rsv_30=0}},
    .l4lut3    ={.bits={.NBC_ANR_SL2_SP0=8, .rsv_6=0, .NBC_ANR_SL2_SP1=8, .rsv_14=0, .NBC_ANR_SL2_SP2=8, .rsv_22=0, .NBC_ANR_SL2_SP3=8, .rsv_30=0}},
    .pty0v     ={.bits={.NBC_ANR_Y_L0_V_RNG1=2, .NBC_ANR_Y_L0_V_RNG2=4, .NBC_ANR_Y_L0_V_RNG3=6, .NBC_ANR_Y_L0_V_RNG4=9}},
    .cad       ={.bits={.rsv_0=0, .NBC_ANR_PTC_GAIN_TH=0, .rsv_13=0, .NBC_ANR_C_L_DIFF_TH=24, .rsv_24=0}},
    .pty1v     ={.bits={.NBC_ANR_Y_L1_V_RNG1=2, .NBC_ANR_Y_L1_V_RNG2=4, .NBC_ANR_Y_L1_V_RNG3=6, .NBC_ANR_Y_L1_V_RNG4=9}},
    .sl2       ={.bits={.NBC_ANR_SL2_C_GAIN=6, .NBC_ANR_SL2_SCALE_GAIN=0, .rsv_7=0}},
    .pty2v     ={.bits={.NBC_ANR_Y_L2_V_RNG1=2, .NBC_ANR_Y_L2_V_RNG2=4, .NBC_ANR_Y_L2_V_RNG3=6, .NBC_ANR_Y_L2_V_RNG4=9}},
    .pty3v     ={.bits={.NBC_ANR_Y_L3_V_RNG1=1, .NBC_ANR_Y_L3_V_RNG2=2, .NBC_ANR_Y_L3_V_RNG3=3, .NBC_ANR_Y_L3_V_RNG4=5}},
    .pty0h     ={.bits={.NBC_ANR_Y_L0_H_RNG1=2, .NBC_ANR_Y_L0_H_RNG2=4, .NBC_ANR_Y_L0_H_RNG3=6, .NBC_ANR_Y_L0_H_RNG4=8}},
    .pty1h     ={.bits={.NBC_ANR_Y_L1_H_RNG1=2, .NBC_ANR_Y_L1_H_RNG2=4, .NBC_ANR_Y_L1_H_RNG3=6, .NBC_ANR_Y_L1_H_RNG4=8}},
    .pty2h     ={.bits={.NBC_ANR_Y_L2_H_RNG1=2, .NBC_ANR_Y_L2_H_RNG2=4, .NBC_ANR_Y_L2_H_RNG3=6, .NBC_ANR_Y_L2_H_RNG4=8}},
    .t4lut1    ={.bits={.NBC_ANR_TBL_CPX1=64, .NBC_ANR_TBL_CPX2=128, .NBC_ANR_TBL_CPX3=192, .rsv_24=0}},
    .t4lut2    ={.bits={.NBC_ANR_TBL_GAIN_CPY0=1, .rsv_5=0, .NBC_ANR_TBL_GAIN_CPY1=8, .rsv_13=0, .NBC_ANR_TBL_GAIN_CPY2=16, .rsv_21=0, .NBC_ANR_TBL_GAIN_CPY3=24, .rsv_29=0}},
    .t4lut3    ={.bits={.NBC_ANR_TBL_GAIN_SP0=14, .rsv_5=0, .NBC_ANR_TBL_GAIN_SP1=15, .rsv_13=0, .NBC_ANR_TBL_GAIN_SP2=15, .rsv_21=0, .NBC_ANR_TBL_GAIN_SP3=15, .rsv_29=0}},
    .act1      ={.bits={.NBC_ANR_ACT_SL2_GAIN=8, .rsv_4=0, .NBC_ANR_ACT_DIF_HI_TH=16, .rsv_13=0, .NBC_ANR_ACT_DIF_GAIN=4, .NBC_ANR_ACT_DIF_LO_TH=16, .rsv_29=0}},
    .pty3h     ={.bits={.NBC_ANR_Y_L3_H_RNG1=1, .NBC_ANR_Y_L3_H_RNG2=2, .NBC_ANR_Y_L3_H_RNG3=3, .NBC_ANR_Y_L3_H_RNG4=4}},
    .ptcv      ={.bits={.NBC_ANR_C_V_RNG1=2, .NBC_ANR_C_V_RNG2=4, .NBC_ANR_C_V_RNG3=6, .NBC_ANR_C_V_RNG4=9}},
    .act4      ={.bits={.NBC_ANR_Y_ACT_CEN_OFT=32, .rsv_6=0, .NBC_ANR_Y_ACT_CEN_GAIN=0, .rsv_14=0, .NBC_ANR_Y_ACT_CEN_TH=32, .rsv_22=0}},
    .ptch      ={.bits={.NBC_ANR_C_H_RNG1=2, .NBC_ANR_C_H_RNG2=4, .NBC_ANR_C_H_RNG3=6, .NBC_ANR_C_H_RNG4=8}},
    .ylvl0     ={.bits={.NBC_ANR_Y_L0_RNG_RAT_TH=8, .NBC_ANR_Y_L1_RNG_RAT_TH=12, .NBC_ANR_Y_L2_RNG_RAT_TH=12, .NBC_ANR_Y_L3_RNG_RAT_TH=15, .NBC_ANR_Y_L0_RNG_RAT_SL=3, .rsv_18=0, .NBC_ANR_Y_L1_RNG_RAT_SL=3, .rsv_22=0, .NBC_ANR_Y_L2_RNG_RAT_SL=3, .rsv_26=0, .NBC_ANR_Y_L3_RNG_RAT_SL=3, .rsv_30=0}},
    .ylvl1     ={.bits={.NBC_ANR_Y_L0_HF_W=16, .rsv_5=0, .NBC_ANR_Y_L1_HF_W=8, .rsv_13=0, .NBC_ANR_Y_L2_HF_W=4, .rsv_21=0, .NBC_ANR_Y_L3_HF_W=4, .rsv_29=0}},
    .hf_cor    ={.bits={.NBC_ANR_Y_HF_CORE_TH=0, .NBC_ANR_Y_HF_CORE_SL=2, .rsv_10=0, .NBC_ANR_Y_HF_CLIP=255, .NBC_ANR_HF_BAL_MODE=1, .rsv_26=0}},
    .hf_act0   ={.bits={.NBC_ANR_Y_HF_ACT_X1=16, .NBC_ANR_Y_HF_ACT_X2=24, .NBC_ANR_Y_HF_ACT_X3=32, .NBC_ANR_Y_HF_ACT_X4=40}},
    .hf_act1   ={.bits={.NBC_ANR_Y_HF_ACT_Y0=24, .rsv_7=0, .NBC_ANR_Y_HF_ACT_Y1=24, .rsv_15=0, .NBC_ANR_Y_HF_ACT_Y2=56, .rsv_23=0, .NBC_ANR_Y_HF_ACT_Y3=56, .rsv_31=0}},
    .actc      ={.bits={.rsv_0=0, .NBC_ANR_ACT_BLD_BASE_C=48, .rsv_15=0, .NBC_ANR_C_DITH_U=8, .rsv_21=0, .NBC_ANR_C_DITH_V=8, .rsv_29=0}},
    .ylad      ={.bits={.NBC_ANR_CEN_GAIN_LO_TH_LPF=1, .rsv_5=0, .NBC_ANR_CEN_GAIN_HI_TH_LPF=6, .rsv_13=0}},
    .hf_act2   ={.bits={.NBC_ANR_Y_HF_ACT_Y4=40, .rsv_7=0, .NBC_ANR_Y_HF_ACT_SP4=0, .rsv_14=0}},
    .hf_act3   ={.bits={.NBC_ANR_Y_HF_ACT_SP0=0, .rsv_6=0, .NBC_ANR_Y_HF_ACT_SP1=31, .rsv_14=0, .NBC_ANR_Y_HF_ACT_SP2=0, .rsv_22=0, .NBC_ANR_Y_HF_ACT_SP3=48, .rsv_30=0}},
    .hf_luma0  ={.bits={.NBC_ANR_Y_HF_LUMA_X1=192, .NBC_ANR_Y_HF_LUMA_X2=224, .NBC_ANR_Y_HF_LUMA_Y0=0, .rsv_23=0, .NBC_ANR_Y_HF_LUMA_Y1=0, .rsv_31=0}},
    .hf_luma1  ={.bits={.NBC_ANR_Y_HF_LUMA_Y2=4, .rsv_7=0, .NBC_ANR_Y_HF_LUMA_SP0=0, .rsv_13=0, .NBC_ANR_Y_HF_LUMA_SP1=1, .rsv_21=0, .NBC_ANR_Y_HF_LUMA_SP2=0, .rsv_29=0}},
    .y4lut4    ={.bits={.NBC_ANR_Y_CPX5=255, .NBC_ANR_Y_CPX6=255, .NBC_ANR_Y_CPX7=255, .NBC_ANR_Y_CPX8=255}},
    .y4lut5    ={.bits={.NBC_ANR_Y_SCALE_CPY4=8, .rsv_5=0, .NBC_ANR_Y_SCALE_CPY5=8, .rsv_13=0, .NBC_ANR_Y_SCALE_CPY6=8, .rsv_21=0, .NBC_ANR_Y_SCALE_CPY7=8, .rsv_29=0}},
    .y4lut6    ={.bits={.NBC_ANR_Y_SCALE_SP4=0, .rsv_5=0, .NBC_ANR_Y_SCALE_SP5=0, .rsv_13=0, .NBC_ANR_Y_SCALE_SP6=1, .rsv_21=0, .NBC_ANR_Y_SCALE_SP7=2, .rsv_29=0}},
    .y4lut7    ={.bits={.NBC_ANR_Y_SCALE_CPY8=8, .rsv_5=0, .NBC_ANR_Y_SCALE_SP8=3, .rsv_13=0}},
    .a4lut1    ={.bits={.NBC_ANR_Y_ACT_CPX1=64, .NBC_ANR_Y_ACT_CPX2=128, .NBC_ANR_Y_ACT_CPX3=192, .rsv_24=0}}

};
const ISP_NVRAM_ANR_T gc13a0mipiraw_NBC_ANR_0196 = {
        .con1      ={.bits={.NBC_ANR_ENC=1, .NBC_ANR_ENY=1, .rsv_2=0, .NBC_ANR_Y_FLT0_IDX=0, .rsv_5=0, .NBC_ANR_Y_FLT1_IDX=0, .rsv_7=0, .NBC_ANR_Y_FLT2_IDX=2, .NBC_ANR_Y_FLT3_IDX=3, .NBC_ANR_ACT_LP_EN=0, .rsv_13=0, .NBC_ANR_TILE_EDGE=15, .NBC_ANR_LTM_LINK=1, .NBC_ANR_LTM_LUT_BYPASS=0, .rsv_22=0, .NBC_ANR_SL2_LINK=1, .rsv_25=0, .NBC_ANR_TABLE_EN=0, .NBC_ANR_TBL_PRC=0, .rsv_30=0}},
    .con2      ={.bits={.NBC_ANR_IMPL_MODE=2, .rsv_2=0, .NBC_ANR_C_SM_EDGE=1, .rsv_10=0, .NBC_ANR_FLT_C=0, .rsv_13=0, .NBC_ANR_C_SM_EDGE_TH=2, .rsv_27=0}},
    .yad1      ={.bits={.NBC_ANR_CEN_GAIN_LO_TH=0, .rsv_5=0, .NBC_ANR_CEN_GAIN_HI_TH=0, .rsv_13=0, .NBC_ANR_Y_SLOPE_V_TH=20, .NBC_ANR_Y_SLOPE_H_TH=16}},
    .yad2      ={.bits={.NBC_ANR_Y_VERT_ACT_TH=7, .rsv_5=0, .NBC_ANR_PTY_GAIN_TH=0, .rsv_13=0, .NBC_ANR_Y_VERT_SIGMA=2, .rsv_24=0}},
    .y4lut1    ={.bits={.NBC_ANR_Y_CPX1=64, .NBC_ANR_Y_CPX2=128, .NBC_ANR_Y_CPX3=192, .NBC_ANR_Y_CPX4=255}},
    .y4lut2    ={.bits={.NBC_ANR_Y_SCALE_CPY0=15, .rsv_5=0, .NBC_ANR_Y_SCALE_CPY1=16, .rsv_13=0, .NBC_ANR_Y_SCALE_CPY2=16, .rsv_21=0, .NBC_ANR_Y_SCALE_CPY3=12, .rsv_29=0}},
    .y4lut3    ={.bits={.NBC_ANR_Y_SCALE_SP0=2, .rsv_5=0, .NBC_ANR_Y_SCALE_SP1=0, .rsv_13=0, .NBC_ANR_Y_SCALE_SP2=24, .rsv_21=0, .NBC_ANR_Y_SCALE_SP3=24, .rsv_29=0}},
    .c4lut1    ={.bits={.NBC_ANR_C_CPX1=40, .NBC_ANR_C_CPX2=120, .NBC_ANR_C_CPX3=160, .rsv_24=0}},
    .c4lut2    ={.bits={.NBC_ANR_C_SCALE_CPY0=16, .rsv_5=0, .NBC_ANR_C_SCALE_CPY1=16, .rsv_13=0, .NBC_ANR_C_SCALE_CPY2=16, .rsv_21=0, .NBC_ANR_C_SCALE_CPY3=8, .rsv_29=0}},
    .c4lut3    ={.bits={.NBC_ANR_C_SCALE_SP0=0, .rsv_5=0, .NBC_ANR_C_SCALE_SP1=0, .rsv_13=0, .NBC_ANR_C_SCALE_SP2=28, .rsv_21=0, .NBC_ANR_C_SCALE_SP3=30, .rsv_29=0}},
    .a4lut2    ={.bits={.NBC_ANR_Y_ACT_CPY0=0, .NBC_ANR_Y_ACT_CPY1=0, .NBC_ANR_Y_ACT_CPY2=0, .NBC_ANR_Y_ACT_CPY3=0}},
    .a4lut3    ={.bits={.NBC_ANR_Y_ACT_SP0=0, .rsv_6=0, .NBC_ANR_Y_ACT_SP1=0, .rsv_14=0, .NBC_ANR_Y_ACT_SP2=0, .rsv_22=0, .NBC_ANR_Y_ACT_SP3=0, .rsv_30=0}},
    .l4lut1    ={.bits={.NBC_ANR_SL2_X1=64, .NBC_ANR_SL2_X2=128, .NBC_ANR_SL2_X3=192, .rsv_24=0}},
    .l4lut2    ={.bits={.NBC_ANR_SL2_GAIN0=16, .rsv_6=0, .NBC_ANR_SL2_GAIN1=20, .rsv_14=0, .NBC_ANR_SL2_GAIN2=24, .rsv_22=0, .NBC_ANR_SL2_GAIN3=28, .rsv_30=0}},
    .l4lut3    ={.bits={.NBC_ANR_SL2_SP0=8, .rsv_6=0, .NBC_ANR_SL2_SP1=8, .rsv_14=0, .NBC_ANR_SL2_SP2=8, .rsv_22=0, .NBC_ANR_SL2_SP3=8, .rsv_30=0}},
    .pty0v     ={.bits={.NBC_ANR_Y_L0_V_RNG1=2, .NBC_ANR_Y_L0_V_RNG2=4, .NBC_ANR_Y_L0_V_RNG3=6, .NBC_ANR_Y_L0_V_RNG4=9}},
    .cad       ={.bits={.rsv_0=0, .NBC_ANR_PTC_GAIN_TH=0, .rsv_13=0, .NBC_ANR_C_L_DIFF_TH=24, .rsv_24=0}},
    .pty1v     ={.bits={.NBC_ANR_Y_L1_V_RNG1=2, .NBC_ANR_Y_L1_V_RNG2=4, .NBC_ANR_Y_L1_V_RNG3=6, .NBC_ANR_Y_L1_V_RNG4=9}},
    .sl2       ={.bits={.NBC_ANR_SL2_C_GAIN=6, .NBC_ANR_SL2_SCALE_GAIN=0, .rsv_7=0}},
    .pty2v     ={.bits={.NBC_ANR_Y_L2_V_RNG1=2, .NBC_ANR_Y_L2_V_RNG2=4, .NBC_ANR_Y_L2_V_RNG3=6, .NBC_ANR_Y_L2_V_RNG4=9}},
    .pty3v     ={.bits={.NBC_ANR_Y_L3_V_RNG1=1, .NBC_ANR_Y_L3_V_RNG2=2, .NBC_ANR_Y_L3_V_RNG3=3, .NBC_ANR_Y_L3_V_RNG4=5}},
    .pty0h     ={.bits={.NBC_ANR_Y_L0_H_RNG1=2, .NBC_ANR_Y_L0_H_RNG2=4, .NBC_ANR_Y_L0_H_RNG3=6, .NBC_ANR_Y_L0_H_RNG4=8}},
    .pty1h     ={.bits={.NBC_ANR_Y_L1_H_RNG1=2, .NBC_ANR_Y_L1_H_RNG2=4, .NBC_ANR_Y_L1_H_RNG3=6, .NBC_ANR_Y_L1_H_RNG4=8}},
    .pty2h     ={.bits={.NBC_ANR_Y_L2_H_RNG1=2, .NBC_ANR_Y_L2_H_RNG2=4, .NBC_ANR_Y_L2_H_RNG3=6, .NBC_ANR_Y_L2_H_RNG4=8}},
    .t4lut1    ={.bits={.NBC_ANR_TBL_CPX1=64, .NBC_ANR_TBL_CPX2=128, .NBC_ANR_TBL_CPX3=192, .rsv_24=0}},
    .t4lut2    ={.bits={.NBC_ANR_TBL_GAIN_CPY0=1, .rsv_5=0, .NBC_ANR_TBL_GAIN_CPY1=8, .rsv_13=0, .NBC_ANR_TBL_GAIN_CPY2=16, .rsv_21=0, .NBC_ANR_TBL_GAIN_CPY3=24, .rsv_29=0}},
    .t4lut3    ={.bits={.NBC_ANR_TBL_GAIN_SP0=14, .rsv_5=0, .NBC_ANR_TBL_GAIN_SP1=15, .rsv_13=0, .NBC_ANR_TBL_GAIN_SP2=15, .rsv_21=0, .NBC_ANR_TBL_GAIN_SP3=15, .rsv_29=0}},
    .act1      ={.bits={.NBC_ANR_ACT_SL2_GAIN=8, .rsv_4=0, .NBC_ANR_ACT_DIF_HI_TH=16, .rsv_13=0, .NBC_ANR_ACT_DIF_GAIN=4, .NBC_ANR_ACT_DIF_LO_TH=16, .rsv_29=0}},
    .pty3h     ={.bits={.NBC_ANR_Y_L3_H_RNG1=1, .NBC_ANR_Y_L3_H_RNG2=2, .NBC_ANR_Y_L3_H_RNG3=3, .NBC_ANR_Y_L3_H_RNG4=4}},
    .ptcv      ={.bits={.NBC_ANR_C_V_RNG1=2, .NBC_ANR_C_V_RNG2=4, .NBC_ANR_C_V_RNG3=6, .NBC_ANR_C_V_RNG4=9}},
    .act4      ={.bits={.NBC_ANR_Y_ACT_CEN_OFT=32, .rsv_6=0, .NBC_ANR_Y_ACT_CEN_GAIN=0, .rsv_14=0, .NBC_ANR_Y_ACT_CEN_TH=32, .rsv_22=0}},
    .ptch      ={.bits={.NBC_ANR_C_H_RNG1=2, .NBC_ANR_C_H_RNG2=4, .NBC_ANR_C_H_RNG3=6, .NBC_ANR_C_H_RNG4=8}},
    .ylvl0     ={.bits={.NBC_ANR_Y_L0_RNG_RAT_TH=8, .NBC_ANR_Y_L1_RNG_RAT_TH=12, .NBC_ANR_Y_L2_RNG_RAT_TH=12, .NBC_ANR_Y_L3_RNG_RAT_TH=15, .NBC_ANR_Y_L0_RNG_RAT_SL=3, .rsv_18=0, .NBC_ANR_Y_L1_RNG_RAT_SL=3, .rsv_22=0, .NBC_ANR_Y_L2_RNG_RAT_SL=3, .rsv_26=0, .NBC_ANR_Y_L3_RNG_RAT_SL=3, .rsv_30=0}},
    .ylvl1     ={.bits={.NBC_ANR_Y_L0_HF_W=16, .rsv_5=0, .NBC_ANR_Y_L1_HF_W=8, .rsv_13=0, .NBC_ANR_Y_L2_HF_W=4, .rsv_21=0, .NBC_ANR_Y_L3_HF_W=4, .rsv_29=0}},
    .hf_cor    ={.bits={.NBC_ANR_Y_HF_CORE_TH=0, .NBC_ANR_Y_HF_CORE_SL=2, .rsv_10=0, .NBC_ANR_Y_HF_CLIP=255, .NBC_ANR_HF_BAL_MODE=1, .rsv_26=0}},
    .hf_act0   ={.bits={.NBC_ANR_Y_HF_ACT_X1=16, .NBC_ANR_Y_HF_ACT_X2=24, .NBC_ANR_Y_HF_ACT_X3=32, .NBC_ANR_Y_HF_ACT_X4=40}},
    .hf_act1   ={.bits={.NBC_ANR_Y_HF_ACT_Y0=24, .rsv_7=0, .NBC_ANR_Y_HF_ACT_Y1=24, .rsv_15=0, .NBC_ANR_Y_HF_ACT_Y2=56, .rsv_23=0, .NBC_ANR_Y_HF_ACT_Y3=56, .rsv_31=0}},
    .actc      ={.bits={.rsv_0=0, .NBC_ANR_ACT_BLD_BASE_C=48, .rsv_15=0, .NBC_ANR_C_DITH_U=8, .rsv_21=0, .NBC_ANR_C_DITH_V=8, .rsv_29=0}},
    .ylad      ={.bits={.NBC_ANR_CEN_GAIN_LO_TH_LPF=1, .rsv_5=0, .NBC_ANR_CEN_GAIN_HI_TH_LPF=6, .rsv_13=0}},
    .hf_act2   ={.bits={.NBC_ANR_Y_HF_ACT_Y4=40, .rsv_7=0, .NBC_ANR_Y_HF_ACT_SP4=0, .rsv_14=0}},
    .hf_act3   ={.bits={.NBC_ANR_Y_HF_ACT_SP0=0, .rsv_6=0, .NBC_ANR_Y_HF_ACT_SP1=31, .rsv_14=0, .NBC_ANR_Y_HF_ACT_SP2=0, .rsv_22=0, .NBC_ANR_Y_HF_ACT_SP3=48, .rsv_30=0}},
    .hf_luma0  ={.bits={.NBC_ANR_Y_HF_LUMA_X1=192, .NBC_ANR_Y_HF_LUMA_X2=224, .NBC_ANR_Y_HF_LUMA_Y0=0, .rsv_23=0, .NBC_ANR_Y_HF_LUMA_Y1=0, .rsv_31=0}},
    .hf_luma1  ={.bits={.NBC_ANR_Y_HF_LUMA_Y2=4, .rsv_7=0, .NBC_ANR_Y_HF_LUMA_SP0=0, .rsv_13=0, .NBC_ANR_Y_HF_LUMA_SP1=1, .rsv_21=0, .NBC_ANR_Y_HF_LUMA_SP2=0, .rsv_29=0}},
    .y4lut4    ={.bits={.NBC_ANR_Y_CPX5=255, .NBC_ANR_Y_CPX6=255, .NBC_ANR_Y_CPX7=255, .NBC_ANR_Y_CPX8=255}},
    .y4lut5    ={.bits={.NBC_ANR_Y_SCALE_CPY4=8, .rsv_5=0, .NBC_ANR_Y_SCALE_CPY5=8, .rsv_13=0, .NBC_ANR_Y_SCALE_CPY6=8, .rsv_21=0, .NBC_ANR_Y_SCALE_CPY7=8, .rsv_29=0}},
    .y4lut6    ={.bits={.NBC_ANR_Y_SCALE_SP4=0, .rsv_5=0, .NBC_ANR_Y_SCALE_SP5=0, .rsv_13=0, .NBC_ANR_Y_SCALE_SP6=1, .rsv_21=0, .NBC_ANR_Y_SCALE_SP7=2, .rsv_29=0}},
    .y4lut7    ={.bits={.NBC_ANR_Y_SCALE_CPY8=8, .rsv_5=0, .NBC_ANR_Y_SCALE_SP8=3, .rsv_13=0}},
    .a4lut1    ={.bits={.NBC_ANR_Y_ACT_CPX1=64, .NBC_ANR_Y_ACT_CPX2=128, .NBC_ANR_Y_ACT_CPX3=192, .rsv_24=0}}

};
const ISP_NVRAM_ANR_T gc13a0mipiraw_NBC_ANR_0197 = {
        .con1      ={.bits={.NBC_ANR_ENC=1, .NBC_ANR_ENY=1, .rsv_2=0, .NBC_ANR_Y_FLT0_IDX=0, .rsv_5=0, .NBC_ANR_Y_FLT1_IDX=0, .rsv_7=0, .NBC_ANR_Y_FLT2_IDX=2, .NBC_ANR_Y_FLT3_IDX=3, .NBC_ANR_ACT_LP_EN=0, .rsv_13=0, .NBC_ANR_TILE_EDGE=15, .NBC_ANR_LTM_LINK=1, .NBC_ANR_LTM_LUT_BYPASS=0, .rsv_22=0, .NBC_ANR_SL2_LINK=1, .rsv_25=0, .NBC_ANR_TABLE_EN=0, .NBC_ANR_TBL_PRC=0, .rsv_30=0}},
    .con2      ={.bits={.NBC_ANR_IMPL_MODE=2, .rsv_2=0, .NBC_ANR_C_SM_EDGE=1, .rsv_10=0, .NBC_ANR_FLT_C=0, .rsv_13=0, .NBC_ANR_C_SM_EDGE_TH=2, .rsv_27=0}},
    .yad1      ={.bits={.NBC_ANR_CEN_GAIN_LO_TH=0, .rsv_5=0, .NBC_ANR_CEN_GAIN_HI_TH=0, .rsv_13=0, .NBC_ANR_Y_SLOPE_V_TH=20, .NBC_ANR_Y_SLOPE_H_TH=16}},
    .yad2      ={.bits={.NBC_ANR_Y_VERT_ACT_TH=7, .rsv_5=0, .NBC_ANR_PTY_GAIN_TH=0, .rsv_13=0, .NBC_ANR_Y_VERT_SIGMA=2, .rsv_24=0}},
    .y4lut1    ={.bits={.NBC_ANR_Y_CPX1=64, .NBC_ANR_Y_CPX2=128, .NBC_ANR_Y_CPX3=192, .NBC_ANR_Y_CPX4=255}},
    .y4lut2    ={.bits={.NBC_ANR_Y_SCALE_CPY0=15, .rsv_5=0, .NBC_ANR_Y_SCALE_CPY1=16, .rsv_13=0, .NBC_ANR_Y_SCALE_CPY2=16, .rsv_21=0, .NBC_ANR_Y_SCALE_CPY3=12, .rsv_29=0}},
    .y4lut3    ={.bits={.NBC_ANR_Y_SCALE_SP0=2, .rsv_5=0, .NBC_ANR_Y_SCALE_SP1=0, .rsv_13=0, .NBC_ANR_Y_SCALE_SP2=24, .rsv_21=0, .NBC_ANR_Y_SCALE_SP3=24, .rsv_29=0}},
    .c4lut1    ={.bits={.NBC_ANR_C_CPX1=40, .NBC_ANR_C_CPX2=120, .NBC_ANR_C_CPX3=160, .rsv_24=0}},
    .c4lut2    ={.bits={.NBC_ANR_C_SCALE_CPY0=16, .rsv_5=0, .NBC_ANR_C_SCALE_CPY1=16, .rsv_13=0, .NBC_ANR_C_SCALE_CPY2=16, .rsv_21=0, .NBC_ANR_C_SCALE_CPY3=8, .rsv_29=0}},
    .c4lut3    ={.bits={.NBC_ANR_C_SCALE_SP0=0, .rsv_5=0, .NBC_ANR_C_SCALE_SP1=0, .rsv_13=0, .NBC_ANR_C_SCALE_SP2=28, .rsv_21=0, .NBC_ANR_C_SCALE_SP3=30, .rsv_29=0}},
    .a4lut2    ={.bits={.NBC_ANR_Y_ACT_CPY0=0, .NBC_ANR_Y_ACT_CPY1=0, .NBC_ANR_Y_ACT_CPY2=0, .NBC_ANR_Y_ACT_CPY3=0}},
    .a4lut3    ={.bits={.NBC_ANR_Y_ACT_SP0=0, .rsv_6=0, .NBC_ANR_Y_ACT_SP1=0, .rsv_14=0, .NBC_ANR_Y_ACT_SP2=0, .rsv_22=0, .NBC_ANR_Y_ACT_SP3=0, .rsv_30=0}},
    .l4lut1    ={.bits={.NBC_ANR_SL2_X1=64, .NBC_ANR_SL2_X2=128, .NBC_ANR_SL2_X3=192, .rsv_24=0}},
    .l4lut2    ={.bits={.NBC_ANR_SL2_GAIN0=16, .rsv_6=0, .NBC_ANR_SL2_GAIN1=20, .rsv_14=0, .NBC_ANR_SL2_GAIN2=24, .rsv_22=0, .NBC_ANR_SL2_GAIN3=28, .rsv_30=0}},
    .l4lut3    ={.bits={.NBC_ANR_SL2_SP0=8, .rsv_6=0, .NBC_ANR_SL2_SP1=8, .rsv_14=0, .NBC_ANR_SL2_SP2=8, .rsv_22=0, .NBC_ANR_SL2_SP3=8, .rsv_30=0}},
    .pty0v     ={.bits={.NBC_ANR_Y_L0_V_RNG1=2, .NBC_ANR_Y_L0_V_RNG2=4, .NBC_ANR_Y_L0_V_RNG3=6, .NBC_ANR_Y_L0_V_RNG4=9}},
    .cad       ={.bits={.rsv_0=0, .NBC_ANR_PTC_GAIN_TH=0, .rsv_13=0, .NBC_ANR_C_L_DIFF_TH=24, .rsv_24=0}},
    .pty1v     ={.bits={.NBC_ANR_Y_L1_V_RNG1=2, .NBC_ANR_Y_L1_V_RNG2=4, .NBC_ANR_Y_L1_V_RNG3=6, .NBC_ANR_Y_L1_V_RNG4=9}},
    .sl2       ={.bits={.NBC_ANR_SL2_C_GAIN=6, .NBC_ANR_SL2_SCALE_GAIN=0, .rsv_7=0}},
    .pty2v     ={.bits={.NBC_ANR_Y_L2_V_RNG1=2, .NBC_ANR_Y_L2_V_RNG2=4, .NBC_ANR_Y_L2_V_RNG3=6, .NBC_ANR_Y_L2_V_RNG4=9}},
    .pty3v     ={.bits={.NBC_ANR_Y_L3_V_RNG1=1, .NBC_ANR_Y_L3_V_RNG2=2, .NBC_ANR_Y_L3_V_RNG3=3, .NBC_ANR_Y_L3_V_RNG4=5}},
    .pty0h     ={.bits={.NBC_ANR_Y_L0_H_RNG1=2, .NBC_ANR_Y_L0_H_RNG2=4, .NBC_ANR_Y_L0_H_RNG3=6, .NBC_ANR_Y_L0_H_RNG4=8}},
    .pty1h     ={.bits={.NBC_ANR_Y_L1_H_RNG1=2, .NBC_ANR_Y_L1_H_RNG2=4, .NBC_ANR_Y_L1_H_RNG3=6, .NBC_ANR_Y_L1_H_RNG4=8}},
    .pty2h     ={.bits={.NBC_ANR_Y_L2_H_RNG1=2, .NBC_ANR_Y_L2_H_RNG2=4, .NBC_ANR_Y_L2_H_RNG3=6, .NBC_ANR_Y_L2_H_RNG4=8}},
    .t4lut1    ={.bits={.NBC_ANR_TBL_CPX1=64, .NBC_ANR_TBL_CPX2=128, .NBC_ANR_TBL_CPX3=192, .rsv_24=0}},
    .t4lut2    ={.bits={.NBC_ANR_TBL_GAIN_CPY0=1, .rsv_5=0, .NBC_ANR_TBL_GAIN_CPY1=8, .rsv_13=0, .NBC_ANR_TBL_GAIN_CPY2=16, .rsv_21=0, .NBC_ANR_TBL_GAIN_CPY3=24, .rsv_29=0}},
    .t4lut3    ={.bits={.NBC_ANR_TBL_GAIN_SP0=14, .rsv_5=0, .NBC_ANR_TBL_GAIN_SP1=15, .rsv_13=0, .NBC_ANR_TBL_GAIN_SP2=15, .rsv_21=0, .NBC_ANR_TBL_GAIN_SP3=15, .rsv_29=0}},
    .act1      ={.bits={.NBC_ANR_ACT_SL2_GAIN=8, .rsv_4=0, .NBC_ANR_ACT_DIF_HI_TH=16, .rsv_13=0, .NBC_ANR_ACT_DIF_GAIN=4, .NBC_ANR_ACT_DIF_LO_TH=16, .rsv_29=0}},
    .pty3h     ={.bits={.NBC_ANR_Y_L3_H_RNG1=1, .NBC_ANR_Y_L3_H_RNG2=2, .NBC_ANR_Y_L3_H_RNG3=3, .NBC_ANR_Y_L3_H_RNG4=4}},
    .ptcv      ={.bits={.NBC_ANR_C_V_RNG1=2, .NBC_ANR_C_V_RNG2=4, .NBC_ANR_C_V_RNG3=6, .NBC_ANR_C_V_RNG4=9}},
    .act4      ={.bits={.NBC_ANR_Y_ACT_CEN_OFT=32, .rsv_6=0, .NBC_ANR_Y_ACT_CEN_GAIN=0, .rsv_14=0, .NBC_ANR_Y_ACT_CEN_TH=32, .rsv_22=0}},
    .ptch      ={.bits={.NBC_ANR_C_H_RNG1=2, .NBC_ANR_C_H_RNG2=4, .NBC_ANR_C_H_RNG3=6, .NBC_ANR_C_H_RNG4=8}},
    .ylvl0     ={.bits={.NBC_ANR_Y_L0_RNG_RAT_TH=8, .NBC_ANR_Y_L1_RNG_RAT_TH=12, .NBC_ANR_Y_L2_RNG_RAT_TH=12, .NBC_ANR_Y_L3_RNG_RAT_TH=15, .NBC_ANR_Y_L0_RNG_RAT_SL=3, .rsv_18=0, .NBC_ANR_Y_L1_RNG_RAT_SL=3, .rsv_22=0, .NBC_ANR_Y_L2_RNG_RAT_SL=3, .rsv_26=0, .NBC_ANR_Y_L3_RNG_RAT_SL=3, .rsv_30=0}},
    .ylvl1     ={.bits={.NBC_ANR_Y_L0_HF_W=16, .rsv_5=0, .NBC_ANR_Y_L1_HF_W=8, .rsv_13=0, .NBC_ANR_Y_L2_HF_W=4, .rsv_21=0, .NBC_ANR_Y_L3_HF_W=4, .rsv_29=0}},
    .hf_cor    ={.bits={.NBC_ANR_Y_HF_CORE_TH=0, .NBC_ANR_Y_HF_CORE_SL=2, .rsv_10=0, .NBC_ANR_Y_HF_CLIP=255, .NBC_ANR_HF_BAL_MODE=1, .rsv_26=0}},
    .hf_act0   ={.bits={.NBC_ANR_Y_HF_ACT_X1=16, .NBC_ANR_Y_HF_ACT_X2=24, .NBC_ANR_Y_HF_ACT_X3=32, .NBC_ANR_Y_HF_ACT_X4=40}},
    .hf_act1   ={.bits={.NBC_ANR_Y_HF_ACT_Y0=24, .rsv_7=0, .NBC_ANR_Y_HF_ACT_Y1=24, .rsv_15=0, .NBC_ANR_Y_HF_ACT_Y2=56, .rsv_23=0, .NBC_ANR_Y_HF_ACT_Y3=56, .rsv_31=0}},
    .actc      ={.bits={.rsv_0=0, .NBC_ANR_ACT_BLD_BASE_C=48, .rsv_15=0, .NBC_ANR_C_DITH_U=8, .rsv_21=0, .NBC_ANR_C_DITH_V=8, .rsv_29=0}},
    .ylad      ={.bits={.NBC_ANR_CEN_GAIN_LO_TH_LPF=1, .rsv_5=0, .NBC_ANR_CEN_GAIN_HI_TH_LPF=6, .rsv_13=0}},
    .hf_act2   ={.bits={.NBC_ANR_Y_HF_ACT_Y4=40, .rsv_7=0, .NBC_ANR_Y_HF_ACT_SP4=0, .rsv_14=0}},
    .hf_act3   ={.bits={.NBC_ANR_Y_HF_ACT_SP0=0, .rsv_6=0, .NBC_ANR_Y_HF_ACT_SP1=31, .rsv_14=0, .NBC_ANR_Y_HF_ACT_SP2=0, .rsv_22=0, .NBC_ANR_Y_HF_ACT_SP3=48, .rsv_30=0}},
    .hf_luma0  ={.bits={.NBC_ANR_Y_HF_LUMA_X1=192, .NBC_ANR_Y_HF_LUMA_X2=224, .NBC_ANR_Y_HF_LUMA_Y0=0, .rsv_23=0, .NBC_ANR_Y_HF_LUMA_Y1=0, .rsv_31=0}},
    .hf_luma1  ={.bits={.NBC_ANR_Y_HF_LUMA_Y2=4, .rsv_7=0, .NBC_ANR_Y_HF_LUMA_SP0=0, .rsv_13=0, .NBC_ANR_Y_HF_LUMA_SP1=1, .rsv_21=0, .NBC_ANR_Y_HF_LUMA_SP2=0, .rsv_29=0}},
    .y4lut4    ={.bits={.NBC_ANR_Y_CPX5=255, .NBC_ANR_Y_CPX6=255, .NBC_ANR_Y_CPX7=255, .NBC_ANR_Y_CPX8=255}},
    .y4lut5    ={.bits={.NBC_ANR_Y_SCALE_CPY4=8, .rsv_5=0, .NBC_ANR_Y_SCALE_CPY5=8, .rsv_13=0, .NBC_ANR_Y_SCALE_CPY6=8, .rsv_21=0, .NBC_ANR_Y_SCALE_CPY7=8, .rsv_29=0}},
    .y4lut6    ={.bits={.NBC_ANR_Y_SCALE_SP4=0, .rsv_5=0, .NBC_ANR_Y_SCALE_SP5=0, .rsv_13=0, .NBC_ANR_Y_SCALE_SP6=1, .rsv_21=0, .NBC_ANR_Y_SCALE_SP7=2, .rsv_29=0}},
    .y4lut7    ={.bits={.NBC_ANR_Y_SCALE_CPY8=8, .rsv_5=0, .NBC_ANR_Y_SCALE_SP8=3, .rsv_13=0}},
    .a4lut1    ={.bits={.NBC_ANR_Y_ACT_CPX1=64, .NBC_ANR_Y_ACT_CPX2=128, .NBC_ANR_Y_ACT_CPX3=192, .rsv_24=0}}

};
const ISP_NVRAM_ANR_T gc13a0mipiraw_NBC_ANR_0198 = {
        .con1      ={.bits={.NBC_ANR_ENC=1, .NBC_ANR_ENY=1, .rsv_2=0, .NBC_ANR_Y_FLT0_IDX=0, .rsv_5=0, .NBC_ANR_Y_FLT1_IDX=0, .rsv_7=0, .NBC_ANR_Y_FLT2_IDX=2, .NBC_ANR_Y_FLT3_IDX=3, .NBC_ANR_ACT_LP_EN=0, .rsv_13=0, .NBC_ANR_TILE_EDGE=15, .NBC_ANR_LTM_LINK=1, .NBC_ANR_LTM_LUT_BYPASS=0, .rsv_22=0, .NBC_ANR_SL2_LINK=1, .rsv_25=0, .NBC_ANR_TABLE_EN=0, .NBC_ANR_TBL_PRC=0, .rsv_30=0}},
    .con2      ={.bits={.NBC_ANR_IMPL_MODE=2, .rsv_2=0, .NBC_ANR_C_SM_EDGE=1, .rsv_10=0, .NBC_ANR_FLT_C=0, .rsv_13=0, .NBC_ANR_C_SM_EDGE_TH=2, .rsv_27=0}},
    .yad1      ={.bits={.NBC_ANR_CEN_GAIN_LO_TH=0, .rsv_5=0, .NBC_ANR_CEN_GAIN_HI_TH=0, .rsv_13=0, .NBC_ANR_Y_SLOPE_V_TH=20, .NBC_ANR_Y_SLOPE_H_TH=16}},
    .yad2      ={.bits={.NBC_ANR_Y_VERT_ACT_TH=7, .rsv_5=0, .NBC_ANR_PTY_GAIN_TH=0, .rsv_13=0, .NBC_ANR_Y_VERT_SIGMA=2, .rsv_24=0}},
    .y4lut1    ={.bits={.NBC_ANR_Y_CPX1=64, .NBC_ANR_Y_CPX2=128, .NBC_ANR_Y_CPX3=192, .NBC_ANR_Y_CPX4=255}},
    .y4lut2    ={.bits={.NBC_ANR_Y_SCALE_CPY0=15, .rsv_5=0, .NBC_ANR_Y_SCALE_CPY1=16, .rsv_13=0, .NBC_ANR_Y_SCALE_CPY2=16, .rsv_21=0, .NBC_ANR_Y_SCALE_CPY3=12, .rsv_29=0}},
    .y4lut3    ={.bits={.NBC_ANR_Y_SCALE_SP0=2, .rsv_5=0, .NBC_ANR_Y_SCALE_SP1=0, .rsv_13=0, .NBC_ANR_Y_SCALE_SP2=24, .rsv_21=0, .NBC_ANR_Y_SCALE_SP3=24, .rsv_29=0}},
    .c4lut1    ={.bits={.NBC_ANR_C_CPX1=40, .NBC_ANR_C_CPX2=120, .NBC_ANR_C_CPX3=160, .rsv_24=0}},
    .c4lut2    ={.bits={.NBC_ANR_C_SCALE_CPY0=16, .rsv_5=0, .NBC_ANR_C_SCALE_CPY1=16, .rsv_13=0, .NBC_ANR_C_SCALE_CPY2=16, .rsv_21=0, .NBC_ANR_C_SCALE_CPY3=8, .rsv_29=0}},
    .c4lut3    ={.bits={.NBC_ANR_C_SCALE_SP0=0, .rsv_5=0, .NBC_ANR_C_SCALE_SP1=0, .rsv_13=0, .NBC_ANR_C_SCALE_SP2=28, .rsv_21=0, .NBC_ANR_C_SCALE_SP3=30, .rsv_29=0}},
    .a4lut2    ={.bits={.NBC_ANR_Y_ACT_CPY0=0, .NBC_ANR_Y_ACT_CPY1=0, .NBC_ANR_Y_ACT_CPY2=0, .NBC_ANR_Y_ACT_CPY3=0}},
    .a4lut3    ={.bits={.NBC_ANR_Y_ACT_SP0=0, .rsv_6=0, .NBC_ANR_Y_ACT_SP1=0, .rsv_14=0, .NBC_ANR_Y_ACT_SP2=0, .rsv_22=0, .NBC_ANR_Y_ACT_SP3=0, .rsv_30=0}},
    .l4lut1    ={.bits={.NBC_ANR_SL2_X1=64, .NBC_ANR_SL2_X2=128, .NBC_ANR_SL2_X3=192, .rsv_24=0}},
    .l4lut2    ={.bits={.NBC_ANR_SL2_GAIN0=16, .rsv_6=0, .NBC_ANR_SL2_GAIN1=20, .rsv_14=0, .NBC_ANR_SL2_GAIN2=24, .rsv_22=0, .NBC_ANR_SL2_GAIN3=28, .rsv_30=0}},
    .l4lut3    ={.bits={.NBC_ANR_SL2_SP0=8, .rsv_6=0, .NBC_ANR_SL2_SP1=8, .rsv_14=0, .NBC_ANR_SL2_SP2=8, .rsv_22=0, .NBC_ANR_SL2_SP3=8, .rsv_30=0}},
    .pty0v     ={.bits={.NBC_ANR_Y_L0_V_RNG1=2, .NBC_ANR_Y_L0_V_RNG2=4, .NBC_ANR_Y_L0_V_RNG3=6, .NBC_ANR_Y_L0_V_RNG4=9}},
    .cad       ={.bits={.rsv_0=0, .NBC_ANR_PTC_GAIN_TH=0, .rsv_13=0, .NBC_ANR_C_L_DIFF_TH=24, .rsv_24=0}},
    .pty1v     ={.bits={.NBC_ANR_Y_L1_V_RNG1=2, .NBC_ANR_Y_L1_V_RNG2=4, .NBC_ANR_Y_L1_V_RNG3=6, .NBC_ANR_Y_L1_V_RNG4=9}},
    .sl2       ={.bits={.NBC_ANR_SL2_C_GAIN=6, .NBC_ANR_SL2_SCALE_GAIN=0, .rsv_7=0}},
    .pty2v     ={.bits={.NBC_ANR_Y_L2_V_RNG1=2, .NBC_ANR_Y_L2_V_RNG2=4, .NBC_ANR_Y_L2_V_RNG3=6, .NBC_ANR_Y_L2_V_RNG4=9}},
    .pty3v     ={.bits={.NBC_ANR_Y_L3_V_RNG1=1, .NBC_ANR_Y_L3_V_RNG2=2, .NBC_ANR_Y_L3_V_RNG3=3, .NBC_ANR_Y_L3_V_RNG4=5}},
    .pty0h     ={.bits={.NBC_ANR_Y_L0_H_RNG1=2, .NBC_ANR_Y_L0_H_RNG2=4, .NBC_ANR_Y_L0_H_RNG3=6, .NBC_ANR_Y_L0_H_RNG4=8}},
    .pty1h     ={.bits={.NBC_ANR_Y_L1_H_RNG1=2, .NBC_ANR_Y_L1_H_RNG2=4, .NBC_ANR_Y_L1_H_RNG3=6, .NBC_ANR_Y_L1_H_RNG4=8}},
    .pty2h     ={.bits={.NBC_ANR_Y_L2_H_RNG1=2, .NBC_ANR_Y_L2_H_RNG2=4, .NBC_ANR_Y_L2_H_RNG3=6, .NBC_ANR_Y_L2_H_RNG4=8}},
    .t4lut1    ={.bits={.NBC_ANR_TBL_CPX1=64, .NBC_ANR_TBL_CPX2=128, .NBC_ANR_TBL_CPX3=192, .rsv_24=0}},
    .t4lut2    ={.bits={.NBC_ANR_TBL_GAIN_CPY0=1, .rsv_5=0, .NBC_ANR_TBL_GAIN_CPY1=8, .rsv_13=0, .NBC_ANR_TBL_GAIN_CPY2=16, .rsv_21=0, .NBC_ANR_TBL_GAIN_CPY3=24, .rsv_29=0}},
    .t4lut3    ={.bits={.NBC_ANR_TBL_GAIN_SP0=14, .rsv_5=0, .NBC_ANR_TBL_GAIN_SP1=15, .rsv_13=0, .NBC_ANR_TBL_GAIN_SP2=15, .rsv_21=0, .NBC_ANR_TBL_GAIN_SP3=15, .rsv_29=0}},
    .act1      ={.bits={.NBC_ANR_ACT_SL2_GAIN=8, .rsv_4=0, .NBC_ANR_ACT_DIF_HI_TH=16, .rsv_13=0, .NBC_ANR_ACT_DIF_GAIN=4, .NBC_ANR_ACT_DIF_LO_TH=16, .rsv_29=0}},
    .pty3h     ={.bits={.NBC_ANR_Y_L3_H_RNG1=1, .NBC_ANR_Y_L3_H_RNG2=2, .NBC_ANR_Y_L3_H_RNG3=3, .NBC_ANR_Y_L3_H_RNG4=4}},
    .ptcv      ={.bits={.NBC_ANR_C_V_RNG1=2, .NBC_ANR_C_V_RNG2=4, .NBC_ANR_C_V_RNG3=6, .NBC_ANR_C_V_RNG4=9}},
    .act4      ={.bits={.NBC_ANR_Y_ACT_CEN_OFT=32, .rsv_6=0, .NBC_ANR_Y_ACT_CEN_GAIN=0, .rsv_14=0, .NBC_ANR_Y_ACT_CEN_TH=32, .rsv_22=0}},
    .ptch      ={.bits={.NBC_ANR_C_H_RNG1=2, .NBC_ANR_C_H_RNG2=4, .NBC_ANR_C_H_RNG3=6, .NBC_ANR_C_H_RNG4=8}},
    .ylvl0     ={.bits={.NBC_ANR_Y_L0_RNG_RAT_TH=8, .NBC_ANR_Y_L1_RNG_RAT_TH=12, .NBC_ANR_Y_L2_RNG_RAT_TH=12, .NBC_ANR_Y_L3_RNG_RAT_TH=15, .NBC_ANR_Y_L0_RNG_RAT_SL=3, .rsv_18=0, .NBC_ANR_Y_L1_RNG_RAT_SL=3, .rsv_22=0, .NBC_ANR_Y_L2_RNG_RAT_SL=3, .rsv_26=0, .NBC_ANR_Y_L3_RNG_RAT_SL=3, .rsv_30=0}},
    .ylvl1     ={.bits={.NBC_ANR_Y_L0_HF_W=16, .rsv_5=0, .NBC_ANR_Y_L1_HF_W=8, .rsv_13=0, .NBC_ANR_Y_L2_HF_W=4, .rsv_21=0, .NBC_ANR_Y_L3_HF_W=4, .rsv_29=0}},
    .hf_cor    ={.bits={.NBC_ANR_Y_HF_CORE_TH=0, .NBC_ANR_Y_HF_CORE_SL=2, .rsv_10=0, .NBC_ANR_Y_HF_CLIP=255, .NBC_ANR_HF_BAL_MODE=1, .rsv_26=0}},
    .hf_act0   ={.bits={.NBC_ANR_Y_HF_ACT_X1=16, .NBC_ANR_Y_HF_ACT_X2=24, .NBC_ANR_Y_HF_ACT_X3=32, .NBC_ANR_Y_HF_ACT_X4=40}},
    .hf_act1   ={.bits={.NBC_ANR_Y_HF_ACT_Y0=24, .rsv_7=0, .NBC_ANR_Y_HF_ACT_Y1=24, .rsv_15=0, .NBC_ANR_Y_HF_ACT_Y2=56, .rsv_23=0, .NBC_ANR_Y_HF_ACT_Y3=56, .rsv_31=0}},
    .actc      ={.bits={.rsv_0=0, .NBC_ANR_ACT_BLD_BASE_C=48, .rsv_15=0, .NBC_ANR_C_DITH_U=8, .rsv_21=0, .NBC_ANR_C_DITH_V=8, .rsv_29=0}},
    .ylad      ={.bits={.NBC_ANR_CEN_GAIN_LO_TH_LPF=1, .rsv_5=0, .NBC_ANR_CEN_GAIN_HI_TH_LPF=6, .rsv_13=0}},
    .hf_act2   ={.bits={.NBC_ANR_Y_HF_ACT_Y4=40, .rsv_7=0, .NBC_ANR_Y_HF_ACT_SP4=0, .rsv_14=0}},
    .hf_act3   ={.bits={.NBC_ANR_Y_HF_ACT_SP0=0, .rsv_6=0, .NBC_ANR_Y_HF_ACT_SP1=31, .rsv_14=0, .NBC_ANR_Y_HF_ACT_SP2=0, .rsv_22=0, .NBC_ANR_Y_HF_ACT_SP3=48, .rsv_30=0}},
    .hf_luma0  ={.bits={.NBC_ANR_Y_HF_LUMA_X1=192, .NBC_ANR_Y_HF_LUMA_X2=224, .NBC_ANR_Y_HF_LUMA_Y0=0, .rsv_23=0, .NBC_ANR_Y_HF_LUMA_Y1=0, .rsv_31=0}},
    .hf_luma1  ={.bits={.NBC_ANR_Y_HF_LUMA_Y2=4, .rsv_7=0, .NBC_ANR_Y_HF_LUMA_SP0=0, .rsv_13=0, .NBC_ANR_Y_HF_LUMA_SP1=1, .rsv_21=0, .NBC_ANR_Y_HF_LUMA_SP2=0, .rsv_29=0}},
    .y4lut4    ={.bits={.NBC_ANR_Y_CPX5=255, .NBC_ANR_Y_CPX6=255, .NBC_ANR_Y_CPX7=255, .NBC_ANR_Y_CPX8=255}},
    .y4lut5    ={.bits={.NBC_ANR_Y_SCALE_CPY4=8, .rsv_5=0, .NBC_ANR_Y_SCALE_CPY5=8, .rsv_13=0, .NBC_ANR_Y_SCALE_CPY6=8, .rsv_21=0, .NBC_ANR_Y_SCALE_CPY7=8, .rsv_29=0}},
    .y4lut6    ={.bits={.NBC_ANR_Y_SCALE_SP4=0, .rsv_5=0, .NBC_ANR_Y_SCALE_SP5=0, .rsv_13=0, .NBC_ANR_Y_SCALE_SP6=1, .rsv_21=0, .NBC_ANR_Y_SCALE_SP7=2, .rsv_29=0}},
    .y4lut7    ={.bits={.NBC_ANR_Y_SCALE_CPY8=8, .rsv_5=0, .NBC_ANR_Y_SCALE_SP8=3, .rsv_13=0}},
    .a4lut1    ={.bits={.NBC_ANR_Y_ACT_CPX1=64, .NBC_ANR_Y_ACT_CPX2=128, .NBC_ANR_Y_ACT_CPX3=192, .rsv_24=0}}

};
const ISP_NVRAM_ANR_T gc13a0mipiraw_NBC_ANR_0199 = {
        .con1      ={.bits={.NBC_ANR_ENC=1, .NBC_ANR_ENY=1, .rsv_2=0, .NBC_ANR_Y_FLT0_IDX=0, .rsv_5=0, .NBC_ANR_Y_FLT1_IDX=0, .rsv_7=0, .NBC_ANR_Y_FLT2_IDX=2, .NBC_ANR_Y_FLT3_IDX=3, .NBC_ANR_ACT_LP_EN=0, .rsv_13=0, .NBC_ANR_TILE_EDGE=15, .NBC_ANR_LTM_LINK=1, .NBC_ANR_LTM_LUT_BYPASS=0, .rsv_22=0, .NBC_ANR_SL2_LINK=1, .rsv_25=0, .NBC_ANR_TABLE_EN=0, .NBC_ANR_TBL_PRC=0, .rsv_30=0}},
    .con2      ={.bits={.NBC_ANR_IMPL_MODE=2, .rsv_2=0, .NBC_ANR_C_SM_EDGE=1, .rsv_10=0, .NBC_ANR_FLT_C=0, .rsv_13=0, .NBC_ANR_C_SM_EDGE_TH=2, .rsv_27=0}},
    .yad1      ={.bits={.NBC_ANR_CEN_GAIN_LO_TH=0, .rsv_5=0, .NBC_ANR_CEN_GAIN_HI_TH=0, .rsv_13=0, .NBC_ANR_Y_SLOPE_V_TH=20, .NBC_ANR_Y_SLOPE_H_TH=16}},
    .yad2      ={.bits={.NBC_ANR_Y_VERT_ACT_TH=7, .rsv_5=0, .NBC_ANR_PTY_GAIN_TH=0, .rsv_13=0, .NBC_ANR_Y_VERT_SIGMA=2, .rsv_24=0}},
    .y4lut1    ={.bits={.NBC_ANR_Y_CPX1=64, .NBC_ANR_Y_CPX2=128, .NBC_ANR_Y_CPX3=192, .NBC_ANR_Y_CPX4=255}},
    .y4lut2    ={.bits={.NBC_ANR_Y_SCALE_CPY0=15, .rsv_5=0, .NBC_ANR_Y_SCALE_CPY1=16, .rsv_13=0, .NBC_ANR_Y_SCALE_CPY2=16, .rsv_21=0, .NBC_ANR_Y_SCALE_CPY3=12, .rsv_29=0}},
    .y4lut3    ={.bits={.NBC_ANR_Y_SCALE_SP0=2, .rsv_5=0, .NBC_ANR_Y_SCALE_SP1=0, .rsv_13=0, .NBC_ANR_Y_SCALE_SP2=24, .rsv_21=0, .NBC_ANR_Y_SCALE_SP3=24, .rsv_29=0}},
    .c4lut1    ={.bits={.NBC_ANR_C_CPX1=40, .NBC_ANR_C_CPX2=120, .NBC_ANR_C_CPX3=160, .rsv_24=0}},
    .c4lut2    ={.bits={.NBC_ANR_C_SCALE_CPY0=16, .rsv_5=0, .NBC_ANR_C_SCALE_CPY1=16, .rsv_13=0, .NBC_ANR_C_SCALE_CPY2=16, .rsv_21=0, .NBC_ANR_C_SCALE_CPY3=8, .rsv_29=0}},
    .c4lut3    ={.bits={.NBC_ANR_C_SCALE_SP0=0, .rsv_5=0, .NBC_ANR_C_SCALE_SP1=0, .rsv_13=0, .NBC_ANR_C_SCALE_SP2=28, .rsv_21=0, .NBC_ANR_C_SCALE_SP3=30, .rsv_29=0}},
    .a4lut2    ={.bits={.NBC_ANR_Y_ACT_CPY0=0, .NBC_ANR_Y_ACT_CPY1=0, .NBC_ANR_Y_ACT_CPY2=0, .NBC_ANR_Y_ACT_CPY3=0}},
    .a4lut3    ={.bits={.NBC_ANR_Y_ACT_SP0=0, .rsv_6=0, .NBC_ANR_Y_ACT_SP1=0, .rsv_14=0, .NBC_ANR_Y_ACT_SP2=0, .rsv_22=0, .NBC_ANR_Y_ACT_SP3=0, .rsv_30=0}},
    .l4lut1    ={.bits={.NBC_ANR_SL2_X1=64, .NBC_ANR_SL2_X2=128, .NBC_ANR_SL2_X3=192, .rsv_24=0}},
    .l4lut2    ={.bits={.NBC_ANR_SL2_GAIN0=16, .rsv_6=0, .NBC_ANR_SL2_GAIN1=20, .rsv_14=0, .NBC_ANR_SL2_GAIN2=24, .rsv_22=0, .NBC_ANR_SL2_GAIN3=28, .rsv_30=0}},
    .l4lut3    ={.bits={.NBC_ANR_SL2_SP0=8, .rsv_6=0, .NBC_ANR_SL2_SP1=8, .rsv_14=0, .NBC_ANR_SL2_SP2=8, .rsv_22=0, .NBC_ANR_SL2_SP3=8, .rsv_30=0}},
    .pty0v     ={.bits={.NBC_ANR_Y_L0_V_RNG1=2, .NBC_ANR_Y_L0_V_RNG2=4, .NBC_ANR_Y_L0_V_RNG3=6, .NBC_ANR_Y_L0_V_RNG4=9}},
    .cad       ={.bits={.rsv_0=0, .NBC_ANR_PTC_GAIN_TH=0, .rsv_13=0, .NBC_ANR_C_L_DIFF_TH=24, .rsv_24=0}},
    .pty1v     ={.bits={.NBC_ANR_Y_L1_V_RNG1=2, .NBC_ANR_Y_L1_V_RNG2=4, .NBC_ANR_Y_L1_V_RNG3=6, .NBC_ANR_Y_L1_V_RNG4=9}},
    .sl2       ={.bits={.NBC_ANR_SL2_C_GAIN=6, .NBC_ANR_SL2_SCALE_GAIN=0, .rsv_7=0}},
    .pty2v     ={.bits={.NBC_ANR_Y_L2_V_RNG1=2, .NBC_ANR_Y_L2_V_RNG2=4, .NBC_ANR_Y_L2_V_RNG3=6, .NBC_ANR_Y_L2_V_RNG4=9}},
    .pty3v     ={.bits={.NBC_ANR_Y_L3_V_RNG1=1, .NBC_ANR_Y_L3_V_RNG2=2, .NBC_ANR_Y_L3_V_RNG3=3, .NBC_ANR_Y_L3_V_RNG4=5}},
    .pty0h     ={.bits={.NBC_ANR_Y_L0_H_RNG1=2, .NBC_ANR_Y_L0_H_RNG2=4, .NBC_ANR_Y_L0_H_RNG3=6, .NBC_ANR_Y_L0_H_RNG4=8}},
    .pty1h     ={.bits={.NBC_ANR_Y_L1_H_RNG1=2, .NBC_ANR_Y_L1_H_RNG2=4, .NBC_ANR_Y_L1_H_RNG3=6, .NBC_ANR_Y_L1_H_RNG4=8}},
    .pty2h     ={.bits={.NBC_ANR_Y_L2_H_RNG1=2, .NBC_ANR_Y_L2_H_RNG2=4, .NBC_ANR_Y_L2_H_RNG3=6, .NBC_ANR_Y_L2_H_RNG4=8}},
    .t4lut1    ={.bits={.NBC_ANR_TBL_CPX1=64, .NBC_ANR_TBL_CPX2=128, .NBC_ANR_TBL_CPX3=192, .rsv_24=0}},
    .t4lut2    ={.bits={.NBC_ANR_TBL_GAIN_CPY0=1, .rsv_5=0, .NBC_ANR_TBL_GAIN_CPY1=8, .rsv_13=0, .NBC_ANR_TBL_GAIN_CPY2=16, .rsv_21=0, .NBC_ANR_TBL_GAIN_CPY3=24, .rsv_29=0}},
    .t4lut3    ={.bits={.NBC_ANR_TBL_GAIN_SP0=14, .rsv_5=0, .NBC_ANR_TBL_GAIN_SP1=15, .rsv_13=0, .NBC_ANR_TBL_GAIN_SP2=15, .rsv_21=0, .NBC_ANR_TBL_GAIN_SP3=15, .rsv_29=0}},
    .act1      ={.bits={.NBC_ANR_ACT_SL2_GAIN=8, .rsv_4=0, .NBC_ANR_ACT_DIF_HI_TH=16, .rsv_13=0, .NBC_ANR_ACT_DIF_GAIN=4, .NBC_ANR_ACT_DIF_LO_TH=16, .rsv_29=0}},
    .pty3h     ={.bits={.NBC_ANR_Y_L3_H_RNG1=1, .NBC_ANR_Y_L3_H_RNG2=2, .NBC_ANR_Y_L3_H_RNG3=3, .NBC_ANR_Y_L3_H_RNG4=4}},
    .ptcv      ={.bits={.NBC_ANR_C_V_RNG1=2, .NBC_ANR_C_V_RNG2=4, .NBC_ANR_C_V_RNG3=6, .NBC_ANR_C_V_RNG4=9}},
    .act4      ={.bits={.NBC_ANR_Y_ACT_CEN_OFT=32, .rsv_6=0, .NBC_ANR_Y_ACT_CEN_GAIN=0, .rsv_14=0, .NBC_ANR_Y_ACT_CEN_TH=32, .rsv_22=0}},
    .ptch      ={.bits={.NBC_ANR_C_H_RNG1=2, .NBC_ANR_C_H_RNG2=4, .NBC_ANR_C_H_RNG3=6, .NBC_ANR_C_H_RNG4=8}},
    .ylvl0     ={.bits={.NBC_ANR_Y_L0_RNG_RAT_TH=8, .NBC_ANR_Y_L1_RNG_RAT_TH=12, .NBC_ANR_Y_L2_RNG_RAT_TH=12, .NBC_ANR_Y_L3_RNG_RAT_TH=15, .NBC_ANR_Y_L0_RNG_RAT_SL=3, .rsv_18=0, .NBC_ANR_Y_L1_RNG_RAT_SL=3, .rsv_22=0, .NBC_ANR_Y_L2_RNG_RAT_SL=3, .rsv_26=0, .NBC_ANR_Y_L3_RNG_RAT_SL=3, .rsv_30=0}},
    .ylvl1     ={.bits={.NBC_ANR_Y_L0_HF_W=16, .rsv_5=0, .NBC_ANR_Y_L1_HF_W=8, .rsv_13=0, .NBC_ANR_Y_L2_HF_W=4, .rsv_21=0, .NBC_ANR_Y_L3_HF_W=4, .rsv_29=0}},
    .hf_cor    ={.bits={.NBC_ANR_Y_HF_CORE_TH=0, .NBC_ANR_Y_HF_CORE_SL=2, .rsv_10=0, .NBC_ANR_Y_HF_CLIP=255, .NBC_ANR_HF_BAL_MODE=1, .rsv_26=0}},
    .hf_act0   ={.bits={.NBC_ANR_Y_HF_ACT_X1=16, .NBC_ANR_Y_HF_ACT_X2=24, .NBC_ANR_Y_HF_ACT_X3=32, .NBC_ANR_Y_HF_ACT_X4=40}},
    .hf_act1   ={.bits={.NBC_ANR_Y_HF_ACT_Y0=24, .rsv_7=0, .NBC_ANR_Y_HF_ACT_Y1=24, .rsv_15=0, .NBC_ANR_Y_HF_ACT_Y2=56, .rsv_23=0, .NBC_ANR_Y_HF_ACT_Y3=56, .rsv_31=0}},
    .actc      ={.bits={.rsv_0=0, .NBC_ANR_ACT_BLD_BASE_C=48, .rsv_15=0, .NBC_ANR_C_DITH_U=8, .rsv_21=0, .NBC_ANR_C_DITH_V=8, .rsv_29=0}},
    .ylad      ={.bits={.NBC_ANR_CEN_GAIN_LO_TH_LPF=1, .rsv_5=0, .NBC_ANR_CEN_GAIN_HI_TH_LPF=6, .rsv_13=0}},
    .hf_act2   ={.bits={.NBC_ANR_Y_HF_ACT_Y4=40, .rsv_7=0, .NBC_ANR_Y_HF_ACT_SP4=0, .rsv_14=0}},
    .hf_act3   ={.bits={.NBC_ANR_Y_HF_ACT_SP0=0, .rsv_6=0, .NBC_ANR_Y_HF_ACT_SP1=31, .rsv_14=0, .NBC_ANR_Y_HF_ACT_SP2=0, .rsv_22=0, .NBC_ANR_Y_HF_ACT_SP3=48, .rsv_30=0}},
    .hf_luma0  ={.bits={.NBC_ANR_Y_HF_LUMA_X1=192, .NBC_ANR_Y_HF_LUMA_X2=224, .NBC_ANR_Y_HF_LUMA_Y0=0, .rsv_23=0, .NBC_ANR_Y_HF_LUMA_Y1=0, .rsv_31=0}},
    .hf_luma1  ={.bits={.NBC_ANR_Y_HF_LUMA_Y2=4, .rsv_7=0, .NBC_ANR_Y_HF_LUMA_SP0=0, .rsv_13=0, .NBC_ANR_Y_HF_LUMA_SP1=1, .rsv_21=0, .NBC_ANR_Y_HF_LUMA_SP2=0, .rsv_29=0}},
    .y4lut4    ={.bits={.NBC_ANR_Y_CPX5=255, .NBC_ANR_Y_CPX6=255, .NBC_ANR_Y_CPX7=255, .NBC_ANR_Y_CPX8=255}},
    .y4lut5    ={.bits={.NBC_ANR_Y_SCALE_CPY4=8, .rsv_5=0, .NBC_ANR_Y_SCALE_CPY5=8, .rsv_13=0, .NBC_ANR_Y_SCALE_CPY6=8, .rsv_21=0, .NBC_ANR_Y_SCALE_CPY7=8, .rsv_29=0}},
    .y4lut6    ={.bits={.NBC_ANR_Y_SCALE_SP4=0, .rsv_5=0, .NBC_ANR_Y_SCALE_SP5=0, .rsv_13=0, .NBC_ANR_Y_SCALE_SP6=1, .rsv_21=0, .NBC_ANR_Y_SCALE_SP7=2, .rsv_29=0}},
    .y4lut7    ={.bits={.NBC_ANR_Y_SCALE_CPY8=8, .rsv_5=0, .NBC_ANR_Y_SCALE_SP8=3, .rsv_13=0}},
    .a4lut1    ={.bits={.NBC_ANR_Y_ACT_CPX1=64, .NBC_ANR_Y_ACT_CPX2=128, .NBC_ANR_Y_ACT_CPX3=192, .rsv_24=0}}

};
const ISP_NVRAM_ANR2_T gc13a0mipiraw_NBC2_ANR2_0180 = {
        .con1      ={.bits={.NBC2_ANR2_ENC=1, .NBC2_ANR2_ENY=1, .rsv_2=0, .NBC2_ANR2_SCALE_MODE=0, .rsv_6=0, .NBC2_ANR2_VER_C_REF_Y=1, .rsv_9=0, .NBC2_ANR2_MODE=0, .rsv_13=0, .NBC2_ANR2_TILE_EDGE=0, .rsv_20=0, .NBC2_ANR2_SL2_LINK=1, .rsv_25=0}},
    .con2      ={.bits={.rsv_0=0, .NBC2_ANR2_C_SM_EDGE=1, .rsv_10=0, .NBC2_ANR2_FLT_C=0, .rsv_13=0}},
    .yad1      ={.bits={.rsv_0=0, .NBC2_ANR2_K_TH_C=8}},
    .y4lut1    ={.bits={.NBC2_ANR2_Y_CPX1=40, .NBC2_ANR2_Y_CPX2=120, .NBC2_ANR2_Y_CPX3=160, .rsv_24=0}},
    .y4lut2    ={.bits={.NBC2_ANR2_Y_SCALE_CPY0=16, .rsv_5=0, .NBC2_ANR2_Y_SCALE_CPY1=16, .rsv_13=0, .NBC2_ANR2_Y_SCALE_CPY2=16, .rsv_21=0, .NBC2_ANR2_Y_SCALE_CPY3=8, .rsv_29=0}},
    .y4lut3    ={.bits={.NBC2_ANR2_Y_SCALE_SP0=0, .rsv_5=0, .NBC2_ANR2_Y_SCALE_SP1=0, .rsv_13=0, .NBC2_ANR2_Y_SCALE_SP2=17, .rsv_21=0, .NBC2_ANR2_Y_SCALE_SP3=30, .rsv_29=0}},
    .l4lut1    ={.bits={.NBC2_ANR2_SL2_X1=64, .NBC2_ANR2_SL2_X2=128, .NBC2_ANR2_SL2_X3=192, .rsv_24=0}},
    .l4lut2    ={.bits={.NBC2_ANR2_SL2_GAIN0=16, .rsv_6=0, .NBC2_ANR2_SL2_GAIN1=20, .rsv_14=0, .NBC2_ANR2_SL2_GAIN2=24, .rsv_22=0, .NBC2_ANR2_SL2_GAIN3=32, .rsv_30=0}},
    .l4lut3    ={.bits={.NBC2_ANR2_SL2_SP0=8, .rsv_6=0, .NBC2_ANR2_SL2_SP1=8, .rsv_14=0, .NBC2_ANR2_SL2_SP2=16, .rsv_22=0, .NBC2_ANR2_SL2_SP3=16, .rsv_30=0}},
    .cad       ={.bits={.NBC2_ANR2_PTC_VGAIN=10, .NBC2_ANR2_C_GAIN=0, .NBC2_ANR2_PTC_GAIN_TH=0, .rsv_13=0, .NBC2_ANR2_C_L_DIFF_TH=24, .NBC2_ANR2_C_MODE=0, .rsv_25=0}},
    .ptc       ={.bits={.NBC2_ANR2_PTC1=2, .NBC2_ANR2_PTC2=4, .NBC2_ANR2_PTC3=6, .NBC2_ANR2_PTC4=8}},
    .sl2       ={.bits={.NBC2_ANR2_SL2_C_GAIN=6, .rsv_4=0, .NBC2_ANR2_LM_WT=4, .rsv_20=0}},
    .med1      ={.bits={.NBC2_ANR2_COR_TH=5, .rsv_5=0, .NBC2_ANR2_COR_SL=4, .rsv_11=0, .NBC2_ANR2_MCD_TH=5, .rsv_17=0, .NBC2_ANR2_MCD_SL=3, .rsv_23=0, .NBC2_ANR2_LCL_TH=32}},
    .med2      ={.bits={.NBC2_ANR2_LCL_SL=3, .rsv_3=0, .NBC2_ANR2_LCL_LV=8, .rsv_9=0, .NBC2_ANR2_SCL_TH=12, .rsv_18=0, .NBC2_ANR2_SCL_SL=3, .rsv_23=0, .NBC2_ANR2_SCL_LV=16, .rsv_29=0}},
    .med3      ={.bits={.NBC2_ANR2_NCL_TH=48, .NBC2_ANR2_NCL_SL=3, .rsv_11=0, .NBC2_ANR2_NCL_LV=8, .rsv_17=0, .NBC2_ANR2_VAR=3, .rsv_23=0, .NBC2_ANR2_Y0=10, .rsv_30=0}},
    .med4      ={.bits={.NBC2_ANR2_Y1=13, .rsv_6=0, .NBC2_ANR2_Y2=16, .rsv_14=0, .NBC2_ANR2_Y3=19, .rsv_22=0, .NBC2_ANR2_Y4=22, .rsv_30=0}},
    .med5      ={.bits={.NBC2_ANR2_LCL_OFT=0, .NBC2_ANR2_SCL_OFT=0, .rsv_14=0, .NBC2_ANR2_NCL_OFT=0, .rsv_24=0}},
    .actc      ={.bits={.rsv_0=0, .NBC2_ANR2_ACT_BLD_BASE_C=48, .rsv_15=0, .NBC2_ANR2_C_DITH_U=8, .rsv_21=0, .NBC2_ANR2_C_DITH_V=8, .rsv_29=0}}

};
const ISP_NVRAM_ANR2_T gc13a0mipiraw_NBC2_ANR2_0181 = {
        .con1      ={.bits={.NBC2_ANR2_ENC=1, .NBC2_ANR2_ENY=1, .rsv_2=0, .NBC2_ANR2_SCALE_MODE=0, .rsv_6=0, .NBC2_ANR2_VER_C_REF_Y=1, .rsv_9=0, .NBC2_ANR2_MODE=0, .rsv_13=0, .NBC2_ANR2_TILE_EDGE=0, .rsv_20=0, .NBC2_ANR2_SL2_LINK=1, .rsv_25=0}},
    .con2      ={.bits={.rsv_0=0, .NBC2_ANR2_C_SM_EDGE=1, .rsv_10=0, .NBC2_ANR2_FLT_C=0, .rsv_13=0}},
    .yad1      ={.bits={.rsv_0=0, .NBC2_ANR2_K_TH_C=8}},
    .y4lut1    ={.bits={.NBC2_ANR2_Y_CPX1=40, .NBC2_ANR2_Y_CPX2=120, .NBC2_ANR2_Y_CPX3=160, .rsv_24=0}},
    .y4lut2    ={.bits={.NBC2_ANR2_Y_SCALE_CPY0=16, .rsv_5=0, .NBC2_ANR2_Y_SCALE_CPY1=16, .rsv_13=0, .NBC2_ANR2_Y_SCALE_CPY2=16, .rsv_21=0, .NBC2_ANR2_Y_SCALE_CPY3=8, .rsv_29=0}},
    .y4lut3    ={.bits={.NBC2_ANR2_Y_SCALE_SP0=0, .rsv_5=0, .NBC2_ANR2_Y_SCALE_SP1=0, .rsv_13=0, .NBC2_ANR2_Y_SCALE_SP2=17, .rsv_21=0, .NBC2_ANR2_Y_SCALE_SP3=30, .rsv_29=0}},
    .l4lut1    ={.bits={.NBC2_ANR2_SL2_X1=64, .NBC2_ANR2_SL2_X2=128, .NBC2_ANR2_SL2_X3=192, .rsv_24=0}},
    .l4lut2    ={.bits={.NBC2_ANR2_SL2_GAIN0=16, .rsv_6=0, .NBC2_ANR2_SL2_GAIN1=20, .rsv_14=0, .NBC2_ANR2_SL2_GAIN2=24, .rsv_22=0, .NBC2_ANR2_SL2_GAIN3=32, .rsv_30=0}},
    .l4lut3    ={.bits={.NBC2_ANR2_SL2_SP0=8, .rsv_6=0, .NBC2_ANR2_SL2_SP1=8, .rsv_14=0, .NBC2_ANR2_SL2_SP2=16, .rsv_22=0, .NBC2_ANR2_SL2_SP3=16, .rsv_30=0}},
    .cad       ={.bits={.NBC2_ANR2_PTC_VGAIN=10, .NBC2_ANR2_C_GAIN=0, .NBC2_ANR2_PTC_GAIN_TH=0, .rsv_13=0, .NBC2_ANR2_C_L_DIFF_TH=24, .NBC2_ANR2_C_MODE=0, .rsv_25=0}},
    .ptc       ={.bits={.NBC2_ANR2_PTC1=2, .NBC2_ANR2_PTC2=4, .NBC2_ANR2_PTC3=6, .NBC2_ANR2_PTC4=8}},
    .sl2       ={.bits={.NBC2_ANR2_SL2_C_GAIN=6, .rsv_4=0, .NBC2_ANR2_LM_WT=4, .rsv_20=0}},
    .med1      ={.bits={.NBC2_ANR2_COR_TH=5, .rsv_5=0, .NBC2_ANR2_COR_SL=4, .rsv_11=0, .NBC2_ANR2_MCD_TH=5, .rsv_17=0, .NBC2_ANR2_MCD_SL=3, .rsv_23=0, .NBC2_ANR2_LCL_TH=32}},
    .med2      ={.bits={.NBC2_ANR2_LCL_SL=3, .rsv_3=0, .NBC2_ANR2_LCL_LV=8, .rsv_9=0, .NBC2_ANR2_SCL_TH=12, .rsv_18=0, .NBC2_ANR2_SCL_SL=3, .rsv_23=0, .NBC2_ANR2_SCL_LV=16, .rsv_29=0}},
    .med3      ={.bits={.NBC2_ANR2_NCL_TH=48, .NBC2_ANR2_NCL_SL=3, .rsv_11=0, .NBC2_ANR2_NCL_LV=8, .rsv_17=0, .NBC2_ANR2_VAR=3, .rsv_23=0, .NBC2_ANR2_Y0=10, .rsv_30=0}},
    .med4      ={.bits={.NBC2_ANR2_Y1=13, .rsv_6=0, .NBC2_ANR2_Y2=16, .rsv_14=0, .NBC2_ANR2_Y3=19, .rsv_22=0, .NBC2_ANR2_Y4=22, .rsv_30=0}},
    .med5      ={.bits={.NBC2_ANR2_LCL_OFT=0, .NBC2_ANR2_SCL_OFT=0, .rsv_14=0, .NBC2_ANR2_NCL_OFT=0, .rsv_24=0}},
    .actc      ={.bits={.rsv_0=0, .NBC2_ANR2_ACT_BLD_BASE_C=48, .rsv_15=0, .NBC2_ANR2_C_DITH_U=8, .rsv_21=0, .NBC2_ANR2_C_DITH_V=8, .rsv_29=0}}

};
const ISP_NVRAM_ANR2_T gc13a0mipiraw_NBC2_ANR2_0182 = {
        .con1      ={.bits={.NBC2_ANR2_ENC=1, .NBC2_ANR2_ENY=1, .rsv_2=0, .NBC2_ANR2_SCALE_MODE=0, .rsv_6=0, .NBC2_ANR2_VER_C_REF_Y=1, .rsv_9=0, .NBC2_ANR2_MODE=0, .rsv_13=0, .NBC2_ANR2_TILE_EDGE=15, .rsv_20=0, .NBC2_ANR2_SL2_LINK=1, .rsv_25=0}},
    .con2      ={.bits={.rsv_0=0, .NBC2_ANR2_C_SM_EDGE=1, .rsv_10=0, .NBC2_ANR2_FLT_C=0, .rsv_13=0}},
    .yad1      ={.bits={.rsv_0=0, .NBC2_ANR2_K_TH_C=8}},
    .y4lut1    ={.bits={.NBC2_ANR2_Y_CPX1=40, .NBC2_ANR2_Y_CPX2=120, .NBC2_ANR2_Y_CPX3=160, .rsv_24=0}},
    .y4lut2    ={.bits={.NBC2_ANR2_Y_SCALE_CPY0=16, .rsv_5=0, .NBC2_ANR2_Y_SCALE_CPY1=16, .rsv_13=0, .NBC2_ANR2_Y_SCALE_CPY2=16, .rsv_21=0, .NBC2_ANR2_Y_SCALE_CPY3=8, .rsv_29=0}},
    .y4lut3    ={.bits={.NBC2_ANR2_Y_SCALE_SP0=0, .rsv_5=0, .NBC2_ANR2_Y_SCALE_SP1=0, .rsv_13=0, .NBC2_ANR2_Y_SCALE_SP2=28, .rsv_21=0, .NBC2_ANR2_Y_SCALE_SP3=30, .rsv_29=0}},
    .l4lut1    ={.bits={.NBC2_ANR2_SL2_X1=64, .NBC2_ANR2_SL2_X2=128, .NBC2_ANR2_SL2_X3=192, .rsv_24=0}},
    .l4lut2    ={.bits={.NBC2_ANR2_SL2_GAIN0=16, .rsv_6=0, .NBC2_ANR2_SL2_GAIN1=20, .rsv_14=0, .NBC2_ANR2_SL2_GAIN2=24, .rsv_22=0, .NBC2_ANR2_SL2_GAIN3=32, .rsv_30=0}},
    .l4lut3    ={.bits={.NBC2_ANR2_SL2_SP0=8, .rsv_6=0, .NBC2_ANR2_SL2_SP1=8, .rsv_14=0, .NBC2_ANR2_SL2_SP2=16, .rsv_22=0, .NBC2_ANR2_SL2_SP3=16, .rsv_30=0}},
    .cad       ={.bits={.NBC2_ANR2_PTC_VGAIN=10, .NBC2_ANR2_C_GAIN=8, .NBC2_ANR2_PTC_GAIN_TH=0, .rsv_13=0, .NBC2_ANR2_C_L_DIFF_TH=30, .NBC2_ANR2_C_MODE=0, .rsv_25=0}},
    .ptc       ={.bits={.NBC2_ANR2_PTC1=5, .NBC2_ANR2_PTC2=10, .NBC2_ANR2_PTC3=15, .NBC2_ANR2_PTC4=20}},
    .sl2       ={.bits={.NBC2_ANR2_SL2_C_GAIN=6, .rsv_4=0, .NBC2_ANR2_LM_WT=4, .rsv_20=0}},
    .med1      ={.bits={.NBC2_ANR2_COR_TH=5, .rsv_5=0, .NBC2_ANR2_COR_SL=4, .rsv_11=0, .NBC2_ANR2_MCD_TH=5, .rsv_17=0, .NBC2_ANR2_MCD_SL=3, .rsv_23=0, .NBC2_ANR2_LCL_TH=32}},
    .med2      ={.bits={.NBC2_ANR2_LCL_SL=3, .rsv_3=0, .NBC2_ANR2_LCL_LV=16, .rsv_9=0, .NBC2_ANR2_SCL_TH=12, .rsv_18=0, .NBC2_ANR2_SCL_SL=3, .rsv_23=0, .NBC2_ANR2_SCL_LV=16, .rsv_29=0}},
    .med3      ={.bits={.NBC2_ANR2_NCL_TH=48, .NBC2_ANR2_NCL_SL=3, .rsv_11=0, .NBC2_ANR2_NCL_LV=16, .rsv_17=0, .NBC2_ANR2_VAR=3, .rsv_23=0, .NBC2_ANR2_Y0=10, .rsv_30=0}},
    .med4      ={.bits={.NBC2_ANR2_Y1=13, .rsv_6=0, .NBC2_ANR2_Y2=16, .rsv_14=0, .NBC2_ANR2_Y3=19, .rsv_22=0, .NBC2_ANR2_Y4=22, .rsv_30=0}},
    .med5      ={.bits={.NBC2_ANR2_LCL_OFT=0, .NBC2_ANR2_SCL_OFT=0, .rsv_14=0, .NBC2_ANR2_NCL_OFT=0, .rsv_24=0}},
    .actc      ={.bits={.rsv_0=0, .NBC2_ANR2_ACT_BLD_BASE_C=64, .rsv_15=0, .NBC2_ANR2_C_DITH_U=8, .rsv_21=0, .NBC2_ANR2_C_DITH_V=8, .rsv_29=0}}

};
const ISP_NVRAM_ANR2_T gc13a0mipiraw_NBC2_ANR2_0183 = {
        .con1      ={.bits={.NBC2_ANR2_ENC=1, .NBC2_ANR2_ENY=1, .rsv_2=0, .NBC2_ANR2_SCALE_MODE=0, .rsv_6=0, .NBC2_ANR2_VER_C_REF_Y=1, .rsv_9=0, .NBC2_ANR2_MODE=0, .rsv_13=0, .NBC2_ANR2_TILE_EDGE=15, .rsv_20=0, .NBC2_ANR2_SL2_LINK=1, .rsv_25=0}},
    .con2      ={.bits={.rsv_0=0, .NBC2_ANR2_C_SM_EDGE=1, .rsv_10=0, .NBC2_ANR2_FLT_C=0, .rsv_13=0}},
    .yad1      ={.bits={.rsv_0=0, .NBC2_ANR2_K_TH_C=8}},
    .y4lut1    ={.bits={.NBC2_ANR2_Y_CPX1=40, .NBC2_ANR2_Y_CPX2=120, .NBC2_ANR2_Y_CPX3=160, .rsv_24=0}},
    .y4lut2    ={.bits={.NBC2_ANR2_Y_SCALE_CPY0=16, .rsv_5=0, .NBC2_ANR2_Y_SCALE_CPY1=16, .rsv_13=0, .NBC2_ANR2_Y_SCALE_CPY2=16, .rsv_21=0, .NBC2_ANR2_Y_SCALE_CPY3=8, .rsv_29=0}},
    .y4lut3    ={.bits={.NBC2_ANR2_Y_SCALE_SP0=0, .rsv_5=0, .NBC2_ANR2_Y_SCALE_SP1=0, .rsv_13=0, .NBC2_ANR2_Y_SCALE_SP2=28, .rsv_21=0, .NBC2_ANR2_Y_SCALE_SP3=30, .rsv_29=0}},
    .l4lut1    ={.bits={.NBC2_ANR2_SL2_X1=64, .NBC2_ANR2_SL2_X2=128, .NBC2_ANR2_SL2_X3=192, .rsv_24=0}},
    .l4lut2    ={.bits={.NBC2_ANR2_SL2_GAIN0=16, .rsv_6=0, .NBC2_ANR2_SL2_GAIN1=20, .rsv_14=0, .NBC2_ANR2_SL2_GAIN2=24, .rsv_22=0, .NBC2_ANR2_SL2_GAIN3=32, .rsv_30=0}},
    .l4lut3    ={.bits={.NBC2_ANR2_SL2_SP0=8, .rsv_6=0, .NBC2_ANR2_SL2_SP1=8, .rsv_14=0, .NBC2_ANR2_SL2_SP2=16, .rsv_22=0, .NBC2_ANR2_SL2_SP3=16, .rsv_30=0}},
    .cad       ={.bits={.NBC2_ANR2_PTC_VGAIN=10, .NBC2_ANR2_C_GAIN=8, .NBC2_ANR2_PTC_GAIN_TH=0, .rsv_13=0, .NBC2_ANR2_C_L_DIFF_TH=40, .NBC2_ANR2_C_MODE=0, .rsv_25=0}},
    .ptc       ={.bits={.NBC2_ANR2_PTC1=5, .NBC2_ANR2_PTC2=10, .NBC2_ANR2_PTC3=15, .NBC2_ANR2_PTC4=20}},
    .sl2       ={.bits={.NBC2_ANR2_SL2_C_GAIN=6, .rsv_4=0, .NBC2_ANR2_LM_WT=4, .rsv_20=0}},
    .med1      ={.bits={.NBC2_ANR2_COR_TH=5, .rsv_5=0, .NBC2_ANR2_COR_SL=4, .rsv_11=0, .NBC2_ANR2_MCD_TH=5, .rsv_17=0, .NBC2_ANR2_MCD_SL=3, .rsv_23=0, .NBC2_ANR2_LCL_TH=32}},
    .med2      ={.bits={.NBC2_ANR2_LCL_SL=3, .rsv_3=0, .NBC2_ANR2_LCL_LV=8, .rsv_9=0, .NBC2_ANR2_SCL_TH=12, .rsv_18=0, .NBC2_ANR2_SCL_SL=3, .rsv_23=0, .NBC2_ANR2_SCL_LV=16, .rsv_29=0}},
    .med3      ={.bits={.NBC2_ANR2_NCL_TH=48, .NBC2_ANR2_NCL_SL=3, .rsv_11=0, .NBC2_ANR2_NCL_LV=8, .rsv_17=0, .NBC2_ANR2_VAR=3, .rsv_23=0, .NBC2_ANR2_Y0=10, .rsv_30=0}},
    .med4      ={.bits={.NBC2_ANR2_Y1=13, .rsv_6=0, .NBC2_ANR2_Y2=16, .rsv_14=0, .NBC2_ANR2_Y3=19, .rsv_22=0, .NBC2_ANR2_Y4=22, .rsv_30=0}},
    .med5      ={.bits={.NBC2_ANR2_LCL_OFT=0, .NBC2_ANR2_SCL_OFT=0, .rsv_14=0, .NBC2_ANR2_NCL_OFT=0, .rsv_24=0}},
    .actc      ={.bits={.rsv_0=0, .NBC2_ANR2_ACT_BLD_BASE_C=64, .rsv_15=0, .NBC2_ANR2_C_DITH_U=8, .rsv_21=0, .NBC2_ANR2_C_DITH_V=8, .rsv_29=0}}

};
const ISP_NVRAM_ANR2_T gc13a0mipiraw_NBC2_ANR2_0184 = {
        .con1      ={.bits={.NBC2_ANR2_ENC=1, .NBC2_ANR2_ENY=1, .rsv_2=0, .NBC2_ANR2_SCALE_MODE=0, .rsv_6=0, .NBC2_ANR2_VER_C_REF_Y=1, .rsv_9=0, .NBC2_ANR2_MODE=0, .rsv_13=0, .NBC2_ANR2_TILE_EDGE=15, .rsv_20=0, .NBC2_ANR2_SL2_LINK=1, .rsv_25=0}},
    .con2      ={.bits={.rsv_0=0, .NBC2_ANR2_C_SM_EDGE=1, .rsv_10=0, .NBC2_ANR2_FLT_C=0, .rsv_13=0}},
    .yad1      ={.bits={.rsv_0=0, .NBC2_ANR2_K_TH_C=8}},
    .y4lut1    ={.bits={.NBC2_ANR2_Y_CPX1=40, .NBC2_ANR2_Y_CPX2=120, .NBC2_ANR2_Y_CPX3=160, .rsv_24=0}},
    .y4lut2    ={.bits={.NBC2_ANR2_Y_SCALE_CPY0=16, .rsv_5=0, .NBC2_ANR2_Y_SCALE_CPY1=16, .rsv_13=0, .NBC2_ANR2_Y_SCALE_CPY2=16, .rsv_21=0, .NBC2_ANR2_Y_SCALE_CPY3=8, .rsv_29=0}},
    .y4lut3    ={.bits={.NBC2_ANR2_Y_SCALE_SP0=0, .rsv_5=0, .NBC2_ANR2_Y_SCALE_SP1=0, .rsv_13=0, .NBC2_ANR2_Y_SCALE_SP2=28, .rsv_21=0, .NBC2_ANR2_Y_SCALE_SP3=30, .rsv_29=0}},
    .l4lut1    ={.bits={.NBC2_ANR2_SL2_X1=64, .NBC2_ANR2_SL2_X2=128, .NBC2_ANR2_SL2_X3=192, .rsv_24=0}},
    .l4lut2    ={.bits={.NBC2_ANR2_SL2_GAIN0=16, .rsv_6=0, .NBC2_ANR2_SL2_GAIN1=20, .rsv_14=0, .NBC2_ANR2_SL2_GAIN2=24, .rsv_22=0, .NBC2_ANR2_SL2_GAIN3=32, .rsv_30=0}},
    .l4lut3    ={.bits={.NBC2_ANR2_SL2_SP0=8, .rsv_6=0, .NBC2_ANR2_SL2_SP1=8, .rsv_14=0, .NBC2_ANR2_SL2_SP2=16, .rsv_22=0, .NBC2_ANR2_SL2_SP3=16, .rsv_30=0}},
    .cad       ={.bits={.NBC2_ANR2_PTC_VGAIN=10, .NBC2_ANR2_C_GAIN=8, .NBC2_ANR2_PTC_GAIN_TH=0, .rsv_13=0, .NBC2_ANR2_C_L_DIFF_TH=42, .NBC2_ANR2_C_MODE=0, .rsv_25=0}},
    .ptc       ={.bits={.NBC2_ANR2_PTC1=5, .NBC2_ANR2_PTC2=10, .NBC2_ANR2_PTC3=15, .NBC2_ANR2_PTC4=20}},
    .sl2       ={.bits={.NBC2_ANR2_SL2_C_GAIN=6, .rsv_4=0, .NBC2_ANR2_LM_WT=4, .rsv_20=0}},
    .med1      ={.bits={.NBC2_ANR2_COR_TH=5, .rsv_5=0, .NBC2_ANR2_COR_SL=4, .rsv_11=0, .NBC2_ANR2_MCD_TH=5, .rsv_17=0, .NBC2_ANR2_MCD_SL=3, .rsv_23=0, .NBC2_ANR2_LCL_TH=32}},
    .med2      ={.bits={.NBC2_ANR2_LCL_SL=3, .rsv_3=0, .NBC2_ANR2_LCL_LV=16, .rsv_9=0, .NBC2_ANR2_SCL_TH=12, .rsv_18=0, .NBC2_ANR2_SCL_SL=3, .rsv_23=0, .NBC2_ANR2_SCL_LV=16, .rsv_29=0}},
    .med3      ={.bits={.NBC2_ANR2_NCL_TH=48, .NBC2_ANR2_NCL_SL=3, .rsv_11=0, .NBC2_ANR2_NCL_LV=16, .rsv_17=0, .NBC2_ANR2_VAR=3, .rsv_23=0, .NBC2_ANR2_Y0=10, .rsv_30=0}},
    .med4      ={.bits={.NBC2_ANR2_Y1=13, .rsv_6=0, .NBC2_ANR2_Y2=16, .rsv_14=0, .NBC2_ANR2_Y3=19, .rsv_22=0, .NBC2_ANR2_Y4=22, .rsv_30=0}},
    .med5      ={.bits={.NBC2_ANR2_LCL_OFT=0, .NBC2_ANR2_SCL_OFT=0, .rsv_14=0, .NBC2_ANR2_NCL_OFT=0, .rsv_24=0}},
    .actc      ={.bits={.rsv_0=0, .NBC2_ANR2_ACT_BLD_BASE_C=64, .rsv_15=0, .NBC2_ANR2_C_DITH_U=8, .rsv_21=0, .NBC2_ANR2_C_DITH_V=8, .rsv_29=0}}

};
const ISP_NVRAM_ANR2_T gc13a0mipiraw_NBC2_ANR2_0185 = {
        .con1      ={.bits={.NBC2_ANR2_ENC=1, .NBC2_ANR2_ENY=1, .rsv_2=0, .NBC2_ANR2_SCALE_MODE=0, .rsv_6=0, .NBC2_ANR2_VER_C_REF_Y=1, .rsv_9=0, .NBC2_ANR2_MODE=0, .rsv_13=0, .NBC2_ANR2_TILE_EDGE=15, .rsv_20=0, .NBC2_ANR2_SL2_LINK=1, .rsv_25=0}},
    .con2      ={.bits={.rsv_0=0, .NBC2_ANR2_C_SM_EDGE=1, .rsv_10=0, .NBC2_ANR2_FLT_C=0, .rsv_13=0}},
    .yad1      ={.bits={.rsv_0=0, .NBC2_ANR2_K_TH_C=8}},
    .y4lut1    ={.bits={.NBC2_ANR2_Y_CPX1=40, .NBC2_ANR2_Y_CPX2=120, .NBC2_ANR2_Y_CPX3=160, .rsv_24=0}},
    .y4lut2    ={.bits={.NBC2_ANR2_Y_SCALE_CPY0=16, .rsv_5=0, .NBC2_ANR2_Y_SCALE_CPY1=16, .rsv_13=0, .NBC2_ANR2_Y_SCALE_CPY2=16, .rsv_21=0, .NBC2_ANR2_Y_SCALE_CPY3=8, .rsv_29=0}},
    .y4lut3    ={.bits={.NBC2_ANR2_Y_SCALE_SP0=0, .rsv_5=0, .NBC2_ANR2_Y_SCALE_SP1=0, .rsv_13=0, .NBC2_ANR2_Y_SCALE_SP2=28, .rsv_21=0, .NBC2_ANR2_Y_SCALE_SP3=30, .rsv_29=0}},
    .l4lut1    ={.bits={.NBC2_ANR2_SL2_X1=64, .NBC2_ANR2_SL2_X2=128, .NBC2_ANR2_SL2_X3=192, .rsv_24=0}},
    .l4lut2    ={.bits={.NBC2_ANR2_SL2_GAIN0=16, .rsv_6=0, .NBC2_ANR2_SL2_GAIN1=20, .rsv_14=0, .NBC2_ANR2_SL2_GAIN2=24, .rsv_22=0, .NBC2_ANR2_SL2_GAIN3=32, .rsv_30=0}},
    .l4lut3    ={.bits={.NBC2_ANR2_SL2_SP0=8, .rsv_6=0, .NBC2_ANR2_SL2_SP1=8, .rsv_14=0, .NBC2_ANR2_SL2_SP2=16, .rsv_22=0, .NBC2_ANR2_SL2_SP3=16, .rsv_30=0}},
    .cad       ={.bits={.NBC2_ANR2_PTC_VGAIN=10, .NBC2_ANR2_C_GAIN=8, .NBC2_ANR2_PTC_GAIN_TH=0, .rsv_13=0, .NBC2_ANR2_C_L_DIFF_TH=24, .NBC2_ANR2_C_MODE=0, .rsv_25=0}},
    .ptc       ={.bits={.NBC2_ANR2_PTC1=2, .NBC2_ANR2_PTC2=3, .NBC2_ANR2_PTC3=4, .NBC2_ANR2_PTC4=6}},
    .sl2       ={.bits={.NBC2_ANR2_SL2_C_GAIN=6, .rsv_4=0, .NBC2_ANR2_LM_WT=4, .rsv_20=0}},
    .med1      ={.bits={.NBC2_ANR2_COR_TH=5, .rsv_5=0, .NBC2_ANR2_COR_SL=4, .rsv_11=0, .NBC2_ANR2_MCD_TH=5, .rsv_17=0, .NBC2_ANR2_MCD_SL=3, .rsv_23=0, .NBC2_ANR2_LCL_TH=32}},
    .med2      ={.bits={.NBC2_ANR2_LCL_SL=3, .rsv_3=0, .NBC2_ANR2_LCL_LV=16, .rsv_9=0, .NBC2_ANR2_SCL_TH=12, .rsv_18=0, .NBC2_ANR2_SCL_SL=3, .rsv_23=0, .NBC2_ANR2_SCL_LV=16, .rsv_29=0}},
    .med3      ={.bits={.NBC2_ANR2_NCL_TH=48, .NBC2_ANR2_NCL_SL=3, .rsv_11=0, .NBC2_ANR2_NCL_LV=16, .rsv_17=0, .NBC2_ANR2_VAR=3, .rsv_23=0, .NBC2_ANR2_Y0=10, .rsv_30=0}},
    .med4      ={.bits={.NBC2_ANR2_Y1=13, .rsv_6=0, .NBC2_ANR2_Y2=16, .rsv_14=0, .NBC2_ANR2_Y3=19, .rsv_22=0, .NBC2_ANR2_Y4=22, .rsv_30=0}},
    .med5      ={.bits={.NBC2_ANR2_LCL_OFT=0, .NBC2_ANR2_SCL_OFT=0, .rsv_14=0, .NBC2_ANR2_NCL_OFT=0, .rsv_24=0}},
    .actc      ={.bits={.rsv_0=0, .NBC2_ANR2_ACT_BLD_BASE_C=48, .rsv_15=0, .NBC2_ANR2_C_DITH_U=8, .rsv_21=0, .NBC2_ANR2_C_DITH_V=8, .rsv_29=0}}

};
const ISP_NVRAM_ANR2_T gc13a0mipiraw_NBC2_ANR2_0186 = {
        .con1      ={.bits={.NBC2_ANR2_ENC=1, .NBC2_ANR2_ENY=1, .rsv_2=0, .NBC2_ANR2_SCALE_MODE=0, .rsv_6=0, .NBC2_ANR2_VER_C_REF_Y=1, .rsv_9=0, .NBC2_ANR2_MODE=0, .rsv_13=0, .NBC2_ANR2_TILE_EDGE=15, .rsv_20=0, .NBC2_ANR2_SL2_LINK=1, .rsv_25=0}},
    .con2      ={.bits={.rsv_0=0, .NBC2_ANR2_C_SM_EDGE=1, .rsv_10=0, .NBC2_ANR2_FLT_C=0, .rsv_13=0}},
    .yad1      ={.bits={.rsv_0=0, .NBC2_ANR2_K_TH_C=8}},
    .y4lut1    ={.bits={.NBC2_ANR2_Y_CPX1=40, .NBC2_ANR2_Y_CPX2=120, .NBC2_ANR2_Y_CPX3=160, .rsv_24=0}},
    .y4lut2    ={.bits={.NBC2_ANR2_Y_SCALE_CPY0=16, .rsv_5=0, .NBC2_ANR2_Y_SCALE_CPY1=16, .rsv_13=0, .NBC2_ANR2_Y_SCALE_CPY2=16, .rsv_21=0, .NBC2_ANR2_Y_SCALE_CPY3=8, .rsv_29=0}},
    .y4lut3    ={.bits={.NBC2_ANR2_Y_SCALE_SP0=0, .rsv_5=0, .NBC2_ANR2_Y_SCALE_SP1=0, .rsv_13=0, .NBC2_ANR2_Y_SCALE_SP2=28, .rsv_21=0, .NBC2_ANR2_Y_SCALE_SP3=30, .rsv_29=0}},
    .l4lut1    ={.bits={.NBC2_ANR2_SL2_X1=64, .NBC2_ANR2_SL2_X2=128, .NBC2_ANR2_SL2_X3=192, .rsv_24=0}},
    .l4lut2    ={.bits={.NBC2_ANR2_SL2_GAIN0=16, .rsv_6=0, .NBC2_ANR2_SL2_GAIN1=20, .rsv_14=0, .NBC2_ANR2_SL2_GAIN2=24, .rsv_22=0, .NBC2_ANR2_SL2_GAIN3=32, .rsv_30=0}},
    .l4lut3    ={.bits={.NBC2_ANR2_SL2_SP0=8, .rsv_6=0, .NBC2_ANR2_SL2_SP1=8, .rsv_14=0, .NBC2_ANR2_SL2_SP2=16, .rsv_22=0, .NBC2_ANR2_SL2_SP3=16, .rsv_30=0}},
    .cad       ={.bits={.NBC2_ANR2_PTC_VGAIN=10, .NBC2_ANR2_C_GAIN=8, .NBC2_ANR2_PTC_GAIN_TH=0, .rsv_13=0, .NBC2_ANR2_C_L_DIFF_TH=24, .NBC2_ANR2_C_MODE=0, .rsv_25=0}},
    .ptc       ={.bits={.NBC2_ANR2_PTC1=2, .NBC2_ANR2_PTC2=3, .NBC2_ANR2_PTC3=4, .NBC2_ANR2_PTC4=6}},
    .sl2       ={.bits={.NBC2_ANR2_SL2_C_GAIN=6, .rsv_4=0, .NBC2_ANR2_LM_WT=4, .rsv_20=0}},
    .med1      ={.bits={.NBC2_ANR2_COR_TH=5, .rsv_5=0, .NBC2_ANR2_COR_SL=4, .rsv_11=0, .NBC2_ANR2_MCD_TH=5, .rsv_17=0, .NBC2_ANR2_MCD_SL=3, .rsv_23=0, .NBC2_ANR2_LCL_TH=32}},
    .med2      ={.bits={.NBC2_ANR2_LCL_SL=3, .rsv_3=0, .NBC2_ANR2_LCL_LV=16, .rsv_9=0, .NBC2_ANR2_SCL_TH=12, .rsv_18=0, .NBC2_ANR2_SCL_SL=3, .rsv_23=0, .NBC2_ANR2_SCL_LV=16, .rsv_29=0}},
    .med3      ={.bits={.NBC2_ANR2_NCL_TH=48, .NBC2_ANR2_NCL_SL=3, .rsv_11=0, .NBC2_ANR2_NCL_LV=16, .rsv_17=0, .NBC2_ANR2_VAR=3, .rsv_23=0, .NBC2_ANR2_Y0=10, .rsv_30=0}},
    .med4      ={.bits={.NBC2_ANR2_Y1=13, .rsv_6=0, .NBC2_ANR2_Y2=16, .rsv_14=0, .NBC2_ANR2_Y3=19, .rsv_22=0, .NBC2_ANR2_Y4=22, .rsv_30=0}},
    .med5      ={.bits={.NBC2_ANR2_LCL_OFT=0, .NBC2_ANR2_SCL_OFT=0, .rsv_14=0, .NBC2_ANR2_NCL_OFT=0, .rsv_24=0}},
    .actc      ={.bits={.rsv_0=0, .NBC2_ANR2_ACT_BLD_BASE_C=48, .rsv_15=0, .NBC2_ANR2_C_DITH_U=8, .rsv_21=0, .NBC2_ANR2_C_DITH_V=8, .rsv_29=0}}

};
const ISP_NVRAM_ANR2_T gc13a0mipiraw_NBC2_ANR2_0187 = {
        .con1      ={.bits={.NBC2_ANR2_ENC=1, .NBC2_ANR2_ENY=1, .rsv_2=0, .NBC2_ANR2_SCALE_MODE=0, .rsv_6=0, .NBC2_ANR2_VER_C_REF_Y=1, .rsv_9=0, .NBC2_ANR2_MODE=0, .rsv_13=0, .NBC2_ANR2_TILE_EDGE=15, .rsv_20=0, .NBC2_ANR2_SL2_LINK=1, .rsv_25=0}},
    .con2      ={.bits={.rsv_0=0, .NBC2_ANR2_C_SM_EDGE=1, .rsv_10=0, .NBC2_ANR2_FLT_C=0, .rsv_13=0}},
    .yad1      ={.bits={.rsv_0=0, .NBC2_ANR2_K_TH_C=8}},
    .y4lut1    ={.bits={.NBC2_ANR2_Y_CPX1=40, .NBC2_ANR2_Y_CPX2=120, .NBC2_ANR2_Y_CPX3=160, .rsv_24=0}},
    .y4lut2    ={.bits={.NBC2_ANR2_Y_SCALE_CPY0=16, .rsv_5=0, .NBC2_ANR2_Y_SCALE_CPY1=16, .rsv_13=0, .NBC2_ANR2_Y_SCALE_CPY2=16, .rsv_21=0, .NBC2_ANR2_Y_SCALE_CPY3=8, .rsv_29=0}},
    .y4lut3    ={.bits={.NBC2_ANR2_Y_SCALE_SP0=0, .rsv_5=0, .NBC2_ANR2_Y_SCALE_SP1=0, .rsv_13=0, .NBC2_ANR2_Y_SCALE_SP2=28, .rsv_21=0, .NBC2_ANR2_Y_SCALE_SP3=30, .rsv_29=0}},
    .l4lut1    ={.bits={.NBC2_ANR2_SL2_X1=64, .NBC2_ANR2_SL2_X2=128, .NBC2_ANR2_SL2_X3=192, .rsv_24=0}},
    .l4lut2    ={.bits={.NBC2_ANR2_SL2_GAIN0=16, .rsv_6=0, .NBC2_ANR2_SL2_GAIN1=20, .rsv_14=0, .NBC2_ANR2_SL2_GAIN2=24, .rsv_22=0, .NBC2_ANR2_SL2_GAIN3=32, .rsv_30=0}},
    .l4lut3    ={.bits={.NBC2_ANR2_SL2_SP0=8, .rsv_6=0, .NBC2_ANR2_SL2_SP1=8, .rsv_14=0, .NBC2_ANR2_SL2_SP2=16, .rsv_22=0, .NBC2_ANR2_SL2_SP3=16, .rsv_30=0}},
    .cad       ={.bits={.NBC2_ANR2_PTC_VGAIN=10, .NBC2_ANR2_C_GAIN=8, .NBC2_ANR2_PTC_GAIN_TH=0, .rsv_13=0, .NBC2_ANR2_C_L_DIFF_TH=24, .NBC2_ANR2_C_MODE=0, .rsv_25=0}},
    .ptc       ={.bits={.NBC2_ANR2_PTC1=2, .NBC2_ANR2_PTC2=3, .NBC2_ANR2_PTC3=4, .NBC2_ANR2_PTC4=6}},
    .sl2       ={.bits={.NBC2_ANR2_SL2_C_GAIN=6, .rsv_4=0, .NBC2_ANR2_LM_WT=4, .rsv_20=0}},
    .med1      ={.bits={.NBC2_ANR2_COR_TH=5, .rsv_5=0, .NBC2_ANR2_COR_SL=4, .rsv_11=0, .NBC2_ANR2_MCD_TH=5, .rsv_17=0, .NBC2_ANR2_MCD_SL=3, .rsv_23=0, .NBC2_ANR2_LCL_TH=32}},
    .med2      ={.bits={.NBC2_ANR2_LCL_SL=3, .rsv_3=0, .NBC2_ANR2_LCL_LV=16, .rsv_9=0, .NBC2_ANR2_SCL_TH=12, .rsv_18=0, .NBC2_ANR2_SCL_SL=3, .rsv_23=0, .NBC2_ANR2_SCL_LV=16, .rsv_29=0}},
    .med3      ={.bits={.NBC2_ANR2_NCL_TH=48, .NBC2_ANR2_NCL_SL=3, .rsv_11=0, .NBC2_ANR2_NCL_LV=16, .rsv_17=0, .NBC2_ANR2_VAR=3, .rsv_23=0, .NBC2_ANR2_Y0=10, .rsv_30=0}},
    .med4      ={.bits={.NBC2_ANR2_Y1=13, .rsv_6=0, .NBC2_ANR2_Y2=16, .rsv_14=0, .NBC2_ANR2_Y3=19, .rsv_22=0, .NBC2_ANR2_Y4=22, .rsv_30=0}},
    .med5      ={.bits={.NBC2_ANR2_LCL_OFT=0, .NBC2_ANR2_SCL_OFT=0, .rsv_14=0, .NBC2_ANR2_NCL_OFT=0, .rsv_24=0}},
    .actc      ={.bits={.rsv_0=0, .NBC2_ANR2_ACT_BLD_BASE_C=48, .rsv_15=0, .NBC2_ANR2_C_DITH_U=8, .rsv_21=0, .NBC2_ANR2_C_DITH_V=8, .rsv_29=0}}

};
const ISP_NVRAM_ANR2_T gc13a0mipiraw_NBC2_ANR2_0188 = {
        .con1      ={.bits={.NBC2_ANR2_ENC=1, .NBC2_ANR2_ENY=1, .rsv_2=0, .NBC2_ANR2_SCALE_MODE=0, .rsv_6=0, .NBC2_ANR2_VER_C_REF_Y=1, .rsv_9=0, .NBC2_ANR2_MODE=0, .rsv_13=0, .NBC2_ANR2_TILE_EDGE=15, .rsv_20=0, .NBC2_ANR2_SL2_LINK=1, .rsv_25=0}},
    .con2      ={.bits={.rsv_0=0, .NBC2_ANR2_C_SM_EDGE=1, .rsv_10=0, .NBC2_ANR2_FLT_C=0, .rsv_13=0}},
    .yad1      ={.bits={.rsv_0=0, .NBC2_ANR2_K_TH_C=8}},
    .y4lut1    ={.bits={.NBC2_ANR2_Y_CPX1=40, .NBC2_ANR2_Y_CPX2=120, .NBC2_ANR2_Y_CPX3=160, .rsv_24=0}},
    .y4lut2    ={.bits={.NBC2_ANR2_Y_SCALE_CPY0=16, .rsv_5=0, .NBC2_ANR2_Y_SCALE_CPY1=16, .rsv_13=0, .NBC2_ANR2_Y_SCALE_CPY2=16, .rsv_21=0, .NBC2_ANR2_Y_SCALE_CPY3=8, .rsv_29=0}},
    .y4lut3    ={.bits={.NBC2_ANR2_Y_SCALE_SP0=0, .rsv_5=0, .NBC2_ANR2_Y_SCALE_SP1=0, .rsv_13=0, .NBC2_ANR2_Y_SCALE_SP2=28, .rsv_21=0, .NBC2_ANR2_Y_SCALE_SP3=30, .rsv_29=0}},
    .l4lut1    ={.bits={.NBC2_ANR2_SL2_X1=64, .NBC2_ANR2_SL2_X2=128, .NBC2_ANR2_SL2_X3=192, .rsv_24=0}},
    .l4lut2    ={.bits={.NBC2_ANR2_SL2_GAIN0=16, .rsv_6=0, .NBC2_ANR2_SL2_GAIN1=20, .rsv_14=0, .NBC2_ANR2_SL2_GAIN2=24, .rsv_22=0, .NBC2_ANR2_SL2_GAIN3=32, .rsv_30=0}},
    .l4lut3    ={.bits={.NBC2_ANR2_SL2_SP0=8, .rsv_6=0, .NBC2_ANR2_SL2_SP1=8, .rsv_14=0, .NBC2_ANR2_SL2_SP2=16, .rsv_22=0, .NBC2_ANR2_SL2_SP3=16, .rsv_30=0}},
    .cad       ={.bits={.NBC2_ANR2_PTC_VGAIN=10, .NBC2_ANR2_C_GAIN=8, .NBC2_ANR2_PTC_GAIN_TH=0, .rsv_13=0, .NBC2_ANR2_C_L_DIFF_TH=24, .NBC2_ANR2_C_MODE=0, .rsv_25=0}},
    .ptc       ={.bits={.NBC2_ANR2_PTC1=2, .NBC2_ANR2_PTC2=3, .NBC2_ANR2_PTC3=4, .NBC2_ANR2_PTC4=6}},
    .sl2       ={.bits={.NBC2_ANR2_SL2_C_GAIN=6, .rsv_4=0, .NBC2_ANR2_LM_WT=4, .rsv_20=0}},
    .med1      ={.bits={.NBC2_ANR2_COR_TH=5, .rsv_5=0, .NBC2_ANR2_COR_SL=4, .rsv_11=0, .NBC2_ANR2_MCD_TH=5, .rsv_17=0, .NBC2_ANR2_MCD_SL=3, .rsv_23=0, .NBC2_ANR2_LCL_TH=32}},
    .med2      ={.bits={.NBC2_ANR2_LCL_SL=3, .rsv_3=0, .NBC2_ANR2_LCL_LV=16, .rsv_9=0, .NBC2_ANR2_SCL_TH=12, .rsv_18=0, .NBC2_ANR2_SCL_SL=3, .rsv_23=0, .NBC2_ANR2_SCL_LV=16, .rsv_29=0}},
    .med3      ={.bits={.NBC2_ANR2_NCL_TH=48, .NBC2_ANR2_NCL_SL=3, .rsv_11=0, .NBC2_ANR2_NCL_LV=16, .rsv_17=0, .NBC2_ANR2_VAR=3, .rsv_23=0, .NBC2_ANR2_Y0=10, .rsv_30=0}},
    .med4      ={.bits={.NBC2_ANR2_Y1=13, .rsv_6=0, .NBC2_ANR2_Y2=16, .rsv_14=0, .NBC2_ANR2_Y3=19, .rsv_22=0, .NBC2_ANR2_Y4=22, .rsv_30=0}},
    .med5      ={.bits={.NBC2_ANR2_LCL_OFT=0, .NBC2_ANR2_SCL_OFT=0, .rsv_14=0, .NBC2_ANR2_NCL_OFT=0, .rsv_24=0}},
    .actc      ={.bits={.rsv_0=0, .NBC2_ANR2_ACT_BLD_BASE_C=48, .rsv_15=0, .NBC2_ANR2_C_DITH_U=8, .rsv_21=0, .NBC2_ANR2_C_DITH_V=8, .rsv_29=0}}

};
const ISP_NVRAM_ANR2_T gc13a0mipiraw_NBC2_ANR2_0189 = {
        .con1      ={.bits={.NBC2_ANR2_ENC=1, .NBC2_ANR2_ENY=1, .rsv_2=0, .NBC2_ANR2_SCALE_MODE=0, .rsv_6=0, .NBC2_ANR2_VER_C_REF_Y=1, .rsv_9=0, .NBC2_ANR2_MODE=0, .rsv_13=0, .NBC2_ANR2_TILE_EDGE=15, .rsv_20=0, .NBC2_ANR2_SL2_LINK=1, .rsv_25=0}},
    .con2      ={.bits={.rsv_0=0, .NBC2_ANR2_C_SM_EDGE=1, .rsv_10=0, .NBC2_ANR2_FLT_C=0, .rsv_13=0}},
    .yad1      ={.bits={.rsv_0=0, .NBC2_ANR2_K_TH_C=8}},
    .y4lut1    ={.bits={.NBC2_ANR2_Y_CPX1=40, .NBC2_ANR2_Y_CPX2=120, .NBC2_ANR2_Y_CPX3=160, .rsv_24=0}},
    .y4lut2    ={.bits={.NBC2_ANR2_Y_SCALE_CPY0=16, .rsv_5=0, .NBC2_ANR2_Y_SCALE_CPY1=16, .rsv_13=0, .NBC2_ANR2_Y_SCALE_CPY2=16, .rsv_21=0, .NBC2_ANR2_Y_SCALE_CPY3=8, .rsv_29=0}},
    .y4lut3    ={.bits={.NBC2_ANR2_Y_SCALE_SP0=0, .rsv_5=0, .NBC2_ANR2_Y_SCALE_SP1=0, .rsv_13=0, .NBC2_ANR2_Y_SCALE_SP2=28, .rsv_21=0, .NBC2_ANR2_Y_SCALE_SP3=30, .rsv_29=0}},
    .l4lut1    ={.bits={.NBC2_ANR2_SL2_X1=64, .NBC2_ANR2_SL2_X2=128, .NBC2_ANR2_SL2_X3=192, .rsv_24=0}},
    .l4lut2    ={.bits={.NBC2_ANR2_SL2_GAIN0=16, .rsv_6=0, .NBC2_ANR2_SL2_GAIN1=20, .rsv_14=0, .NBC2_ANR2_SL2_GAIN2=24, .rsv_22=0, .NBC2_ANR2_SL2_GAIN3=32, .rsv_30=0}},
    .l4lut3    ={.bits={.NBC2_ANR2_SL2_SP0=8, .rsv_6=0, .NBC2_ANR2_SL2_SP1=8, .rsv_14=0, .NBC2_ANR2_SL2_SP2=16, .rsv_22=0, .NBC2_ANR2_SL2_SP3=16, .rsv_30=0}},
    .cad       ={.bits={.NBC2_ANR2_PTC_VGAIN=10, .NBC2_ANR2_C_GAIN=8, .NBC2_ANR2_PTC_GAIN_TH=0, .rsv_13=0, .NBC2_ANR2_C_L_DIFF_TH=24, .NBC2_ANR2_C_MODE=0, .rsv_25=0}},
    .ptc       ={.bits={.NBC2_ANR2_PTC1=2, .NBC2_ANR2_PTC2=3, .NBC2_ANR2_PTC3=4, .NBC2_ANR2_PTC4=6}},
    .sl2       ={.bits={.NBC2_ANR2_SL2_C_GAIN=6, .rsv_4=0, .NBC2_ANR2_LM_WT=4, .rsv_20=0}},
    .med1      ={.bits={.NBC2_ANR2_COR_TH=5, .rsv_5=0, .NBC2_ANR2_COR_SL=4, .rsv_11=0, .NBC2_ANR2_MCD_TH=5, .rsv_17=0, .NBC2_ANR2_MCD_SL=3, .rsv_23=0, .NBC2_ANR2_LCL_TH=32}},
    .med2      ={.bits={.NBC2_ANR2_LCL_SL=3, .rsv_3=0, .NBC2_ANR2_LCL_LV=16, .rsv_9=0, .NBC2_ANR2_SCL_TH=12, .rsv_18=0, .NBC2_ANR2_SCL_SL=3, .rsv_23=0, .NBC2_ANR2_SCL_LV=16, .rsv_29=0}},
    .med3      ={.bits={.NBC2_ANR2_NCL_TH=48, .NBC2_ANR2_NCL_SL=3, .rsv_11=0, .NBC2_ANR2_NCL_LV=16, .rsv_17=0, .NBC2_ANR2_VAR=3, .rsv_23=0, .NBC2_ANR2_Y0=10, .rsv_30=0}},
    .med4      ={.bits={.NBC2_ANR2_Y1=13, .rsv_6=0, .NBC2_ANR2_Y2=16, .rsv_14=0, .NBC2_ANR2_Y3=19, .rsv_22=0, .NBC2_ANR2_Y4=22, .rsv_30=0}},
    .med5      ={.bits={.NBC2_ANR2_LCL_OFT=0, .NBC2_ANR2_SCL_OFT=0, .rsv_14=0, .NBC2_ANR2_NCL_OFT=0, .rsv_24=0}},
    .actc      ={.bits={.rsv_0=0, .NBC2_ANR2_ACT_BLD_BASE_C=48, .rsv_15=0, .NBC2_ANR2_C_DITH_U=8, .rsv_21=0, .NBC2_ANR2_C_DITH_V=8, .rsv_29=0}}

};
const ISP_NVRAM_ANR2_T gc13a0mipiraw_NBC2_ANR2_0190 = {
        .con1      ={.bits={.NBC2_ANR2_ENC=1, .NBC2_ANR2_ENY=1, .rsv_2=0, .NBC2_ANR2_SCALE_MODE=0, .rsv_6=0, .NBC2_ANR2_VER_C_REF_Y=1, .rsv_9=0, .NBC2_ANR2_MODE=0, .rsv_13=0, .NBC2_ANR2_TILE_EDGE=15, .rsv_20=0, .NBC2_ANR2_SL2_LINK=1, .rsv_25=0}},
    .con2      ={.bits={.rsv_0=0, .NBC2_ANR2_C_SM_EDGE=1, .rsv_10=0, .NBC2_ANR2_FLT_C=0, .rsv_13=0}},
    .yad1      ={.bits={.rsv_0=0, .NBC2_ANR2_K_TH_C=8}},
    .y4lut1    ={.bits={.NBC2_ANR2_Y_CPX1=40, .NBC2_ANR2_Y_CPX2=120, .NBC2_ANR2_Y_CPX3=160, .rsv_24=0}},
    .y4lut2    ={.bits={.NBC2_ANR2_Y_SCALE_CPY0=16, .rsv_5=0, .NBC2_ANR2_Y_SCALE_CPY1=16, .rsv_13=0, .NBC2_ANR2_Y_SCALE_CPY2=16, .rsv_21=0, .NBC2_ANR2_Y_SCALE_CPY3=8, .rsv_29=0}},
    .y4lut3    ={.bits={.NBC2_ANR2_Y_SCALE_SP0=0, .rsv_5=0, .NBC2_ANR2_Y_SCALE_SP1=0, .rsv_13=0, .NBC2_ANR2_Y_SCALE_SP2=28, .rsv_21=0, .NBC2_ANR2_Y_SCALE_SP3=30, .rsv_29=0}},
    .l4lut1    ={.bits={.NBC2_ANR2_SL2_X1=64, .NBC2_ANR2_SL2_X2=128, .NBC2_ANR2_SL2_X3=192, .rsv_24=0}},
    .l4lut2    ={.bits={.NBC2_ANR2_SL2_GAIN0=16, .rsv_6=0, .NBC2_ANR2_SL2_GAIN1=20, .rsv_14=0, .NBC2_ANR2_SL2_GAIN2=24, .rsv_22=0, .NBC2_ANR2_SL2_GAIN3=32, .rsv_30=0}},
    .l4lut3    ={.bits={.NBC2_ANR2_SL2_SP0=8, .rsv_6=0, .NBC2_ANR2_SL2_SP1=8, .rsv_14=0, .NBC2_ANR2_SL2_SP2=16, .rsv_22=0, .NBC2_ANR2_SL2_SP3=16, .rsv_30=0}},
    .cad       ={.bits={.NBC2_ANR2_PTC_VGAIN=10, .NBC2_ANR2_C_GAIN=8, .NBC2_ANR2_PTC_GAIN_TH=0, .rsv_13=0, .NBC2_ANR2_C_L_DIFF_TH=24, .NBC2_ANR2_C_MODE=0, .rsv_25=0}},
    .ptc       ={.bits={.NBC2_ANR2_PTC1=2, .NBC2_ANR2_PTC2=3, .NBC2_ANR2_PTC3=4, .NBC2_ANR2_PTC4=6}},
    .sl2       ={.bits={.NBC2_ANR2_SL2_C_GAIN=6, .rsv_4=0, .NBC2_ANR2_LM_WT=4, .rsv_20=0}},
    .med1      ={.bits={.NBC2_ANR2_COR_TH=5, .rsv_5=0, .NBC2_ANR2_COR_SL=4, .rsv_11=0, .NBC2_ANR2_MCD_TH=5, .rsv_17=0, .NBC2_ANR2_MCD_SL=3, .rsv_23=0, .NBC2_ANR2_LCL_TH=32}},
    .med2      ={.bits={.NBC2_ANR2_LCL_SL=3, .rsv_3=0, .NBC2_ANR2_LCL_LV=16, .rsv_9=0, .NBC2_ANR2_SCL_TH=12, .rsv_18=0, .NBC2_ANR2_SCL_SL=3, .rsv_23=0, .NBC2_ANR2_SCL_LV=16, .rsv_29=0}},
    .med3      ={.bits={.NBC2_ANR2_NCL_TH=48, .NBC2_ANR2_NCL_SL=3, .rsv_11=0, .NBC2_ANR2_NCL_LV=16, .rsv_17=0, .NBC2_ANR2_VAR=3, .rsv_23=0, .NBC2_ANR2_Y0=10, .rsv_30=0}},
    .med4      ={.bits={.NBC2_ANR2_Y1=13, .rsv_6=0, .NBC2_ANR2_Y2=16, .rsv_14=0, .NBC2_ANR2_Y3=19, .rsv_22=0, .NBC2_ANR2_Y4=22, .rsv_30=0}},
    .med5      ={.bits={.NBC2_ANR2_LCL_OFT=0, .NBC2_ANR2_SCL_OFT=0, .rsv_14=0, .NBC2_ANR2_NCL_OFT=0, .rsv_24=0}},
    .actc      ={.bits={.rsv_0=0, .NBC2_ANR2_ACT_BLD_BASE_C=48, .rsv_15=0, .NBC2_ANR2_C_DITH_U=8, .rsv_21=0, .NBC2_ANR2_C_DITH_V=8, .rsv_29=0}}

};
const ISP_NVRAM_ANR2_T gc13a0mipiraw_NBC2_ANR2_0191 = {
        .con1      ={.bits={.NBC2_ANR2_ENC=1, .NBC2_ANR2_ENY=1, .rsv_2=0, .NBC2_ANR2_SCALE_MODE=0, .rsv_6=0, .NBC2_ANR2_VER_C_REF_Y=1, .rsv_9=0, .NBC2_ANR2_MODE=0, .rsv_13=0, .NBC2_ANR2_TILE_EDGE=15, .rsv_20=0, .NBC2_ANR2_SL2_LINK=1, .rsv_25=0}},
    .con2      ={.bits={.rsv_0=0, .NBC2_ANR2_C_SM_EDGE=1, .rsv_10=0, .NBC2_ANR2_FLT_C=0, .rsv_13=0}},
    .yad1      ={.bits={.rsv_0=0, .NBC2_ANR2_K_TH_C=8}},
    .y4lut1    ={.bits={.NBC2_ANR2_Y_CPX1=40, .NBC2_ANR2_Y_CPX2=120, .NBC2_ANR2_Y_CPX3=160, .rsv_24=0}},
    .y4lut2    ={.bits={.NBC2_ANR2_Y_SCALE_CPY0=16, .rsv_5=0, .NBC2_ANR2_Y_SCALE_CPY1=16, .rsv_13=0, .NBC2_ANR2_Y_SCALE_CPY2=16, .rsv_21=0, .NBC2_ANR2_Y_SCALE_CPY3=8, .rsv_29=0}},
    .y4lut3    ={.bits={.NBC2_ANR2_Y_SCALE_SP0=0, .rsv_5=0, .NBC2_ANR2_Y_SCALE_SP1=0, .rsv_13=0, .NBC2_ANR2_Y_SCALE_SP2=28, .rsv_21=0, .NBC2_ANR2_Y_SCALE_SP3=30, .rsv_29=0}},
    .l4lut1    ={.bits={.NBC2_ANR2_SL2_X1=64, .NBC2_ANR2_SL2_X2=128, .NBC2_ANR2_SL2_X3=192, .rsv_24=0}},
    .l4lut2    ={.bits={.NBC2_ANR2_SL2_GAIN0=16, .rsv_6=0, .NBC2_ANR2_SL2_GAIN1=20, .rsv_14=0, .NBC2_ANR2_SL2_GAIN2=24, .rsv_22=0, .NBC2_ANR2_SL2_GAIN3=32, .rsv_30=0}},
    .l4lut3    ={.bits={.NBC2_ANR2_SL2_SP0=8, .rsv_6=0, .NBC2_ANR2_SL2_SP1=8, .rsv_14=0, .NBC2_ANR2_SL2_SP2=16, .rsv_22=0, .NBC2_ANR2_SL2_SP3=16, .rsv_30=0}},
    .cad       ={.bits={.NBC2_ANR2_PTC_VGAIN=10, .NBC2_ANR2_C_GAIN=8, .NBC2_ANR2_PTC_GAIN_TH=0, .rsv_13=0, .NBC2_ANR2_C_L_DIFF_TH=24, .NBC2_ANR2_C_MODE=0, .rsv_25=0}},
    .ptc       ={.bits={.NBC2_ANR2_PTC1=2, .NBC2_ANR2_PTC2=3, .NBC2_ANR2_PTC3=4, .NBC2_ANR2_PTC4=6}},
    .sl2       ={.bits={.NBC2_ANR2_SL2_C_GAIN=6, .rsv_4=0, .NBC2_ANR2_LM_WT=4, .rsv_20=0}},
    .med1      ={.bits={.NBC2_ANR2_COR_TH=5, .rsv_5=0, .NBC2_ANR2_COR_SL=4, .rsv_11=0, .NBC2_ANR2_MCD_TH=5, .rsv_17=0, .NBC2_ANR2_MCD_SL=3, .rsv_23=0, .NBC2_ANR2_LCL_TH=32}},
    .med2      ={.bits={.NBC2_ANR2_LCL_SL=3, .rsv_3=0, .NBC2_ANR2_LCL_LV=16, .rsv_9=0, .NBC2_ANR2_SCL_TH=12, .rsv_18=0, .NBC2_ANR2_SCL_SL=3, .rsv_23=0, .NBC2_ANR2_SCL_LV=16, .rsv_29=0}},
    .med3      ={.bits={.NBC2_ANR2_NCL_TH=48, .NBC2_ANR2_NCL_SL=3, .rsv_11=0, .NBC2_ANR2_NCL_LV=16, .rsv_17=0, .NBC2_ANR2_VAR=3, .rsv_23=0, .NBC2_ANR2_Y0=10, .rsv_30=0}},
    .med4      ={.bits={.NBC2_ANR2_Y1=13, .rsv_6=0, .NBC2_ANR2_Y2=16, .rsv_14=0, .NBC2_ANR2_Y3=19, .rsv_22=0, .NBC2_ANR2_Y4=22, .rsv_30=0}},
    .med5      ={.bits={.NBC2_ANR2_LCL_OFT=0, .NBC2_ANR2_SCL_OFT=0, .rsv_14=0, .NBC2_ANR2_NCL_OFT=0, .rsv_24=0}},
    .actc      ={.bits={.rsv_0=0, .NBC2_ANR2_ACT_BLD_BASE_C=48, .rsv_15=0, .NBC2_ANR2_C_DITH_U=8, .rsv_21=0, .NBC2_ANR2_C_DITH_V=8, .rsv_29=0}}

};
const ISP_NVRAM_ANR2_T gc13a0mipiraw_NBC2_ANR2_0192 = {
        .con1      ={.bits={.NBC2_ANR2_ENC=1, .NBC2_ANR2_ENY=1, .rsv_2=0, .NBC2_ANR2_SCALE_MODE=0, .rsv_6=0, .NBC2_ANR2_VER_C_REF_Y=1, .rsv_9=0, .NBC2_ANR2_MODE=0, .rsv_13=0, .NBC2_ANR2_TILE_EDGE=15, .rsv_20=0, .NBC2_ANR2_SL2_LINK=1, .rsv_25=0}},
    .con2      ={.bits={.rsv_0=0, .NBC2_ANR2_C_SM_EDGE=1, .rsv_10=0, .NBC2_ANR2_FLT_C=0, .rsv_13=0}},
    .yad1      ={.bits={.rsv_0=0, .NBC2_ANR2_K_TH_C=8}},
    .y4lut1    ={.bits={.NBC2_ANR2_Y_CPX1=40, .NBC2_ANR2_Y_CPX2=120, .NBC2_ANR2_Y_CPX3=160, .rsv_24=0}},
    .y4lut2    ={.bits={.NBC2_ANR2_Y_SCALE_CPY0=16, .rsv_5=0, .NBC2_ANR2_Y_SCALE_CPY1=16, .rsv_13=0, .NBC2_ANR2_Y_SCALE_CPY2=16, .rsv_21=0, .NBC2_ANR2_Y_SCALE_CPY3=8, .rsv_29=0}},
    .y4lut3    ={.bits={.NBC2_ANR2_Y_SCALE_SP0=0, .rsv_5=0, .NBC2_ANR2_Y_SCALE_SP1=0, .rsv_13=0, .NBC2_ANR2_Y_SCALE_SP2=28, .rsv_21=0, .NBC2_ANR2_Y_SCALE_SP3=30, .rsv_29=0}},
    .l4lut1    ={.bits={.NBC2_ANR2_SL2_X1=64, .NBC2_ANR2_SL2_X2=128, .NBC2_ANR2_SL2_X3=192, .rsv_24=0}},
    .l4lut2    ={.bits={.NBC2_ANR2_SL2_GAIN0=16, .rsv_6=0, .NBC2_ANR2_SL2_GAIN1=20, .rsv_14=0, .NBC2_ANR2_SL2_GAIN2=24, .rsv_22=0, .NBC2_ANR2_SL2_GAIN3=32, .rsv_30=0}},
    .l4lut3    ={.bits={.NBC2_ANR2_SL2_SP0=8, .rsv_6=0, .NBC2_ANR2_SL2_SP1=8, .rsv_14=0, .NBC2_ANR2_SL2_SP2=16, .rsv_22=0, .NBC2_ANR2_SL2_SP3=16, .rsv_30=0}},
    .cad       ={.bits={.NBC2_ANR2_PTC_VGAIN=10, .NBC2_ANR2_C_GAIN=8, .NBC2_ANR2_PTC_GAIN_TH=0, .rsv_13=0, .NBC2_ANR2_C_L_DIFF_TH=24, .NBC2_ANR2_C_MODE=0, .rsv_25=0}},
    .ptc       ={.bits={.NBC2_ANR2_PTC1=2, .NBC2_ANR2_PTC2=3, .NBC2_ANR2_PTC3=4, .NBC2_ANR2_PTC4=6}},
    .sl2       ={.bits={.NBC2_ANR2_SL2_C_GAIN=6, .rsv_4=0, .NBC2_ANR2_LM_WT=4, .rsv_20=0}},
    .med1      ={.bits={.NBC2_ANR2_COR_TH=5, .rsv_5=0, .NBC2_ANR2_COR_SL=4, .rsv_11=0, .NBC2_ANR2_MCD_TH=5, .rsv_17=0, .NBC2_ANR2_MCD_SL=3, .rsv_23=0, .NBC2_ANR2_LCL_TH=32}},
    .med2      ={.bits={.NBC2_ANR2_LCL_SL=3, .rsv_3=0, .NBC2_ANR2_LCL_LV=16, .rsv_9=0, .NBC2_ANR2_SCL_TH=12, .rsv_18=0, .NBC2_ANR2_SCL_SL=3, .rsv_23=0, .NBC2_ANR2_SCL_LV=16, .rsv_29=0}},
    .med3      ={.bits={.NBC2_ANR2_NCL_TH=48, .NBC2_ANR2_NCL_SL=3, .rsv_11=0, .NBC2_ANR2_NCL_LV=16, .rsv_17=0, .NBC2_ANR2_VAR=3, .rsv_23=0, .NBC2_ANR2_Y0=10, .rsv_30=0}},
    .med4      ={.bits={.NBC2_ANR2_Y1=13, .rsv_6=0, .NBC2_ANR2_Y2=16, .rsv_14=0, .NBC2_ANR2_Y3=19, .rsv_22=0, .NBC2_ANR2_Y4=22, .rsv_30=0}},
    .med5      ={.bits={.NBC2_ANR2_LCL_OFT=0, .NBC2_ANR2_SCL_OFT=0, .rsv_14=0, .NBC2_ANR2_NCL_OFT=0, .rsv_24=0}},
    .actc      ={.bits={.rsv_0=0, .NBC2_ANR2_ACT_BLD_BASE_C=48, .rsv_15=0, .NBC2_ANR2_C_DITH_U=8, .rsv_21=0, .NBC2_ANR2_C_DITH_V=8, .rsv_29=0}}

};
const ISP_NVRAM_ANR2_T gc13a0mipiraw_NBC2_ANR2_0193 = {
        .con1      ={.bits={.NBC2_ANR2_ENC=1, .NBC2_ANR2_ENY=1, .rsv_2=0, .NBC2_ANR2_SCALE_MODE=0, .rsv_6=0, .NBC2_ANR2_VER_C_REF_Y=1, .rsv_9=0, .NBC2_ANR2_MODE=0, .rsv_13=0, .NBC2_ANR2_TILE_EDGE=15, .rsv_20=0, .NBC2_ANR2_SL2_LINK=1, .rsv_25=0}},
    .con2      ={.bits={.rsv_0=0, .NBC2_ANR2_C_SM_EDGE=1, .rsv_10=0, .NBC2_ANR2_FLT_C=0, .rsv_13=0}},
    .yad1      ={.bits={.rsv_0=0, .NBC2_ANR2_K_TH_C=8}},
    .y4lut1    ={.bits={.NBC2_ANR2_Y_CPX1=40, .NBC2_ANR2_Y_CPX2=120, .NBC2_ANR2_Y_CPX3=160, .rsv_24=0}},
    .y4lut2    ={.bits={.NBC2_ANR2_Y_SCALE_CPY0=16, .rsv_5=0, .NBC2_ANR2_Y_SCALE_CPY1=16, .rsv_13=0, .NBC2_ANR2_Y_SCALE_CPY2=16, .rsv_21=0, .NBC2_ANR2_Y_SCALE_CPY3=8, .rsv_29=0}},
    .y4lut3    ={.bits={.NBC2_ANR2_Y_SCALE_SP0=0, .rsv_5=0, .NBC2_ANR2_Y_SCALE_SP1=0, .rsv_13=0, .NBC2_ANR2_Y_SCALE_SP2=28, .rsv_21=0, .NBC2_ANR2_Y_SCALE_SP3=30, .rsv_29=0}},
    .l4lut1    ={.bits={.NBC2_ANR2_SL2_X1=64, .NBC2_ANR2_SL2_X2=128, .NBC2_ANR2_SL2_X3=192, .rsv_24=0}},
    .l4lut2    ={.bits={.NBC2_ANR2_SL2_GAIN0=16, .rsv_6=0, .NBC2_ANR2_SL2_GAIN1=20, .rsv_14=0, .NBC2_ANR2_SL2_GAIN2=24, .rsv_22=0, .NBC2_ANR2_SL2_GAIN3=32, .rsv_30=0}},
    .l4lut3    ={.bits={.NBC2_ANR2_SL2_SP0=8, .rsv_6=0, .NBC2_ANR2_SL2_SP1=8, .rsv_14=0, .NBC2_ANR2_SL2_SP2=16, .rsv_22=0, .NBC2_ANR2_SL2_SP3=16, .rsv_30=0}},
    .cad       ={.bits={.NBC2_ANR2_PTC_VGAIN=10, .NBC2_ANR2_C_GAIN=8, .NBC2_ANR2_PTC_GAIN_TH=0, .rsv_13=0, .NBC2_ANR2_C_L_DIFF_TH=24, .NBC2_ANR2_C_MODE=0, .rsv_25=0}},
    .ptc       ={.bits={.NBC2_ANR2_PTC1=2, .NBC2_ANR2_PTC2=3, .NBC2_ANR2_PTC3=4, .NBC2_ANR2_PTC4=6}},
    .sl2       ={.bits={.NBC2_ANR2_SL2_C_GAIN=6, .rsv_4=0, .NBC2_ANR2_LM_WT=4, .rsv_20=0}},
    .med1      ={.bits={.NBC2_ANR2_COR_TH=5, .rsv_5=0, .NBC2_ANR2_COR_SL=4, .rsv_11=0, .NBC2_ANR2_MCD_TH=5, .rsv_17=0, .NBC2_ANR2_MCD_SL=3, .rsv_23=0, .NBC2_ANR2_LCL_TH=32}},
    .med2      ={.bits={.NBC2_ANR2_LCL_SL=3, .rsv_3=0, .NBC2_ANR2_LCL_LV=16, .rsv_9=0, .NBC2_ANR2_SCL_TH=12, .rsv_18=0, .NBC2_ANR2_SCL_SL=3, .rsv_23=0, .NBC2_ANR2_SCL_LV=16, .rsv_29=0}},
    .med3      ={.bits={.NBC2_ANR2_NCL_TH=48, .NBC2_ANR2_NCL_SL=3, .rsv_11=0, .NBC2_ANR2_NCL_LV=16, .rsv_17=0, .NBC2_ANR2_VAR=3, .rsv_23=0, .NBC2_ANR2_Y0=10, .rsv_30=0}},
    .med4      ={.bits={.NBC2_ANR2_Y1=13, .rsv_6=0, .NBC2_ANR2_Y2=16, .rsv_14=0, .NBC2_ANR2_Y3=19, .rsv_22=0, .NBC2_ANR2_Y4=22, .rsv_30=0}},
    .med5      ={.bits={.NBC2_ANR2_LCL_OFT=0, .NBC2_ANR2_SCL_OFT=0, .rsv_14=0, .NBC2_ANR2_NCL_OFT=0, .rsv_24=0}},
    .actc      ={.bits={.rsv_0=0, .NBC2_ANR2_ACT_BLD_BASE_C=48, .rsv_15=0, .NBC2_ANR2_C_DITH_U=8, .rsv_21=0, .NBC2_ANR2_C_DITH_V=8, .rsv_29=0}}

};
const ISP_NVRAM_ANR2_T gc13a0mipiraw_NBC2_ANR2_0194 = {
        .con1      ={.bits={.NBC2_ANR2_ENC=1, .NBC2_ANR2_ENY=1, .rsv_2=0, .NBC2_ANR2_SCALE_MODE=0, .rsv_6=0, .NBC2_ANR2_VER_C_REF_Y=1, .rsv_9=0, .NBC2_ANR2_MODE=0, .rsv_13=0, .NBC2_ANR2_TILE_EDGE=15, .rsv_20=0, .NBC2_ANR2_SL2_LINK=1, .rsv_25=0}},
    .con2      ={.bits={.rsv_0=0, .NBC2_ANR2_C_SM_EDGE=1, .rsv_10=0, .NBC2_ANR2_FLT_C=0, .rsv_13=0}},
    .yad1      ={.bits={.rsv_0=0, .NBC2_ANR2_K_TH_C=8}},
    .y4lut1    ={.bits={.NBC2_ANR2_Y_CPX1=40, .NBC2_ANR2_Y_CPX2=120, .NBC2_ANR2_Y_CPX3=160, .rsv_24=0}},
    .y4lut2    ={.bits={.NBC2_ANR2_Y_SCALE_CPY0=16, .rsv_5=0, .NBC2_ANR2_Y_SCALE_CPY1=16, .rsv_13=0, .NBC2_ANR2_Y_SCALE_CPY2=16, .rsv_21=0, .NBC2_ANR2_Y_SCALE_CPY3=8, .rsv_29=0}},
    .y4lut3    ={.bits={.NBC2_ANR2_Y_SCALE_SP0=0, .rsv_5=0, .NBC2_ANR2_Y_SCALE_SP1=0, .rsv_13=0, .NBC2_ANR2_Y_SCALE_SP2=28, .rsv_21=0, .NBC2_ANR2_Y_SCALE_SP3=30, .rsv_29=0}},
    .l4lut1    ={.bits={.NBC2_ANR2_SL2_X1=64, .NBC2_ANR2_SL2_X2=128, .NBC2_ANR2_SL2_X3=192, .rsv_24=0}},
    .l4lut2    ={.bits={.NBC2_ANR2_SL2_GAIN0=16, .rsv_6=0, .NBC2_ANR2_SL2_GAIN1=20, .rsv_14=0, .NBC2_ANR2_SL2_GAIN2=24, .rsv_22=0, .NBC2_ANR2_SL2_GAIN3=32, .rsv_30=0}},
    .l4lut3    ={.bits={.NBC2_ANR2_SL2_SP0=8, .rsv_6=0, .NBC2_ANR2_SL2_SP1=8, .rsv_14=0, .NBC2_ANR2_SL2_SP2=16, .rsv_22=0, .NBC2_ANR2_SL2_SP3=16, .rsv_30=0}},
    .cad       ={.bits={.NBC2_ANR2_PTC_VGAIN=10, .NBC2_ANR2_C_GAIN=8, .NBC2_ANR2_PTC_GAIN_TH=0, .rsv_13=0, .NBC2_ANR2_C_L_DIFF_TH=24, .NBC2_ANR2_C_MODE=0, .rsv_25=0}},
    .ptc       ={.bits={.NBC2_ANR2_PTC1=2, .NBC2_ANR2_PTC2=3, .NBC2_ANR2_PTC3=4, .NBC2_ANR2_PTC4=6}},
    .sl2       ={.bits={.NBC2_ANR2_SL2_C_GAIN=6, .rsv_4=0, .NBC2_ANR2_LM_WT=4, .rsv_20=0}},
    .med1      ={.bits={.NBC2_ANR2_COR_TH=5, .rsv_5=0, .NBC2_ANR2_COR_SL=4, .rsv_11=0, .NBC2_ANR2_MCD_TH=5, .rsv_17=0, .NBC2_ANR2_MCD_SL=3, .rsv_23=0, .NBC2_ANR2_LCL_TH=32}},
    .med2      ={.bits={.NBC2_ANR2_LCL_SL=3, .rsv_3=0, .NBC2_ANR2_LCL_LV=16, .rsv_9=0, .NBC2_ANR2_SCL_TH=12, .rsv_18=0, .NBC2_ANR2_SCL_SL=3, .rsv_23=0, .NBC2_ANR2_SCL_LV=16, .rsv_29=0}},
    .med3      ={.bits={.NBC2_ANR2_NCL_TH=48, .NBC2_ANR2_NCL_SL=3, .rsv_11=0, .NBC2_ANR2_NCL_LV=16, .rsv_17=0, .NBC2_ANR2_VAR=3, .rsv_23=0, .NBC2_ANR2_Y0=10, .rsv_30=0}},
    .med4      ={.bits={.NBC2_ANR2_Y1=13, .rsv_6=0, .NBC2_ANR2_Y2=16, .rsv_14=0, .NBC2_ANR2_Y3=19, .rsv_22=0, .NBC2_ANR2_Y4=22, .rsv_30=0}},
    .med5      ={.bits={.NBC2_ANR2_LCL_OFT=0, .NBC2_ANR2_SCL_OFT=0, .rsv_14=0, .NBC2_ANR2_NCL_OFT=0, .rsv_24=0}},
    .actc      ={.bits={.rsv_0=0, .NBC2_ANR2_ACT_BLD_BASE_C=48, .rsv_15=0, .NBC2_ANR2_C_DITH_U=8, .rsv_21=0, .NBC2_ANR2_C_DITH_V=8, .rsv_29=0}}

};
const ISP_NVRAM_ANR2_T gc13a0mipiraw_NBC2_ANR2_0195 = {
        .con1      ={.bits={.NBC2_ANR2_ENC=1, .NBC2_ANR2_ENY=1, .rsv_2=0, .NBC2_ANR2_SCALE_MODE=0, .rsv_6=0, .NBC2_ANR2_VER_C_REF_Y=1, .rsv_9=0, .NBC2_ANR2_MODE=0, .rsv_13=0, .NBC2_ANR2_TILE_EDGE=15, .rsv_20=0, .NBC2_ANR2_SL2_LINK=1, .rsv_25=0}},
    .con2      ={.bits={.rsv_0=0, .NBC2_ANR2_C_SM_EDGE=1, .rsv_10=0, .NBC2_ANR2_FLT_C=0, .rsv_13=0}},
    .yad1      ={.bits={.rsv_0=0, .NBC2_ANR2_K_TH_C=8}},
    .y4lut1    ={.bits={.NBC2_ANR2_Y_CPX1=40, .NBC2_ANR2_Y_CPX2=120, .NBC2_ANR2_Y_CPX3=160, .rsv_24=0}},
    .y4lut2    ={.bits={.NBC2_ANR2_Y_SCALE_CPY0=16, .rsv_5=0, .NBC2_ANR2_Y_SCALE_CPY1=16, .rsv_13=0, .NBC2_ANR2_Y_SCALE_CPY2=16, .rsv_21=0, .NBC2_ANR2_Y_SCALE_CPY3=8, .rsv_29=0}},
    .y4lut3    ={.bits={.NBC2_ANR2_Y_SCALE_SP0=0, .rsv_5=0, .NBC2_ANR2_Y_SCALE_SP1=0, .rsv_13=0, .NBC2_ANR2_Y_SCALE_SP2=28, .rsv_21=0, .NBC2_ANR2_Y_SCALE_SP3=30, .rsv_29=0}},
    .l4lut1    ={.bits={.NBC2_ANR2_SL2_X1=64, .NBC2_ANR2_SL2_X2=128, .NBC2_ANR2_SL2_X3=192, .rsv_24=0}},
    .l4lut2    ={.bits={.NBC2_ANR2_SL2_GAIN0=16, .rsv_6=0, .NBC2_ANR2_SL2_GAIN1=20, .rsv_14=0, .NBC2_ANR2_SL2_GAIN2=24, .rsv_22=0, .NBC2_ANR2_SL2_GAIN3=32, .rsv_30=0}},
    .l4lut3    ={.bits={.NBC2_ANR2_SL2_SP0=8, .rsv_6=0, .NBC2_ANR2_SL2_SP1=8, .rsv_14=0, .NBC2_ANR2_SL2_SP2=16, .rsv_22=0, .NBC2_ANR2_SL2_SP3=16, .rsv_30=0}},
    .cad       ={.bits={.NBC2_ANR2_PTC_VGAIN=10, .NBC2_ANR2_C_GAIN=8, .NBC2_ANR2_PTC_GAIN_TH=0, .rsv_13=0, .NBC2_ANR2_C_L_DIFF_TH=24, .NBC2_ANR2_C_MODE=0, .rsv_25=0}},
    .ptc       ={.bits={.NBC2_ANR2_PTC1=2, .NBC2_ANR2_PTC2=3, .NBC2_ANR2_PTC3=4, .NBC2_ANR2_PTC4=6}},
    .sl2       ={.bits={.NBC2_ANR2_SL2_C_GAIN=6, .rsv_4=0, .NBC2_ANR2_LM_WT=4, .rsv_20=0}},
    .med1      ={.bits={.NBC2_ANR2_COR_TH=5, .rsv_5=0, .NBC2_ANR2_COR_SL=4, .rsv_11=0, .NBC2_ANR2_MCD_TH=5, .rsv_17=0, .NBC2_ANR2_MCD_SL=3, .rsv_23=0, .NBC2_ANR2_LCL_TH=32}},
    .med2      ={.bits={.NBC2_ANR2_LCL_SL=3, .rsv_3=0, .NBC2_ANR2_LCL_LV=16, .rsv_9=0, .NBC2_ANR2_SCL_TH=12, .rsv_18=0, .NBC2_ANR2_SCL_SL=3, .rsv_23=0, .NBC2_ANR2_SCL_LV=16, .rsv_29=0}},
    .med3      ={.bits={.NBC2_ANR2_NCL_TH=48, .NBC2_ANR2_NCL_SL=3, .rsv_11=0, .NBC2_ANR2_NCL_LV=16, .rsv_17=0, .NBC2_ANR2_VAR=3, .rsv_23=0, .NBC2_ANR2_Y0=10, .rsv_30=0}},
    .med4      ={.bits={.NBC2_ANR2_Y1=13, .rsv_6=0, .NBC2_ANR2_Y2=16, .rsv_14=0, .NBC2_ANR2_Y3=19, .rsv_22=0, .NBC2_ANR2_Y4=22, .rsv_30=0}},
    .med5      ={.bits={.NBC2_ANR2_LCL_OFT=0, .NBC2_ANR2_SCL_OFT=0, .rsv_14=0, .NBC2_ANR2_NCL_OFT=0, .rsv_24=0}},
    .actc      ={.bits={.rsv_0=0, .NBC2_ANR2_ACT_BLD_BASE_C=48, .rsv_15=0, .NBC2_ANR2_C_DITH_U=8, .rsv_21=0, .NBC2_ANR2_C_DITH_V=8, .rsv_29=0}}

};
const ISP_NVRAM_ANR2_T gc13a0mipiraw_NBC2_ANR2_0196 = {
        .con1      ={.bits={.NBC2_ANR2_ENC=1, .NBC2_ANR2_ENY=1, .rsv_2=0, .NBC2_ANR2_SCALE_MODE=0, .rsv_6=0, .NBC2_ANR2_VER_C_REF_Y=1, .rsv_9=0, .NBC2_ANR2_MODE=0, .rsv_13=0, .NBC2_ANR2_TILE_EDGE=15, .rsv_20=0, .NBC2_ANR2_SL2_LINK=1, .rsv_25=0}},
    .con2      ={.bits={.rsv_0=0, .NBC2_ANR2_C_SM_EDGE=1, .rsv_10=0, .NBC2_ANR2_FLT_C=0, .rsv_13=0}},
    .yad1      ={.bits={.rsv_0=0, .NBC2_ANR2_K_TH_C=8}},
    .y4lut1    ={.bits={.NBC2_ANR2_Y_CPX1=40, .NBC2_ANR2_Y_CPX2=120, .NBC2_ANR2_Y_CPX3=160, .rsv_24=0}},
    .y4lut2    ={.bits={.NBC2_ANR2_Y_SCALE_CPY0=16, .rsv_5=0, .NBC2_ANR2_Y_SCALE_CPY1=16, .rsv_13=0, .NBC2_ANR2_Y_SCALE_CPY2=16, .rsv_21=0, .NBC2_ANR2_Y_SCALE_CPY3=8, .rsv_29=0}},
    .y4lut3    ={.bits={.NBC2_ANR2_Y_SCALE_SP0=0, .rsv_5=0, .NBC2_ANR2_Y_SCALE_SP1=0, .rsv_13=0, .NBC2_ANR2_Y_SCALE_SP2=28, .rsv_21=0, .NBC2_ANR2_Y_SCALE_SP3=30, .rsv_29=0}},
    .l4lut1    ={.bits={.NBC2_ANR2_SL2_X1=64, .NBC2_ANR2_SL2_X2=128, .NBC2_ANR2_SL2_X3=192, .rsv_24=0}},
    .l4lut2    ={.bits={.NBC2_ANR2_SL2_GAIN0=16, .rsv_6=0, .NBC2_ANR2_SL2_GAIN1=20, .rsv_14=0, .NBC2_ANR2_SL2_GAIN2=24, .rsv_22=0, .NBC2_ANR2_SL2_GAIN3=32, .rsv_30=0}},
    .l4lut3    ={.bits={.NBC2_ANR2_SL2_SP0=8, .rsv_6=0, .NBC2_ANR2_SL2_SP1=8, .rsv_14=0, .NBC2_ANR2_SL2_SP2=16, .rsv_22=0, .NBC2_ANR2_SL2_SP3=16, .rsv_30=0}},
    .cad       ={.bits={.NBC2_ANR2_PTC_VGAIN=10, .NBC2_ANR2_C_GAIN=8, .NBC2_ANR2_PTC_GAIN_TH=0, .rsv_13=0, .NBC2_ANR2_C_L_DIFF_TH=24, .NBC2_ANR2_C_MODE=0, .rsv_25=0}},
    .ptc       ={.bits={.NBC2_ANR2_PTC1=2, .NBC2_ANR2_PTC2=3, .NBC2_ANR2_PTC3=4, .NBC2_ANR2_PTC4=6}},
    .sl2       ={.bits={.NBC2_ANR2_SL2_C_GAIN=6, .rsv_4=0, .NBC2_ANR2_LM_WT=4, .rsv_20=0}},
    .med1      ={.bits={.NBC2_ANR2_COR_TH=5, .rsv_5=0, .NBC2_ANR2_COR_SL=4, .rsv_11=0, .NBC2_ANR2_MCD_TH=5, .rsv_17=0, .NBC2_ANR2_MCD_SL=3, .rsv_23=0, .NBC2_ANR2_LCL_TH=32}},
    .med2      ={.bits={.NBC2_ANR2_LCL_SL=3, .rsv_3=0, .NBC2_ANR2_LCL_LV=16, .rsv_9=0, .NBC2_ANR2_SCL_TH=12, .rsv_18=0, .NBC2_ANR2_SCL_SL=3, .rsv_23=0, .NBC2_ANR2_SCL_LV=16, .rsv_29=0}},
    .med3      ={.bits={.NBC2_ANR2_NCL_TH=48, .NBC2_ANR2_NCL_SL=3, .rsv_11=0, .NBC2_ANR2_NCL_LV=16, .rsv_17=0, .NBC2_ANR2_VAR=3, .rsv_23=0, .NBC2_ANR2_Y0=10, .rsv_30=0}},
    .med4      ={.bits={.NBC2_ANR2_Y1=13, .rsv_6=0, .NBC2_ANR2_Y2=16, .rsv_14=0, .NBC2_ANR2_Y3=19, .rsv_22=0, .NBC2_ANR2_Y4=22, .rsv_30=0}},
    .med5      ={.bits={.NBC2_ANR2_LCL_OFT=0, .NBC2_ANR2_SCL_OFT=0, .rsv_14=0, .NBC2_ANR2_NCL_OFT=0, .rsv_24=0}},
    .actc      ={.bits={.rsv_0=0, .NBC2_ANR2_ACT_BLD_BASE_C=48, .rsv_15=0, .NBC2_ANR2_C_DITH_U=8, .rsv_21=0, .NBC2_ANR2_C_DITH_V=8, .rsv_29=0}}

};
const ISP_NVRAM_ANR2_T gc13a0mipiraw_NBC2_ANR2_0197 = {
        .con1      ={.bits={.NBC2_ANR2_ENC=1, .NBC2_ANR2_ENY=1, .rsv_2=0, .NBC2_ANR2_SCALE_MODE=0, .rsv_6=0, .NBC2_ANR2_VER_C_REF_Y=1, .rsv_9=0, .NBC2_ANR2_MODE=0, .rsv_13=0, .NBC2_ANR2_TILE_EDGE=15, .rsv_20=0, .NBC2_ANR2_SL2_LINK=1, .rsv_25=0}},
    .con2      ={.bits={.rsv_0=0, .NBC2_ANR2_C_SM_EDGE=1, .rsv_10=0, .NBC2_ANR2_FLT_C=0, .rsv_13=0}},
    .yad1      ={.bits={.rsv_0=0, .NBC2_ANR2_K_TH_C=8}},
    .y4lut1    ={.bits={.NBC2_ANR2_Y_CPX1=40, .NBC2_ANR2_Y_CPX2=120, .NBC2_ANR2_Y_CPX3=160, .rsv_24=0}},
    .y4lut2    ={.bits={.NBC2_ANR2_Y_SCALE_CPY0=16, .rsv_5=0, .NBC2_ANR2_Y_SCALE_CPY1=16, .rsv_13=0, .NBC2_ANR2_Y_SCALE_CPY2=16, .rsv_21=0, .NBC2_ANR2_Y_SCALE_CPY3=8, .rsv_29=0}},
    .y4lut3    ={.bits={.NBC2_ANR2_Y_SCALE_SP0=0, .rsv_5=0, .NBC2_ANR2_Y_SCALE_SP1=0, .rsv_13=0, .NBC2_ANR2_Y_SCALE_SP2=28, .rsv_21=0, .NBC2_ANR2_Y_SCALE_SP3=30, .rsv_29=0}},
    .l4lut1    ={.bits={.NBC2_ANR2_SL2_X1=64, .NBC2_ANR2_SL2_X2=128, .NBC2_ANR2_SL2_X3=192, .rsv_24=0}},
    .l4lut2    ={.bits={.NBC2_ANR2_SL2_GAIN0=16, .rsv_6=0, .NBC2_ANR2_SL2_GAIN1=20, .rsv_14=0, .NBC2_ANR2_SL2_GAIN2=24, .rsv_22=0, .NBC2_ANR2_SL2_GAIN3=32, .rsv_30=0}},
    .l4lut3    ={.bits={.NBC2_ANR2_SL2_SP0=8, .rsv_6=0, .NBC2_ANR2_SL2_SP1=8, .rsv_14=0, .NBC2_ANR2_SL2_SP2=16, .rsv_22=0, .NBC2_ANR2_SL2_SP3=16, .rsv_30=0}},
    .cad       ={.bits={.NBC2_ANR2_PTC_VGAIN=10, .NBC2_ANR2_C_GAIN=8, .NBC2_ANR2_PTC_GAIN_TH=0, .rsv_13=0, .NBC2_ANR2_C_L_DIFF_TH=24, .NBC2_ANR2_C_MODE=0, .rsv_25=0}},
    .ptc       ={.bits={.NBC2_ANR2_PTC1=2, .NBC2_ANR2_PTC2=3, .NBC2_ANR2_PTC3=4, .NBC2_ANR2_PTC4=6}},
    .sl2       ={.bits={.NBC2_ANR2_SL2_C_GAIN=6, .rsv_4=0, .NBC2_ANR2_LM_WT=4, .rsv_20=0}},
    .med1      ={.bits={.NBC2_ANR2_COR_TH=5, .rsv_5=0, .NBC2_ANR2_COR_SL=4, .rsv_11=0, .NBC2_ANR2_MCD_TH=5, .rsv_17=0, .NBC2_ANR2_MCD_SL=3, .rsv_23=0, .NBC2_ANR2_LCL_TH=32}},
    .med2      ={.bits={.NBC2_ANR2_LCL_SL=3, .rsv_3=0, .NBC2_ANR2_LCL_LV=16, .rsv_9=0, .NBC2_ANR2_SCL_TH=12, .rsv_18=0, .NBC2_ANR2_SCL_SL=3, .rsv_23=0, .NBC2_ANR2_SCL_LV=16, .rsv_29=0}},
    .med3      ={.bits={.NBC2_ANR2_NCL_TH=48, .NBC2_ANR2_NCL_SL=3, .rsv_11=0, .NBC2_ANR2_NCL_LV=16, .rsv_17=0, .NBC2_ANR2_VAR=3, .rsv_23=0, .NBC2_ANR2_Y0=10, .rsv_30=0}},
    .med4      ={.bits={.NBC2_ANR2_Y1=13, .rsv_6=0, .NBC2_ANR2_Y2=16, .rsv_14=0, .NBC2_ANR2_Y3=19, .rsv_22=0, .NBC2_ANR2_Y4=22, .rsv_30=0}},
    .med5      ={.bits={.NBC2_ANR2_LCL_OFT=0, .NBC2_ANR2_SCL_OFT=0, .rsv_14=0, .NBC2_ANR2_NCL_OFT=0, .rsv_24=0}},
    .actc      ={.bits={.rsv_0=0, .NBC2_ANR2_ACT_BLD_BASE_C=48, .rsv_15=0, .NBC2_ANR2_C_DITH_U=8, .rsv_21=0, .NBC2_ANR2_C_DITH_V=8, .rsv_29=0}}

};
const ISP_NVRAM_ANR2_T gc13a0mipiraw_NBC2_ANR2_0198 = {
        .con1      ={.bits={.NBC2_ANR2_ENC=1, .NBC2_ANR2_ENY=1, .rsv_2=0, .NBC2_ANR2_SCALE_MODE=0, .rsv_6=0, .NBC2_ANR2_VER_C_REF_Y=1, .rsv_9=0, .NBC2_ANR2_MODE=0, .rsv_13=0, .NBC2_ANR2_TILE_EDGE=15, .rsv_20=0, .NBC2_ANR2_SL2_LINK=1, .rsv_25=0}},
    .con2      ={.bits={.rsv_0=0, .NBC2_ANR2_C_SM_EDGE=1, .rsv_10=0, .NBC2_ANR2_FLT_C=0, .rsv_13=0}},
    .yad1      ={.bits={.rsv_0=0, .NBC2_ANR2_K_TH_C=8}},
    .y4lut1    ={.bits={.NBC2_ANR2_Y_CPX1=40, .NBC2_ANR2_Y_CPX2=120, .NBC2_ANR2_Y_CPX3=160, .rsv_24=0}},
    .y4lut2    ={.bits={.NBC2_ANR2_Y_SCALE_CPY0=16, .rsv_5=0, .NBC2_ANR2_Y_SCALE_CPY1=16, .rsv_13=0, .NBC2_ANR2_Y_SCALE_CPY2=16, .rsv_21=0, .NBC2_ANR2_Y_SCALE_CPY3=8, .rsv_29=0}},
    .y4lut3    ={.bits={.NBC2_ANR2_Y_SCALE_SP0=0, .rsv_5=0, .NBC2_ANR2_Y_SCALE_SP1=0, .rsv_13=0, .NBC2_ANR2_Y_SCALE_SP2=28, .rsv_21=0, .NBC2_ANR2_Y_SCALE_SP3=30, .rsv_29=0}},
    .l4lut1    ={.bits={.NBC2_ANR2_SL2_X1=64, .NBC2_ANR2_SL2_X2=128, .NBC2_ANR2_SL2_X3=192, .rsv_24=0}},
    .l4lut2    ={.bits={.NBC2_ANR2_SL2_GAIN0=16, .rsv_6=0, .NBC2_ANR2_SL2_GAIN1=20, .rsv_14=0, .NBC2_ANR2_SL2_GAIN2=24, .rsv_22=0, .NBC2_ANR2_SL2_GAIN3=32, .rsv_30=0}},
    .l4lut3    ={.bits={.NBC2_ANR2_SL2_SP0=8, .rsv_6=0, .NBC2_ANR2_SL2_SP1=8, .rsv_14=0, .NBC2_ANR2_SL2_SP2=16, .rsv_22=0, .NBC2_ANR2_SL2_SP3=16, .rsv_30=0}},
    .cad       ={.bits={.NBC2_ANR2_PTC_VGAIN=10, .NBC2_ANR2_C_GAIN=8, .NBC2_ANR2_PTC_GAIN_TH=0, .rsv_13=0, .NBC2_ANR2_C_L_DIFF_TH=24, .NBC2_ANR2_C_MODE=0, .rsv_25=0}},
    .ptc       ={.bits={.NBC2_ANR2_PTC1=2, .NBC2_ANR2_PTC2=3, .NBC2_ANR2_PTC3=4, .NBC2_ANR2_PTC4=6}},
    .sl2       ={.bits={.NBC2_ANR2_SL2_C_GAIN=6, .rsv_4=0, .NBC2_ANR2_LM_WT=4, .rsv_20=0}},
    .med1      ={.bits={.NBC2_ANR2_COR_TH=5, .rsv_5=0, .NBC2_ANR2_COR_SL=4, .rsv_11=0, .NBC2_ANR2_MCD_TH=5, .rsv_17=0, .NBC2_ANR2_MCD_SL=3, .rsv_23=0, .NBC2_ANR2_LCL_TH=32}},
    .med2      ={.bits={.NBC2_ANR2_LCL_SL=3, .rsv_3=0, .NBC2_ANR2_LCL_LV=16, .rsv_9=0, .NBC2_ANR2_SCL_TH=12, .rsv_18=0, .NBC2_ANR2_SCL_SL=3, .rsv_23=0, .NBC2_ANR2_SCL_LV=16, .rsv_29=0}},
    .med3      ={.bits={.NBC2_ANR2_NCL_TH=48, .NBC2_ANR2_NCL_SL=3, .rsv_11=0, .NBC2_ANR2_NCL_LV=16, .rsv_17=0, .NBC2_ANR2_VAR=3, .rsv_23=0, .NBC2_ANR2_Y0=10, .rsv_30=0}},
    .med4      ={.bits={.NBC2_ANR2_Y1=13, .rsv_6=0, .NBC2_ANR2_Y2=16, .rsv_14=0, .NBC2_ANR2_Y3=19, .rsv_22=0, .NBC2_ANR2_Y4=22, .rsv_30=0}},
    .med5      ={.bits={.NBC2_ANR2_LCL_OFT=0, .NBC2_ANR2_SCL_OFT=0, .rsv_14=0, .NBC2_ANR2_NCL_OFT=0, .rsv_24=0}},
    .actc      ={.bits={.rsv_0=0, .NBC2_ANR2_ACT_BLD_BASE_C=48, .rsv_15=0, .NBC2_ANR2_C_DITH_U=8, .rsv_21=0, .NBC2_ANR2_C_DITH_V=8, .rsv_29=0}}

};
const ISP_NVRAM_ANR2_T gc13a0mipiraw_NBC2_ANR2_0199 = {
        .con1      ={.bits={.NBC2_ANR2_ENC=1, .NBC2_ANR2_ENY=1, .rsv_2=0, .NBC2_ANR2_SCALE_MODE=0, .rsv_6=0, .NBC2_ANR2_VER_C_REF_Y=1, .rsv_9=0, .NBC2_ANR2_MODE=0, .rsv_13=0, .NBC2_ANR2_TILE_EDGE=15, .rsv_20=0, .NBC2_ANR2_SL2_LINK=1, .rsv_25=0}},
    .con2      ={.bits={.rsv_0=0, .NBC2_ANR2_C_SM_EDGE=1, .rsv_10=0, .NBC2_ANR2_FLT_C=0, .rsv_13=0}},
    .yad1      ={.bits={.rsv_0=0, .NBC2_ANR2_K_TH_C=8}},
    .y4lut1    ={.bits={.NBC2_ANR2_Y_CPX1=40, .NBC2_ANR2_Y_CPX2=120, .NBC2_ANR2_Y_CPX3=160, .rsv_24=0}},
    .y4lut2    ={.bits={.NBC2_ANR2_Y_SCALE_CPY0=16, .rsv_5=0, .NBC2_ANR2_Y_SCALE_CPY1=16, .rsv_13=0, .NBC2_ANR2_Y_SCALE_CPY2=16, .rsv_21=0, .NBC2_ANR2_Y_SCALE_CPY3=8, .rsv_29=0}},
    .y4lut3    ={.bits={.NBC2_ANR2_Y_SCALE_SP0=0, .rsv_5=0, .NBC2_ANR2_Y_SCALE_SP1=0, .rsv_13=0, .NBC2_ANR2_Y_SCALE_SP2=28, .rsv_21=0, .NBC2_ANR2_Y_SCALE_SP3=30, .rsv_29=0}},
    .l4lut1    ={.bits={.NBC2_ANR2_SL2_X1=64, .NBC2_ANR2_SL2_X2=128, .NBC2_ANR2_SL2_X3=192, .rsv_24=0}},
    .l4lut2    ={.bits={.NBC2_ANR2_SL2_GAIN0=16, .rsv_6=0, .NBC2_ANR2_SL2_GAIN1=20, .rsv_14=0, .NBC2_ANR2_SL2_GAIN2=24, .rsv_22=0, .NBC2_ANR2_SL2_GAIN3=32, .rsv_30=0}},
    .l4lut3    ={.bits={.NBC2_ANR2_SL2_SP0=8, .rsv_6=0, .NBC2_ANR2_SL2_SP1=8, .rsv_14=0, .NBC2_ANR2_SL2_SP2=16, .rsv_22=0, .NBC2_ANR2_SL2_SP3=16, .rsv_30=0}},
    .cad       ={.bits={.NBC2_ANR2_PTC_VGAIN=10, .NBC2_ANR2_C_GAIN=8, .NBC2_ANR2_PTC_GAIN_TH=0, .rsv_13=0, .NBC2_ANR2_C_L_DIFF_TH=24, .NBC2_ANR2_C_MODE=0, .rsv_25=0}},
    .ptc       ={.bits={.NBC2_ANR2_PTC1=2, .NBC2_ANR2_PTC2=3, .NBC2_ANR2_PTC3=4, .NBC2_ANR2_PTC4=6}},
    .sl2       ={.bits={.NBC2_ANR2_SL2_C_GAIN=6, .rsv_4=0, .NBC2_ANR2_LM_WT=4, .rsv_20=0}},
    .med1      ={.bits={.NBC2_ANR2_COR_TH=5, .rsv_5=0, .NBC2_ANR2_COR_SL=4, .rsv_11=0, .NBC2_ANR2_MCD_TH=5, .rsv_17=0, .NBC2_ANR2_MCD_SL=3, .rsv_23=0, .NBC2_ANR2_LCL_TH=32}},
    .med2      ={.bits={.NBC2_ANR2_LCL_SL=3, .rsv_3=0, .NBC2_ANR2_LCL_LV=16, .rsv_9=0, .NBC2_ANR2_SCL_TH=12, .rsv_18=0, .NBC2_ANR2_SCL_SL=3, .rsv_23=0, .NBC2_ANR2_SCL_LV=16, .rsv_29=0}},
    .med3      ={.bits={.NBC2_ANR2_NCL_TH=48, .NBC2_ANR2_NCL_SL=3, .rsv_11=0, .NBC2_ANR2_NCL_LV=16, .rsv_17=0, .NBC2_ANR2_VAR=3, .rsv_23=0, .NBC2_ANR2_Y0=10, .rsv_30=0}},
    .med4      ={.bits={.NBC2_ANR2_Y1=13, .rsv_6=0, .NBC2_ANR2_Y2=16, .rsv_14=0, .NBC2_ANR2_Y3=19, .rsv_22=0, .NBC2_ANR2_Y4=22, .rsv_30=0}},
    .med5      ={.bits={.NBC2_ANR2_LCL_OFT=0, .NBC2_ANR2_SCL_OFT=0, .rsv_14=0, .NBC2_ANR2_NCL_OFT=0, .rsv_24=0}},
    .actc      ={.bits={.rsv_0=0, .NBC2_ANR2_ACT_BLD_BASE_C=48, .rsv_15=0, .NBC2_ANR2_C_DITH_U=8, .rsv_21=0, .NBC2_ANR2_C_DITH_V=8, .rsv_29=0}}

};
const ISP_NVRAM_HFG_T gc13a0mipiraw_HFG_0140 = {
        .con_0     ={.bits={.DIP_HFC_STD=0, .HFC_LCE_LINK_EN=1, .rsv_9=0}},
    .luma_0    ={.bits={.HFC_LUMA_CPX1=64, .HFC_LUMA_CPX2=128, .HFC_LUMA_CPX3=192, .rsv_24=0}},
    .luma_1    ={.bits={.HFC_LUMA_CPY0=32, .rsv_6=0, .HFC_LUMA_CPY1=28, .rsv_14=0, .HFC_LUMA_CPY2=24, .rsv_22=0, .HFC_LUMA_CPY3=20, .rsv_30=0}},
    .luma_2    ={.bits={.HFC_LUMA_SP0=28, .rsv_5=0, .HFC_LUMA_SP1=28, .rsv_13=0, .HFC_LUMA_SP2=28, .rsv_21=0, .HFC_LUMA_SP3=28, .rsv_29=0}},
    .lce_0     ={.bits={.HFC_LCE_CPX1=64, .HFC_LCE_CPX2=128, .HFC_LCE_CPX3=192, .rsv_24=0}},
    .lce_1     ={.bits={.HFC_LCE_CPY0=16, .rsv_6=0, .HFC_LCE_CPY1=20, .rsv_14=0, .HFC_LCE_CPY2=24, .rsv_22=0, .HFC_LCE_CPY3=28, .rsv_30=0}},
    .lce_2     ={.bits={.HFC_LCE_SP0=4, .rsv_5=0, .HFC_LCE_SP1=4, .rsv_13=0, .HFC_LCE_SP2=4, .rsv_21=0, .HFC_LCE_SP3=4, .rsv_29=0}}

};
const ISP_NVRAM_HFG_T gc13a0mipiraw_HFG_0141 = {
        .con_0     ={.bits={.DIP_HFC_STD=0, .HFC_LCE_LINK_EN=1, .rsv_9=0}},
    .luma_0    ={.bits={.HFC_LUMA_CPX1=64, .HFC_LUMA_CPX2=128, .HFC_LUMA_CPX3=192, .rsv_24=0}},
    .luma_1    ={.bits={.HFC_LUMA_CPY0=32, .rsv_6=0, .HFC_LUMA_CPY1=28, .rsv_14=0, .HFC_LUMA_CPY2=24, .rsv_22=0, .HFC_LUMA_CPY3=20, .rsv_30=0}},
    .luma_2    ={.bits={.HFC_LUMA_SP0=28, .rsv_5=0, .HFC_LUMA_SP1=28, .rsv_13=0, .HFC_LUMA_SP2=28, .rsv_21=0, .HFC_LUMA_SP3=28, .rsv_29=0}},
    .lce_0     ={.bits={.HFC_LCE_CPX1=64, .HFC_LCE_CPX2=128, .HFC_LCE_CPX3=192, .rsv_24=0}},
    .lce_1     ={.bits={.HFC_LCE_CPY0=16, .rsv_6=0, .HFC_LCE_CPY1=20, .rsv_14=0, .HFC_LCE_CPY2=24, .rsv_22=0, .HFC_LCE_CPY3=28, .rsv_30=0}},
    .lce_2     ={.bits={.HFC_LCE_SP0=4, .rsv_5=0, .HFC_LCE_SP1=4, .rsv_13=0, .HFC_LCE_SP2=4, .rsv_21=0, .HFC_LCE_SP3=4, .rsv_29=0}}

};
const ISP_NVRAM_HFG_T gc13a0mipiraw_HFG_0142 = {
        .con_0     ={.bits={.DIP_HFC_STD=0, .HFC_LCE_LINK_EN=1, .rsv_9=0}},
    .luma_0    ={.bits={.HFC_LUMA_CPX1=64, .HFC_LUMA_CPX2=128, .HFC_LUMA_CPX3=192, .rsv_24=0}},
    .luma_1    ={.bits={.HFC_LUMA_CPY0=32, .rsv_6=0, .HFC_LUMA_CPY1=28, .rsv_14=0, .HFC_LUMA_CPY2=24, .rsv_22=0, .HFC_LUMA_CPY3=20, .rsv_30=0}},
    .luma_2    ={.bits={.HFC_LUMA_SP0=28, .rsv_5=0, .HFC_LUMA_SP1=28, .rsv_13=0, .HFC_LUMA_SP2=28, .rsv_21=0, .HFC_LUMA_SP3=28, .rsv_29=0}},
    .lce_0     ={.bits={.HFC_LCE_CPX1=64, .HFC_LCE_CPX2=128, .HFC_LCE_CPX3=192, .rsv_24=0}},
    .lce_1     ={.bits={.HFC_LCE_CPY0=16, .rsv_6=0, .HFC_LCE_CPY1=20, .rsv_14=0, .HFC_LCE_CPY2=24, .rsv_22=0, .HFC_LCE_CPY3=28, .rsv_30=0}},
    .lce_2     ={.bits={.HFC_LCE_SP0=4, .rsv_5=0, .HFC_LCE_SP1=4, .rsv_13=0, .HFC_LCE_SP2=4, .rsv_21=0, .HFC_LCE_SP3=4, .rsv_29=0}}

};
const ISP_NVRAM_HFG_T gc13a0mipiraw_HFG_0143 = {
        .con_0     ={.bits={.DIP_HFC_STD=0, .HFC_LCE_LINK_EN=1, .rsv_9=0}},
    .luma_0    ={.bits={.HFC_LUMA_CPX1=64, .HFC_LUMA_CPX2=128, .HFC_LUMA_CPX3=192, .rsv_24=0}},
    .luma_1    ={.bits={.HFC_LUMA_CPY0=32, .rsv_6=0, .HFC_LUMA_CPY1=28, .rsv_14=0, .HFC_LUMA_CPY2=24, .rsv_22=0, .HFC_LUMA_CPY3=20, .rsv_30=0}},
    .luma_2    ={.bits={.HFC_LUMA_SP0=28, .rsv_5=0, .HFC_LUMA_SP1=28, .rsv_13=0, .HFC_LUMA_SP2=28, .rsv_21=0, .HFC_LUMA_SP3=28, .rsv_29=0}},
    .lce_0     ={.bits={.HFC_LCE_CPX1=64, .HFC_LCE_CPX2=128, .HFC_LCE_CPX3=192, .rsv_24=0}},
    .lce_1     ={.bits={.HFC_LCE_CPY0=16, .rsv_6=0, .HFC_LCE_CPY1=20, .rsv_14=0, .HFC_LCE_CPY2=24, .rsv_22=0, .HFC_LCE_CPY3=28, .rsv_30=0}},
    .lce_2     ={.bits={.HFC_LCE_SP0=4, .rsv_5=0, .HFC_LCE_SP1=4, .rsv_13=0, .HFC_LCE_SP2=4, .rsv_21=0, .HFC_LCE_SP3=4, .rsv_29=0}}

};
const ISP_NVRAM_HFG_T gc13a0mipiraw_HFG_0144 = {
        .con_0     ={.bits={.DIP_HFC_STD=0, .HFC_LCE_LINK_EN=1, .rsv_9=0}},
    .luma_0    ={.bits={.HFC_LUMA_CPX1=64, .HFC_LUMA_CPX2=128, .HFC_LUMA_CPX3=192, .rsv_24=0}},
    .luma_1    ={.bits={.HFC_LUMA_CPY0=32, .rsv_6=0, .HFC_LUMA_CPY1=28, .rsv_14=0, .HFC_LUMA_CPY2=24, .rsv_22=0, .HFC_LUMA_CPY3=20, .rsv_30=0}},
    .luma_2    ={.bits={.HFC_LUMA_SP0=28, .rsv_5=0, .HFC_LUMA_SP1=28, .rsv_13=0, .HFC_LUMA_SP2=28, .rsv_21=0, .HFC_LUMA_SP3=28, .rsv_29=0}},
    .lce_0     ={.bits={.HFC_LCE_CPX1=64, .HFC_LCE_CPX2=128, .HFC_LCE_CPX3=192, .rsv_24=0}},
    .lce_1     ={.bits={.HFC_LCE_CPY0=16, .rsv_6=0, .HFC_LCE_CPY1=20, .rsv_14=0, .HFC_LCE_CPY2=24, .rsv_22=0, .HFC_LCE_CPY3=28, .rsv_30=0}},
    .lce_2     ={.bits={.HFC_LCE_SP0=4, .rsv_5=0, .HFC_LCE_SP1=4, .rsv_13=0, .HFC_LCE_SP2=4, .rsv_21=0, .HFC_LCE_SP3=4, .rsv_29=0}}

};
const ISP_NVRAM_HFG_T gc13a0mipiraw_HFG_0145 = {
        .con_0     ={.bits={.DIP_HFC_STD=0, .HFC_LCE_LINK_EN=1, .rsv_9=0}},
    .luma_0    ={.bits={.HFC_LUMA_CPX1=64, .HFC_LUMA_CPX2=128, .HFC_LUMA_CPX3=192, .rsv_24=0}},
    .luma_1    ={.bits={.HFC_LUMA_CPY0=32, .rsv_6=0, .HFC_LUMA_CPY1=28, .rsv_14=0, .HFC_LUMA_CPY2=24, .rsv_22=0, .HFC_LUMA_CPY3=20, .rsv_30=0}},
    .luma_2    ={.bits={.HFC_LUMA_SP0=28, .rsv_5=0, .HFC_LUMA_SP1=28, .rsv_13=0, .HFC_LUMA_SP2=28, .rsv_21=0, .HFC_LUMA_SP3=28, .rsv_29=0}},
    .lce_0     ={.bits={.HFC_LCE_CPX1=64, .HFC_LCE_CPX2=128, .HFC_LCE_CPX3=192, .rsv_24=0}},
    .lce_1     ={.bits={.HFC_LCE_CPY0=16, .rsv_6=0, .HFC_LCE_CPY1=20, .rsv_14=0, .HFC_LCE_CPY2=24, .rsv_22=0, .HFC_LCE_CPY3=28, .rsv_30=0}},
    .lce_2     ={.bits={.HFC_LCE_SP0=4, .rsv_5=0, .HFC_LCE_SP1=4, .rsv_13=0, .HFC_LCE_SP2=4, .rsv_21=0, .HFC_LCE_SP3=4, .rsv_29=0}}

};
const ISP_NVRAM_HFG_T gc13a0mipiraw_HFG_0146 = {
        .con_0     ={.bits={.DIP_HFC_STD=0, .HFC_LCE_LINK_EN=1, .rsv_9=0}},
    .luma_0    ={.bits={.HFC_LUMA_CPX1=64, .HFC_LUMA_CPX2=128, .HFC_LUMA_CPX3=192, .rsv_24=0}},
    .luma_1    ={.bits={.HFC_LUMA_CPY0=32, .rsv_6=0, .HFC_LUMA_CPY1=28, .rsv_14=0, .HFC_LUMA_CPY2=24, .rsv_22=0, .HFC_LUMA_CPY3=20, .rsv_30=0}},
    .luma_2    ={.bits={.HFC_LUMA_SP0=28, .rsv_5=0, .HFC_LUMA_SP1=28, .rsv_13=0, .HFC_LUMA_SP2=28, .rsv_21=0, .HFC_LUMA_SP3=28, .rsv_29=0}},
    .lce_0     ={.bits={.HFC_LCE_CPX1=64, .HFC_LCE_CPX2=128, .HFC_LCE_CPX3=192, .rsv_24=0}},
    .lce_1     ={.bits={.HFC_LCE_CPY0=16, .rsv_6=0, .HFC_LCE_CPY1=20, .rsv_14=0, .HFC_LCE_CPY2=24, .rsv_22=0, .HFC_LCE_CPY3=28, .rsv_30=0}},
    .lce_2     ={.bits={.HFC_LCE_SP0=4, .rsv_5=0, .HFC_LCE_SP1=4, .rsv_13=0, .HFC_LCE_SP2=4, .rsv_21=0, .HFC_LCE_SP3=4, .rsv_29=0}}

};
const ISP_NVRAM_HFG_T gc13a0mipiraw_HFG_0147 = {
        .con_0     ={.bits={.DIP_HFC_STD=0, .HFC_LCE_LINK_EN=1, .rsv_9=0}},
    .luma_0    ={.bits={.HFC_LUMA_CPX1=64, .HFC_LUMA_CPX2=128, .HFC_LUMA_CPX3=192, .rsv_24=0}},
    .luma_1    ={.bits={.HFC_LUMA_CPY0=32, .rsv_6=0, .HFC_LUMA_CPY1=28, .rsv_14=0, .HFC_LUMA_CPY2=24, .rsv_22=0, .HFC_LUMA_CPY3=20, .rsv_30=0}},
    .luma_2    ={.bits={.HFC_LUMA_SP0=28, .rsv_5=0, .HFC_LUMA_SP1=28, .rsv_13=0, .HFC_LUMA_SP2=28, .rsv_21=0, .HFC_LUMA_SP3=28, .rsv_29=0}},
    .lce_0     ={.bits={.HFC_LCE_CPX1=64, .HFC_LCE_CPX2=128, .HFC_LCE_CPX3=192, .rsv_24=0}},
    .lce_1     ={.bits={.HFC_LCE_CPY0=16, .rsv_6=0, .HFC_LCE_CPY1=20, .rsv_14=0, .HFC_LCE_CPY2=24, .rsv_22=0, .HFC_LCE_CPY3=28, .rsv_30=0}},
    .lce_2     ={.bits={.HFC_LCE_SP0=4, .rsv_5=0, .HFC_LCE_SP1=4, .rsv_13=0, .HFC_LCE_SP2=4, .rsv_21=0, .HFC_LCE_SP3=4, .rsv_29=0}}

};
const ISP_NVRAM_HFG_T gc13a0mipiraw_HFG_0148 = {
        .con_0     ={.bits={.DIP_HFC_STD=0, .HFC_LCE_LINK_EN=1, .rsv_9=0}},
    .luma_0    ={.bits={.HFC_LUMA_CPX1=64, .HFC_LUMA_CPX2=128, .HFC_LUMA_CPX3=192, .rsv_24=0}},
    .luma_1    ={.bits={.HFC_LUMA_CPY0=32, .rsv_6=0, .HFC_LUMA_CPY1=28, .rsv_14=0, .HFC_LUMA_CPY2=24, .rsv_22=0, .HFC_LUMA_CPY3=20, .rsv_30=0}},
    .luma_2    ={.bits={.HFC_LUMA_SP0=28, .rsv_5=0, .HFC_LUMA_SP1=28, .rsv_13=0, .HFC_LUMA_SP2=28, .rsv_21=0, .HFC_LUMA_SP3=28, .rsv_29=0}},
    .lce_0     ={.bits={.HFC_LCE_CPX1=64, .HFC_LCE_CPX2=128, .HFC_LCE_CPX3=192, .rsv_24=0}},
    .lce_1     ={.bits={.HFC_LCE_CPY0=16, .rsv_6=0, .HFC_LCE_CPY1=20, .rsv_14=0, .HFC_LCE_CPY2=24, .rsv_22=0, .HFC_LCE_CPY3=28, .rsv_30=0}},
    .lce_2     ={.bits={.HFC_LCE_SP0=4, .rsv_5=0, .HFC_LCE_SP1=4, .rsv_13=0, .HFC_LCE_SP2=4, .rsv_21=0, .HFC_LCE_SP3=4, .rsv_29=0}}

};
const ISP_NVRAM_HFG_T gc13a0mipiraw_HFG_0149 = {
        .con_0     ={.bits={.DIP_HFC_STD=0, .HFC_LCE_LINK_EN=1, .rsv_9=0}},
    .luma_0    ={.bits={.HFC_LUMA_CPX1=64, .HFC_LUMA_CPX2=128, .HFC_LUMA_CPX3=192, .rsv_24=0}},
    .luma_1    ={.bits={.HFC_LUMA_CPY0=32, .rsv_6=0, .HFC_LUMA_CPY1=28, .rsv_14=0, .HFC_LUMA_CPY2=24, .rsv_22=0, .HFC_LUMA_CPY3=20, .rsv_30=0}},
    .luma_2    ={.bits={.HFC_LUMA_SP0=28, .rsv_5=0, .HFC_LUMA_SP1=28, .rsv_13=0, .HFC_LUMA_SP2=28, .rsv_21=0, .HFC_LUMA_SP3=28, .rsv_29=0}},
    .lce_0     ={.bits={.HFC_LCE_CPX1=64, .HFC_LCE_CPX2=128, .HFC_LCE_CPX3=192, .rsv_24=0}},
    .lce_1     ={.bits={.HFC_LCE_CPY0=16, .rsv_6=0, .HFC_LCE_CPY1=20, .rsv_14=0, .HFC_LCE_CPY2=24, .rsv_22=0, .HFC_LCE_CPY3=28, .rsv_30=0}},
    .lce_2     ={.bits={.HFC_LCE_SP0=4, .rsv_5=0, .HFC_LCE_SP1=4, .rsv_13=0, .HFC_LCE_SP2=4, .rsv_21=0, .HFC_LCE_SP3=4, .rsv_29=0}}

};
const ISP_NVRAM_HFG_T gc13a0mipiraw_HFG_0150 = {
        .con_0     ={.bits={.DIP_HFC_STD=0, .HFC_LCE_LINK_EN=1, .rsv_9=0}},
    .luma_0    ={.bits={.HFC_LUMA_CPX1=64, .HFC_LUMA_CPX2=128, .HFC_LUMA_CPX3=192, .rsv_24=0}},
    .luma_1    ={.bits={.HFC_LUMA_CPY0=32, .rsv_6=0, .HFC_LUMA_CPY1=28, .rsv_14=0, .HFC_LUMA_CPY2=24, .rsv_22=0, .HFC_LUMA_CPY3=20, .rsv_30=0}},
    .luma_2    ={.bits={.HFC_LUMA_SP0=28, .rsv_5=0, .HFC_LUMA_SP1=28, .rsv_13=0, .HFC_LUMA_SP2=28, .rsv_21=0, .HFC_LUMA_SP3=28, .rsv_29=0}},
    .lce_0     ={.bits={.HFC_LCE_CPX1=64, .HFC_LCE_CPX2=128, .HFC_LCE_CPX3=192, .rsv_24=0}},
    .lce_1     ={.bits={.HFC_LCE_CPY0=16, .rsv_6=0, .HFC_LCE_CPY1=20, .rsv_14=0, .HFC_LCE_CPY2=24, .rsv_22=0, .HFC_LCE_CPY3=28, .rsv_30=0}},
    .lce_2     ={.bits={.HFC_LCE_SP0=4, .rsv_5=0, .HFC_LCE_SP1=4, .rsv_13=0, .HFC_LCE_SP2=4, .rsv_21=0, .HFC_LCE_SP3=4, .rsv_29=0}}

};
const ISP_NVRAM_HFG_T gc13a0mipiraw_HFG_0151 = {
        .con_0     ={.bits={.DIP_HFC_STD=0, .HFC_LCE_LINK_EN=1, .rsv_9=0}},
    .luma_0    ={.bits={.HFC_LUMA_CPX1=64, .HFC_LUMA_CPX2=128, .HFC_LUMA_CPX3=192, .rsv_24=0}},
    .luma_1    ={.bits={.HFC_LUMA_CPY0=32, .rsv_6=0, .HFC_LUMA_CPY1=28, .rsv_14=0, .HFC_LUMA_CPY2=24, .rsv_22=0, .HFC_LUMA_CPY3=20, .rsv_30=0}},
    .luma_2    ={.bits={.HFC_LUMA_SP0=28, .rsv_5=0, .HFC_LUMA_SP1=28, .rsv_13=0, .HFC_LUMA_SP2=28, .rsv_21=0, .HFC_LUMA_SP3=28, .rsv_29=0}},
    .lce_0     ={.bits={.HFC_LCE_CPX1=64, .HFC_LCE_CPX2=128, .HFC_LCE_CPX3=192, .rsv_24=0}},
    .lce_1     ={.bits={.HFC_LCE_CPY0=16, .rsv_6=0, .HFC_LCE_CPY1=20, .rsv_14=0, .HFC_LCE_CPY2=24, .rsv_22=0, .HFC_LCE_CPY3=28, .rsv_30=0}},
    .lce_2     ={.bits={.HFC_LCE_SP0=4, .rsv_5=0, .HFC_LCE_SP1=4, .rsv_13=0, .HFC_LCE_SP2=4, .rsv_21=0, .HFC_LCE_SP3=4, .rsv_29=0}}

};
const ISP_NVRAM_HFG_T gc13a0mipiraw_HFG_0152 = {
        .con_0     ={.bits={.DIP_HFC_STD=0, .HFC_LCE_LINK_EN=1, .rsv_9=0}},
    .luma_0    ={.bits={.HFC_LUMA_CPX1=64, .HFC_LUMA_CPX2=128, .HFC_LUMA_CPX3=192, .rsv_24=0}},
    .luma_1    ={.bits={.HFC_LUMA_CPY0=32, .rsv_6=0, .HFC_LUMA_CPY1=28, .rsv_14=0, .HFC_LUMA_CPY2=24, .rsv_22=0, .HFC_LUMA_CPY3=20, .rsv_30=0}},
    .luma_2    ={.bits={.HFC_LUMA_SP0=28, .rsv_5=0, .HFC_LUMA_SP1=28, .rsv_13=0, .HFC_LUMA_SP2=28, .rsv_21=0, .HFC_LUMA_SP3=28, .rsv_29=0}},
    .lce_0     ={.bits={.HFC_LCE_CPX1=64, .HFC_LCE_CPX2=128, .HFC_LCE_CPX3=192, .rsv_24=0}},
    .lce_1     ={.bits={.HFC_LCE_CPY0=16, .rsv_6=0, .HFC_LCE_CPY1=20, .rsv_14=0, .HFC_LCE_CPY2=24, .rsv_22=0, .HFC_LCE_CPY3=28, .rsv_30=0}},
    .lce_2     ={.bits={.HFC_LCE_SP0=4, .rsv_5=0, .HFC_LCE_SP1=4, .rsv_13=0, .HFC_LCE_SP2=4, .rsv_21=0, .HFC_LCE_SP3=4, .rsv_29=0}}

};
const ISP_NVRAM_HFG_T gc13a0mipiraw_HFG_0153 = {
        .con_0     ={.bits={.DIP_HFC_STD=0, .HFC_LCE_LINK_EN=1, .rsv_9=0}},
    .luma_0    ={.bits={.HFC_LUMA_CPX1=64, .HFC_LUMA_CPX2=128, .HFC_LUMA_CPX3=192, .rsv_24=0}},
    .luma_1    ={.bits={.HFC_LUMA_CPY0=32, .rsv_6=0, .HFC_LUMA_CPY1=28, .rsv_14=0, .HFC_LUMA_CPY2=24, .rsv_22=0, .HFC_LUMA_CPY3=20, .rsv_30=0}},
    .luma_2    ={.bits={.HFC_LUMA_SP0=28, .rsv_5=0, .HFC_LUMA_SP1=28, .rsv_13=0, .HFC_LUMA_SP2=28, .rsv_21=0, .HFC_LUMA_SP3=28, .rsv_29=0}},
    .lce_0     ={.bits={.HFC_LCE_CPX1=64, .HFC_LCE_CPX2=128, .HFC_LCE_CPX3=192, .rsv_24=0}},
    .lce_1     ={.bits={.HFC_LCE_CPY0=16, .rsv_6=0, .HFC_LCE_CPY1=20, .rsv_14=0, .HFC_LCE_CPY2=24, .rsv_22=0, .HFC_LCE_CPY3=28, .rsv_30=0}},
    .lce_2     ={.bits={.HFC_LCE_SP0=4, .rsv_5=0, .HFC_LCE_SP1=4, .rsv_13=0, .HFC_LCE_SP2=4, .rsv_21=0, .HFC_LCE_SP3=4, .rsv_29=0}}

};
const ISP_NVRAM_HFG_T gc13a0mipiraw_HFG_0154 = {
        .con_0     ={.bits={.DIP_HFC_STD=0, .HFC_LCE_LINK_EN=1, .rsv_9=0}},
    .luma_0    ={.bits={.HFC_LUMA_CPX1=64, .HFC_LUMA_CPX2=128, .HFC_LUMA_CPX3=192, .rsv_24=0}},
    .luma_1    ={.bits={.HFC_LUMA_CPY0=32, .rsv_6=0, .HFC_LUMA_CPY1=28, .rsv_14=0, .HFC_LUMA_CPY2=24, .rsv_22=0, .HFC_LUMA_CPY3=20, .rsv_30=0}},
    .luma_2    ={.bits={.HFC_LUMA_SP0=28, .rsv_5=0, .HFC_LUMA_SP1=28, .rsv_13=0, .HFC_LUMA_SP2=28, .rsv_21=0, .HFC_LUMA_SP3=28, .rsv_29=0}},
    .lce_0     ={.bits={.HFC_LCE_CPX1=64, .HFC_LCE_CPX2=128, .HFC_LCE_CPX3=192, .rsv_24=0}},
    .lce_1     ={.bits={.HFC_LCE_CPY0=16, .rsv_6=0, .HFC_LCE_CPY1=20, .rsv_14=0, .HFC_LCE_CPY2=24, .rsv_22=0, .HFC_LCE_CPY3=28, .rsv_30=0}},
    .lce_2     ={.bits={.HFC_LCE_SP0=4, .rsv_5=0, .HFC_LCE_SP1=4, .rsv_13=0, .HFC_LCE_SP2=4, .rsv_21=0, .HFC_LCE_SP3=4, .rsv_29=0}}

};
const ISP_NVRAM_HFG_T gc13a0mipiraw_HFG_0155 = {
        .con_0     ={.bits={.DIP_HFC_STD=0, .HFC_LCE_LINK_EN=1, .rsv_9=0}},
    .luma_0    ={.bits={.HFC_LUMA_CPX1=64, .HFC_LUMA_CPX2=128, .HFC_LUMA_CPX3=192, .rsv_24=0}},
    .luma_1    ={.bits={.HFC_LUMA_CPY0=32, .rsv_6=0, .HFC_LUMA_CPY1=28, .rsv_14=0, .HFC_LUMA_CPY2=24, .rsv_22=0, .HFC_LUMA_CPY3=20, .rsv_30=0}},
    .luma_2    ={.bits={.HFC_LUMA_SP0=28, .rsv_5=0, .HFC_LUMA_SP1=28, .rsv_13=0, .HFC_LUMA_SP2=28, .rsv_21=0, .HFC_LUMA_SP3=28, .rsv_29=0}},
    .lce_0     ={.bits={.HFC_LCE_CPX1=64, .HFC_LCE_CPX2=128, .HFC_LCE_CPX3=192, .rsv_24=0}},
    .lce_1     ={.bits={.HFC_LCE_CPY0=16, .rsv_6=0, .HFC_LCE_CPY1=20, .rsv_14=0, .HFC_LCE_CPY2=24, .rsv_22=0, .HFC_LCE_CPY3=28, .rsv_30=0}},
    .lce_2     ={.bits={.HFC_LCE_SP0=4, .rsv_5=0, .HFC_LCE_SP1=4, .rsv_13=0, .HFC_LCE_SP2=4, .rsv_21=0, .HFC_LCE_SP3=4, .rsv_29=0}}

};
const ISP_NVRAM_HFG_T gc13a0mipiraw_HFG_0156 = {
        .con_0     ={.bits={.DIP_HFC_STD=0, .HFC_LCE_LINK_EN=1, .rsv_9=0}},
    .luma_0    ={.bits={.HFC_LUMA_CPX1=64, .HFC_LUMA_CPX2=128, .HFC_LUMA_CPX3=192, .rsv_24=0}},
    .luma_1    ={.bits={.HFC_LUMA_CPY0=32, .rsv_6=0, .HFC_LUMA_CPY1=28, .rsv_14=0, .HFC_LUMA_CPY2=24, .rsv_22=0, .HFC_LUMA_CPY3=20, .rsv_30=0}},
    .luma_2    ={.bits={.HFC_LUMA_SP0=28, .rsv_5=0, .HFC_LUMA_SP1=28, .rsv_13=0, .HFC_LUMA_SP2=28, .rsv_21=0, .HFC_LUMA_SP3=28, .rsv_29=0}},
    .lce_0     ={.bits={.HFC_LCE_CPX1=64, .HFC_LCE_CPX2=128, .HFC_LCE_CPX3=192, .rsv_24=0}},
    .lce_1     ={.bits={.HFC_LCE_CPY0=16, .rsv_6=0, .HFC_LCE_CPY1=20, .rsv_14=0, .HFC_LCE_CPY2=24, .rsv_22=0, .HFC_LCE_CPY3=28, .rsv_30=0}},
    .lce_2     ={.bits={.HFC_LCE_SP0=4, .rsv_5=0, .HFC_LCE_SP1=4, .rsv_13=0, .HFC_LCE_SP2=4, .rsv_21=0, .HFC_LCE_SP3=4, .rsv_29=0}}

};
const ISP_NVRAM_HFG_T gc13a0mipiraw_HFG_0157 = {
        .con_0     ={.bits={.DIP_HFC_STD=0, .HFC_LCE_LINK_EN=1, .rsv_9=0}},
    .luma_0    ={.bits={.HFC_LUMA_CPX1=64, .HFC_LUMA_CPX2=128, .HFC_LUMA_CPX3=192, .rsv_24=0}},
    .luma_1    ={.bits={.HFC_LUMA_CPY0=32, .rsv_6=0, .HFC_LUMA_CPY1=28, .rsv_14=0, .HFC_LUMA_CPY2=24, .rsv_22=0, .HFC_LUMA_CPY3=20, .rsv_30=0}},
    .luma_2    ={.bits={.HFC_LUMA_SP0=28, .rsv_5=0, .HFC_LUMA_SP1=28, .rsv_13=0, .HFC_LUMA_SP2=28, .rsv_21=0, .HFC_LUMA_SP3=28, .rsv_29=0}},
    .lce_0     ={.bits={.HFC_LCE_CPX1=64, .HFC_LCE_CPX2=128, .HFC_LCE_CPX3=192, .rsv_24=0}},
    .lce_1     ={.bits={.HFC_LCE_CPY0=16, .rsv_6=0, .HFC_LCE_CPY1=20, .rsv_14=0, .HFC_LCE_CPY2=24, .rsv_22=0, .HFC_LCE_CPY3=28, .rsv_30=0}},
    .lce_2     ={.bits={.HFC_LCE_SP0=4, .rsv_5=0, .HFC_LCE_SP1=4, .rsv_13=0, .HFC_LCE_SP2=4, .rsv_21=0, .HFC_LCE_SP3=4, .rsv_29=0}}

};
const ISP_NVRAM_HFG_T gc13a0mipiraw_HFG_0158 = {
        .con_0     ={.bits={.DIP_HFC_STD=0, .HFC_LCE_LINK_EN=1, .rsv_9=0}},
    .luma_0    ={.bits={.HFC_LUMA_CPX1=64, .HFC_LUMA_CPX2=128, .HFC_LUMA_CPX3=192, .rsv_24=0}},
    .luma_1    ={.bits={.HFC_LUMA_CPY0=32, .rsv_6=0, .HFC_LUMA_CPY1=28, .rsv_14=0, .HFC_LUMA_CPY2=24, .rsv_22=0, .HFC_LUMA_CPY3=20, .rsv_30=0}},
    .luma_2    ={.bits={.HFC_LUMA_SP0=28, .rsv_5=0, .HFC_LUMA_SP1=28, .rsv_13=0, .HFC_LUMA_SP2=28, .rsv_21=0, .HFC_LUMA_SP3=28, .rsv_29=0}},
    .lce_0     ={.bits={.HFC_LCE_CPX1=64, .HFC_LCE_CPX2=128, .HFC_LCE_CPX3=192, .rsv_24=0}},
    .lce_1     ={.bits={.HFC_LCE_CPY0=16, .rsv_6=0, .HFC_LCE_CPY1=20, .rsv_14=0, .HFC_LCE_CPY2=24, .rsv_22=0, .HFC_LCE_CPY3=28, .rsv_30=0}},
    .lce_2     ={.bits={.HFC_LCE_SP0=4, .rsv_5=0, .HFC_LCE_SP1=4, .rsv_13=0, .HFC_LCE_SP2=4, .rsv_21=0, .HFC_LCE_SP3=4, .rsv_29=0}}

};
const ISP_NVRAM_HFG_T gc13a0mipiraw_HFG_0159 = {
        .con_0     ={.bits={.DIP_HFC_STD=0, .HFC_LCE_LINK_EN=1, .rsv_9=0}},
    .luma_0    ={.bits={.HFC_LUMA_CPX1=64, .HFC_LUMA_CPX2=128, .HFC_LUMA_CPX3=192, .rsv_24=0}},
    .luma_1    ={.bits={.HFC_LUMA_CPY0=32, .rsv_6=0, .HFC_LUMA_CPY1=28, .rsv_14=0, .HFC_LUMA_CPY2=24, .rsv_22=0, .HFC_LUMA_CPY3=20, .rsv_30=0}},
    .luma_2    ={.bits={.HFC_LUMA_SP0=28, .rsv_5=0, .HFC_LUMA_SP1=28, .rsv_13=0, .HFC_LUMA_SP2=28, .rsv_21=0, .HFC_LUMA_SP3=28, .rsv_29=0}},
    .lce_0     ={.bits={.HFC_LCE_CPX1=64, .HFC_LCE_CPX2=128, .HFC_LCE_CPX3=192, .rsv_24=0}},
    .lce_1     ={.bits={.HFC_LCE_CPY0=16, .rsv_6=0, .HFC_LCE_CPY1=20, .rsv_14=0, .HFC_LCE_CPY2=24, .rsv_22=0, .HFC_LCE_CPY3=28, .rsv_30=0}},
    .lce_2     ={.bits={.HFC_LCE_SP0=4, .rsv_5=0, .HFC_LCE_SP1=4, .rsv_13=0, .HFC_LCE_SP2=4, .rsv_21=0, .HFC_LCE_SP3=4, .rsv_29=0}}

};
const ISP_NVRAM_EE_T gc13a0mipiraw_EE_0140 = {
        .blnd_ctrl_1={.bits={.SEEE_H1_DI_BLND_OFST=0, .SEEE_H2_DI_BLND_OFST=0, .SEEE_H3_DI_BLND_OFST=0, .rsv_24=0}},
    .blnd_ctrl_2={.bits={.SEEE_H1_DI_BLND_SL=12, .SEEE_H2_DI_BLND_SL=12, .SEEE_H3_DI_BLND_SL=12, .SEEE_HX_ISO_BLND_RAT=3, .rsv_29=0}},
    .core_ctrl ={.bits={.SEEE_H1_FLT_CORE_TH=0, .SEEE_H2_FLT_CORE_TH=0, .SEEE_H3_FLT_CORE_TH=0, .SEEE_FLT_CORE_TH=8}},
    .gn_ctrl_1 ={.bits={.SEEE_H1_GN=12, .rsv_5=0, .SEEE_H2_GN=12, .rsv_13=0, .SEEE_H3_GN=12, .rsv_21=0}},
    .luma_ctrl_1={.bits={.SEEE_LUMA_MOD_Y0=256, .rsv_9=0, .SEEE_LUMA_MOD_Y1=256, .rsv_19=0, .SEEE_LUMA_MOD_Y2=256, .rsv_29=0}},
    .luma_ctrl_2={.bits={.SEEE_LUMA_MOD_Y3=256, .rsv_9=0, .SEEE_LUMA_MOD_Y4=256, .rsv_19=0, .SEEE_LUMA_MOD_Y5=256, .rsv_29=0}},
    .luma_slnk_ctrl={.bits={.SEEE_SLNK_GN_Y1=255, .SEEE_SLNK_GN_Y2=255, .SEEE_RESP_SLNK_GN_RAT=16, .SEEE_GLUT_LINK_EN=0, .SEEE_LUMA_MOD_Y6=256, .rsv_31=0}},
    .glut_ctrl_1={.bits={.SEEE_GLUT_S1=9, .SEEE_GLUT_X1=35, .SEEE_GLUT_Y1=20, .rsv_26=0}},
    .glut_ctrl_2={.bits={.SEEE_GLUT_S2=127, .SEEE_GLUT_X2=60, .SEEE_GLUT_Y2=614, .rsv_26=0}},
    .glut_ctrl_3={.bits={.SEEE_GLUT_S3=133, .SEEE_GLUT_X3=100, .SEEE_GLUT_Y3=307, .rsv_26=0}},
    .glut_ctrl_4={.bits={.SEEE_GLUT_S4=242, .SEEE_GLUT_X4=220, .SEEE_GLUT_Y4=200, .rsv_26=0}},
    .glut_ctrl_5={.bits={.SEEE_GLUT_S5=219, .rsv_8=0, .SEEE_GLUT_SL_DEC_Y=32, .rsv_26=0}},
    .glut_ctrl_6={.bits={.SEEE_GLUT_TH_OVR=255, .SEEE_GLUT_TH_UND=255, .SEEE_GLUT_TH_MIN=0, .rsv_24=0}},
    .artifact_ctrl={.bits={.SEEE_RESP_SMO_STR=7, .rsv_3=0, .SEEE_OVRSH_CLIP_STR=2, .rsv_7=0, .SEEE_DOT_REDUC_AMNT=128, .SEEE_DOT_TH=6, .rsv_24=0}},
    .clip_ctrl ={.bits={.SEEE_RESP_CLIP=64, .SEEE_RESP_CLIP_LUMA_SPC_TH=0, .SEEE_RESP_CLIP_LUMA_LWB=0, .SEEE_RESP_CLIP_LUMA_UPB=255}},
    .gn_ctrl_2 ={.bits={.SEEE_MASTER_GN_NEG=16, .SEEE_MASTER_GN_POS=16, .rsv_16=0}},
    .st_ctrl_1 ={.bits={.SEEE_ST_UB=12, .SEEE_ST_LB=4, .rsv_16=0}},
    .st_ctrl_2 ={.bits={.SEEE_ST_SL_CE=16, .SEEE_ST_OFST_CE=100, .SEEE_ST_SL_RESP=16, .SEEE_ST_OFST_RESP=100}},
    .ct_ctrl   ={.bits={.SEEE_LUMA_LMT_DIFF=255, .SEEE_LUMA_CNTST_LV=3, .rsv_11=0, .SEEE_LUMA_MINI=2, .rsv_15=0, .SEEE_LUMA_MAXI=2, .rsv_19=0, .SEEE_CHR_CNTST_LV=3, .rsv_23=0, .SEEE_CHR_MINI=2, .rsv_26=0, .SEEE_CHR_MAXI=2, .rsv_30=0}},
    .cboost_ctrl_1={.bits={.SEEE_CBOOST_LMT_U=255, .SEEE_CBOOST_LMT_L=64, .SEEE_CBOOST_GAIN=128, .SEEE_CBOOST_EN=1, .rsv_25=0}},
    .cboost_ctrl_2={.bits={.SEEE_CBOOST_YCONST=4, .SEEE_CBOOST_YOFFSET=0, .SEEE_CBOOST_YOFFSET_SEL=0, .rsv_18=0}},
    .pbc1_ctrl_1={.bits={.SEEE_PBC1_RADIUS_R=42, .rsv_6=0, .SEEE_PBC1_RSLOPE=85, .rsv_18=0, .SEEE_PBC1_RSLOPE_1=39, .SEEE_PBC1_EN=1, .SEEE_PBC_EN=0}},
    .pbc1_ctrl_2={.bits={.SEEE_PBC1_TSLOPE=85, .SEEE_PBC1_THETA_R=24, .SEEE_PBC1_THETA_C=149, .SEEE_PBC1_RADIUS_C=48}},
    .pbc1_ctrl_3={.bits={.SEEE_PBC1_LPF_GAIN=16, .SEEE_PBC1_LPF_EN=0, .SEEE_PBC1_EDGE_EN=0, .SEEE_PBC1_EDGE_SLOPE=32, .SEEE_PBC1_EDGE_THR=12, .SEEE_PBC1_CONF_GAIN=1, .SEEE_PBC1_GAIN=48}},
    .pbc2_ctrl_1={.bits={.SEEE_PBC2_RADIUS_R=40, .rsv_6=0, .SEEE_PBC2_RSLOPE=43, .rsv_18=0, .SEEE_PBC2_RSLOPE_1=32, .SEEE_PBC2_EN=1, .rsv_31=0}},
    .pbc2_ctrl_2={.bits={.SEEE_PBC2_TSLOPE=43, .SEEE_PBC2_THETA_R=24, .SEEE_PBC2_THETA_C=88, .SEEE_PBC2_RADIUS_C=48}},
    .pbc2_ctrl_3={.bits={.SEEE_PBC2_LPF_GAIN=10, .SEEE_PBC2_LPF_EN=1, .SEEE_PBC2_EDGE_EN=1, .SEEE_PBC2_EDGE_SLOPE=16, .SEEE_PBC2_EDGE_THR=16, .SEEE_PBC2_CONF_GAIN=4, .SEEE_PBC2_GAIN=0}},
    .pbc3_ctrl_1={.bits={.SEEE_PBC3_RADIUS_R=42, .rsv_6=0, .SEEE_PBC3_RSLOPE=32, .rsv_18=0, .SEEE_PBC3_RSLOPE_1=17, .SEEE_PBC3_EN=1, .rsv_31=0}},
    .pbc3_ctrl_2={.bits={.SEEE_PBC3_TSLOPE=64, .SEEE_PBC3_THETA_R=32, .SEEE_PBC3_THETA_C=224, .SEEE_PBC3_RADIUS_C=60}},
    .pbc3_ctrl_3={.bits={.SEEE_PBC3_LPF_GAIN=6, .SEEE_PBC3_LPF_EN=1, .SEEE_PBC3_EDGE_EN=1, .SEEE_PBC3_EDGE_SLOPE=32, .SEEE_PBC3_EDGE_THR=12, .SEEE_PBC3_CONF_GAIN=1, .SEEE_PBC3_GAIN=0}}

};
const ISP_NVRAM_EE_T gc13a0mipiraw_EE_0141 = {
        .blnd_ctrl_1={.bits={.SEEE_H1_DI_BLND_OFST=0, .SEEE_H2_DI_BLND_OFST=0, .SEEE_H3_DI_BLND_OFST=0, .rsv_24=0}},
    .blnd_ctrl_2={.bits={.SEEE_H1_DI_BLND_SL=12, .SEEE_H2_DI_BLND_SL=12, .SEEE_H3_DI_BLND_SL=12, .SEEE_HX_ISO_BLND_RAT=3, .rsv_29=0}},
    .core_ctrl ={.bits={.SEEE_H1_FLT_CORE_TH=0, .SEEE_H2_FLT_CORE_TH=0, .SEEE_H3_FLT_CORE_TH=0, .SEEE_FLT_CORE_TH=8}},
    .gn_ctrl_1 ={.bits={.SEEE_H1_GN=12, .rsv_5=0, .SEEE_H2_GN=12, .rsv_13=0, .SEEE_H3_GN=12, .rsv_21=0}},
    .luma_ctrl_1={.bits={.SEEE_LUMA_MOD_Y0=256, .rsv_9=0, .SEEE_LUMA_MOD_Y1=256, .rsv_19=0, .SEEE_LUMA_MOD_Y2=256, .rsv_29=0}},
    .luma_ctrl_2={.bits={.SEEE_LUMA_MOD_Y3=256, .rsv_9=0, .SEEE_LUMA_MOD_Y4=256, .rsv_19=0, .SEEE_LUMA_MOD_Y5=256, .rsv_29=0}},
    .luma_slnk_ctrl={.bits={.SEEE_SLNK_GN_Y1=255, .SEEE_SLNK_GN_Y2=255, .SEEE_RESP_SLNK_GN_RAT=16, .SEEE_GLUT_LINK_EN=0, .SEEE_LUMA_MOD_Y6=256, .rsv_31=0}},
    .glut_ctrl_1={.bits={.SEEE_GLUT_S1=9, .SEEE_GLUT_X1=35, .SEEE_GLUT_Y1=20, .rsv_26=0}},
    .glut_ctrl_2={.bits={.SEEE_GLUT_S2=127, .SEEE_GLUT_X2=60, .SEEE_GLUT_Y2=614, .rsv_26=0}},
    .glut_ctrl_3={.bits={.SEEE_GLUT_S3=133, .SEEE_GLUT_X3=100, .SEEE_GLUT_Y3=307, .rsv_26=0}},
    .glut_ctrl_4={.bits={.SEEE_GLUT_S4=242, .SEEE_GLUT_X4=220, .SEEE_GLUT_Y4=200, .rsv_26=0}},
    .glut_ctrl_5={.bits={.SEEE_GLUT_S5=219, .rsv_8=0, .SEEE_GLUT_SL_DEC_Y=32, .rsv_26=0}},
    .glut_ctrl_6={.bits={.SEEE_GLUT_TH_OVR=255, .SEEE_GLUT_TH_UND=255, .SEEE_GLUT_TH_MIN=0, .rsv_24=0}},
    .artifact_ctrl={.bits={.SEEE_RESP_SMO_STR=7, .rsv_3=0, .SEEE_OVRSH_CLIP_STR=2, .rsv_7=0, .SEEE_DOT_REDUC_AMNT=128, .SEEE_DOT_TH=6, .rsv_24=0}},
    .clip_ctrl ={.bits={.SEEE_RESP_CLIP=64, .SEEE_RESP_CLIP_LUMA_SPC_TH=0, .SEEE_RESP_CLIP_LUMA_LWB=0, .SEEE_RESP_CLIP_LUMA_UPB=255}},
    .gn_ctrl_2 ={.bits={.SEEE_MASTER_GN_NEG=16, .SEEE_MASTER_GN_POS=16, .rsv_16=0}},
    .st_ctrl_1 ={.bits={.SEEE_ST_UB=12, .SEEE_ST_LB=4, .rsv_16=0}},
    .st_ctrl_2 ={.bits={.SEEE_ST_SL_CE=16, .SEEE_ST_OFST_CE=100, .SEEE_ST_SL_RESP=16, .SEEE_ST_OFST_RESP=100}},
    .ct_ctrl   ={.bits={.SEEE_LUMA_LMT_DIFF=255, .SEEE_LUMA_CNTST_LV=3, .rsv_11=0, .SEEE_LUMA_MINI=2, .rsv_15=0, .SEEE_LUMA_MAXI=2, .rsv_19=0, .SEEE_CHR_CNTST_LV=3, .rsv_23=0, .SEEE_CHR_MINI=2, .rsv_26=0, .SEEE_CHR_MAXI=2, .rsv_30=0}},
    .cboost_ctrl_1={.bits={.SEEE_CBOOST_LMT_U=255, .SEEE_CBOOST_LMT_L=64, .SEEE_CBOOST_GAIN=128, .SEEE_CBOOST_EN=1, .rsv_25=0}},
    .cboost_ctrl_2={.bits={.SEEE_CBOOST_YCONST=4, .SEEE_CBOOST_YOFFSET=0, .SEEE_CBOOST_YOFFSET_SEL=0, .rsv_18=0}},
    .pbc1_ctrl_1={.bits={.SEEE_PBC1_RADIUS_R=42, .rsv_6=0, .SEEE_PBC1_RSLOPE=85, .rsv_18=0, .SEEE_PBC1_RSLOPE_1=39, .SEEE_PBC1_EN=1, .SEEE_PBC_EN=0}},
    .pbc1_ctrl_2={.bits={.SEEE_PBC1_TSLOPE=85, .SEEE_PBC1_THETA_R=24, .SEEE_PBC1_THETA_C=149, .SEEE_PBC1_RADIUS_C=48}},
    .pbc1_ctrl_3={.bits={.SEEE_PBC1_LPF_GAIN=16, .SEEE_PBC1_LPF_EN=0, .SEEE_PBC1_EDGE_EN=0, .SEEE_PBC1_EDGE_SLOPE=32, .SEEE_PBC1_EDGE_THR=12, .SEEE_PBC1_CONF_GAIN=1, .SEEE_PBC1_GAIN=48}},
    .pbc2_ctrl_1={.bits={.SEEE_PBC2_RADIUS_R=40, .rsv_6=0, .SEEE_PBC2_RSLOPE=43, .rsv_18=0, .SEEE_PBC2_RSLOPE_1=32, .SEEE_PBC2_EN=1, .rsv_31=0}},
    .pbc2_ctrl_2={.bits={.SEEE_PBC2_TSLOPE=43, .SEEE_PBC2_THETA_R=24, .SEEE_PBC2_THETA_C=88, .SEEE_PBC2_RADIUS_C=48}},
    .pbc2_ctrl_3={.bits={.SEEE_PBC2_LPF_GAIN=10, .SEEE_PBC2_LPF_EN=1, .SEEE_PBC2_EDGE_EN=1, .SEEE_PBC2_EDGE_SLOPE=16, .SEEE_PBC2_EDGE_THR=16, .SEEE_PBC2_CONF_GAIN=4, .SEEE_PBC2_GAIN=0}},
    .pbc3_ctrl_1={.bits={.SEEE_PBC3_RADIUS_R=42, .rsv_6=0, .SEEE_PBC3_RSLOPE=32, .rsv_18=0, .SEEE_PBC3_RSLOPE_1=17, .SEEE_PBC3_EN=1, .rsv_31=0}},
    .pbc3_ctrl_2={.bits={.SEEE_PBC3_TSLOPE=64, .SEEE_PBC3_THETA_R=32, .SEEE_PBC3_THETA_C=224, .SEEE_PBC3_RADIUS_C=60}},
    .pbc3_ctrl_3={.bits={.SEEE_PBC3_LPF_GAIN=6, .SEEE_PBC3_LPF_EN=1, .SEEE_PBC3_EDGE_EN=1, .SEEE_PBC3_EDGE_SLOPE=32, .SEEE_PBC3_EDGE_THR=12, .SEEE_PBC3_CONF_GAIN=1, .SEEE_PBC3_GAIN=0}}

};
const ISP_NVRAM_EE_T gc13a0mipiraw_EE_0142 = {
        .blnd_ctrl_1={.bits={.SEEE_H1_DI_BLND_OFST=0, .SEEE_H2_DI_BLND_OFST=0, .SEEE_H3_DI_BLND_OFST=0, .rsv_24=0}},
    .blnd_ctrl_2={.bits={.SEEE_H1_DI_BLND_SL=12, .SEEE_H2_DI_BLND_SL=12, .SEEE_H3_DI_BLND_SL=12, .SEEE_HX_ISO_BLND_RAT=3, .rsv_29=0}},
    .core_ctrl ={.bits={.SEEE_H1_FLT_CORE_TH=0, .SEEE_H2_FLT_CORE_TH=0, .SEEE_H3_FLT_CORE_TH=0, .SEEE_FLT_CORE_TH=8}},
    .gn_ctrl_1 ={.bits={.SEEE_H1_GN=10, .rsv_5=0, .SEEE_H2_GN=10, .rsv_13=0, .SEEE_H3_GN=5, .rsv_21=0}},
    .luma_ctrl_1={.bits={.SEEE_LUMA_MOD_Y0=256, .rsv_9=0, .SEEE_LUMA_MOD_Y1=256, .rsv_19=0, .SEEE_LUMA_MOD_Y2=256, .rsv_29=0}},
    .luma_ctrl_2={.bits={.SEEE_LUMA_MOD_Y3=256, .rsv_9=0, .SEEE_LUMA_MOD_Y4=256, .rsv_19=0, .SEEE_LUMA_MOD_Y5=256, .rsv_29=0}},
    .luma_slnk_ctrl={.bits={.SEEE_SLNK_GN_Y1=180, .SEEE_SLNK_GN_Y2=120, .SEEE_RESP_SLNK_GN_RAT=16, .SEEE_GLUT_LINK_EN=1, .SEEE_LUMA_MOD_Y6=256, .rsv_31=0}},
    .glut_ctrl_1={.bits={.SEEE_GLUT_S1=9, .SEEE_GLUT_X1=35, .SEEE_GLUT_Y1=20, .rsv_26=0}},
    .glut_ctrl_2={.bits={.SEEE_GLUT_S2=127, .SEEE_GLUT_X2=60, .SEEE_GLUT_Y2=300, .rsv_26=0}},
    .glut_ctrl_3={.bits={.SEEE_GLUT_S3=3, .SEEE_GLUT_X3=100, .SEEE_GLUT_Y3=307, .rsv_26=0}},
    .glut_ctrl_4={.bits={.SEEE_GLUT_S4=231, .SEEE_GLUT_X4=220, .SEEE_GLUT_Y4=120, .rsv_26=0}},
    .glut_ctrl_5={.bits={.SEEE_GLUT_S5=247, .rsv_8=0, .SEEE_GLUT_SL_DEC_Y=32, .rsv_26=0}},
    .glut_ctrl_6={.bits={.SEEE_GLUT_TH_OVR=255, .SEEE_GLUT_TH_UND=255, .SEEE_GLUT_TH_MIN=0, .rsv_24=0}},
    .artifact_ctrl={.bits={.SEEE_RESP_SMO_STR=7, .rsv_3=0, .SEEE_OVRSH_CLIP_STR=2, .rsv_7=0, .SEEE_DOT_REDUC_AMNT=128, .SEEE_DOT_TH=6, .rsv_24=0}},
    .clip_ctrl ={.bits={.SEEE_RESP_CLIP=64, .SEEE_RESP_CLIP_LUMA_SPC_TH=0, .SEEE_RESP_CLIP_LUMA_LWB=0, .SEEE_RESP_CLIP_LUMA_UPB=255}},
    .gn_ctrl_2 ={.bits={.SEEE_MASTER_GN_NEG=16, .SEEE_MASTER_GN_POS=16, .rsv_16=0}},
    .st_ctrl_1 ={.bits={.SEEE_ST_UB=12, .SEEE_ST_LB=4, .rsv_16=0}},
    .st_ctrl_2 ={.bits={.SEEE_ST_SL_CE=16, .SEEE_ST_OFST_CE=100, .SEEE_ST_SL_RESP=16, .SEEE_ST_OFST_RESP=100}},
    .ct_ctrl   ={.bits={.SEEE_LUMA_LMT_DIFF=255, .SEEE_LUMA_CNTST_LV=3, .rsv_11=0, .SEEE_LUMA_MINI=2, .rsv_15=0, .SEEE_LUMA_MAXI=2, .rsv_19=0, .SEEE_CHR_CNTST_LV=3, .rsv_23=0, .SEEE_CHR_MINI=2, .rsv_26=0, .SEEE_CHR_MAXI=2, .rsv_30=0}},
    .cboost_ctrl_1={.bits={.SEEE_CBOOST_LMT_U=255, .SEEE_CBOOST_LMT_L=64, .SEEE_CBOOST_GAIN=128, .SEEE_CBOOST_EN=1, .rsv_25=0}},
    .cboost_ctrl_2={.bits={.SEEE_CBOOST_YCONST=4, .SEEE_CBOOST_YOFFSET=0, .SEEE_CBOOST_YOFFSET_SEL=0, .rsv_18=0}},
    .pbc1_ctrl_1={.bits={.SEEE_PBC1_RADIUS_R=42, .rsv_6=0, .SEEE_PBC1_RSLOPE=85, .rsv_18=0, .SEEE_PBC1_RSLOPE_1=39, .SEEE_PBC1_EN=1, .SEEE_PBC_EN=0}},
    .pbc1_ctrl_2={.bits={.SEEE_PBC1_TSLOPE=85, .SEEE_PBC1_THETA_R=24, .SEEE_PBC1_THETA_C=149, .SEEE_PBC1_RADIUS_C=48}},
    .pbc1_ctrl_3={.bits={.SEEE_PBC1_LPF_GAIN=16, .SEEE_PBC1_LPF_EN=0, .SEEE_PBC1_EDGE_EN=0, .SEEE_PBC1_EDGE_SLOPE=32, .SEEE_PBC1_EDGE_THR=12, .SEEE_PBC1_CONF_GAIN=1, .SEEE_PBC1_GAIN=48}},
    .pbc2_ctrl_1={.bits={.SEEE_PBC2_RADIUS_R=40, .rsv_6=0, .SEEE_PBC2_RSLOPE=43, .rsv_18=0, .SEEE_PBC2_RSLOPE_1=32, .SEEE_PBC2_EN=1, .rsv_31=0}},
    .pbc2_ctrl_2={.bits={.SEEE_PBC2_TSLOPE=43, .SEEE_PBC2_THETA_R=24, .SEEE_PBC2_THETA_C=88, .SEEE_PBC2_RADIUS_C=48}},
    .pbc2_ctrl_3={.bits={.SEEE_PBC2_LPF_GAIN=10, .SEEE_PBC2_LPF_EN=1, .SEEE_PBC2_EDGE_EN=1, .SEEE_PBC2_EDGE_SLOPE=16, .SEEE_PBC2_EDGE_THR=16, .SEEE_PBC2_CONF_GAIN=4, .SEEE_PBC2_GAIN=0}},
    .pbc3_ctrl_1={.bits={.SEEE_PBC3_RADIUS_R=42, .rsv_6=0, .SEEE_PBC3_RSLOPE=32, .rsv_18=0, .SEEE_PBC3_RSLOPE_1=17, .SEEE_PBC3_EN=1, .rsv_31=0}},
    .pbc3_ctrl_2={.bits={.SEEE_PBC3_TSLOPE=64, .SEEE_PBC3_THETA_R=32, .SEEE_PBC3_THETA_C=224, .SEEE_PBC3_RADIUS_C=60}},
    .pbc3_ctrl_3={.bits={.SEEE_PBC3_LPF_GAIN=6, .SEEE_PBC3_LPF_EN=1, .SEEE_PBC3_EDGE_EN=1, .SEEE_PBC3_EDGE_SLOPE=32, .SEEE_PBC3_EDGE_THR=12, .SEEE_PBC3_CONF_GAIN=1, .SEEE_PBC3_GAIN=0}}

};
const ISP_NVRAM_EE_T gc13a0mipiraw_EE_0143 = {
        .blnd_ctrl_1={.bits={.SEEE_H1_DI_BLND_OFST=0, .SEEE_H2_DI_BLND_OFST=0, .SEEE_H3_DI_BLND_OFST=0, .rsv_24=0}},
    .blnd_ctrl_2={.bits={.SEEE_H1_DI_BLND_SL=12, .SEEE_H2_DI_BLND_SL=12, .SEEE_H3_DI_BLND_SL=12, .SEEE_HX_ISO_BLND_RAT=3, .rsv_29=0}},
    .core_ctrl ={.bits={.SEEE_H1_FLT_CORE_TH=0, .SEEE_H2_FLT_CORE_TH=0, .SEEE_H3_FLT_CORE_TH=0, .SEEE_FLT_CORE_TH=8}},
    .gn_ctrl_1 ={.bits={.SEEE_H1_GN=16, .rsv_5=0, .SEEE_H2_GN=12, .rsv_13=0, .SEEE_H3_GN=8, .rsv_21=0}},
    .luma_ctrl_1={.bits={.SEEE_LUMA_MOD_Y0=256, .rsv_9=0, .SEEE_LUMA_MOD_Y1=256, .rsv_19=0, .SEEE_LUMA_MOD_Y2=256, .rsv_29=0}},
    .luma_ctrl_2={.bits={.SEEE_LUMA_MOD_Y3=256, .rsv_9=0, .SEEE_LUMA_MOD_Y4=256, .rsv_19=0, .SEEE_LUMA_MOD_Y5=256, .rsv_29=0}},
    .luma_slnk_ctrl={.bits={.SEEE_SLNK_GN_Y1=200, .SEEE_SLNK_GN_Y2=120, .SEEE_RESP_SLNK_GN_RAT=16, .SEEE_GLUT_LINK_EN=1, .SEEE_LUMA_MOD_Y6=256, .rsv_31=0}},
    .glut_ctrl_1={.bits={.SEEE_GLUT_S1=9, .SEEE_GLUT_X1=35, .SEEE_GLUT_Y1=20, .rsv_26=0}},
    .glut_ctrl_2={.bits={.SEEE_GLUT_S2=127, .SEEE_GLUT_X2=60, .SEEE_GLUT_Y2=360, .rsv_26=0}},
    .glut_ctrl_3={.bits={.SEEE_GLUT_S3=116, .SEEE_GLUT_X3=100, .SEEE_GLUT_Y3=650, .rsv_26=0}},
    .glut_ctrl_4={.bits={.SEEE_GLUT_S4=229, .SEEE_GLUT_X4=220, .SEEE_GLUT_Y4=450, .rsv_26=0}},
    .glut_ctrl_5={.bits={.SEEE_GLUT_S5=128, .rsv_8=0, .SEEE_GLUT_SL_DEC_Y=32, .rsv_26=0}},
    .glut_ctrl_6={.bits={.SEEE_GLUT_TH_OVR=255, .SEEE_GLUT_TH_UND=255, .SEEE_GLUT_TH_MIN=0, .rsv_24=0}},
    .artifact_ctrl={.bits={.SEEE_RESP_SMO_STR=7, .rsv_3=0, .SEEE_OVRSH_CLIP_STR=2, .rsv_7=0, .SEEE_DOT_REDUC_AMNT=128, .SEEE_DOT_TH=6, .rsv_24=0}},
    .clip_ctrl ={.bits={.SEEE_RESP_CLIP=64, .SEEE_RESP_CLIP_LUMA_SPC_TH=0, .SEEE_RESP_CLIP_LUMA_LWB=0, .SEEE_RESP_CLIP_LUMA_UPB=255}},
    .gn_ctrl_2 ={.bits={.SEEE_MASTER_GN_NEG=16, .SEEE_MASTER_GN_POS=16, .rsv_16=0}},
    .st_ctrl_1 ={.bits={.SEEE_ST_UB=12, .SEEE_ST_LB=4, .rsv_16=0}},
    .st_ctrl_2 ={.bits={.SEEE_ST_SL_CE=16, .SEEE_ST_OFST_CE=100, .SEEE_ST_SL_RESP=16, .SEEE_ST_OFST_RESP=100}},
    .ct_ctrl   ={.bits={.SEEE_LUMA_LMT_DIFF=255, .SEEE_LUMA_CNTST_LV=3, .rsv_11=0, .SEEE_LUMA_MINI=2, .rsv_15=0, .SEEE_LUMA_MAXI=2, .rsv_19=0, .SEEE_CHR_CNTST_LV=3, .rsv_23=0, .SEEE_CHR_MINI=2, .rsv_26=0, .SEEE_CHR_MAXI=2, .rsv_30=0}},
    .cboost_ctrl_1={.bits={.SEEE_CBOOST_LMT_U=255, .SEEE_CBOOST_LMT_L=64, .SEEE_CBOOST_GAIN=128, .SEEE_CBOOST_EN=1, .rsv_25=0}},
    .cboost_ctrl_2={.bits={.SEEE_CBOOST_YCONST=4, .SEEE_CBOOST_YOFFSET=0, .SEEE_CBOOST_YOFFSET_SEL=0, .rsv_18=0}},
    .pbc1_ctrl_1={.bits={.SEEE_PBC1_RADIUS_R=42, .rsv_6=0, .SEEE_PBC1_RSLOPE=85, .rsv_18=0, .SEEE_PBC1_RSLOPE_1=39, .SEEE_PBC1_EN=1, .SEEE_PBC_EN=0}},
    .pbc1_ctrl_2={.bits={.SEEE_PBC1_TSLOPE=85, .SEEE_PBC1_THETA_R=24, .SEEE_PBC1_THETA_C=149, .SEEE_PBC1_RADIUS_C=48}},
    .pbc1_ctrl_3={.bits={.SEEE_PBC1_LPF_GAIN=16, .SEEE_PBC1_LPF_EN=0, .SEEE_PBC1_EDGE_EN=0, .SEEE_PBC1_EDGE_SLOPE=32, .SEEE_PBC1_EDGE_THR=12, .SEEE_PBC1_CONF_GAIN=1, .SEEE_PBC1_GAIN=48}},
    .pbc2_ctrl_1={.bits={.SEEE_PBC2_RADIUS_R=40, .rsv_6=0, .SEEE_PBC2_RSLOPE=43, .rsv_18=0, .SEEE_PBC2_RSLOPE_1=32, .SEEE_PBC2_EN=1, .rsv_31=0}},
    .pbc2_ctrl_2={.bits={.SEEE_PBC2_TSLOPE=43, .SEEE_PBC2_THETA_R=24, .SEEE_PBC2_THETA_C=88, .SEEE_PBC2_RADIUS_C=48}},
    .pbc2_ctrl_3={.bits={.SEEE_PBC2_LPF_GAIN=10, .SEEE_PBC2_LPF_EN=1, .SEEE_PBC2_EDGE_EN=1, .SEEE_PBC2_EDGE_SLOPE=16, .SEEE_PBC2_EDGE_THR=16, .SEEE_PBC2_CONF_GAIN=4, .SEEE_PBC2_GAIN=0}},
    .pbc3_ctrl_1={.bits={.SEEE_PBC3_RADIUS_R=42, .rsv_6=0, .SEEE_PBC3_RSLOPE=32, .rsv_18=0, .SEEE_PBC3_RSLOPE_1=17, .SEEE_PBC3_EN=1, .rsv_31=0}},
    .pbc3_ctrl_2={.bits={.SEEE_PBC3_TSLOPE=64, .SEEE_PBC3_THETA_R=32, .SEEE_PBC3_THETA_C=224, .SEEE_PBC3_RADIUS_C=60}},
    .pbc3_ctrl_3={.bits={.SEEE_PBC3_LPF_GAIN=6, .SEEE_PBC3_LPF_EN=1, .SEEE_PBC3_EDGE_EN=1, .SEEE_PBC3_EDGE_SLOPE=32, .SEEE_PBC3_EDGE_THR=12, .SEEE_PBC3_CONF_GAIN=1, .SEEE_PBC3_GAIN=0}}

};
const ISP_NVRAM_EE_T gc13a0mipiraw_EE_0144 = {
        .blnd_ctrl_1={.bits={.SEEE_H1_DI_BLND_OFST=0, .SEEE_H2_DI_BLND_OFST=0, .SEEE_H3_DI_BLND_OFST=0, .rsv_24=0}},
    .blnd_ctrl_2={.bits={.SEEE_H1_DI_BLND_SL=12, .SEEE_H2_DI_BLND_SL=12, .SEEE_H3_DI_BLND_SL=12, .SEEE_HX_ISO_BLND_RAT=3, .rsv_29=0}},
    .core_ctrl ={.bits={.SEEE_H1_FLT_CORE_TH=0, .SEEE_H2_FLT_CORE_TH=0, .SEEE_H3_FLT_CORE_TH=0, .SEEE_FLT_CORE_TH=8}},
    .gn_ctrl_1 ={.bits={.SEEE_H1_GN=8, .rsv_5=0, .SEEE_H2_GN=5, .rsv_13=0, .SEEE_H3_GN=5, .rsv_21=0}},
    .luma_ctrl_1={.bits={.SEEE_LUMA_MOD_Y0=256, .rsv_9=0, .SEEE_LUMA_MOD_Y1=256, .rsv_19=0, .SEEE_LUMA_MOD_Y2=256, .rsv_29=0}},
    .luma_ctrl_2={.bits={.SEEE_LUMA_MOD_Y3=256, .rsv_9=0, .SEEE_LUMA_MOD_Y4=256, .rsv_19=0, .SEEE_LUMA_MOD_Y5=256, .rsv_29=0}},
    .luma_slnk_ctrl={.bits={.SEEE_SLNK_GN_Y1=180, .SEEE_SLNK_GN_Y2=120, .SEEE_RESP_SLNK_GN_RAT=16, .SEEE_GLUT_LINK_EN=1, .SEEE_LUMA_MOD_Y6=256, .rsv_31=0}},
    .glut_ctrl_1={.bits={.SEEE_GLUT_S1=9, .SEEE_GLUT_X1=35, .SEEE_GLUT_Y1=20, .rsv_26=0}},
    .glut_ctrl_2={.bits={.SEEE_GLUT_S2=127, .SEEE_GLUT_X2=60, .SEEE_GLUT_Y2=360, .rsv_26=0}},
    .glut_ctrl_3={.bits={.SEEE_GLUT_S3=240, .SEEE_GLUT_X3=100, .SEEE_GLUT_Y3=320, .rsv_26=0}},
    .glut_ctrl_4={.bits={.SEEE_GLUT_S4=229, .SEEE_GLUT_X4=220, .SEEE_GLUT_Y4=120, .rsv_26=0}},
    .glut_ctrl_5={.bits={.SEEE_GLUT_S5=219, .rsv_8=0, .SEEE_GLUT_SL_DEC_Y=32, .rsv_26=0}},
    .glut_ctrl_6={.bits={.SEEE_GLUT_TH_OVR=255, .SEEE_GLUT_TH_UND=255, .SEEE_GLUT_TH_MIN=0, .rsv_24=0}},
    .artifact_ctrl={.bits={.SEEE_RESP_SMO_STR=7, .rsv_3=0, .SEEE_OVRSH_CLIP_STR=2, .rsv_7=0, .SEEE_DOT_REDUC_AMNT=128, .SEEE_DOT_TH=6, .rsv_24=0}},
    .clip_ctrl ={.bits={.SEEE_RESP_CLIP=64, .SEEE_RESP_CLIP_LUMA_SPC_TH=0, .SEEE_RESP_CLIP_LUMA_LWB=0, .SEEE_RESP_CLIP_LUMA_UPB=255}},
    .gn_ctrl_2 ={.bits={.SEEE_MASTER_GN_NEG=16, .SEEE_MASTER_GN_POS=16, .rsv_16=0}},
    .st_ctrl_1 ={.bits={.SEEE_ST_UB=12, .SEEE_ST_LB=4, .rsv_16=0}},
    .st_ctrl_2 ={.bits={.SEEE_ST_SL_CE=16, .SEEE_ST_OFST_CE=100, .SEEE_ST_SL_RESP=16, .SEEE_ST_OFST_RESP=100}},
    .ct_ctrl   ={.bits={.SEEE_LUMA_LMT_DIFF=255, .SEEE_LUMA_CNTST_LV=3, .rsv_11=0, .SEEE_LUMA_MINI=2, .rsv_15=0, .SEEE_LUMA_MAXI=2, .rsv_19=0, .SEEE_CHR_CNTST_LV=3, .rsv_23=0, .SEEE_CHR_MINI=2, .rsv_26=0, .SEEE_CHR_MAXI=2, .rsv_30=0}},
    .cboost_ctrl_1={.bits={.SEEE_CBOOST_LMT_U=255, .SEEE_CBOOST_LMT_L=64, .SEEE_CBOOST_GAIN=128, .SEEE_CBOOST_EN=1, .rsv_25=0}},
    .cboost_ctrl_2={.bits={.SEEE_CBOOST_YCONST=4, .SEEE_CBOOST_YOFFSET=0, .SEEE_CBOOST_YOFFSET_SEL=0, .rsv_18=0}},
    .pbc1_ctrl_1={.bits={.SEEE_PBC1_RADIUS_R=42, .rsv_6=0, .SEEE_PBC1_RSLOPE=85, .rsv_18=0, .SEEE_PBC1_RSLOPE_1=39, .SEEE_PBC1_EN=1, .SEEE_PBC_EN=0}},
    .pbc1_ctrl_2={.bits={.SEEE_PBC1_TSLOPE=85, .SEEE_PBC1_THETA_R=24, .SEEE_PBC1_THETA_C=149, .SEEE_PBC1_RADIUS_C=48}},
    .pbc1_ctrl_3={.bits={.SEEE_PBC1_LPF_GAIN=16, .SEEE_PBC1_LPF_EN=0, .SEEE_PBC1_EDGE_EN=0, .SEEE_PBC1_EDGE_SLOPE=32, .SEEE_PBC1_EDGE_THR=12, .SEEE_PBC1_CONF_GAIN=1, .SEEE_PBC1_GAIN=48}},
    .pbc2_ctrl_1={.bits={.SEEE_PBC2_RADIUS_R=40, .rsv_6=0, .SEEE_PBC2_RSLOPE=43, .rsv_18=0, .SEEE_PBC2_RSLOPE_1=32, .SEEE_PBC2_EN=1, .rsv_31=0}},
    .pbc2_ctrl_2={.bits={.SEEE_PBC2_TSLOPE=43, .SEEE_PBC2_THETA_R=24, .SEEE_PBC2_THETA_C=88, .SEEE_PBC2_RADIUS_C=48}},
    .pbc2_ctrl_3={.bits={.SEEE_PBC2_LPF_GAIN=10, .SEEE_PBC2_LPF_EN=1, .SEEE_PBC2_EDGE_EN=1, .SEEE_PBC2_EDGE_SLOPE=16, .SEEE_PBC2_EDGE_THR=16, .SEEE_PBC2_CONF_GAIN=4, .SEEE_PBC2_GAIN=0}},
    .pbc3_ctrl_1={.bits={.SEEE_PBC3_RADIUS_R=42, .rsv_6=0, .SEEE_PBC3_RSLOPE=32, .rsv_18=0, .SEEE_PBC3_RSLOPE_1=17, .SEEE_PBC3_EN=1, .rsv_31=0}},
    .pbc3_ctrl_2={.bits={.SEEE_PBC3_TSLOPE=64, .SEEE_PBC3_THETA_R=32, .SEEE_PBC3_THETA_C=224, .SEEE_PBC3_RADIUS_C=60}},
    .pbc3_ctrl_3={.bits={.SEEE_PBC3_LPF_GAIN=6, .SEEE_PBC3_LPF_EN=1, .SEEE_PBC3_EDGE_EN=1, .SEEE_PBC3_EDGE_SLOPE=32, .SEEE_PBC3_EDGE_THR=12, .SEEE_PBC3_CONF_GAIN=1, .SEEE_PBC3_GAIN=0}}

};
const ISP_NVRAM_EE_T gc13a0mipiraw_EE_0145 = {
        .blnd_ctrl_1={.bits={.SEEE_H1_DI_BLND_OFST=0, .SEEE_H2_DI_BLND_OFST=0, .SEEE_H3_DI_BLND_OFST=0, .rsv_24=0}},
    .blnd_ctrl_2={.bits={.SEEE_H1_DI_BLND_SL=12, .SEEE_H2_DI_BLND_SL=12, .SEEE_H3_DI_BLND_SL=12, .SEEE_HX_ISO_BLND_RAT=3, .rsv_29=0}},
    .core_ctrl ={.bits={.SEEE_H1_FLT_CORE_TH=0, .SEEE_H2_FLT_CORE_TH=0, .SEEE_H3_FLT_CORE_TH=0, .SEEE_FLT_CORE_TH=8}},
    .gn_ctrl_1 ={.bits={.SEEE_H1_GN=14, .rsv_5=0, .SEEE_H2_GN=4, .rsv_13=0, .SEEE_H3_GN=1, .rsv_21=0}},
    .luma_ctrl_1={.bits={.SEEE_LUMA_MOD_Y0=256, .rsv_9=0, .SEEE_LUMA_MOD_Y1=256, .rsv_19=0, .SEEE_LUMA_MOD_Y2=256, .rsv_29=0}},
    .luma_ctrl_2={.bits={.SEEE_LUMA_MOD_Y3=256, .rsv_9=0, .SEEE_LUMA_MOD_Y4=256, .rsv_19=0, .SEEE_LUMA_MOD_Y5=256, .rsv_29=0}},
    .luma_slnk_ctrl={.bits={.SEEE_SLNK_GN_Y1=255, .SEEE_SLNK_GN_Y2=255, .SEEE_RESP_SLNK_GN_RAT=16, .SEEE_GLUT_LINK_EN=0, .SEEE_LUMA_MOD_Y6=256, .rsv_31=0}},
    .glut_ctrl_1={.bits={.SEEE_GLUT_S1=1, .SEEE_GLUT_X1=35, .SEEE_GLUT_Y1=20, .rsv_26=0}},
    .glut_ctrl_2={.bits={.SEEE_GLUT_S2=24, .SEEE_GLUT_X2=60, .SEEE_GLUT_Y2=614, .rsv_26=0}},
    .glut_ctrl_3={.bits={.SEEE_GLUT_S3=248, .SEEE_GLUT_X3=100, .SEEE_GLUT_Y3=307, .rsv_26=0}},
    .glut_ctrl_4={.bits={.SEEE_GLUT_S4=254, .SEEE_GLUT_X4=220, .SEEE_GLUT_Y4=41, .rsv_26=0}},
    .glut_ctrl_5={.bits={.SEEE_GLUT_S5=255, .rsv_8=0, .SEEE_GLUT_SL_DEC_Y=32, .rsv_26=0}},
    .glut_ctrl_6={.bits={.SEEE_GLUT_TH_OVR=255, .SEEE_GLUT_TH_UND=255, .SEEE_GLUT_TH_MIN=0, .rsv_24=0}},
    .artifact_ctrl={.bits={.SEEE_RESP_SMO_STR=7, .rsv_3=0, .SEEE_OVRSH_CLIP_STR=2, .rsv_7=0, .SEEE_DOT_REDUC_AMNT=128, .SEEE_DOT_TH=6, .rsv_24=0}},
    .clip_ctrl ={.bits={.SEEE_RESP_CLIP=64, .SEEE_RESP_CLIP_LUMA_SPC_TH=0, .SEEE_RESP_CLIP_LUMA_LWB=0, .SEEE_RESP_CLIP_LUMA_UPB=255}},
    .gn_ctrl_2 ={.bits={.SEEE_MASTER_GN_NEG=16, .SEEE_MASTER_GN_POS=16, .rsv_16=0}},
    .st_ctrl_1 ={.bits={.SEEE_ST_UB=12, .SEEE_ST_LB=4, .rsv_16=0}},
    .st_ctrl_2 ={.bits={.SEEE_ST_SL_CE=16, .SEEE_ST_OFST_CE=100, .SEEE_ST_SL_RESP=16, .SEEE_ST_OFST_RESP=100}},
    .ct_ctrl   ={.bits={.SEEE_LUMA_LMT_DIFF=255, .SEEE_LUMA_CNTST_LV=3, .rsv_11=0, .SEEE_LUMA_MINI=2, .rsv_15=0, .SEEE_LUMA_MAXI=2, .rsv_19=0, .SEEE_CHR_CNTST_LV=3, .rsv_23=0, .SEEE_CHR_MINI=2, .rsv_26=0, .SEEE_CHR_MAXI=2, .rsv_30=0}},
    .cboost_ctrl_1={.bits={.SEEE_CBOOST_LMT_U=255, .SEEE_CBOOST_LMT_L=64, .SEEE_CBOOST_GAIN=128, .SEEE_CBOOST_EN=1, .rsv_25=0}},
    .cboost_ctrl_2={.bits={.SEEE_CBOOST_YCONST=4, .SEEE_CBOOST_YOFFSET=0, .SEEE_CBOOST_YOFFSET_SEL=0, .rsv_18=0}},
    .pbc1_ctrl_1={.bits={.SEEE_PBC1_RADIUS_R=42, .rsv_6=0, .SEEE_PBC1_RSLOPE=85, .rsv_18=0, .SEEE_PBC1_RSLOPE_1=39, .SEEE_PBC1_EN=1, .SEEE_PBC_EN=0}},
    .pbc1_ctrl_2={.bits={.SEEE_PBC1_TSLOPE=85, .SEEE_PBC1_THETA_R=24, .SEEE_PBC1_THETA_C=149, .SEEE_PBC1_RADIUS_C=48}},
    .pbc1_ctrl_3={.bits={.SEEE_PBC1_LPF_GAIN=16, .SEEE_PBC1_LPF_EN=0, .SEEE_PBC1_EDGE_EN=0, .SEEE_PBC1_EDGE_SLOPE=32, .SEEE_PBC1_EDGE_THR=12, .SEEE_PBC1_CONF_GAIN=1, .SEEE_PBC1_GAIN=48}},
    .pbc2_ctrl_1={.bits={.SEEE_PBC2_RADIUS_R=40, .rsv_6=0, .SEEE_PBC2_RSLOPE=43, .rsv_18=0, .SEEE_PBC2_RSLOPE_1=32, .SEEE_PBC2_EN=1, .rsv_31=0}},
    .pbc2_ctrl_2={.bits={.SEEE_PBC2_TSLOPE=43, .SEEE_PBC2_THETA_R=24, .SEEE_PBC2_THETA_C=88, .SEEE_PBC2_RADIUS_C=48}},
    .pbc2_ctrl_3={.bits={.SEEE_PBC2_LPF_GAIN=10, .SEEE_PBC2_LPF_EN=1, .SEEE_PBC2_EDGE_EN=1, .SEEE_PBC2_EDGE_SLOPE=16, .SEEE_PBC2_EDGE_THR=16, .SEEE_PBC2_CONF_GAIN=4, .SEEE_PBC2_GAIN=0}},
    .pbc3_ctrl_1={.bits={.SEEE_PBC3_RADIUS_R=42, .rsv_6=0, .SEEE_PBC3_RSLOPE=32, .rsv_18=0, .SEEE_PBC3_RSLOPE_1=17, .SEEE_PBC3_EN=1, .rsv_31=0}},
    .pbc3_ctrl_2={.bits={.SEEE_PBC3_TSLOPE=64, .SEEE_PBC3_THETA_R=32, .SEEE_PBC3_THETA_C=224, .SEEE_PBC3_RADIUS_C=60}},
    .pbc3_ctrl_3={.bits={.SEEE_PBC3_LPF_GAIN=6, .SEEE_PBC3_LPF_EN=1, .SEEE_PBC3_EDGE_EN=1, .SEEE_PBC3_EDGE_SLOPE=32, .SEEE_PBC3_EDGE_THR=12, .SEEE_PBC3_CONF_GAIN=1, .SEEE_PBC3_GAIN=0}}

};
const ISP_NVRAM_EE_T gc13a0mipiraw_EE_0146 = {
        .blnd_ctrl_1={.bits={.SEEE_H1_DI_BLND_OFST=0, .SEEE_H2_DI_BLND_OFST=0, .SEEE_H3_DI_BLND_OFST=0, .rsv_24=0}},
    .blnd_ctrl_2={.bits={.SEEE_H1_DI_BLND_SL=12, .SEEE_H2_DI_BLND_SL=12, .SEEE_H3_DI_BLND_SL=12, .SEEE_HX_ISO_BLND_RAT=3, .rsv_29=0}},
    .core_ctrl ={.bits={.SEEE_H1_FLT_CORE_TH=0, .SEEE_H2_FLT_CORE_TH=0, .SEEE_H3_FLT_CORE_TH=0, .SEEE_FLT_CORE_TH=8}},
    .gn_ctrl_1 ={.bits={.SEEE_H1_GN=14, .rsv_5=0, .SEEE_H2_GN=4, .rsv_13=0, .SEEE_H3_GN=1, .rsv_21=0}},
    .luma_ctrl_1={.bits={.SEEE_LUMA_MOD_Y0=256, .rsv_9=0, .SEEE_LUMA_MOD_Y1=256, .rsv_19=0, .SEEE_LUMA_MOD_Y2=256, .rsv_29=0}},
    .luma_ctrl_2={.bits={.SEEE_LUMA_MOD_Y3=256, .rsv_9=0, .SEEE_LUMA_MOD_Y4=256, .rsv_19=0, .SEEE_LUMA_MOD_Y5=256, .rsv_29=0}},
    .luma_slnk_ctrl={.bits={.SEEE_SLNK_GN_Y1=255, .SEEE_SLNK_GN_Y2=255, .SEEE_RESP_SLNK_GN_RAT=16, .SEEE_GLUT_LINK_EN=0, .SEEE_LUMA_MOD_Y6=256, .rsv_31=0}},
    .glut_ctrl_1={.bits={.SEEE_GLUT_S1=1, .SEEE_GLUT_X1=35, .SEEE_GLUT_Y1=20, .rsv_26=0}},
    .glut_ctrl_2={.bits={.SEEE_GLUT_S2=24, .SEEE_GLUT_X2=60, .SEEE_GLUT_Y2=614, .rsv_26=0}},
    .glut_ctrl_3={.bits={.SEEE_GLUT_S3=248, .SEEE_GLUT_X3=100, .SEEE_GLUT_Y3=307, .rsv_26=0}},
    .glut_ctrl_4={.bits={.SEEE_GLUT_S4=254, .SEEE_GLUT_X4=220, .SEEE_GLUT_Y4=41, .rsv_26=0}},
    .glut_ctrl_5={.bits={.SEEE_GLUT_S5=255, .rsv_8=0, .SEEE_GLUT_SL_DEC_Y=32, .rsv_26=0}},
    .glut_ctrl_6={.bits={.SEEE_GLUT_TH_OVR=255, .SEEE_GLUT_TH_UND=255, .SEEE_GLUT_TH_MIN=0, .rsv_24=0}},
    .artifact_ctrl={.bits={.SEEE_RESP_SMO_STR=7, .rsv_3=0, .SEEE_OVRSH_CLIP_STR=2, .rsv_7=0, .SEEE_DOT_REDUC_AMNT=128, .SEEE_DOT_TH=6, .rsv_24=0}},
    .clip_ctrl ={.bits={.SEEE_RESP_CLIP=64, .SEEE_RESP_CLIP_LUMA_SPC_TH=0, .SEEE_RESP_CLIP_LUMA_LWB=0, .SEEE_RESP_CLIP_LUMA_UPB=255}},
    .gn_ctrl_2 ={.bits={.SEEE_MASTER_GN_NEG=16, .SEEE_MASTER_GN_POS=16, .rsv_16=0}},
    .st_ctrl_1 ={.bits={.SEEE_ST_UB=12, .SEEE_ST_LB=4, .rsv_16=0}},
    .st_ctrl_2 ={.bits={.SEEE_ST_SL_CE=16, .SEEE_ST_OFST_CE=100, .SEEE_ST_SL_RESP=16, .SEEE_ST_OFST_RESP=100}},
    .ct_ctrl   ={.bits={.SEEE_LUMA_LMT_DIFF=255, .SEEE_LUMA_CNTST_LV=3, .rsv_11=0, .SEEE_LUMA_MINI=2, .rsv_15=0, .SEEE_LUMA_MAXI=2, .rsv_19=0, .SEEE_CHR_CNTST_LV=3, .rsv_23=0, .SEEE_CHR_MINI=2, .rsv_26=0, .SEEE_CHR_MAXI=2, .rsv_30=0}},
    .cboost_ctrl_1={.bits={.SEEE_CBOOST_LMT_U=255, .SEEE_CBOOST_LMT_L=64, .SEEE_CBOOST_GAIN=128, .SEEE_CBOOST_EN=1, .rsv_25=0}},
    .cboost_ctrl_2={.bits={.SEEE_CBOOST_YCONST=4, .SEEE_CBOOST_YOFFSET=0, .SEEE_CBOOST_YOFFSET_SEL=0, .rsv_18=0}},
    .pbc1_ctrl_1={.bits={.SEEE_PBC1_RADIUS_R=42, .rsv_6=0, .SEEE_PBC1_RSLOPE=85, .rsv_18=0, .SEEE_PBC1_RSLOPE_1=39, .SEEE_PBC1_EN=1, .SEEE_PBC_EN=0}},
    .pbc1_ctrl_2={.bits={.SEEE_PBC1_TSLOPE=85, .SEEE_PBC1_THETA_R=24, .SEEE_PBC1_THETA_C=149, .SEEE_PBC1_RADIUS_C=48}},
    .pbc1_ctrl_3={.bits={.SEEE_PBC1_LPF_GAIN=16, .SEEE_PBC1_LPF_EN=0, .SEEE_PBC1_EDGE_EN=0, .SEEE_PBC1_EDGE_SLOPE=32, .SEEE_PBC1_EDGE_THR=12, .SEEE_PBC1_CONF_GAIN=1, .SEEE_PBC1_GAIN=48}},
    .pbc2_ctrl_1={.bits={.SEEE_PBC2_RADIUS_R=40, .rsv_6=0, .SEEE_PBC2_RSLOPE=43, .rsv_18=0, .SEEE_PBC2_RSLOPE_1=32, .SEEE_PBC2_EN=1, .rsv_31=0}},
    .pbc2_ctrl_2={.bits={.SEEE_PBC2_TSLOPE=43, .SEEE_PBC2_THETA_R=24, .SEEE_PBC2_THETA_C=88, .SEEE_PBC2_RADIUS_C=48}},
    .pbc2_ctrl_3={.bits={.SEEE_PBC2_LPF_GAIN=10, .SEEE_PBC2_LPF_EN=1, .SEEE_PBC2_EDGE_EN=1, .SEEE_PBC2_EDGE_SLOPE=16, .SEEE_PBC2_EDGE_THR=16, .SEEE_PBC2_CONF_GAIN=4, .SEEE_PBC2_GAIN=0}},
    .pbc3_ctrl_1={.bits={.SEEE_PBC3_RADIUS_R=42, .rsv_6=0, .SEEE_PBC3_RSLOPE=32, .rsv_18=0, .SEEE_PBC3_RSLOPE_1=17, .SEEE_PBC3_EN=1, .rsv_31=0}},
    .pbc3_ctrl_2={.bits={.SEEE_PBC3_TSLOPE=64, .SEEE_PBC3_THETA_R=32, .SEEE_PBC3_THETA_C=224, .SEEE_PBC3_RADIUS_C=60}},
    .pbc3_ctrl_3={.bits={.SEEE_PBC3_LPF_GAIN=6, .SEEE_PBC3_LPF_EN=1, .SEEE_PBC3_EDGE_EN=1, .SEEE_PBC3_EDGE_SLOPE=32, .SEEE_PBC3_EDGE_THR=12, .SEEE_PBC3_CONF_GAIN=1, .SEEE_PBC3_GAIN=0}}

};
const ISP_NVRAM_EE_T gc13a0mipiraw_EE_0147 = {
        .blnd_ctrl_1={.bits={.SEEE_H1_DI_BLND_OFST=0, .SEEE_H2_DI_BLND_OFST=0, .SEEE_H3_DI_BLND_OFST=0, .rsv_24=0}},
    .blnd_ctrl_2={.bits={.SEEE_H1_DI_BLND_SL=12, .SEEE_H2_DI_BLND_SL=12, .SEEE_H3_DI_BLND_SL=12, .SEEE_HX_ISO_BLND_RAT=3, .rsv_29=0}},
    .core_ctrl ={.bits={.SEEE_H1_FLT_CORE_TH=0, .SEEE_H2_FLT_CORE_TH=0, .SEEE_H3_FLT_CORE_TH=0, .SEEE_FLT_CORE_TH=8}},
    .gn_ctrl_1 ={.bits={.SEEE_H1_GN=14, .rsv_5=0, .SEEE_H2_GN=4, .rsv_13=0, .SEEE_H3_GN=1, .rsv_21=0}},
    .luma_ctrl_1={.bits={.SEEE_LUMA_MOD_Y0=256, .rsv_9=0, .SEEE_LUMA_MOD_Y1=256, .rsv_19=0, .SEEE_LUMA_MOD_Y2=256, .rsv_29=0}},
    .luma_ctrl_2={.bits={.SEEE_LUMA_MOD_Y3=256, .rsv_9=0, .SEEE_LUMA_MOD_Y4=256, .rsv_19=0, .SEEE_LUMA_MOD_Y5=256, .rsv_29=0}},
    .luma_slnk_ctrl={.bits={.SEEE_SLNK_GN_Y1=255, .SEEE_SLNK_GN_Y2=255, .SEEE_RESP_SLNK_GN_RAT=16, .SEEE_GLUT_LINK_EN=0, .SEEE_LUMA_MOD_Y6=256, .rsv_31=0}},
    .glut_ctrl_1={.bits={.SEEE_GLUT_S1=1, .SEEE_GLUT_X1=35, .SEEE_GLUT_Y1=20, .rsv_26=0}},
    .glut_ctrl_2={.bits={.SEEE_GLUT_S2=24, .SEEE_GLUT_X2=60, .SEEE_GLUT_Y2=614, .rsv_26=0}},
    .glut_ctrl_3={.bits={.SEEE_GLUT_S3=248, .SEEE_GLUT_X3=100, .SEEE_GLUT_Y3=307, .rsv_26=0}},
    .glut_ctrl_4={.bits={.SEEE_GLUT_S4=254, .SEEE_GLUT_X4=220, .SEEE_GLUT_Y4=41, .rsv_26=0}},
    .glut_ctrl_5={.bits={.SEEE_GLUT_S5=255, .rsv_8=0, .SEEE_GLUT_SL_DEC_Y=32, .rsv_26=0}},
    .glut_ctrl_6={.bits={.SEEE_GLUT_TH_OVR=255, .SEEE_GLUT_TH_UND=255, .SEEE_GLUT_TH_MIN=0, .rsv_24=0}},
    .artifact_ctrl={.bits={.SEEE_RESP_SMO_STR=7, .rsv_3=0, .SEEE_OVRSH_CLIP_STR=2, .rsv_7=0, .SEEE_DOT_REDUC_AMNT=128, .SEEE_DOT_TH=6, .rsv_24=0}},
    .clip_ctrl ={.bits={.SEEE_RESP_CLIP=64, .SEEE_RESP_CLIP_LUMA_SPC_TH=0, .SEEE_RESP_CLIP_LUMA_LWB=0, .SEEE_RESP_CLIP_LUMA_UPB=255}},
    .gn_ctrl_2 ={.bits={.SEEE_MASTER_GN_NEG=16, .SEEE_MASTER_GN_POS=16, .rsv_16=0}},
    .st_ctrl_1 ={.bits={.SEEE_ST_UB=12, .SEEE_ST_LB=4, .rsv_16=0}},
    .st_ctrl_2 ={.bits={.SEEE_ST_SL_CE=16, .SEEE_ST_OFST_CE=100, .SEEE_ST_SL_RESP=16, .SEEE_ST_OFST_RESP=100}},
    .ct_ctrl   ={.bits={.SEEE_LUMA_LMT_DIFF=255, .SEEE_LUMA_CNTST_LV=3, .rsv_11=0, .SEEE_LUMA_MINI=2, .rsv_15=0, .SEEE_LUMA_MAXI=2, .rsv_19=0, .SEEE_CHR_CNTST_LV=3, .rsv_23=0, .SEEE_CHR_MINI=2, .rsv_26=0, .SEEE_CHR_MAXI=2, .rsv_30=0}},
    .cboost_ctrl_1={.bits={.SEEE_CBOOST_LMT_U=255, .SEEE_CBOOST_LMT_L=64, .SEEE_CBOOST_GAIN=128, .SEEE_CBOOST_EN=1, .rsv_25=0}},
    .cboost_ctrl_2={.bits={.SEEE_CBOOST_YCONST=4, .SEEE_CBOOST_YOFFSET=0, .SEEE_CBOOST_YOFFSET_SEL=0, .rsv_18=0}},
    .pbc1_ctrl_1={.bits={.SEEE_PBC1_RADIUS_R=42, .rsv_6=0, .SEEE_PBC1_RSLOPE=85, .rsv_18=0, .SEEE_PBC1_RSLOPE_1=39, .SEEE_PBC1_EN=1, .SEEE_PBC_EN=0}},
    .pbc1_ctrl_2={.bits={.SEEE_PBC1_TSLOPE=85, .SEEE_PBC1_THETA_R=24, .SEEE_PBC1_THETA_C=149, .SEEE_PBC1_RADIUS_C=48}},
    .pbc1_ctrl_3={.bits={.SEEE_PBC1_LPF_GAIN=16, .SEEE_PBC1_LPF_EN=0, .SEEE_PBC1_EDGE_EN=0, .SEEE_PBC1_EDGE_SLOPE=32, .SEEE_PBC1_EDGE_THR=12, .SEEE_PBC1_CONF_GAIN=1, .SEEE_PBC1_GAIN=48}},
    .pbc2_ctrl_1={.bits={.SEEE_PBC2_RADIUS_R=40, .rsv_6=0, .SEEE_PBC2_RSLOPE=43, .rsv_18=0, .SEEE_PBC2_RSLOPE_1=32, .SEEE_PBC2_EN=1, .rsv_31=0}},
    .pbc2_ctrl_2={.bits={.SEEE_PBC2_TSLOPE=43, .SEEE_PBC2_THETA_R=24, .SEEE_PBC2_THETA_C=88, .SEEE_PBC2_RADIUS_C=48}},
    .pbc2_ctrl_3={.bits={.SEEE_PBC2_LPF_GAIN=10, .SEEE_PBC2_LPF_EN=1, .SEEE_PBC2_EDGE_EN=1, .SEEE_PBC2_EDGE_SLOPE=16, .SEEE_PBC2_EDGE_THR=16, .SEEE_PBC2_CONF_GAIN=4, .SEEE_PBC2_GAIN=0}},
    .pbc3_ctrl_1={.bits={.SEEE_PBC3_RADIUS_R=42, .rsv_6=0, .SEEE_PBC3_RSLOPE=32, .rsv_18=0, .SEEE_PBC3_RSLOPE_1=17, .SEEE_PBC3_EN=1, .rsv_31=0}},
    .pbc3_ctrl_2={.bits={.SEEE_PBC3_TSLOPE=64, .SEEE_PBC3_THETA_R=32, .SEEE_PBC3_THETA_C=224, .SEEE_PBC3_RADIUS_C=60}},
    .pbc3_ctrl_3={.bits={.SEEE_PBC3_LPF_GAIN=6, .SEEE_PBC3_LPF_EN=1, .SEEE_PBC3_EDGE_EN=1, .SEEE_PBC3_EDGE_SLOPE=32, .SEEE_PBC3_EDGE_THR=12, .SEEE_PBC3_CONF_GAIN=1, .SEEE_PBC3_GAIN=0}}

};
const ISP_NVRAM_EE_T gc13a0mipiraw_EE_0148 = {
        .blnd_ctrl_1={.bits={.SEEE_H1_DI_BLND_OFST=0, .SEEE_H2_DI_BLND_OFST=0, .SEEE_H3_DI_BLND_OFST=0, .rsv_24=0}},
    .blnd_ctrl_2={.bits={.SEEE_H1_DI_BLND_SL=12, .SEEE_H2_DI_BLND_SL=12, .SEEE_H3_DI_BLND_SL=12, .SEEE_HX_ISO_BLND_RAT=3, .rsv_29=0}},
    .core_ctrl ={.bits={.SEEE_H1_FLT_CORE_TH=0, .SEEE_H2_FLT_CORE_TH=0, .SEEE_H3_FLT_CORE_TH=0, .SEEE_FLT_CORE_TH=8}},
    .gn_ctrl_1 ={.bits={.SEEE_H1_GN=14, .rsv_5=0, .SEEE_H2_GN=4, .rsv_13=0, .SEEE_H3_GN=1, .rsv_21=0}},
    .luma_ctrl_1={.bits={.SEEE_LUMA_MOD_Y0=256, .rsv_9=0, .SEEE_LUMA_MOD_Y1=256, .rsv_19=0, .SEEE_LUMA_MOD_Y2=256, .rsv_29=0}},
    .luma_ctrl_2={.bits={.SEEE_LUMA_MOD_Y3=256, .rsv_9=0, .SEEE_LUMA_MOD_Y4=256, .rsv_19=0, .SEEE_LUMA_MOD_Y5=256, .rsv_29=0}},
    .luma_slnk_ctrl={.bits={.SEEE_SLNK_GN_Y1=255, .SEEE_SLNK_GN_Y2=255, .SEEE_RESP_SLNK_GN_RAT=16, .SEEE_GLUT_LINK_EN=0, .SEEE_LUMA_MOD_Y6=256, .rsv_31=0}},
    .glut_ctrl_1={.bits={.SEEE_GLUT_S1=1, .SEEE_GLUT_X1=35, .SEEE_GLUT_Y1=20, .rsv_26=0}},
    .glut_ctrl_2={.bits={.SEEE_GLUT_S2=24, .SEEE_GLUT_X2=60, .SEEE_GLUT_Y2=614, .rsv_26=0}},
    .glut_ctrl_3={.bits={.SEEE_GLUT_S3=248, .SEEE_GLUT_X3=100, .SEEE_GLUT_Y3=307, .rsv_26=0}},
    .glut_ctrl_4={.bits={.SEEE_GLUT_S4=254, .SEEE_GLUT_X4=220, .SEEE_GLUT_Y4=41, .rsv_26=0}},
    .glut_ctrl_5={.bits={.SEEE_GLUT_S5=255, .rsv_8=0, .SEEE_GLUT_SL_DEC_Y=32, .rsv_26=0}},
    .glut_ctrl_6={.bits={.SEEE_GLUT_TH_OVR=255, .SEEE_GLUT_TH_UND=255, .SEEE_GLUT_TH_MIN=0, .rsv_24=0}},
    .artifact_ctrl={.bits={.SEEE_RESP_SMO_STR=7, .rsv_3=0, .SEEE_OVRSH_CLIP_STR=2, .rsv_7=0, .SEEE_DOT_REDUC_AMNT=128, .SEEE_DOT_TH=6, .rsv_24=0}},
    .clip_ctrl ={.bits={.SEEE_RESP_CLIP=64, .SEEE_RESP_CLIP_LUMA_SPC_TH=0, .SEEE_RESP_CLIP_LUMA_LWB=0, .SEEE_RESP_CLIP_LUMA_UPB=255}},
    .gn_ctrl_2 ={.bits={.SEEE_MASTER_GN_NEG=16, .SEEE_MASTER_GN_POS=16, .rsv_16=0}},
    .st_ctrl_1 ={.bits={.SEEE_ST_UB=12, .SEEE_ST_LB=4, .rsv_16=0}},
    .st_ctrl_2 ={.bits={.SEEE_ST_SL_CE=16, .SEEE_ST_OFST_CE=100, .SEEE_ST_SL_RESP=16, .SEEE_ST_OFST_RESP=100}},
    .ct_ctrl   ={.bits={.SEEE_LUMA_LMT_DIFF=255, .SEEE_LUMA_CNTST_LV=3, .rsv_11=0, .SEEE_LUMA_MINI=2, .rsv_15=0, .SEEE_LUMA_MAXI=2, .rsv_19=0, .SEEE_CHR_CNTST_LV=3, .rsv_23=0, .SEEE_CHR_MINI=2, .rsv_26=0, .SEEE_CHR_MAXI=2, .rsv_30=0}},
    .cboost_ctrl_1={.bits={.SEEE_CBOOST_LMT_U=255, .SEEE_CBOOST_LMT_L=64, .SEEE_CBOOST_GAIN=128, .SEEE_CBOOST_EN=1, .rsv_25=0}},
    .cboost_ctrl_2={.bits={.SEEE_CBOOST_YCONST=4, .SEEE_CBOOST_YOFFSET=0, .SEEE_CBOOST_YOFFSET_SEL=0, .rsv_18=0}},
    .pbc1_ctrl_1={.bits={.SEEE_PBC1_RADIUS_R=42, .rsv_6=0, .SEEE_PBC1_RSLOPE=85, .rsv_18=0, .SEEE_PBC1_RSLOPE_1=39, .SEEE_PBC1_EN=1, .SEEE_PBC_EN=0}},
    .pbc1_ctrl_2={.bits={.SEEE_PBC1_TSLOPE=85, .SEEE_PBC1_THETA_R=24, .SEEE_PBC1_THETA_C=149, .SEEE_PBC1_RADIUS_C=48}},
    .pbc1_ctrl_3={.bits={.SEEE_PBC1_LPF_GAIN=16, .SEEE_PBC1_LPF_EN=0, .SEEE_PBC1_EDGE_EN=0, .SEEE_PBC1_EDGE_SLOPE=32, .SEEE_PBC1_EDGE_THR=12, .SEEE_PBC1_CONF_GAIN=1, .SEEE_PBC1_GAIN=48}},
    .pbc2_ctrl_1={.bits={.SEEE_PBC2_RADIUS_R=40, .rsv_6=0, .SEEE_PBC2_RSLOPE=43, .rsv_18=0, .SEEE_PBC2_RSLOPE_1=32, .SEEE_PBC2_EN=1, .rsv_31=0}},
    .pbc2_ctrl_2={.bits={.SEEE_PBC2_TSLOPE=43, .SEEE_PBC2_THETA_R=24, .SEEE_PBC2_THETA_C=88, .SEEE_PBC2_RADIUS_C=48}},
    .pbc2_ctrl_3={.bits={.SEEE_PBC2_LPF_GAIN=10, .SEEE_PBC2_LPF_EN=1, .SEEE_PBC2_EDGE_EN=1, .SEEE_PBC2_EDGE_SLOPE=16, .SEEE_PBC2_EDGE_THR=16, .SEEE_PBC2_CONF_GAIN=4, .SEEE_PBC2_GAIN=0}},
    .pbc3_ctrl_1={.bits={.SEEE_PBC3_RADIUS_R=42, .rsv_6=0, .SEEE_PBC3_RSLOPE=32, .rsv_18=0, .SEEE_PBC3_RSLOPE_1=17, .SEEE_PBC3_EN=1, .rsv_31=0}},
    .pbc3_ctrl_2={.bits={.SEEE_PBC3_TSLOPE=64, .SEEE_PBC3_THETA_R=32, .SEEE_PBC3_THETA_C=224, .SEEE_PBC3_RADIUS_C=60}},
    .pbc3_ctrl_3={.bits={.SEEE_PBC3_LPF_GAIN=6, .SEEE_PBC3_LPF_EN=1, .SEEE_PBC3_EDGE_EN=1, .SEEE_PBC3_EDGE_SLOPE=32, .SEEE_PBC3_EDGE_THR=12, .SEEE_PBC3_CONF_GAIN=1, .SEEE_PBC3_GAIN=0}}

};
const ISP_NVRAM_EE_T gc13a0mipiraw_EE_0149 = {
        .blnd_ctrl_1={.bits={.SEEE_H1_DI_BLND_OFST=0, .SEEE_H2_DI_BLND_OFST=0, .SEEE_H3_DI_BLND_OFST=0, .rsv_24=0}},
    .blnd_ctrl_2={.bits={.SEEE_H1_DI_BLND_SL=12, .SEEE_H2_DI_BLND_SL=12, .SEEE_H3_DI_BLND_SL=12, .SEEE_HX_ISO_BLND_RAT=3, .rsv_29=0}},
    .core_ctrl ={.bits={.SEEE_H1_FLT_CORE_TH=0, .SEEE_H2_FLT_CORE_TH=0, .SEEE_H3_FLT_CORE_TH=0, .SEEE_FLT_CORE_TH=8}},
    .gn_ctrl_1 ={.bits={.SEEE_H1_GN=14, .rsv_5=0, .SEEE_H2_GN=4, .rsv_13=0, .SEEE_H3_GN=1, .rsv_21=0}},
    .luma_ctrl_1={.bits={.SEEE_LUMA_MOD_Y0=256, .rsv_9=0, .SEEE_LUMA_MOD_Y1=256, .rsv_19=0, .SEEE_LUMA_MOD_Y2=256, .rsv_29=0}},
    .luma_ctrl_2={.bits={.SEEE_LUMA_MOD_Y3=256, .rsv_9=0, .SEEE_LUMA_MOD_Y4=256, .rsv_19=0, .SEEE_LUMA_MOD_Y5=256, .rsv_29=0}},
    .luma_slnk_ctrl={.bits={.SEEE_SLNK_GN_Y1=255, .SEEE_SLNK_GN_Y2=255, .SEEE_RESP_SLNK_GN_RAT=16, .SEEE_GLUT_LINK_EN=0, .SEEE_LUMA_MOD_Y6=256, .rsv_31=0}},
    .glut_ctrl_1={.bits={.SEEE_GLUT_S1=1, .SEEE_GLUT_X1=35, .SEEE_GLUT_Y1=20, .rsv_26=0}},
    .glut_ctrl_2={.bits={.SEEE_GLUT_S2=24, .SEEE_GLUT_X2=60, .SEEE_GLUT_Y2=614, .rsv_26=0}},
    .glut_ctrl_3={.bits={.SEEE_GLUT_S3=248, .SEEE_GLUT_X3=100, .SEEE_GLUT_Y3=307, .rsv_26=0}},
    .glut_ctrl_4={.bits={.SEEE_GLUT_S4=254, .SEEE_GLUT_X4=220, .SEEE_GLUT_Y4=41, .rsv_26=0}},
    .glut_ctrl_5={.bits={.SEEE_GLUT_S5=255, .rsv_8=0, .SEEE_GLUT_SL_DEC_Y=32, .rsv_26=0}},
    .glut_ctrl_6={.bits={.SEEE_GLUT_TH_OVR=255, .SEEE_GLUT_TH_UND=255, .SEEE_GLUT_TH_MIN=0, .rsv_24=0}},
    .artifact_ctrl={.bits={.SEEE_RESP_SMO_STR=7, .rsv_3=0, .SEEE_OVRSH_CLIP_STR=2, .rsv_7=0, .SEEE_DOT_REDUC_AMNT=128, .SEEE_DOT_TH=6, .rsv_24=0}},
    .clip_ctrl ={.bits={.SEEE_RESP_CLIP=64, .SEEE_RESP_CLIP_LUMA_SPC_TH=0, .SEEE_RESP_CLIP_LUMA_LWB=0, .SEEE_RESP_CLIP_LUMA_UPB=255}},
    .gn_ctrl_2 ={.bits={.SEEE_MASTER_GN_NEG=16, .SEEE_MASTER_GN_POS=16, .rsv_16=0}},
    .st_ctrl_1 ={.bits={.SEEE_ST_UB=12, .SEEE_ST_LB=4, .rsv_16=0}},
    .st_ctrl_2 ={.bits={.SEEE_ST_SL_CE=16, .SEEE_ST_OFST_CE=100, .SEEE_ST_SL_RESP=16, .SEEE_ST_OFST_RESP=100}},
    .ct_ctrl   ={.bits={.SEEE_LUMA_LMT_DIFF=255, .SEEE_LUMA_CNTST_LV=3, .rsv_11=0, .SEEE_LUMA_MINI=2, .rsv_15=0, .SEEE_LUMA_MAXI=2, .rsv_19=0, .SEEE_CHR_CNTST_LV=3, .rsv_23=0, .SEEE_CHR_MINI=2, .rsv_26=0, .SEEE_CHR_MAXI=2, .rsv_30=0}},
    .cboost_ctrl_1={.bits={.SEEE_CBOOST_LMT_U=255, .SEEE_CBOOST_LMT_L=64, .SEEE_CBOOST_GAIN=128, .SEEE_CBOOST_EN=1, .rsv_25=0}},
    .cboost_ctrl_2={.bits={.SEEE_CBOOST_YCONST=4, .SEEE_CBOOST_YOFFSET=0, .SEEE_CBOOST_YOFFSET_SEL=0, .rsv_18=0}},
    .pbc1_ctrl_1={.bits={.SEEE_PBC1_RADIUS_R=42, .rsv_6=0, .SEEE_PBC1_RSLOPE=85, .rsv_18=0, .SEEE_PBC1_RSLOPE_1=39, .SEEE_PBC1_EN=1, .SEEE_PBC_EN=0}},
    .pbc1_ctrl_2={.bits={.SEEE_PBC1_TSLOPE=85, .SEEE_PBC1_THETA_R=24, .SEEE_PBC1_THETA_C=149, .SEEE_PBC1_RADIUS_C=48}},
    .pbc1_ctrl_3={.bits={.SEEE_PBC1_LPF_GAIN=16, .SEEE_PBC1_LPF_EN=0, .SEEE_PBC1_EDGE_EN=0, .SEEE_PBC1_EDGE_SLOPE=32, .SEEE_PBC1_EDGE_THR=12, .SEEE_PBC1_CONF_GAIN=1, .SEEE_PBC1_GAIN=48}},
    .pbc2_ctrl_1={.bits={.SEEE_PBC2_RADIUS_R=40, .rsv_6=0, .SEEE_PBC2_RSLOPE=43, .rsv_18=0, .SEEE_PBC2_RSLOPE_1=32, .SEEE_PBC2_EN=1, .rsv_31=0}},
    .pbc2_ctrl_2={.bits={.SEEE_PBC2_TSLOPE=43, .SEEE_PBC2_THETA_R=24, .SEEE_PBC2_THETA_C=88, .SEEE_PBC2_RADIUS_C=48}},
    .pbc2_ctrl_3={.bits={.SEEE_PBC2_LPF_GAIN=10, .SEEE_PBC2_LPF_EN=1, .SEEE_PBC2_EDGE_EN=1, .SEEE_PBC2_EDGE_SLOPE=16, .SEEE_PBC2_EDGE_THR=16, .SEEE_PBC2_CONF_GAIN=4, .SEEE_PBC2_GAIN=0}},
    .pbc3_ctrl_1={.bits={.SEEE_PBC3_RADIUS_R=42, .rsv_6=0, .SEEE_PBC3_RSLOPE=32, .rsv_18=0, .SEEE_PBC3_RSLOPE_1=17, .SEEE_PBC3_EN=1, .rsv_31=0}},
    .pbc3_ctrl_2={.bits={.SEEE_PBC3_TSLOPE=64, .SEEE_PBC3_THETA_R=32, .SEEE_PBC3_THETA_C=224, .SEEE_PBC3_RADIUS_C=60}},
    .pbc3_ctrl_3={.bits={.SEEE_PBC3_LPF_GAIN=6, .SEEE_PBC3_LPF_EN=1, .SEEE_PBC3_EDGE_EN=1, .SEEE_PBC3_EDGE_SLOPE=32, .SEEE_PBC3_EDGE_THR=12, .SEEE_PBC3_CONF_GAIN=1, .SEEE_PBC3_GAIN=0}}

};
const ISP_NVRAM_EE_T gc13a0mipiraw_EE_0150 = {
        .blnd_ctrl_1={.bits={.SEEE_H1_DI_BLND_OFST=0, .SEEE_H2_DI_BLND_OFST=0, .SEEE_H3_DI_BLND_OFST=0, .rsv_24=0}},
    .blnd_ctrl_2={.bits={.SEEE_H1_DI_BLND_SL=12, .SEEE_H2_DI_BLND_SL=12, .SEEE_H3_DI_BLND_SL=12, .SEEE_HX_ISO_BLND_RAT=3, .rsv_29=0}},
    .core_ctrl ={.bits={.SEEE_H1_FLT_CORE_TH=0, .SEEE_H2_FLT_CORE_TH=0, .SEEE_H3_FLT_CORE_TH=0, .SEEE_FLT_CORE_TH=8}},
    .gn_ctrl_1 ={.bits={.SEEE_H1_GN=14, .rsv_5=0, .SEEE_H2_GN=4, .rsv_13=0, .SEEE_H3_GN=1, .rsv_21=0}},
    .luma_ctrl_1={.bits={.SEEE_LUMA_MOD_Y0=256, .rsv_9=0, .SEEE_LUMA_MOD_Y1=256, .rsv_19=0, .SEEE_LUMA_MOD_Y2=256, .rsv_29=0}},
    .luma_ctrl_2={.bits={.SEEE_LUMA_MOD_Y3=256, .rsv_9=0, .SEEE_LUMA_MOD_Y4=256, .rsv_19=0, .SEEE_LUMA_MOD_Y5=256, .rsv_29=0}},
    .luma_slnk_ctrl={.bits={.SEEE_SLNK_GN_Y1=255, .SEEE_SLNK_GN_Y2=255, .SEEE_RESP_SLNK_GN_RAT=16, .SEEE_GLUT_LINK_EN=0, .SEEE_LUMA_MOD_Y6=256, .rsv_31=0}},
    .glut_ctrl_1={.bits={.SEEE_GLUT_S1=1, .SEEE_GLUT_X1=35, .SEEE_GLUT_Y1=20, .rsv_26=0}},
    .glut_ctrl_2={.bits={.SEEE_GLUT_S2=24, .SEEE_GLUT_X2=60, .SEEE_GLUT_Y2=614, .rsv_26=0}},
    .glut_ctrl_3={.bits={.SEEE_GLUT_S3=248, .SEEE_GLUT_X3=100, .SEEE_GLUT_Y3=307, .rsv_26=0}},
    .glut_ctrl_4={.bits={.SEEE_GLUT_S4=254, .SEEE_GLUT_X4=220, .SEEE_GLUT_Y4=41, .rsv_26=0}},
    .glut_ctrl_5={.bits={.SEEE_GLUT_S5=255, .rsv_8=0, .SEEE_GLUT_SL_DEC_Y=32, .rsv_26=0}},
    .glut_ctrl_6={.bits={.SEEE_GLUT_TH_OVR=255, .SEEE_GLUT_TH_UND=255, .SEEE_GLUT_TH_MIN=0, .rsv_24=0}},
    .artifact_ctrl={.bits={.SEEE_RESP_SMO_STR=7, .rsv_3=0, .SEEE_OVRSH_CLIP_STR=2, .rsv_7=0, .SEEE_DOT_REDUC_AMNT=128, .SEEE_DOT_TH=6, .rsv_24=0}},
    .clip_ctrl ={.bits={.SEEE_RESP_CLIP=64, .SEEE_RESP_CLIP_LUMA_SPC_TH=0, .SEEE_RESP_CLIP_LUMA_LWB=0, .SEEE_RESP_CLIP_LUMA_UPB=255}},
    .gn_ctrl_2 ={.bits={.SEEE_MASTER_GN_NEG=16, .SEEE_MASTER_GN_POS=16, .rsv_16=0}},
    .st_ctrl_1 ={.bits={.SEEE_ST_UB=12, .SEEE_ST_LB=4, .rsv_16=0}},
    .st_ctrl_2 ={.bits={.SEEE_ST_SL_CE=16, .SEEE_ST_OFST_CE=100, .SEEE_ST_SL_RESP=16, .SEEE_ST_OFST_RESP=100}},
    .ct_ctrl   ={.bits={.SEEE_LUMA_LMT_DIFF=255, .SEEE_LUMA_CNTST_LV=3, .rsv_11=0, .SEEE_LUMA_MINI=2, .rsv_15=0, .SEEE_LUMA_MAXI=2, .rsv_19=0, .SEEE_CHR_CNTST_LV=3, .rsv_23=0, .SEEE_CHR_MINI=2, .rsv_26=0, .SEEE_CHR_MAXI=2, .rsv_30=0}},
    .cboost_ctrl_1={.bits={.SEEE_CBOOST_LMT_U=255, .SEEE_CBOOST_LMT_L=64, .SEEE_CBOOST_GAIN=128, .SEEE_CBOOST_EN=1, .rsv_25=0}},
    .cboost_ctrl_2={.bits={.SEEE_CBOOST_YCONST=4, .SEEE_CBOOST_YOFFSET=0, .SEEE_CBOOST_YOFFSET_SEL=0, .rsv_18=0}},
    .pbc1_ctrl_1={.bits={.SEEE_PBC1_RADIUS_R=42, .rsv_6=0, .SEEE_PBC1_RSLOPE=85, .rsv_18=0, .SEEE_PBC1_RSLOPE_1=39, .SEEE_PBC1_EN=1, .SEEE_PBC_EN=0}},
    .pbc1_ctrl_2={.bits={.SEEE_PBC1_TSLOPE=85, .SEEE_PBC1_THETA_R=24, .SEEE_PBC1_THETA_C=149, .SEEE_PBC1_RADIUS_C=48}},
    .pbc1_ctrl_3={.bits={.SEEE_PBC1_LPF_GAIN=16, .SEEE_PBC1_LPF_EN=0, .SEEE_PBC1_EDGE_EN=0, .SEEE_PBC1_EDGE_SLOPE=32, .SEEE_PBC1_EDGE_THR=12, .SEEE_PBC1_CONF_GAIN=1, .SEEE_PBC1_GAIN=48}},
    .pbc2_ctrl_1={.bits={.SEEE_PBC2_RADIUS_R=40, .rsv_6=0, .SEEE_PBC2_RSLOPE=43, .rsv_18=0, .SEEE_PBC2_RSLOPE_1=32, .SEEE_PBC2_EN=1, .rsv_31=0}},
    .pbc2_ctrl_2={.bits={.SEEE_PBC2_TSLOPE=43, .SEEE_PBC2_THETA_R=24, .SEEE_PBC2_THETA_C=88, .SEEE_PBC2_RADIUS_C=48}},
    .pbc2_ctrl_3={.bits={.SEEE_PBC2_LPF_GAIN=10, .SEEE_PBC2_LPF_EN=1, .SEEE_PBC2_EDGE_EN=1, .SEEE_PBC2_EDGE_SLOPE=16, .SEEE_PBC2_EDGE_THR=16, .SEEE_PBC2_CONF_GAIN=4, .SEEE_PBC2_GAIN=0}},
    .pbc3_ctrl_1={.bits={.SEEE_PBC3_RADIUS_R=42, .rsv_6=0, .SEEE_PBC3_RSLOPE=32, .rsv_18=0, .SEEE_PBC3_RSLOPE_1=17, .SEEE_PBC3_EN=1, .rsv_31=0}},
    .pbc3_ctrl_2={.bits={.SEEE_PBC3_TSLOPE=64, .SEEE_PBC3_THETA_R=32, .SEEE_PBC3_THETA_C=224, .SEEE_PBC3_RADIUS_C=60}},
    .pbc3_ctrl_3={.bits={.SEEE_PBC3_LPF_GAIN=6, .SEEE_PBC3_LPF_EN=1, .SEEE_PBC3_EDGE_EN=1, .SEEE_PBC3_EDGE_SLOPE=32, .SEEE_PBC3_EDGE_THR=12, .SEEE_PBC3_CONF_GAIN=1, .SEEE_PBC3_GAIN=0}}

};
const ISP_NVRAM_EE_T gc13a0mipiraw_EE_0151 = {
        .blnd_ctrl_1={.bits={.SEEE_H1_DI_BLND_OFST=0, .SEEE_H2_DI_BLND_OFST=0, .SEEE_H3_DI_BLND_OFST=0, .rsv_24=0}},
    .blnd_ctrl_2={.bits={.SEEE_H1_DI_BLND_SL=12, .SEEE_H2_DI_BLND_SL=12, .SEEE_H3_DI_BLND_SL=12, .SEEE_HX_ISO_BLND_RAT=3, .rsv_29=0}},
    .core_ctrl ={.bits={.SEEE_H1_FLT_CORE_TH=0, .SEEE_H2_FLT_CORE_TH=0, .SEEE_H3_FLT_CORE_TH=0, .SEEE_FLT_CORE_TH=8}},
    .gn_ctrl_1 ={.bits={.SEEE_H1_GN=14, .rsv_5=0, .SEEE_H2_GN=4, .rsv_13=0, .SEEE_H3_GN=1, .rsv_21=0}},
    .luma_ctrl_1={.bits={.SEEE_LUMA_MOD_Y0=256, .rsv_9=0, .SEEE_LUMA_MOD_Y1=256, .rsv_19=0, .SEEE_LUMA_MOD_Y2=256, .rsv_29=0}},
    .luma_ctrl_2={.bits={.SEEE_LUMA_MOD_Y3=256, .rsv_9=0, .SEEE_LUMA_MOD_Y4=256, .rsv_19=0, .SEEE_LUMA_MOD_Y5=256, .rsv_29=0}},
    .luma_slnk_ctrl={.bits={.SEEE_SLNK_GN_Y1=255, .SEEE_SLNK_GN_Y2=255, .SEEE_RESP_SLNK_GN_RAT=16, .SEEE_GLUT_LINK_EN=0, .SEEE_LUMA_MOD_Y6=256, .rsv_31=0}},
    .glut_ctrl_1={.bits={.SEEE_GLUT_S1=1, .SEEE_GLUT_X1=35, .SEEE_GLUT_Y1=20, .rsv_26=0}},
    .glut_ctrl_2={.bits={.SEEE_GLUT_S2=24, .SEEE_GLUT_X2=60, .SEEE_GLUT_Y2=614, .rsv_26=0}},
    .glut_ctrl_3={.bits={.SEEE_GLUT_S3=248, .SEEE_GLUT_X3=100, .SEEE_GLUT_Y3=307, .rsv_26=0}},
    .glut_ctrl_4={.bits={.SEEE_GLUT_S4=254, .SEEE_GLUT_X4=220, .SEEE_GLUT_Y4=41, .rsv_26=0}},
    .glut_ctrl_5={.bits={.SEEE_GLUT_S5=255, .rsv_8=0, .SEEE_GLUT_SL_DEC_Y=32, .rsv_26=0}},
    .glut_ctrl_6={.bits={.SEEE_GLUT_TH_OVR=255, .SEEE_GLUT_TH_UND=255, .SEEE_GLUT_TH_MIN=0, .rsv_24=0}},
    .artifact_ctrl={.bits={.SEEE_RESP_SMO_STR=7, .rsv_3=0, .SEEE_OVRSH_CLIP_STR=2, .rsv_7=0, .SEEE_DOT_REDUC_AMNT=128, .SEEE_DOT_TH=6, .rsv_24=0}},
    .clip_ctrl ={.bits={.SEEE_RESP_CLIP=64, .SEEE_RESP_CLIP_LUMA_SPC_TH=0, .SEEE_RESP_CLIP_LUMA_LWB=0, .SEEE_RESP_CLIP_LUMA_UPB=255}},
    .gn_ctrl_2 ={.bits={.SEEE_MASTER_GN_NEG=16, .SEEE_MASTER_GN_POS=16, .rsv_16=0}},
    .st_ctrl_1 ={.bits={.SEEE_ST_UB=12, .SEEE_ST_LB=4, .rsv_16=0}},
    .st_ctrl_2 ={.bits={.SEEE_ST_SL_CE=16, .SEEE_ST_OFST_CE=100, .SEEE_ST_SL_RESP=16, .SEEE_ST_OFST_RESP=100}},
    .ct_ctrl   ={.bits={.SEEE_LUMA_LMT_DIFF=255, .SEEE_LUMA_CNTST_LV=3, .rsv_11=0, .SEEE_LUMA_MINI=2, .rsv_15=0, .SEEE_LUMA_MAXI=2, .rsv_19=0, .SEEE_CHR_CNTST_LV=3, .rsv_23=0, .SEEE_CHR_MINI=2, .rsv_26=0, .SEEE_CHR_MAXI=2, .rsv_30=0}},
    .cboost_ctrl_1={.bits={.SEEE_CBOOST_LMT_U=255, .SEEE_CBOOST_LMT_L=64, .SEEE_CBOOST_GAIN=128, .SEEE_CBOOST_EN=1, .rsv_25=0}},
    .cboost_ctrl_2={.bits={.SEEE_CBOOST_YCONST=4, .SEEE_CBOOST_YOFFSET=0, .SEEE_CBOOST_YOFFSET_SEL=0, .rsv_18=0}},
    .pbc1_ctrl_1={.bits={.SEEE_PBC1_RADIUS_R=42, .rsv_6=0, .SEEE_PBC1_RSLOPE=85, .rsv_18=0, .SEEE_PBC1_RSLOPE_1=39, .SEEE_PBC1_EN=1, .SEEE_PBC_EN=0}},
    .pbc1_ctrl_2={.bits={.SEEE_PBC1_TSLOPE=85, .SEEE_PBC1_THETA_R=24, .SEEE_PBC1_THETA_C=149, .SEEE_PBC1_RADIUS_C=48}},
    .pbc1_ctrl_3={.bits={.SEEE_PBC1_LPF_GAIN=16, .SEEE_PBC1_LPF_EN=0, .SEEE_PBC1_EDGE_EN=0, .SEEE_PBC1_EDGE_SLOPE=32, .SEEE_PBC1_EDGE_THR=12, .SEEE_PBC1_CONF_GAIN=1, .SEEE_PBC1_GAIN=48}},
    .pbc2_ctrl_1={.bits={.SEEE_PBC2_RADIUS_R=40, .rsv_6=0, .SEEE_PBC2_RSLOPE=43, .rsv_18=0, .SEEE_PBC2_RSLOPE_1=32, .SEEE_PBC2_EN=1, .rsv_31=0}},
    .pbc2_ctrl_2={.bits={.SEEE_PBC2_TSLOPE=43, .SEEE_PBC2_THETA_R=24, .SEEE_PBC2_THETA_C=88, .SEEE_PBC2_RADIUS_C=48}},
    .pbc2_ctrl_3={.bits={.SEEE_PBC2_LPF_GAIN=10, .SEEE_PBC2_LPF_EN=1, .SEEE_PBC2_EDGE_EN=1, .SEEE_PBC2_EDGE_SLOPE=16, .SEEE_PBC2_EDGE_THR=16, .SEEE_PBC2_CONF_GAIN=4, .SEEE_PBC2_GAIN=0}},
    .pbc3_ctrl_1={.bits={.SEEE_PBC3_RADIUS_R=42, .rsv_6=0, .SEEE_PBC3_RSLOPE=32, .rsv_18=0, .SEEE_PBC3_RSLOPE_1=17, .SEEE_PBC3_EN=1, .rsv_31=0}},
    .pbc3_ctrl_2={.bits={.SEEE_PBC3_TSLOPE=64, .SEEE_PBC3_THETA_R=32, .SEEE_PBC3_THETA_C=224, .SEEE_PBC3_RADIUS_C=60}},
    .pbc3_ctrl_3={.bits={.SEEE_PBC3_LPF_GAIN=6, .SEEE_PBC3_LPF_EN=1, .SEEE_PBC3_EDGE_EN=1, .SEEE_PBC3_EDGE_SLOPE=32, .SEEE_PBC3_EDGE_THR=12, .SEEE_PBC3_CONF_GAIN=1, .SEEE_PBC3_GAIN=0}}

};
const ISP_NVRAM_EE_T gc13a0mipiraw_EE_0152 = {
        .blnd_ctrl_1={.bits={.SEEE_H1_DI_BLND_OFST=0, .SEEE_H2_DI_BLND_OFST=0, .SEEE_H3_DI_BLND_OFST=0, .rsv_24=0}},
    .blnd_ctrl_2={.bits={.SEEE_H1_DI_BLND_SL=12, .SEEE_H2_DI_BLND_SL=12, .SEEE_H3_DI_BLND_SL=12, .SEEE_HX_ISO_BLND_RAT=3, .rsv_29=0}},
    .core_ctrl ={.bits={.SEEE_H1_FLT_CORE_TH=0, .SEEE_H2_FLT_CORE_TH=0, .SEEE_H3_FLT_CORE_TH=0, .SEEE_FLT_CORE_TH=8}},
    .gn_ctrl_1 ={.bits={.SEEE_H1_GN=14, .rsv_5=0, .SEEE_H2_GN=4, .rsv_13=0, .SEEE_H3_GN=1, .rsv_21=0}},
    .luma_ctrl_1={.bits={.SEEE_LUMA_MOD_Y0=256, .rsv_9=0, .SEEE_LUMA_MOD_Y1=256, .rsv_19=0, .SEEE_LUMA_MOD_Y2=256, .rsv_29=0}},
    .luma_ctrl_2={.bits={.SEEE_LUMA_MOD_Y3=256, .rsv_9=0, .SEEE_LUMA_MOD_Y4=256, .rsv_19=0, .SEEE_LUMA_MOD_Y5=256, .rsv_29=0}},
    .luma_slnk_ctrl={.bits={.SEEE_SLNK_GN_Y1=255, .SEEE_SLNK_GN_Y2=255, .SEEE_RESP_SLNK_GN_RAT=16, .SEEE_GLUT_LINK_EN=0, .SEEE_LUMA_MOD_Y6=256, .rsv_31=0}},
    .glut_ctrl_1={.bits={.SEEE_GLUT_S1=1, .SEEE_GLUT_X1=35, .SEEE_GLUT_Y1=20, .rsv_26=0}},
    .glut_ctrl_2={.bits={.SEEE_GLUT_S2=24, .SEEE_GLUT_X2=60, .SEEE_GLUT_Y2=614, .rsv_26=0}},
    .glut_ctrl_3={.bits={.SEEE_GLUT_S3=248, .SEEE_GLUT_X3=100, .SEEE_GLUT_Y3=307, .rsv_26=0}},
    .glut_ctrl_4={.bits={.SEEE_GLUT_S4=254, .SEEE_GLUT_X4=220, .SEEE_GLUT_Y4=41, .rsv_26=0}},
    .glut_ctrl_5={.bits={.SEEE_GLUT_S5=255, .rsv_8=0, .SEEE_GLUT_SL_DEC_Y=32, .rsv_26=0}},
    .glut_ctrl_6={.bits={.SEEE_GLUT_TH_OVR=255, .SEEE_GLUT_TH_UND=255, .SEEE_GLUT_TH_MIN=0, .rsv_24=0}},
    .artifact_ctrl={.bits={.SEEE_RESP_SMO_STR=7, .rsv_3=0, .SEEE_OVRSH_CLIP_STR=2, .rsv_7=0, .SEEE_DOT_REDUC_AMNT=128, .SEEE_DOT_TH=6, .rsv_24=0}},
    .clip_ctrl ={.bits={.SEEE_RESP_CLIP=64, .SEEE_RESP_CLIP_LUMA_SPC_TH=0, .SEEE_RESP_CLIP_LUMA_LWB=0, .SEEE_RESP_CLIP_LUMA_UPB=255}},
    .gn_ctrl_2 ={.bits={.SEEE_MASTER_GN_NEG=16, .SEEE_MASTER_GN_POS=16, .rsv_16=0}},
    .st_ctrl_1 ={.bits={.SEEE_ST_UB=12, .SEEE_ST_LB=4, .rsv_16=0}},
    .st_ctrl_2 ={.bits={.SEEE_ST_SL_CE=16, .SEEE_ST_OFST_CE=100, .SEEE_ST_SL_RESP=16, .SEEE_ST_OFST_RESP=100}},
    .ct_ctrl   ={.bits={.SEEE_LUMA_LMT_DIFF=255, .SEEE_LUMA_CNTST_LV=3, .rsv_11=0, .SEEE_LUMA_MINI=2, .rsv_15=0, .SEEE_LUMA_MAXI=2, .rsv_19=0, .SEEE_CHR_CNTST_LV=3, .rsv_23=0, .SEEE_CHR_MINI=2, .rsv_26=0, .SEEE_CHR_MAXI=2, .rsv_30=0}},
    .cboost_ctrl_1={.bits={.SEEE_CBOOST_LMT_U=255, .SEEE_CBOOST_LMT_L=64, .SEEE_CBOOST_GAIN=128, .SEEE_CBOOST_EN=1, .rsv_25=0}},
    .cboost_ctrl_2={.bits={.SEEE_CBOOST_YCONST=4, .SEEE_CBOOST_YOFFSET=0, .SEEE_CBOOST_YOFFSET_SEL=0, .rsv_18=0}},
    .pbc1_ctrl_1={.bits={.SEEE_PBC1_RADIUS_R=42, .rsv_6=0, .SEEE_PBC1_RSLOPE=85, .rsv_18=0, .SEEE_PBC1_RSLOPE_1=39, .SEEE_PBC1_EN=1, .SEEE_PBC_EN=0}},
    .pbc1_ctrl_2={.bits={.SEEE_PBC1_TSLOPE=85, .SEEE_PBC1_THETA_R=24, .SEEE_PBC1_THETA_C=149, .SEEE_PBC1_RADIUS_C=48}},
    .pbc1_ctrl_3={.bits={.SEEE_PBC1_LPF_GAIN=16, .SEEE_PBC1_LPF_EN=0, .SEEE_PBC1_EDGE_EN=0, .SEEE_PBC1_EDGE_SLOPE=32, .SEEE_PBC1_EDGE_THR=12, .SEEE_PBC1_CONF_GAIN=1, .SEEE_PBC1_GAIN=48}},
    .pbc2_ctrl_1={.bits={.SEEE_PBC2_RADIUS_R=40, .rsv_6=0, .SEEE_PBC2_RSLOPE=43, .rsv_18=0, .SEEE_PBC2_RSLOPE_1=32, .SEEE_PBC2_EN=1, .rsv_31=0}},
    .pbc2_ctrl_2={.bits={.SEEE_PBC2_TSLOPE=43, .SEEE_PBC2_THETA_R=24, .SEEE_PBC2_THETA_C=88, .SEEE_PBC2_RADIUS_C=48}},
    .pbc2_ctrl_3={.bits={.SEEE_PBC2_LPF_GAIN=10, .SEEE_PBC2_LPF_EN=1, .SEEE_PBC2_EDGE_EN=1, .SEEE_PBC2_EDGE_SLOPE=16, .SEEE_PBC2_EDGE_THR=16, .SEEE_PBC2_CONF_GAIN=4, .SEEE_PBC2_GAIN=0}},
    .pbc3_ctrl_1={.bits={.SEEE_PBC3_RADIUS_R=42, .rsv_6=0, .SEEE_PBC3_RSLOPE=32, .rsv_18=0, .SEEE_PBC3_RSLOPE_1=17, .SEEE_PBC3_EN=1, .rsv_31=0}},
    .pbc3_ctrl_2={.bits={.SEEE_PBC3_TSLOPE=64, .SEEE_PBC3_THETA_R=32, .SEEE_PBC3_THETA_C=224, .SEEE_PBC3_RADIUS_C=60}},
    .pbc3_ctrl_3={.bits={.SEEE_PBC3_LPF_GAIN=6, .SEEE_PBC3_LPF_EN=1, .SEEE_PBC3_EDGE_EN=1, .SEEE_PBC3_EDGE_SLOPE=32, .SEEE_PBC3_EDGE_THR=12, .SEEE_PBC3_CONF_GAIN=1, .SEEE_PBC3_GAIN=0}}

};
const ISP_NVRAM_EE_T gc13a0mipiraw_EE_0153 = {
        .blnd_ctrl_1={.bits={.SEEE_H1_DI_BLND_OFST=0, .SEEE_H2_DI_BLND_OFST=0, .SEEE_H3_DI_BLND_OFST=0, .rsv_24=0}},
    .blnd_ctrl_2={.bits={.SEEE_H1_DI_BLND_SL=12, .SEEE_H2_DI_BLND_SL=12, .SEEE_H3_DI_BLND_SL=12, .SEEE_HX_ISO_BLND_RAT=3, .rsv_29=0}},
    .core_ctrl ={.bits={.SEEE_H1_FLT_CORE_TH=0, .SEEE_H2_FLT_CORE_TH=0, .SEEE_H3_FLT_CORE_TH=0, .SEEE_FLT_CORE_TH=8}},
    .gn_ctrl_1 ={.bits={.SEEE_H1_GN=14, .rsv_5=0, .SEEE_H2_GN=4, .rsv_13=0, .SEEE_H3_GN=1, .rsv_21=0}},
    .luma_ctrl_1={.bits={.SEEE_LUMA_MOD_Y0=256, .rsv_9=0, .SEEE_LUMA_MOD_Y1=256, .rsv_19=0, .SEEE_LUMA_MOD_Y2=256, .rsv_29=0}},
    .luma_ctrl_2={.bits={.SEEE_LUMA_MOD_Y3=256, .rsv_9=0, .SEEE_LUMA_MOD_Y4=256, .rsv_19=0, .SEEE_LUMA_MOD_Y5=256, .rsv_29=0}},
    .luma_slnk_ctrl={.bits={.SEEE_SLNK_GN_Y1=255, .SEEE_SLNK_GN_Y2=255, .SEEE_RESP_SLNK_GN_RAT=16, .SEEE_GLUT_LINK_EN=0, .SEEE_LUMA_MOD_Y6=256, .rsv_31=0}},
    .glut_ctrl_1={.bits={.SEEE_GLUT_S1=1, .SEEE_GLUT_X1=35, .SEEE_GLUT_Y1=20, .rsv_26=0}},
    .glut_ctrl_2={.bits={.SEEE_GLUT_S2=24, .SEEE_GLUT_X2=60, .SEEE_GLUT_Y2=614, .rsv_26=0}},
    .glut_ctrl_3={.bits={.SEEE_GLUT_S3=248, .SEEE_GLUT_X3=100, .SEEE_GLUT_Y3=307, .rsv_26=0}},
    .glut_ctrl_4={.bits={.SEEE_GLUT_S4=254, .SEEE_GLUT_X4=220, .SEEE_GLUT_Y4=41, .rsv_26=0}},
    .glut_ctrl_5={.bits={.SEEE_GLUT_S5=255, .rsv_8=0, .SEEE_GLUT_SL_DEC_Y=32, .rsv_26=0}},
    .glut_ctrl_6={.bits={.SEEE_GLUT_TH_OVR=255, .SEEE_GLUT_TH_UND=255, .SEEE_GLUT_TH_MIN=0, .rsv_24=0}},
    .artifact_ctrl={.bits={.SEEE_RESP_SMO_STR=7, .rsv_3=0, .SEEE_OVRSH_CLIP_STR=2, .rsv_7=0, .SEEE_DOT_REDUC_AMNT=128, .SEEE_DOT_TH=6, .rsv_24=0}},
    .clip_ctrl ={.bits={.SEEE_RESP_CLIP=64, .SEEE_RESP_CLIP_LUMA_SPC_TH=0, .SEEE_RESP_CLIP_LUMA_LWB=0, .SEEE_RESP_CLIP_LUMA_UPB=255}},
    .gn_ctrl_2 ={.bits={.SEEE_MASTER_GN_NEG=16, .SEEE_MASTER_GN_POS=16, .rsv_16=0}},
    .st_ctrl_1 ={.bits={.SEEE_ST_UB=12, .SEEE_ST_LB=4, .rsv_16=0}},
    .st_ctrl_2 ={.bits={.SEEE_ST_SL_CE=16, .SEEE_ST_OFST_CE=100, .SEEE_ST_SL_RESP=16, .SEEE_ST_OFST_RESP=100}},
    .ct_ctrl   ={.bits={.SEEE_LUMA_LMT_DIFF=255, .SEEE_LUMA_CNTST_LV=3, .rsv_11=0, .SEEE_LUMA_MINI=2, .rsv_15=0, .SEEE_LUMA_MAXI=2, .rsv_19=0, .SEEE_CHR_CNTST_LV=3, .rsv_23=0, .SEEE_CHR_MINI=2, .rsv_26=0, .SEEE_CHR_MAXI=2, .rsv_30=0}},
    .cboost_ctrl_1={.bits={.SEEE_CBOOST_LMT_U=255, .SEEE_CBOOST_LMT_L=64, .SEEE_CBOOST_GAIN=128, .SEEE_CBOOST_EN=1, .rsv_25=0}},
    .cboost_ctrl_2={.bits={.SEEE_CBOOST_YCONST=4, .SEEE_CBOOST_YOFFSET=0, .SEEE_CBOOST_YOFFSET_SEL=0, .rsv_18=0}},
    .pbc1_ctrl_1={.bits={.SEEE_PBC1_RADIUS_R=42, .rsv_6=0, .SEEE_PBC1_RSLOPE=85, .rsv_18=0, .SEEE_PBC1_RSLOPE_1=39, .SEEE_PBC1_EN=1, .SEEE_PBC_EN=0}},
    .pbc1_ctrl_2={.bits={.SEEE_PBC1_TSLOPE=85, .SEEE_PBC1_THETA_R=24, .SEEE_PBC1_THETA_C=149, .SEEE_PBC1_RADIUS_C=48}},
    .pbc1_ctrl_3={.bits={.SEEE_PBC1_LPF_GAIN=16, .SEEE_PBC1_LPF_EN=0, .SEEE_PBC1_EDGE_EN=0, .SEEE_PBC1_EDGE_SLOPE=32, .SEEE_PBC1_EDGE_THR=12, .SEEE_PBC1_CONF_GAIN=1, .SEEE_PBC1_GAIN=48}},
    .pbc2_ctrl_1={.bits={.SEEE_PBC2_RADIUS_R=40, .rsv_6=0, .SEEE_PBC2_RSLOPE=43, .rsv_18=0, .SEEE_PBC2_RSLOPE_1=32, .SEEE_PBC2_EN=1, .rsv_31=0}},
    .pbc2_ctrl_2={.bits={.SEEE_PBC2_TSLOPE=43, .SEEE_PBC2_THETA_R=24, .SEEE_PBC2_THETA_C=88, .SEEE_PBC2_RADIUS_C=48}},
    .pbc2_ctrl_3={.bits={.SEEE_PBC2_LPF_GAIN=10, .SEEE_PBC2_LPF_EN=1, .SEEE_PBC2_EDGE_EN=1, .SEEE_PBC2_EDGE_SLOPE=16, .SEEE_PBC2_EDGE_THR=16, .SEEE_PBC2_CONF_GAIN=4, .SEEE_PBC2_GAIN=0}},
    .pbc3_ctrl_1={.bits={.SEEE_PBC3_RADIUS_R=42, .rsv_6=0, .SEEE_PBC3_RSLOPE=32, .rsv_18=0, .SEEE_PBC3_RSLOPE_1=17, .SEEE_PBC3_EN=1, .rsv_31=0}},
    .pbc3_ctrl_2={.bits={.SEEE_PBC3_TSLOPE=64, .SEEE_PBC3_THETA_R=32, .SEEE_PBC3_THETA_C=224, .SEEE_PBC3_RADIUS_C=60}},
    .pbc3_ctrl_3={.bits={.SEEE_PBC3_LPF_GAIN=6, .SEEE_PBC3_LPF_EN=1, .SEEE_PBC3_EDGE_EN=1, .SEEE_PBC3_EDGE_SLOPE=32, .SEEE_PBC3_EDGE_THR=12, .SEEE_PBC3_CONF_GAIN=1, .SEEE_PBC3_GAIN=0}}

};
const ISP_NVRAM_EE_T gc13a0mipiraw_EE_0154 = {
        .blnd_ctrl_1={.bits={.SEEE_H1_DI_BLND_OFST=0, .SEEE_H2_DI_BLND_OFST=0, .SEEE_H3_DI_BLND_OFST=0, .rsv_24=0}},
    .blnd_ctrl_2={.bits={.SEEE_H1_DI_BLND_SL=12, .SEEE_H2_DI_BLND_SL=12, .SEEE_H3_DI_BLND_SL=12, .SEEE_HX_ISO_BLND_RAT=3, .rsv_29=0}},
    .core_ctrl ={.bits={.SEEE_H1_FLT_CORE_TH=0, .SEEE_H2_FLT_CORE_TH=0, .SEEE_H3_FLT_CORE_TH=0, .SEEE_FLT_CORE_TH=8}},
    .gn_ctrl_1 ={.bits={.SEEE_H1_GN=14, .rsv_5=0, .SEEE_H2_GN=4, .rsv_13=0, .SEEE_H3_GN=1, .rsv_21=0}},
    .luma_ctrl_1={.bits={.SEEE_LUMA_MOD_Y0=256, .rsv_9=0, .SEEE_LUMA_MOD_Y1=256, .rsv_19=0, .SEEE_LUMA_MOD_Y2=256, .rsv_29=0}},
    .luma_ctrl_2={.bits={.SEEE_LUMA_MOD_Y3=256, .rsv_9=0, .SEEE_LUMA_MOD_Y4=256, .rsv_19=0, .SEEE_LUMA_MOD_Y5=256, .rsv_29=0}},
    .luma_slnk_ctrl={.bits={.SEEE_SLNK_GN_Y1=255, .SEEE_SLNK_GN_Y2=255, .SEEE_RESP_SLNK_GN_RAT=16, .SEEE_GLUT_LINK_EN=0, .SEEE_LUMA_MOD_Y6=256, .rsv_31=0}},
    .glut_ctrl_1={.bits={.SEEE_GLUT_S1=1, .SEEE_GLUT_X1=35, .SEEE_GLUT_Y1=20, .rsv_26=0}},
    .glut_ctrl_2={.bits={.SEEE_GLUT_S2=24, .SEEE_GLUT_X2=60, .SEEE_GLUT_Y2=614, .rsv_26=0}},
    .glut_ctrl_3={.bits={.SEEE_GLUT_S3=248, .SEEE_GLUT_X3=100, .SEEE_GLUT_Y3=307, .rsv_26=0}},
    .glut_ctrl_4={.bits={.SEEE_GLUT_S4=254, .SEEE_GLUT_X4=220, .SEEE_GLUT_Y4=41, .rsv_26=0}},
    .glut_ctrl_5={.bits={.SEEE_GLUT_S5=255, .rsv_8=0, .SEEE_GLUT_SL_DEC_Y=32, .rsv_26=0}},
    .glut_ctrl_6={.bits={.SEEE_GLUT_TH_OVR=255, .SEEE_GLUT_TH_UND=255, .SEEE_GLUT_TH_MIN=0, .rsv_24=0}},
    .artifact_ctrl={.bits={.SEEE_RESP_SMO_STR=7, .rsv_3=0, .SEEE_OVRSH_CLIP_STR=2, .rsv_7=0, .SEEE_DOT_REDUC_AMNT=128, .SEEE_DOT_TH=6, .rsv_24=0}},
    .clip_ctrl ={.bits={.SEEE_RESP_CLIP=64, .SEEE_RESP_CLIP_LUMA_SPC_TH=0, .SEEE_RESP_CLIP_LUMA_LWB=0, .SEEE_RESP_CLIP_LUMA_UPB=255}},
    .gn_ctrl_2 ={.bits={.SEEE_MASTER_GN_NEG=16, .SEEE_MASTER_GN_POS=16, .rsv_16=0}},
    .st_ctrl_1 ={.bits={.SEEE_ST_UB=12, .SEEE_ST_LB=4, .rsv_16=0}},
    .st_ctrl_2 ={.bits={.SEEE_ST_SL_CE=16, .SEEE_ST_OFST_CE=100, .SEEE_ST_SL_RESP=16, .SEEE_ST_OFST_RESP=100}},
    .ct_ctrl   ={.bits={.SEEE_LUMA_LMT_DIFF=255, .SEEE_LUMA_CNTST_LV=3, .rsv_11=0, .SEEE_LUMA_MINI=2, .rsv_15=0, .SEEE_LUMA_MAXI=2, .rsv_19=0, .SEEE_CHR_CNTST_LV=3, .rsv_23=0, .SEEE_CHR_MINI=2, .rsv_26=0, .SEEE_CHR_MAXI=2, .rsv_30=0}},
    .cboost_ctrl_1={.bits={.SEEE_CBOOST_LMT_U=255, .SEEE_CBOOST_LMT_L=64, .SEEE_CBOOST_GAIN=128, .SEEE_CBOOST_EN=1, .rsv_25=0}},
    .cboost_ctrl_2={.bits={.SEEE_CBOOST_YCONST=4, .SEEE_CBOOST_YOFFSET=0, .SEEE_CBOOST_YOFFSET_SEL=0, .rsv_18=0}},
    .pbc1_ctrl_1={.bits={.SEEE_PBC1_RADIUS_R=42, .rsv_6=0, .SEEE_PBC1_RSLOPE=85, .rsv_18=0, .SEEE_PBC1_RSLOPE_1=39, .SEEE_PBC1_EN=1, .SEEE_PBC_EN=0}},
    .pbc1_ctrl_2={.bits={.SEEE_PBC1_TSLOPE=85, .SEEE_PBC1_THETA_R=24, .SEEE_PBC1_THETA_C=149, .SEEE_PBC1_RADIUS_C=48}},
    .pbc1_ctrl_3={.bits={.SEEE_PBC1_LPF_GAIN=16, .SEEE_PBC1_LPF_EN=0, .SEEE_PBC1_EDGE_EN=0, .SEEE_PBC1_EDGE_SLOPE=32, .SEEE_PBC1_EDGE_THR=12, .SEEE_PBC1_CONF_GAIN=1, .SEEE_PBC1_GAIN=48}},
    .pbc2_ctrl_1={.bits={.SEEE_PBC2_RADIUS_R=40, .rsv_6=0, .SEEE_PBC2_RSLOPE=43, .rsv_18=0, .SEEE_PBC2_RSLOPE_1=32, .SEEE_PBC2_EN=1, .rsv_31=0}},
    .pbc2_ctrl_2={.bits={.SEEE_PBC2_TSLOPE=43, .SEEE_PBC2_THETA_R=24, .SEEE_PBC2_THETA_C=88, .SEEE_PBC2_RADIUS_C=48}},
    .pbc2_ctrl_3={.bits={.SEEE_PBC2_LPF_GAIN=10, .SEEE_PBC2_LPF_EN=1, .SEEE_PBC2_EDGE_EN=1, .SEEE_PBC2_EDGE_SLOPE=16, .SEEE_PBC2_EDGE_THR=16, .SEEE_PBC2_CONF_GAIN=4, .SEEE_PBC2_GAIN=0}},
    .pbc3_ctrl_1={.bits={.SEEE_PBC3_RADIUS_R=42, .rsv_6=0, .SEEE_PBC3_RSLOPE=32, .rsv_18=0, .SEEE_PBC3_RSLOPE_1=17, .SEEE_PBC3_EN=1, .rsv_31=0}},
    .pbc3_ctrl_2={.bits={.SEEE_PBC3_TSLOPE=64, .SEEE_PBC3_THETA_R=32, .SEEE_PBC3_THETA_C=224, .SEEE_PBC3_RADIUS_C=60}},
    .pbc3_ctrl_3={.bits={.SEEE_PBC3_LPF_GAIN=6, .SEEE_PBC3_LPF_EN=1, .SEEE_PBC3_EDGE_EN=1, .SEEE_PBC3_EDGE_SLOPE=32, .SEEE_PBC3_EDGE_THR=12, .SEEE_PBC3_CONF_GAIN=1, .SEEE_PBC3_GAIN=0}}

};
const ISP_NVRAM_EE_T gc13a0mipiraw_EE_0155 = {
        .blnd_ctrl_1={.bits={.SEEE_H1_DI_BLND_OFST=0, .SEEE_H2_DI_BLND_OFST=0, .SEEE_H3_DI_BLND_OFST=0, .rsv_24=0}},
    .blnd_ctrl_2={.bits={.SEEE_H1_DI_BLND_SL=12, .SEEE_H2_DI_BLND_SL=12, .SEEE_H3_DI_BLND_SL=12, .SEEE_HX_ISO_BLND_RAT=3, .rsv_29=0}},
    .core_ctrl ={.bits={.SEEE_H1_FLT_CORE_TH=0, .SEEE_H2_FLT_CORE_TH=0, .SEEE_H3_FLT_CORE_TH=0, .SEEE_FLT_CORE_TH=8}},
    .gn_ctrl_1 ={.bits={.SEEE_H1_GN=14, .rsv_5=0, .SEEE_H2_GN=4, .rsv_13=0, .SEEE_H3_GN=1, .rsv_21=0}},
    .luma_ctrl_1={.bits={.SEEE_LUMA_MOD_Y0=256, .rsv_9=0, .SEEE_LUMA_MOD_Y1=256, .rsv_19=0, .SEEE_LUMA_MOD_Y2=256, .rsv_29=0}},
    .luma_ctrl_2={.bits={.SEEE_LUMA_MOD_Y3=256, .rsv_9=0, .SEEE_LUMA_MOD_Y4=256, .rsv_19=0, .SEEE_LUMA_MOD_Y5=256, .rsv_29=0}},
    .luma_slnk_ctrl={.bits={.SEEE_SLNK_GN_Y1=255, .SEEE_SLNK_GN_Y2=255, .SEEE_RESP_SLNK_GN_RAT=16, .SEEE_GLUT_LINK_EN=0, .SEEE_LUMA_MOD_Y6=256, .rsv_31=0}},
    .glut_ctrl_1={.bits={.SEEE_GLUT_S1=1, .SEEE_GLUT_X1=35, .SEEE_GLUT_Y1=20, .rsv_26=0}},
    .glut_ctrl_2={.bits={.SEEE_GLUT_S2=24, .SEEE_GLUT_X2=60, .SEEE_GLUT_Y2=614, .rsv_26=0}},
    .glut_ctrl_3={.bits={.SEEE_GLUT_S3=248, .SEEE_GLUT_X3=100, .SEEE_GLUT_Y3=307, .rsv_26=0}},
    .glut_ctrl_4={.bits={.SEEE_GLUT_S4=254, .SEEE_GLUT_X4=220, .SEEE_GLUT_Y4=41, .rsv_26=0}},
    .glut_ctrl_5={.bits={.SEEE_GLUT_S5=255, .rsv_8=0, .SEEE_GLUT_SL_DEC_Y=32, .rsv_26=0}},
    .glut_ctrl_6={.bits={.SEEE_GLUT_TH_OVR=255, .SEEE_GLUT_TH_UND=255, .SEEE_GLUT_TH_MIN=0, .rsv_24=0}},
    .artifact_ctrl={.bits={.SEEE_RESP_SMO_STR=7, .rsv_3=0, .SEEE_OVRSH_CLIP_STR=2, .rsv_7=0, .SEEE_DOT_REDUC_AMNT=128, .SEEE_DOT_TH=6, .rsv_24=0}},
    .clip_ctrl ={.bits={.SEEE_RESP_CLIP=64, .SEEE_RESP_CLIP_LUMA_SPC_TH=0, .SEEE_RESP_CLIP_LUMA_LWB=0, .SEEE_RESP_CLIP_LUMA_UPB=255}},
    .gn_ctrl_2 ={.bits={.SEEE_MASTER_GN_NEG=16, .SEEE_MASTER_GN_POS=16, .rsv_16=0}},
    .st_ctrl_1 ={.bits={.SEEE_ST_UB=12, .SEEE_ST_LB=4, .rsv_16=0}},
    .st_ctrl_2 ={.bits={.SEEE_ST_SL_CE=16, .SEEE_ST_OFST_CE=100, .SEEE_ST_SL_RESP=16, .SEEE_ST_OFST_RESP=100}},
    .ct_ctrl   ={.bits={.SEEE_LUMA_LMT_DIFF=255, .SEEE_LUMA_CNTST_LV=3, .rsv_11=0, .SEEE_LUMA_MINI=2, .rsv_15=0, .SEEE_LUMA_MAXI=2, .rsv_19=0, .SEEE_CHR_CNTST_LV=3, .rsv_23=0, .SEEE_CHR_MINI=2, .rsv_26=0, .SEEE_CHR_MAXI=2, .rsv_30=0}},
    .cboost_ctrl_1={.bits={.SEEE_CBOOST_LMT_U=255, .SEEE_CBOOST_LMT_L=64, .SEEE_CBOOST_GAIN=128, .SEEE_CBOOST_EN=1, .rsv_25=0}},
    .cboost_ctrl_2={.bits={.SEEE_CBOOST_YCONST=4, .SEEE_CBOOST_YOFFSET=0, .SEEE_CBOOST_YOFFSET_SEL=0, .rsv_18=0}},
    .pbc1_ctrl_1={.bits={.SEEE_PBC1_RADIUS_R=42, .rsv_6=0, .SEEE_PBC1_RSLOPE=85, .rsv_18=0, .SEEE_PBC1_RSLOPE_1=39, .SEEE_PBC1_EN=1, .SEEE_PBC_EN=0}},
    .pbc1_ctrl_2={.bits={.SEEE_PBC1_TSLOPE=85, .SEEE_PBC1_THETA_R=24, .SEEE_PBC1_THETA_C=149, .SEEE_PBC1_RADIUS_C=48}},
    .pbc1_ctrl_3={.bits={.SEEE_PBC1_LPF_GAIN=16, .SEEE_PBC1_LPF_EN=0, .SEEE_PBC1_EDGE_EN=0, .SEEE_PBC1_EDGE_SLOPE=32, .SEEE_PBC1_EDGE_THR=12, .SEEE_PBC1_CONF_GAIN=1, .SEEE_PBC1_GAIN=48}},
    .pbc2_ctrl_1={.bits={.SEEE_PBC2_RADIUS_R=40, .rsv_6=0, .SEEE_PBC2_RSLOPE=43, .rsv_18=0, .SEEE_PBC2_RSLOPE_1=32, .SEEE_PBC2_EN=1, .rsv_31=0}},
    .pbc2_ctrl_2={.bits={.SEEE_PBC2_TSLOPE=43, .SEEE_PBC2_THETA_R=24, .SEEE_PBC2_THETA_C=88, .SEEE_PBC2_RADIUS_C=48}},
    .pbc2_ctrl_3={.bits={.SEEE_PBC2_LPF_GAIN=10, .SEEE_PBC2_LPF_EN=1, .SEEE_PBC2_EDGE_EN=1, .SEEE_PBC2_EDGE_SLOPE=16, .SEEE_PBC2_EDGE_THR=16, .SEEE_PBC2_CONF_GAIN=4, .SEEE_PBC2_GAIN=0}},
    .pbc3_ctrl_1={.bits={.SEEE_PBC3_RADIUS_R=42, .rsv_6=0, .SEEE_PBC3_RSLOPE=32, .rsv_18=0, .SEEE_PBC3_RSLOPE_1=17, .SEEE_PBC3_EN=1, .rsv_31=0}},
    .pbc3_ctrl_2={.bits={.SEEE_PBC3_TSLOPE=64, .SEEE_PBC3_THETA_R=32, .SEEE_PBC3_THETA_C=224, .SEEE_PBC3_RADIUS_C=60}},
    .pbc3_ctrl_3={.bits={.SEEE_PBC3_LPF_GAIN=6, .SEEE_PBC3_LPF_EN=1, .SEEE_PBC3_EDGE_EN=1, .SEEE_PBC3_EDGE_SLOPE=32, .SEEE_PBC3_EDGE_THR=12, .SEEE_PBC3_CONF_GAIN=1, .SEEE_PBC3_GAIN=0}}

};
const ISP_NVRAM_EE_T gc13a0mipiraw_EE_0156 = {
        .blnd_ctrl_1={.bits={.SEEE_H1_DI_BLND_OFST=0, .SEEE_H2_DI_BLND_OFST=0, .SEEE_H3_DI_BLND_OFST=0, .rsv_24=0}},
    .blnd_ctrl_2={.bits={.SEEE_H1_DI_BLND_SL=12, .SEEE_H2_DI_BLND_SL=12, .SEEE_H3_DI_BLND_SL=12, .SEEE_HX_ISO_BLND_RAT=3, .rsv_29=0}},
    .core_ctrl ={.bits={.SEEE_H1_FLT_CORE_TH=0, .SEEE_H2_FLT_CORE_TH=0, .SEEE_H3_FLT_CORE_TH=0, .SEEE_FLT_CORE_TH=8}},
    .gn_ctrl_1 ={.bits={.SEEE_H1_GN=14, .rsv_5=0, .SEEE_H2_GN=4, .rsv_13=0, .SEEE_H3_GN=1, .rsv_21=0}},
    .luma_ctrl_1={.bits={.SEEE_LUMA_MOD_Y0=256, .rsv_9=0, .SEEE_LUMA_MOD_Y1=256, .rsv_19=0, .SEEE_LUMA_MOD_Y2=256, .rsv_29=0}},
    .luma_ctrl_2={.bits={.SEEE_LUMA_MOD_Y3=256, .rsv_9=0, .SEEE_LUMA_MOD_Y4=256, .rsv_19=0, .SEEE_LUMA_MOD_Y5=256, .rsv_29=0}},
    .luma_slnk_ctrl={.bits={.SEEE_SLNK_GN_Y1=255, .SEEE_SLNK_GN_Y2=255, .SEEE_RESP_SLNK_GN_RAT=16, .SEEE_GLUT_LINK_EN=0, .SEEE_LUMA_MOD_Y6=256, .rsv_31=0}},
    .glut_ctrl_1={.bits={.SEEE_GLUT_S1=1, .SEEE_GLUT_X1=35, .SEEE_GLUT_Y1=20, .rsv_26=0}},
    .glut_ctrl_2={.bits={.SEEE_GLUT_S2=24, .SEEE_GLUT_X2=60, .SEEE_GLUT_Y2=614, .rsv_26=0}},
    .glut_ctrl_3={.bits={.SEEE_GLUT_S3=248, .SEEE_GLUT_X3=100, .SEEE_GLUT_Y3=307, .rsv_26=0}},
    .glut_ctrl_4={.bits={.SEEE_GLUT_S4=254, .SEEE_GLUT_X4=220, .SEEE_GLUT_Y4=41, .rsv_26=0}},
    .glut_ctrl_5={.bits={.SEEE_GLUT_S5=255, .rsv_8=0, .SEEE_GLUT_SL_DEC_Y=32, .rsv_26=0}},
    .glut_ctrl_6={.bits={.SEEE_GLUT_TH_OVR=255, .SEEE_GLUT_TH_UND=255, .SEEE_GLUT_TH_MIN=0, .rsv_24=0}},
    .artifact_ctrl={.bits={.SEEE_RESP_SMO_STR=7, .rsv_3=0, .SEEE_OVRSH_CLIP_STR=2, .rsv_7=0, .SEEE_DOT_REDUC_AMNT=128, .SEEE_DOT_TH=6, .rsv_24=0}},
    .clip_ctrl ={.bits={.SEEE_RESP_CLIP=64, .SEEE_RESP_CLIP_LUMA_SPC_TH=0, .SEEE_RESP_CLIP_LUMA_LWB=0, .SEEE_RESP_CLIP_LUMA_UPB=255}},
    .gn_ctrl_2 ={.bits={.SEEE_MASTER_GN_NEG=16, .SEEE_MASTER_GN_POS=16, .rsv_16=0}},
    .st_ctrl_1 ={.bits={.SEEE_ST_UB=12, .SEEE_ST_LB=4, .rsv_16=0}},
    .st_ctrl_2 ={.bits={.SEEE_ST_SL_CE=16, .SEEE_ST_OFST_CE=100, .SEEE_ST_SL_RESP=16, .SEEE_ST_OFST_RESP=100}},
    .ct_ctrl   ={.bits={.SEEE_LUMA_LMT_DIFF=255, .SEEE_LUMA_CNTST_LV=3, .rsv_11=0, .SEEE_LUMA_MINI=2, .rsv_15=0, .SEEE_LUMA_MAXI=2, .rsv_19=0, .SEEE_CHR_CNTST_LV=3, .rsv_23=0, .SEEE_CHR_MINI=2, .rsv_26=0, .SEEE_CHR_MAXI=2, .rsv_30=0}},
    .cboost_ctrl_1={.bits={.SEEE_CBOOST_LMT_U=255, .SEEE_CBOOST_LMT_L=64, .SEEE_CBOOST_GAIN=128, .SEEE_CBOOST_EN=1, .rsv_25=0}},
    .cboost_ctrl_2={.bits={.SEEE_CBOOST_YCONST=4, .SEEE_CBOOST_YOFFSET=0, .SEEE_CBOOST_YOFFSET_SEL=0, .rsv_18=0}},
    .pbc1_ctrl_1={.bits={.SEEE_PBC1_RADIUS_R=42, .rsv_6=0, .SEEE_PBC1_RSLOPE=85, .rsv_18=0, .SEEE_PBC1_RSLOPE_1=39, .SEEE_PBC1_EN=1, .SEEE_PBC_EN=0}},
    .pbc1_ctrl_2={.bits={.SEEE_PBC1_TSLOPE=85, .SEEE_PBC1_THETA_R=24, .SEEE_PBC1_THETA_C=149, .SEEE_PBC1_RADIUS_C=48}},
    .pbc1_ctrl_3={.bits={.SEEE_PBC1_LPF_GAIN=16, .SEEE_PBC1_LPF_EN=0, .SEEE_PBC1_EDGE_EN=0, .SEEE_PBC1_EDGE_SLOPE=32, .SEEE_PBC1_EDGE_THR=12, .SEEE_PBC1_CONF_GAIN=1, .SEEE_PBC1_GAIN=48}},
    .pbc2_ctrl_1={.bits={.SEEE_PBC2_RADIUS_R=40, .rsv_6=0, .SEEE_PBC2_RSLOPE=43, .rsv_18=0, .SEEE_PBC2_RSLOPE_1=32, .SEEE_PBC2_EN=1, .rsv_31=0}},
    .pbc2_ctrl_2={.bits={.SEEE_PBC2_TSLOPE=43, .SEEE_PBC2_THETA_R=24, .SEEE_PBC2_THETA_C=88, .SEEE_PBC2_RADIUS_C=48}},
    .pbc2_ctrl_3={.bits={.SEEE_PBC2_LPF_GAIN=10, .SEEE_PBC2_LPF_EN=1, .SEEE_PBC2_EDGE_EN=1, .SEEE_PBC2_EDGE_SLOPE=16, .SEEE_PBC2_EDGE_THR=16, .SEEE_PBC2_CONF_GAIN=4, .SEEE_PBC2_GAIN=0}},
    .pbc3_ctrl_1={.bits={.SEEE_PBC3_RADIUS_R=42, .rsv_6=0, .SEEE_PBC3_RSLOPE=32, .rsv_18=0, .SEEE_PBC3_RSLOPE_1=17, .SEEE_PBC3_EN=1, .rsv_31=0}},
    .pbc3_ctrl_2={.bits={.SEEE_PBC3_TSLOPE=64, .SEEE_PBC3_THETA_R=32, .SEEE_PBC3_THETA_C=224, .SEEE_PBC3_RADIUS_C=60}},
    .pbc3_ctrl_3={.bits={.SEEE_PBC3_LPF_GAIN=6, .SEEE_PBC3_LPF_EN=1, .SEEE_PBC3_EDGE_EN=1, .SEEE_PBC3_EDGE_SLOPE=32, .SEEE_PBC3_EDGE_THR=12, .SEEE_PBC3_CONF_GAIN=1, .SEEE_PBC3_GAIN=0}}

};
const ISP_NVRAM_EE_T gc13a0mipiraw_EE_0157 = {
        .blnd_ctrl_1={.bits={.SEEE_H1_DI_BLND_OFST=0, .SEEE_H2_DI_BLND_OFST=0, .SEEE_H3_DI_BLND_OFST=0, .rsv_24=0}},
    .blnd_ctrl_2={.bits={.SEEE_H1_DI_BLND_SL=12, .SEEE_H2_DI_BLND_SL=12, .SEEE_H3_DI_BLND_SL=12, .SEEE_HX_ISO_BLND_RAT=3, .rsv_29=0}},
    .core_ctrl ={.bits={.SEEE_H1_FLT_CORE_TH=0, .SEEE_H2_FLT_CORE_TH=0, .SEEE_H3_FLT_CORE_TH=0, .SEEE_FLT_CORE_TH=8}},
    .gn_ctrl_1 ={.bits={.SEEE_H1_GN=14, .rsv_5=0, .SEEE_H2_GN=4, .rsv_13=0, .SEEE_H3_GN=1, .rsv_21=0}},
    .luma_ctrl_1={.bits={.SEEE_LUMA_MOD_Y0=256, .rsv_9=0, .SEEE_LUMA_MOD_Y1=256, .rsv_19=0, .SEEE_LUMA_MOD_Y2=256, .rsv_29=0}},
    .luma_ctrl_2={.bits={.SEEE_LUMA_MOD_Y3=256, .rsv_9=0, .SEEE_LUMA_MOD_Y4=256, .rsv_19=0, .SEEE_LUMA_MOD_Y5=256, .rsv_29=0}},
    .luma_slnk_ctrl={.bits={.SEEE_SLNK_GN_Y1=255, .SEEE_SLNK_GN_Y2=255, .SEEE_RESP_SLNK_GN_RAT=16, .SEEE_GLUT_LINK_EN=0, .SEEE_LUMA_MOD_Y6=256, .rsv_31=0}},
    .glut_ctrl_1={.bits={.SEEE_GLUT_S1=1, .SEEE_GLUT_X1=35, .SEEE_GLUT_Y1=20, .rsv_26=0}},
    .glut_ctrl_2={.bits={.SEEE_GLUT_S2=24, .SEEE_GLUT_X2=60, .SEEE_GLUT_Y2=614, .rsv_26=0}},
    .glut_ctrl_3={.bits={.SEEE_GLUT_S3=248, .SEEE_GLUT_X3=100, .SEEE_GLUT_Y3=307, .rsv_26=0}},
    .glut_ctrl_4={.bits={.SEEE_GLUT_S4=254, .SEEE_GLUT_X4=220, .SEEE_GLUT_Y4=41, .rsv_26=0}},
    .glut_ctrl_5={.bits={.SEEE_GLUT_S5=255, .rsv_8=0, .SEEE_GLUT_SL_DEC_Y=32, .rsv_26=0}},
    .glut_ctrl_6={.bits={.SEEE_GLUT_TH_OVR=255, .SEEE_GLUT_TH_UND=255, .SEEE_GLUT_TH_MIN=0, .rsv_24=0}},
    .artifact_ctrl={.bits={.SEEE_RESP_SMO_STR=7, .rsv_3=0, .SEEE_OVRSH_CLIP_STR=2, .rsv_7=0, .SEEE_DOT_REDUC_AMNT=128, .SEEE_DOT_TH=6, .rsv_24=0}},
    .clip_ctrl ={.bits={.SEEE_RESP_CLIP=64, .SEEE_RESP_CLIP_LUMA_SPC_TH=0, .SEEE_RESP_CLIP_LUMA_LWB=0, .SEEE_RESP_CLIP_LUMA_UPB=255}},
    .gn_ctrl_2 ={.bits={.SEEE_MASTER_GN_NEG=16, .SEEE_MASTER_GN_POS=16, .rsv_16=0}},
    .st_ctrl_1 ={.bits={.SEEE_ST_UB=12, .SEEE_ST_LB=4, .rsv_16=0}},
    .st_ctrl_2 ={.bits={.SEEE_ST_SL_CE=16, .SEEE_ST_OFST_CE=100, .SEEE_ST_SL_RESP=16, .SEEE_ST_OFST_RESP=100}},
    .ct_ctrl   ={.bits={.SEEE_LUMA_LMT_DIFF=255, .SEEE_LUMA_CNTST_LV=3, .rsv_11=0, .SEEE_LUMA_MINI=2, .rsv_15=0, .SEEE_LUMA_MAXI=2, .rsv_19=0, .SEEE_CHR_CNTST_LV=3, .rsv_23=0, .SEEE_CHR_MINI=2, .rsv_26=0, .SEEE_CHR_MAXI=2, .rsv_30=0}},
    .cboost_ctrl_1={.bits={.SEEE_CBOOST_LMT_U=255, .SEEE_CBOOST_LMT_L=64, .SEEE_CBOOST_GAIN=128, .SEEE_CBOOST_EN=1, .rsv_25=0}},
    .cboost_ctrl_2={.bits={.SEEE_CBOOST_YCONST=4, .SEEE_CBOOST_YOFFSET=0, .SEEE_CBOOST_YOFFSET_SEL=0, .rsv_18=0}},
    .pbc1_ctrl_1={.bits={.SEEE_PBC1_RADIUS_R=42, .rsv_6=0, .SEEE_PBC1_RSLOPE=85, .rsv_18=0, .SEEE_PBC1_RSLOPE_1=39, .SEEE_PBC1_EN=1, .SEEE_PBC_EN=0}},
    .pbc1_ctrl_2={.bits={.SEEE_PBC1_TSLOPE=85, .SEEE_PBC1_THETA_R=24, .SEEE_PBC1_THETA_C=149, .SEEE_PBC1_RADIUS_C=48}},
    .pbc1_ctrl_3={.bits={.SEEE_PBC1_LPF_GAIN=16, .SEEE_PBC1_LPF_EN=0, .SEEE_PBC1_EDGE_EN=0, .SEEE_PBC1_EDGE_SLOPE=32, .SEEE_PBC1_EDGE_THR=12, .SEEE_PBC1_CONF_GAIN=1, .SEEE_PBC1_GAIN=48}},
    .pbc2_ctrl_1={.bits={.SEEE_PBC2_RADIUS_R=40, .rsv_6=0, .SEEE_PBC2_RSLOPE=43, .rsv_18=0, .SEEE_PBC2_RSLOPE_1=32, .SEEE_PBC2_EN=1, .rsv_31=0}},
    .pbc2_ctrl_2={.bits={.SEEE_PBC2_TSLOPE=43, .SEEE_PBC2_THETA_R=24, .SEEE_PBC2_THETA_C=88, .SEEE_PBC2_RADIUS_C=48}},
    .pbc2_ctrl_3={.bits={.SEEE_PBC2_LPF_GAIN=10, .SEEE_PBC2_LPF_EN=1, .SEEE_PBC2_EDGE_EN=1, .SEEE_PBC2_EDGE_SLOPE=16, .SEEE_PBC2_EDGE_THR=16, .SEEE_PBC2_CONF_GAIN=4, .SEEE_PBC2_GAIN=0}},
    .pbc3_ctrl_1={.bits={.SEEE_PBC3_RADIUS_R=42, .rsv_6=0, .SEEE_PBC3_RSLOPE=32, .rsv_18=0, .SEEE_PBC3_RSLOPE_1=17, .SEEE_PBC3_EN=1, .rsv_31=0}},
    .pbc3_ctrl_2={.bits={.SEEE_PBC3_TSLOPE=64, .SEEE_PBC3_THETA_R=32, .SEEE_PBC3_THETA_C=224, .SEEE_PBC3_RADIUS_C=60}},
    .pbc3_ctrl_3={.bits={.SEEE_PBC3_LPF_GAIN=6, .SEEE_PBC3_LPF_EN=1, .SEEE_PBC3_EDGE_EN=1, .SEEE_PBC3_EDGE_SLOPE=32, .SEEE_PBC3_EDGE_THR=12, .SEEE_PBC3_CONF_GAIN=1, .SEEE_PBC3_GAIN=0}}

};
const ISP_NVRAM_EE_T gc13a0mipiraw_EE_0158 = {
        .blnd_ctrl_1={.bits={.SEEE_H1_DI_BLND_OFST=0, .SEEE_H2_DI_BLND_OFST=0, .SEEE_H3_DI_BLND_OFST=0, .rsv_24=0}},
    .blnd_ctrl_2={.bits={.SEEE_H1_DI_BLND_SL=12, .SEEE_H2_DI_BLND_SL=12, .SEEE_H3_DI_BLND_SL=12, .SEEE_HX_ISO_BLND_RAT=3, .rsv_29=0}},
    .core_ctrl ={.bits={.SEEE_H1_FLT_CORE_TH=0, .SEEE_H2_FLT_CORE_TH=0, .SEEE_H3_FLT_CORE_TH=0, .SEEE_FLT_CORE_TH=8}},
    .gn_ctrl_1 ={.bits={.SEEE_H1_GN=14, .rsv_5=0, .SEEE_H2_GN=4, .rsv_13=0, .SEEE_H3_GN=1, .rsv_21=0}},
    .luma_ctrl_1={.bits={.SEEE_LUMA_MOD_Y0=256, .rsv_9=0, .SEEE_LUMA_MOD_Y1=256, .rsv_19=0, .SEEE_LUMA_MOD_Y2=256, .rsv_29=0}},
    .luma_ctrl_2={.bits={.SEEE_LUMA_MOD_Y3=256, .rsv_9=0, .SEEE_LUMA_MOD_Y4=256, .rsv_19=0, .SEEE_LUMA_MOD_Y5=256, .rsv_29=0}},
    .luma_slnk_ctrl={.bits={.SEEE_SLNK_GN_Y1=255, .SEEE_SLNK_GN_Y2=255, .SEEE_RESP_SLNK_GN_RAT=16, .SEEE_GLUT_LINK_EN=0, .SEEE_LUMA_MOD_Y6=256, .rsv_31=0}},
    .glut_ctrl_1={.bits={.SEEE_GLUT_S1=1, .SEEE_GLUT_X1=35, .SEEE_GLUT_Y1=20, .rsv_26=0}},
    .glut_ctrl_2={.bits={.SEEE_GLUT_S2=24, .SEEE_GLUT_X2=60, .SEEE_GLUT_Y2=614, .rsv_26=0}},
    .glut_ctrl_3={.bits={.SEEE_GLUT_S3=248, .SEEE_GLUT_X3=100, .SEEE_GLUT_Y3=307, .rsv_26=0}},
    .glut_ctrl_4={.bits={.SEEE_GLUT_S4=254, .SEEE_GLUT_X4=220, .SEEE_GLUT_Y4=41, .rsv_26=0}},
    .glut_ctrl_5={.bits={.SEEE_GLUT_S5=255, .rsv_8=0, .SEEE_GLUT_SL_DEC_Y=32, .rsv_26=0}},
    .glut_ctrl_6={.bits={.SEEE_GLUT_TH_OVR=255, .SEEE_GLUT_TH_UND=255, .SEEE_GLUT_TH_MIN=0, .rsv_24=0}},
    .artifact_ctrl={.bits={.SEEE_RESP_SMO_STR=7, .rsv_3=0, .SEEE_OVRSH_CLIP_STR=2, .rsv_7=0, .SEEE_DOT_REDUC_AMNT=128, .SEEE_DOT_TH=6, .rsv_24=0}},
    .clip_ctrl ={.bits={.SEEE_RESP_CLIP=64, .SEEE_RESP_CLIP_LUMA_SPC_TH=0, .SEEE_RESP_CLIP_LUMA_LWB=0, .SEEE_RESP_CLIP_LUMA_UPB=255}},
    .gn_ctrl_2 ={.bits={.SEEE_MASTER_GN_NEG=16, .SEEE_MASTER_GN_POS=16, .rsv_16=0}},
    .st_ctrl_1 ={.bits={.SEEE_ST_UB=12, .SEEE_ST_LB=4, .rsv_16=0}},
    .st_ctrl_2 ={.bits={.SEEE_ST_SL_CE=16, .SEEE_ST_OFST_CE=100, .SEEE_ST_SL_RESP=16, .SEEE_ST_OFST_RESP=100}},
    .ct_ctrl   ={.bits={.SEEE_LUMA_LMT_DIFF=255, .SEEE_LUMA_CNTST_LV=3, .rsv_11=0, .SEEE_LUMA_MINI=2, .rsv_15=0, .SEEE_LUMA_MAXI=2, .rsv_19=0, .SEEE_CHR_CNTST_LV=3, .rsv_23=0, .SEEE_CHR_MINI=2, .rsv_26=0, .SEEE_CHR_MAXI=2, .rsv_30=0}},
    .cboost_ctrl_1={.bits={.SEEE_CBOOST_LMT_U=255, .SEEE_CBOOST_LMT_L=64, .SEEE_CBOOST_GAIN=128, .SEEE_CBOOST_EN=1, .rsv_25=0}},
    .cboost_ctrl_2={.bits={.SEEE_CBOOST_YCONST=4, .SEEE_CBOOST_YOFFSET=0, .SEEE_CBOOST_YOFFSET_SEL=0, .rsv_18=0}},
    .pbc1_ctrl_1={.bits={.SEEE_PBC1_RADIUS_R=42, .rsv_6=0, .SEEE_PBC1_RSLOPE=85, .rsv_18=0, .SEEE_PBC1_RSLOPE_1=39, .SEEE_PBC1_EN=1, .SEEE_PBC_EN=0}},
    .pbc1_ctrl_2={.bits={.SEEE_PBC1_TSLOPE=85, .SEEE_PBC1_THETA_R=24, .SEEE_PBC1_THETA_C=149, .SEEE_PBC1_RADIUS_C=48}},
    .pbc1_ctrl_3={.bits={.SEEE_PBC1_LPF_GAIN=16, .SEEE_PBC1_LPF_EN=0, .SEEE_PBC1_EDGE_EN=0, .SEEE_PBC1_EDGE_SLOPE=32, .SEEE_PBC1_EDGE_THR=12, .SEEE_PBC1_CONF_GAIN=1, .SEEE_PBC1_GAIN=48}},
    .pbc2_ctrl_1={.bits={.SEEE_PBC2_RADIUS_R=40, .rsv_6=0, .SEEE_PBC2_RSLOPE=43, .rsv_18=0, .SEEE_PBC2_RSLOPE_1=32, .SEEE_PBC2_EN=1, .rsv_31=0}},
    .pbc2_ctrl_2={.bits={.SEEE_PBC2_TSLOPE=43, .SEEE_PBC2_THETA_R=24, .SEEE_PBC2_THETA_C=88, .SEEE_PBC2_RADIUS_C=48}},
    .pbc2_ctrl_3={.bits={.SEEE_PBC2_LPF_GAIN=10, .SEEE_PBC2_LPF_EN=1, .SEEE_PBC2_EDGE_EN=1, .SEEE_PBC2_EDGE_SLOPE=16, .SEEE_PBC2_EDGE_THR=16, .SEEE_PBC2_CONF_GAIN=4, .SEEE_PBC2_GAIN=0}},
    .pbc3_ctrl_1={.bits={.SEEE_PBC3_RADIUS_R=42, .rsv_6=0, .SEEE_PBC3_RSLOPE=32, .rsv_18=0, .SEEE_PBC3_RSLOPE_1=17, .SEEE_PBC3_EN=1, .rsv_31=0}},
    .pbc3_ctrl_2={.bits={.SEEE_PBC3_TSLOPE=64, .SEEE_PBC3_THETA_R=32, .SEEE_PBC3_THETA_C=224, .SEEE_PBC3_RADIUS_C=60}},
    .pbc3_ctrl_3={.bits={.SEEE_PBC3_LPF_GAIN=6, .SEEE_PBC3_LPF_EN=1, .SEEE_PBC3_EDGE_EN=1, .SEEE_PBC3_EDGE_SLOPE=32, .SEEE_PBC3_EDGE_THR=12, .SEEE_PBC3_CONF_GAIN=1, .SEEE_PBC3_GAIN=0}}

};
const ISP_NVRAM_EE_T gc13a0mipiraw_EE_0159 = {
        .blnd_ctrl_1={.bits={.SEEE_H1_DI_BLND_OFST=0, .SEEE_H2_DI_BLND_OFST=0, .SEEE_H3_DI_BLND_OFST=0, .rsv_24=0}},
    .blnd_ctrl_2={.bits={.SEEE_H1_DI_BLND_SL=12, .SEEE_H2_DI_BLND_SL=12, .SEEE_H3_DI_BLND_SL=12, .SEEE_HX_ISO_BLND_RAT=3, .rsv_29=0}},
    .core_ctrl ={.bits={.SEEE_H1_FLT_CORE_TH=0, .SEEE_H2_FLT_CORE_TH=0, .SEEE_H3_FLT_CORE_TH=0, .SEEE_FLT_CORE_TH=8}},
    .gn_ctrl_1 ={.bits={.SEEE_H1_GN=14, .rsv_5=0, .SEEE_H2_GN=4, .rsv_13=0, .SEEE_H3_GN=1, .rsv_21=0}},
    .luma_ctrl_1={.bits={.SEEE_LUMA_MOD_Y0=256, .rsv_9=0, .SEEE_LUMA_MOD_Y1=256, .rsv_19=0, .SEEE_LUMA_MOD_Y2=256, .rsv_29=0}},
    .luma_ctrl_2={.bits={.SEEE_LUMA_MOD_Y3=256, .rsv_9=0, .SEEE_LUMA_MOD_Y4=256, .rsv_19=0, .SEEE_LUMA_MOD_Y5=256, .rsv_29=0}},
    .luma_slnk_ctrl={.bits={.SEEE_SLNK_GN_Y1=255, .SEEE_SLNK_GN_Y2=255, .SEEE_RESP_SLNK_GN_RAT=16, .SEEE_GLUT_LINK_EN=0, .SEEE_LUMA_MOD_Y6=256, .rsv_31=0}},
    .glut_ctrl_1={.bits={.SEEE_GLUT_S1=1, .SEEE_GLUT_X1=35, .SEEE_GLUT_Y1=20, .rsv_26=0}},
    .glut_ctrl_2={.bits={.SEEE_GLUT_S2=24, .SEEE_GLUT_X2=60, .SEEE_GLUT_Y2=614, .rsv_26=0}},
    .glut_ctrl_3={.bits={.SEEE_GLUT_S3=248, .SEEE_GLUT_X3=100, .SEEE_GLUT_Y3=307, .rsv_26=0}},
    .glut_ctrl_4={.bits={.SEEE_GLUT_S4=254, .SEEE_GLUT_X4=220, .SEEE_GLUT_Y4=41, .rsv_26=0}},
    .glut_ctrl_5={.bits={.SEEE_GLUT_S5=255, .rsv_8=0, .SEEE_GLUT_SL_DEC_Y=32, .rsv_26=0}},
    .glut_ctrl_6={.bits={.SEEE_GLUT_TH_OVR=255, .SEEE_GLUT_TH_UND=255, .SEEE_GLUT_TH_MIN=0, .rsv_24=0}},
    .artifact_ctrl={.bits={.SEEE_RESP_SMO_STR=7, .rsv_3=0, .SEEE_OVRSH_CLIP_STR=2, .rsv_7=0, .SEEE_DOT_REDUC_AMNT=128, .SEEE_DOT_TH=6, .rsv_24=0}},
    .clip_ctrl ={.bits={.SEEE_RESP_CLIP=64, .SEEE_RESP_CLIP_LUMA_SPC_TH=0, .SEEE_RESP_CLIP_LUMA_LWB=0, .SEEE_RESP_CLIP_LUMA_UPB=255}},
    .gn_ctrl_2 ={.bits={.SEEE_MASTER_GN_NEG=16, .SEEE_MASTER_GN_POS=16, .rsv_16=0}},
    .st_ctrl_1 ={.bits={.SEEE_ST_UB=12, .SEEE_ST_LB=4, .rsv_16=0}},
    .st_ctrl_2 ={.bits={.SEEE_ST_SL_CE=16, .SEEE_ST_OFST_CE=100, .SEEE_ST_SL_RESP=16, .SEEE_ST_OFST_RESP=100}},
    .ct_ctrl   ={.bits={.SEEE_LUMA_LMT_DIFF=255, .SEEE_LUMA_CNTST_LV=3, .rsv_11=0, .SEEE_LUMA_MINI=2, .rsv_15=0, .SEEE_LUMA_MAXI=2, .rsv_19=0, .SEEE_CHR_CNTST_LV=3, .rsv_23=0, .SEEE_CHR_MINI=2, .rsv_26=0, .SEEE_CHR_MAXI=2, .rsv_30=0}},
    .cboost_ctrl_1={.bits={.SEEE_CBOOST_LMT_U=255, .SEEE_CBOOST_LMT_L=64, .SEEE_CBOOST_GAIN=128, .SEEE_CBOOST_EN=1, .rsv_25=0}},
    .cboost_ctrl_2={.bits={.SEEE_CBOOST_YCONST=4, .SEEE_CBOOST_YOFFSET=0, .SEEE_CBOOST_YOFFSET_SEL=0, .rsv_18=0}},
    .pbc1_ctrl_1={.bits={.SEEE_PBC1_RADIUS_R=42, .rsv_6=0, .SEEE_PBC1_RSLOPE=85, .rsv_18=0, .SEEE_PBC1_RSLOPE_1=39, .SEEE_PBC1_EN=1, .SEEE_PBC_EN=0}},
    .pbc1_ctrl_2={.bits={.SEEE_PBC1_TSLOPE=85, .SEEE_PBC1_THETA_R=24, .SEEE_PBC1_THETA_C=149, .SEEE_PBC1_RADIUS_C=48}},
    .pbc1_ctrl_3={.bits={.SEEE_PBC1_LPF_GAIN=16, .SEEE_PBC1_LPF_EN=0, .SEEE_PBC1_EDGE_EN=0, .SEEE_PBC1_EDGE_SLOPE=32, .SEEE_PBC1_EDGE_THR=12, .SEEE_PBC1_CONF_GAIN=1, .SEEE_PBC1_GAIN=48}},
    .pbc2_ctrl_1={.bits={.SEEE_PBC2_RADIUS_R=40, .rsv_6=0, .SEEE_PBC2_RSLOPE=43, .rsv_18=0, .SEEE_PBC2_RSLOPE_1=32, .SEEE_PBC2_EN=1, .rsv_31=0}},
    .pbc2_ctrl_2={.bits={.SEEE_PBC2_TSLOPE=43, .SEEE_PBC2_THETA_R=24, .SEEE_PBC2_THETA_C=88, .SEEE_PBC2_RADIUS_C=48}},
    .pbc2_ctrl_3={.bits={.SEEE_PBC2_LPF_GAIN=10, .SEEE_PBC2_LPF_EN=1, .SEEE_PBC2_EDGE_EN=1, .SEEE_PBC2_EDGE_SLOPE=16, .SEEE_PBC2_EDGE_THR=16, .SEEE_PBC2_CONF_GAIN=4, .SEEE_PBC2_GAIN=0}},
    .pbc3_ctrl_1={.bits={.SEEE_PBC3_RADIUS_R=42, .rsv_6=0, .SEEE_PBC3_RSLOPE=32, .rsv_18=0, .SEEE_PBC3_RSLOPE_1=17, .SEEE_PBC3_EN=1, .rsv_31=0}},
    .pbc3_ctrl_2={.bits={.SEEE_PBC3_TSLOPE=64, .SEEE_PBC3_THETA_R=32, .SEEE_PBC3_THETA_C=224, .SEEE_PBC3_RADIUS_C=60}},
    .pbc3_ctrl_3={.bits={.SEEE_PBC3_LPF_GAIN=6, .SEEE_PBC3_LPF_EN=1, .SEEE_PBC3_EDGE_EN=1, .SEEE_PBC3_EDGE_SLOPE=32, .SEEE_PBC3_EDGE_THR=12, .SEEE_PBC3_CONF_GAIN=1, .SEEE_PBC3_GAIN=0}}

};
const ISP_NVRAM_NR3D_T gc13a0mipiraw_NR3D_0060 = {
        .on_con    ={.bits={.rsv_0=0, .NR3D_ON_EN=0, .rsv_5=0, .NR3D_TILE_EDGE=15, .rsv_12=0, .NR3D_SL2_OFF=0, .rsv_21=0}},
    .tnr_tnr_enable={.bits={.rsv_0=0, .NR3D_TNR_C_EN=0, .NR3D_TNR_Y_EN=0}},
    .tnr_flt_config={.bits={.rsv_0=0, .NR3D_EN_CCR=1, .NR3D_EN_CYCR=1, .NR3D_FLT_STR_MAX=28, .NR3D_BLEND_RATIO_MV=8, .NR3D_BLEND_RATIO_TXTR=8, .NR3D_BLEND_RATIO_DE=8, .NR3D_BLEND_RATIO_BLKY=8}},
    .tnr_fb_info1={.bits={.rsv_0=0, .NR3D_Q_SP=20, .NR3D_Q_NL=4}},
    .tnr_thr_1 ={.bits={.rsv_0=0, .NR3D_SMALL_SAD_THR=10, .NR3D_MV_PEN_THR=32, .NR3D_MV_PEN_W=8, .NR3D_BDI_THR=4, .rsv_30=0}},
    .tnr_curve_1={.bits={.rsv_0=0, .NR3D_Q_BLKY_Y4=16, .NR3D_Q_BLKY_Y3=26, .NR3D_Q_BLKY_Y2=32, .NR3D_Q_BLKY_Y1=30, .NR3D_Q_BLKY_Y0=28}},
    .tnr_curve_2={.bits={.rsv_0=0, .NR3D_Q_BLKC_Y1=26, .NR3D_Q_BLKC_Y0=24, .NR3D_Q_BLKY_Y7=0, .NR3D_Q_BLKY_Y6=0, .NR3D_Q_BLKY_Y5=4}},
    .tnr_curve_3={.bits={.rsv_0=0, .NR3D_Q_BLKC_Y6=0, .NR3D_Q_BLKC_Y5=0, .NR3D_Q_BLKC_Y4=0, .NR3D_Q_BLKC_Y3=2, .NR3D_Q_BLKC_Y2=8}},
    .tnr_curve_4={.bits={.rsv_0=0, .NR3D_Q_DETXTR_LVL_Y3=21, .NR3D_Q_DETXTR_LVL_Y2=16, .NR3D_Q_DETXTR_LVL_Y1=8, .NR3D_Q_DETXTR_LVL_Y0=0, .NR3D_Q_BLKC_Y7=0}},
    .tnr_curve_5={.bits={.rsv_0=0, .NR3D_Q_DE1_BASE_Y0=32, .NR3D_Q_DETXTR_LVL_Y7=32, .NR3D_Q_DETXTR_LVL_Y6=32, .NR3D_Q_DETXTR_LVL_Y5=32, .NR3D_Q_DETXTR_LVL_Y4=27}},
    .tnr_curve_6={.bits={.rsv_0=0, .NR3D_Q_DE1_BASE_Y5=0, .NR3D_Q_DE1_BASE_Y4=12, .NR3D_Q_DE1_BASE_Y3=21, .NR3D_Q_DE1_BASE_Y2=27, .NR3D_Q_DE1_BASE_Y1=32}},
    .tnr_curve_7={.bits={.rsv_0=0, .NR3D_Q_DE2TXTR_BASE_Y2=22, .NR3D_Q_DE2TXTR_BASE_Y1=5, .NR3D_Q_DE2TXTR_BASE_Y0=0, .NR3D_Q_DE1_BASE_Y7=0, .NR3D_Q_DE1_BASE_Y6=0}},
    .tnr_curve_8={.bits={.rsv_0=0, .NR3D_Q_DE2TXTR_BASE_Y7=32, .NR3D_Q_DE2TXTR_BASE_Y6=32, .NR3D_Q_DE2TXTR_BASE_Y5=32, .NR3D_Q_DE2TXTR_BASE_Y4=32, .NR3D_Q_DE2TXTR_BASE_Y3=32}},
    .tnr_curve_9={.bits={.rsv_0=0, .NR3D_Q_MV_Y4=20, .NR3D_Q_MV_Y3=14, .NR3D_Q_MV_Y2=7, .NR3D_Q_MV_Y1=3, .NR3D_Q_MV_Y0=0}},
    .tnr_curve_10={.bits={.rsv_0=0, .NR3D_Q_WVAR_Y1=16, .NR3D_Q_WVAR_Y0=16, .NR3D_Q_MV_Y7=32, .NR3D_Q_MV_Y6=30, .NR3D_Q_MV_Y5=26}},
    .tnr_curve_11={.bits={.rsv_0=0, .NR3D_Q_WVAR_Y6=1, .NR3D_Q_WVAR_Y5=1, .NR3D_Q_WVAR_Y4=2, .NR3D_Q_WVAR_Y3=3, .NR3D_Q_WVAR_Y2=6}},
    .tnr_curve_12={.bits={.rsv_0=0, .NR3D_Q_WSM_Y3=9, .NR3D_Q_WSM_Y2=3, .NR3D_Q_WSM_Y1=1, .NR3D_Q_WSM_Y0=0, .NR3D_Q_WVAR_Y7=1}},
    .tnr_curve_13={.bits={.rsv_0=0, .NR3D_Q_WSM_Y7=16, .NR3D_Q_WSM_Y6=16, .NR3D_Q_WSM_Y5=16, .NR3D_Q_WSM_Y4=14}},
    .tnr_curve_14={.bits={.rsv_0=0, .NR3D_Q_SDL_Y4=32, .NR3D_Q_SDL_Y3=40, .NR3D_Q_SDL_Y2=48, .NR3D_Q_SDL_Y1=56, .NR3D_Q_SDL_Y0=63}},
    .tnr_curve_15={.bits={.rsv_0=0, .NR3D_Q_SDL_Y8=0, .NR3D_Q_SDL_Y7=8, .NR3D_Q_SDL_Y6=16, .NR3D_Q_SDL_Y5=24}},
    .tnr_r2c_1 ={.bits={.NR3D_R2CENC=0, .NR3D_R2C_VAL4=13, .NR3D_R2C_VAL3=11, .NR3D_R2C_VAL2=7, .NR3D_R2C_VAL1=3, .rsv_26=0}},
    .tnr_r2c_2 ={.bits={.rsv_0=0, .NR3D_R2C_TXTR_THROFF=12, .NR3D_R2C_TXTR_THR4=9, .NR3D_R2C_TXTR_THR3=6, .NR3D_R2C_TXTR_THR2=4, .NR3D_R2C_TXTR_THR1=2}},
    .tnr_r2c_3 ={.bits={.rsv_0=0, .NR3D_R2CF_CNT4=0, .NR3D_R2CF_CNT3=0, .NR3D_R2CF_CNT2=0, .NR3D_R2CF_CNT1=0}}

};
const ISP_NVRAM_NR3D_T gc13a0mipiraw_NR3D_0061 = {
        .on_con    ={.bits={.rsv_0=0, .NR3D_ON_EN=0, .rsv_5=0, .NR3D_TILE_EDGE=15, .rsv_12=0, .NR3D_SL2_OFF=0, .rsv_21=0}},
    .tnr_tnr_enable={.bits={.rsv_0=0, .NR3D_TNR_C_EN=0, .NR3D_TNR_Y_EN=0}},
    .tnr_flt_config={.bits={.rsv_0=0, .NR3D_EN_CCR=1, .NR3D_EN_CYCR=1, .NR3D_FLT_STR_MAX=28, .NR3D_BLEND_RATIO_MV=8, .NR3D_BLEND_RATIO_TXTR=8, .NR3D_BLEND_RATIO_DE=8, .NR3D_BLEND_RATIO_BLKY=8}},
    .tnr_fb_info1={.bits={.rsv_0=0, .NR3D_Q_SP=20, .NR3D_Q_NL=4}},
    .tnr_thr_1 ={.bits={.rsv_0=0, .NR3D_SMALL_SAD_THR=10, .NR3D_MV_PEN_THR=32, .NR3D_MV_PEN_W=8, .NR3D_BDI_THR=4, .rsv_30=0}},
    .tnr_curve_1={.bits={.rsv_0=0, .NR3D_Q_BLKY_Y4=16, .NR3D_Q_BLKY_Y3=26, .NR3D_Q_BLKY_Y2=32, .NR3D_Q_BLKY_Y1=30, .NR3D_Q_BLKY_Y0=28}},
    .tnr_curve_2={.bits={.rsv_0=0, .NR3D_Q_BLKC_Y1=26, .NR3D_Q_BLKC_Y0=24, .NR3D_Q_BLKY_Y7=0, .NR3D_Q_BLKY_Y6=0, .NR3D_Q_BLKY_Y5=4}},
    .tnr_curve_3={.bits={.rsv_0=0, .NR3D_Q_BLKC_Y6=0, .NR3D_Q_BLKC_Y5=0, .NR3D_Q_BLKC_Y4=0, .NR3D_Q_BLKC_Y3=2, .NR3D_Q_BLKC_Y2=8}},
    .tnr_curve_4={.bits={.rsv_0=0, .NR3D_Q_DETXTR_LVL_Y3=21, .NR3D_Q_DETXTR_LVL_Y2=16, .NR3D_Q_DETXTR_LVL_Y1=8, .NR3D_Q_DETXTR_LVL_Y0=0, .NR3D_Q_BLKC_Y7=0}},
    .tnr_curve_5={.bits={.rsv_0=0, .NR3D_Q_DE1_BASE_Y0=32, .NR3D_Q_DETXTR_LVL_Y7=32, .NR3D_Q_DETXTR_LVL_Y6=32, .NR3D_Q_DETXTR_LVL_Y5=32, .NR3D_Q_DETXTR_LVL_Y4=27}},
    .tnr_curve_6={.bits={.rsv_0=0, .NR3D_Q_DE1_BASE_Y5=0, .NR3D_Q_DE1_BASE_Y4=12, .NR3D_Q_DE1_BASE_Y3=21, .NR3D_Q_DE1_BASE_Y2=27, .NR3D_Q_DE1_BASE_Y1=32}},
    .tnr_curve_7={.bits={.rsv_0=0, .NR3D_Q_DE2TXTR_BASE_Y2=22, .NR3D_Q_DE2TXTR_BASE_Y1=5, .NR3D_Q_DE2TXTR_BASE_Y0=0, .NR3D_Q_DE1_BASE_Y7=0, .NR3D_Q_DE1_BASE_Y6=0}},
    .tnr_curve_8={.bits={.rsv_0=0, .NR3D_Q_DE2TXTR_BASE_Y7=32, .NR3D_Q_DE2TXTR_BASE_Y6=32, .NR3D_Q_DE2TXTR_BASE_Y5=32, .NR3D_Q_DE2TXTR_BASE_Y4=32, .NR3D_Q_DE2TXTR_BASE_Y3=32}},
    .tnr_curve_9={.bits={.rsv_0=0, .NR3D_Q_MV_Y4=20, .NR3D_Q_MV_Y3=14, .NR3D_Q_MV_Y2=7, .NR3D_Q_MV_Y1=3, .NR3D_Q_MV_Y0=0}},
    .tnr_curve_10={.bits={.rsv_0=0, .NR3D_Q_WVAR_Y1=16, .NR3D_Q_WVAR_Y0=16, .NR3D_Q_MV_Y7=32, .NR3D_Q_MV_Y6=30, .NR3D_Q_MV_Y5=26}},
    .tnr_curve_11={.bits={.rsv_0=0, .NR3D_Q_WVAR_Y6=1, .NR3D_Q_WVAR_Y5=1, .NR3D_Q_WVAR_Y4=2, .NR3D_Q_WVAR_Y3=3, .NR3D_Q_WVAR_Y2=6}},
    .tnr_curve_12={.bits={.rsv_0=0, .NR3D_Q_WSM_Y3=9, .NR3D_Q_WSM_Y2=3, .NR3D_Q_WSM_Y1=1, .NR3D_Q_WSM_Y0=0, .NR3D_Q_WVAR_Y7=1}},
    .tnr_curve_13={.bits={.rsv_0=0, .NR3D_Q_WSM_Y7=16, .NR3D_Q_WSM_Y6=16, .NR3D_Q_WSM_Y5=16, .NR3D_Q_WSM_Y4=14}},
    .tnr_curve_14={.bits={.rsv_0=0, .NR3D_Q_SDL_Y4=32, .NR3D_Q_SDL_Y3=40, .NR3D_Q_SDL_Y2=48, .NR3D_Q_SDL_Y1=56, .NR3D_Q_SDL_Y0=63}},
    .tnr_curve_15={.bits={.rsv_0=0, .NR3D_Q_SDL_Y8=0, .NR3D_Q_SDL_Y7=8, .NR3D_Q_SDL_Y6=16, .NR3D_Q_SDL_Y5=24}},
    .tnr_r2c_1 ={.bits={.NR3D_R2CENC=0, .NR3D_R2C_VAL4=13, .NR3D_R2C_VAL3=11, .NR3D_R2C_VAL2=7, .NR3D_R2C_VAL1=3, .rsv_26=0}},
    .tnr_r2c_2 ={.bits={.rsv_0=0, .NR3D_R2C_TXTR_THROFF=12, .NR3D_R2C_TXTR_THR4=9, .NR3D_R2C_TXTR_THR3=6, .NR3D_R2C_TXTR_THR2=4, .NR3D_R2C_TXTR_THR1=2}},
    .tnr_r2c_3 ={.bits={.rsv_0=0, .NR3D_R2CF_CNT4=0, .NR3D_R2CF_CNT3=0, .NR3D_R2CF_CNT2=0, .NR3D_R2CF_CNT1=0}}

};
const ISP_NVRAM_NR3D_T gc13a0mipiraw_NR3D_0062 = {
        .on_con    ={.bits={.rsv_0=0, .NR3D_ON_EN=0, .rsv_5=0, .NR3D_TILE_EDGE=15, .rsv_12=0, .NR3D_SL2_OFF=0, .rsv_21=0}},
    .tnr_tnr_enable={.bits={.rsv_0=0, .NR3D_TNR_C_EN=0, .NR3D_TNR_Y_EN=0}},
    .tnr_flt_config={.bits={.rsv_0=0, .NR3D_EN_CCR=1, .NR3D_EN_CYCR=1, .NR3D_FLT_STR_MAX=28, .NR3D_BLEND_RATIO_MV=8, .NR3D_BLEND_RATIO_TXTR=8, .NR3D_BLEND_RATIO_DE=8, .NR3D_BLEND_RATIO_BLKY=8}},
    .tnr_fb_info1={.bits={.rsv_0=0, .NR3D_Q_SP=20, .NR3D_Q_NL=4}},
    .tnr_thr_1 ={.bits={.rsv_0=0, .NR3D_SMALL_SAD_THR=10, .NR3D_MV_PEN_THR=32, .NR3D_MV_PEN_W=8, .NR3D_BDI_THR=4, .rsv_30=0}},
    .tnr_curve_1={.bits={.rsv_0=0, .NR3D_Q_BLKY_Y4=16, .NR3D_Q_BLKY_Y3=26, .NR3D_Q_BLKY_Y2=32, .NR3D_Q_BLKY_Y1=30, .NR3D_Q_BLKY_Y0=28}},
    .tnr_curve_2={.bits={.rsv_0=0, .NR3D_Q_BLKC_Y1=26, .NR3D_Q_BLKC_Y0=24, .NR3D_Q_BLKY_Y7=0, .NR3D_Q_BLKY_Y6=0, .NR3D_Q_BLKY_Y5=4}},
    .tnr_curve_3={.bits={.rsv_0=0, .NR3D_Q_BLKC_Y6=0, .NR3D_Q_BLKC_Y5=0, .NR3D_Q_BLKC_Y4=0, .NR3D_Q_BLKC_Y3=2, .NR3D_Q_BLKC_Y2=8}},
    .tnr_curve_4={.bits={.rsv_0=0, .NR3D_Q_DETXTR_LVL_Y3=21, .NR3D_Q_DETXTR_LVL_Y2=16, .NR3D_Q_DETXTR_LVL_Y1=8, .NR3D_Q_DETXTR_LVL_Y0=0, .NR3D_Q_BLKC_Y7=0}},
    .tnr_curve_5={.bits={.rsv_0=0, .NR3D_Q_DE1_BASE_Y0=32, .NR3D_Q_DETXTR_LVL_Y7=32, .NR3D_Q_DETXTR_LVL_Y6=32, .NR3D_Q_DETXTR_LVL_Y5=32, .NR3D_Q_DETXTR_LVL_Y4=27}},
    .tnr_curve_6={.bits={.rsv_0=0, .NR3D_Q_DE1_BASE_Y5=0, .NR3D_Q_DE1_BASE_Y4=12, .NR3D_Q_DE1_BASE_Y3=21, .NR3D_Q_DE1_BASE_Y2=27, .NR3D_Q_DE1_BASE_Y1=32}},
    .tnr_curve_7={.bits={.rsv_0=0, .NR3D_Q_DE2TXTR_BASE_Y2=22, .NR3D_Q_DE2TXTR_BASE_Y1=5, .NR3D_Q_DE2TXTR_BASE_Y0=0, .NR3D_Q_DE1_BASE_Y7=0, .NR3D_Q_DE1_BASE_Y6=0}},
    .tnr_curve_8={.bits={.rsv_0=0, .NR3D_Q_DE2TXTR_BASE_Y7=32, .NR3D_Q_DE2TXTR_BASE_Y6=32, .NR3D_Q_DE2TXTR_BASE_Y5=32, .NR3D_Q_DE2TXTR_BASE_Y4=32, .NR3D_Q_DE2TXTR_BASE_Y3=32}},
    .tnr_curve_9={.bits={.rsv_0=0, .NR3D_Q_MV_Y4=20, .NR3D_Q_MV_Y3=14, .NR3D_Q_MV_Y2=7, .NR3D_Q_MV_Y1=3, .NR3D_Q_MV_Y0=0}},
    .tnr_curve_10={.bits={.rsv_0=0, .NR3D_Q_WVAR_Y1=16, .NR3D_Q_WVAR_Y0=16, .NR3D_Q_MV_Y7=32, .NR3D_Q_MV_Y6=30, .NR3D_Q_MV_Y5=26}},
    .tnr_curve_11={.bits={.rsv_0=0, .NR3D_Q_WVAR_Y6=1, .NR3D_Q_WVAR_Y5=1, .NR3D_Q_WVAR_Y4=2, .NR3D_Q_WVAR_Y3=3, .NR3D_Q_WVAR_Y2=6}},
    .tnr_curve_12={.bits={.rsv_0=0, .NR3D_Q_WSM_Y3=9, .NR3D_Q_WSM_Y2=3, .NR3D_Q_WSM_Y1=1, .NR3D_Q_WSM_Y0=0, .NR3D_Q_WVAR_Y7=1}},
    .tnr_curve_13={.bits={.rsv_0=0, .NR3D_Q_WSM_Y7=16, .NR3D_Q_WSM_Y6=16, .NR3D_Q_WSM_Y5=16, .NR3D_Q_WSM_Y4=14}},
    .tnr_curve_14={.bits={.rsv_0=0, .NR3D_Q_SDL_Y4=32, .NR3D_Q_SDL_Y3=40, .NR3D_Q_SDL_Y2=48, .NR3D_Q_SDL_Y1=56, .NR3D_Q_SDL_Y0=63}},
    .tnr_curve_15={.bits={.rsv_0=0, .NR3D_Q_SDL_Y8=0, .NR3D_Q_SDL_Y7=8, .NR3D_Q_SDL_Y6=16, .NR3D_Q_SDL_Y5=24}},
    .tnr_r2c_1 ={.bits={.NR3D_R2CENC=0, .NR3D_R2C_VAL4=13, .NR3D_R2C_VAL3=11, .NR3D_R2C_VAL2=7, .NR3D_R2C_VAL1=3, .rsv_26=0}},
    .tnr_r2c_2 ={.bits={.rsv_0=0, .NR3D_R2C_TXTR_THROFF=12, .NR3D_R2C_TXTR_THR4=9, .NR3D_R2C_TXTR_THR3=6, .NR3D_R2C_TXTR_THR2=4, .NR3D_R2C_TXTR_THR1=2}},
    .tnr_r2c_3 ={.bits={.rsv_0=0, .NR3D_R2CF_CNT4=0, .NR3D_R2CF_CNT3=0, .NR3D_R2CF_CNT2=0, .NR3D_R2CF_CNT1=0}}

};
const ISP_NVRAM_NR3D_T gc13a0mipiraw_NR3D_0063 = {
        .on_con    ={.bits={.rsv_0=0, .NR3D_ON_EN=0, .rsv_5=0, .NR3D_TILE_EDGE=15, .rsv_12=0, .NR3D_SL2_OFF=0, .rsv_21=0}},
    .tnr_tnr_enable={.bits={.rsv_0=0, .NR3D_TNR_C_EN=0, .NR3D_TNR_Y_EN=0}},
    .tnr_flt_config={.bits={.rsv_0=0, .NR3D_EN_CCR=1, .NR3D_EN_CYCR=1, .NR3D_FLT_STR_MAX=28, .NR3D_BLEND_RATIO_MV=8, .NR3D_BLEND_RATIO_TXTR=8, .NR3D_BLEND_RATIO_DE=8, .NR3D_BLEND_RATIO_BLKY=8}},
    .tnr_fb_info1={.bits={.rsv_0=0, .NR3D_Q_SP=20, .NR3D_Q_NL=4}},
    .tnr_thr_1 ={.bits={.rsv_0=0, .NR3D_SMALL_SAD_THR=10, .NR3D_MV_PEN_THR=32, .NR3D_MV_PEN_W=8, .NR3D_BDI_THR=4, .rsv_30=0}},
    .tnr_curve_1={.bits={.rsv_0=0, .NR3D_Q_BLKY_Y4=16, .NR3D_Q_BLKY_Y3=26, .NR3D_Q_BLKY_Y2=32, .NR3D_Q_BLKY_Y1=30, .NR3D_Q_BLKY_Y0=28}},
    .tnr_curve_2={.bits={.rsv_0=0, .NR3D_Q_BLKC_Y1=26, .NR3D_Q_BLKC_Y0=24, .NR3D_Q_BLKY_Y7=0, .NR3D_Q_BLKY_Y6=0, .NR3D_Q_BLKY_Y5=4}},
    .tnr_curve_3={.bits={.rsv_0=0, .NR3D_Q_BLKC_Y6=0, .NR3D_Q_BLKC_Y5=0, .NR3D_Q_BLKC_Y4=0, .NR3D_Q_BLKC_Y3=2, .NR3D_Q_BLKC_Y2=8}},
    .tnr_curve_4={.bits={.rsv_0=0, .NR3D_Q_DETXTR_LVL_Y3=21, .NR3D_Q_DETXTR_LVL_Y2=16, .NR3D_Q_DETXTR_LVL_Y1=8, .NR3D_Q_DETXTR_LVL_Y0=0, .NR3D_Q_BLKC_Y7=0}},
    .tnr_curve_5={.bits={.rsv_0=0, .NR3D_Q_DE1_BASE_Y0=32, .NR3D_Q_DETXTR_LVL_Y7=32, .NR3D_Q_DETXTR_LVL_Y6=32, .NR3D_Q_DETXTR_LVL_Y5=32, .NR3D_Q_DETXTR_LVL_Y4=27}},
    .tnr_curve_6={.bits={.rsv_0=0, .NR3D_Q_DE1_BASE_Y5=0, .NR3D_Q_DE1_BASE_Y4=12, .NR3D_Q_DE1_BASE_Y3=21, .NR3D_Q_DE1_BASE_Y2=27, .NR3D_Q_DE1_BASE_Y1=32}},
    .tnr_curve_7={.bits={.rsv_0=0, .NR3D_Q_DE2TXTR_BASE_Y2=22, .NR3D_Q_DE2TXTR_BASE_Y1=5, .NR3D_Q_DE2TXTR_BASE_Y0=0, .NR3D_Q_DE1_BASE_Y7=0, .NR3D_Q_DE1_BASE_Y6=0}},
    .tnr_curve_8={.bits={.rsv_0=0, .NR3D_Q_DE2TXTR_BASE_Y7=32, .NR3D_Q_DE2TXTR_BASE_Y6=32, .NR3D_Q_DE2TXTR_BASE_Y5=32, .NR3D_Q_DE2TXTR_BASE_Y4=32, .NR3D_Q_DE2TXTR_BASE_Y3=32}},
    .tnr_curve_9={.bits={.rsv_0=0, .NR3D_Q_MV_Y4=20, .NR3D_Q_MV_Y3=14, .NR3D_Q_MV_Y2=7, .NR3D_Q_MV_Y1=3, .NR3D_Q_MV_Y0=0}},
    .tnr_curve_10={.bits={.rsv_0=0, .NR3D_Q_WVAR_Y1=16, .NR3D_Q_WVAR_Y0=16, .NR3D_Q_MV_Y7=32, .NR3D_Q_MV_Y6=30, .NR3D_Q_MV_Y5=26}},
    .tnr_curve_11={.bits={.rsv_0=0, .NR3D_Q_WVAR_Y6=1, .NR3D_Q_WVAR_Y5=1, .NR3D_Q_WVAR_Y4=2, .NR3D_Q_WVAR_Y3=3, .NR3D_Q_WVAR_Y2=6}},
    .tnr_curve_12={.bits={.rsv_0=0, .NR3D_Q_WSM_Y3=9, .NR3D_Q_WSM_Y2=3, .NR3D_Q_WSM_Y1=1, .NR3D_Q_WSM_Y0=0, .NR3D_Q_WVAR_Y7=1}},
    .tnr_curve_13={.bits={.rsv_0=0, .NR3D_Q_WSM_Y7=16, .NR3D_Q_WSM_Y6=16, .NR3D_Q_WSM_Y5=16, .NR3D_Q_WSM_Y4=14}},
    .tnr_curve_14={.bits={.rsv_0=0, .NR3D_Q_SDL_Y4=32, .NR3D_Q_SDL_Y3=40, .NR3D_Q_SDL_Y2=48, .NR3D_Q_SDL_Y1=56, .NR3D_Q_SDL_Y0=63}},
    .tnr_curve_15={.bits={.rsv_0=0, .NR3D_Q_SDL_Y8=0, .NR3D_Q_SDL_Y7=8, .NR3D_Q_SDL_Y6=16, .NR3D_Q_SDL_Y5=24}},
    .tnr_r2c_1 ={.bits={.NR3D_R2CENC=0, .NR3D_R2C_VAL4=13, .NR3D_R2C_VAL3=11, .NR3D_R2C_VAL2=7, .NR3D_R2C_VAL1=3, .rsv_26=0}},
    .tnr_r2c_2 ={.bits={.rsv_0=0, .NR3D_R2C_TXTR_THROFF=12, .NR3D_R2C_TXTR_THR4=9, .NR3D_R2C_TXTR_THR3=6, .NR3D_R2C_TXTR_THR2=4, .NR3D_R2C_TXTR_THR1=2}},
    .tnr_r2c_3 ={.bits={.rsv_0=0, .NR3D_R2CF_CNT4=0, .NR3D_R2CF_CNT3=0, .NR3D_R2CF_CNT2=0, .NR3D_R2CF_CNT1=0}}

};
const ISP_NVRAM_NR3D_T gc13a0mipiraw_NR3D_0064 = {
        .on_con    ={.bits={.rsv_0=0, .NR3D_ON_EN=0, .rsv_5=0, .NR3D_TILE_EDGE=15, .rsv_12=0, .NR3D_SL2_OFF=0, .rsv_21=0}},
    .tnr_tnr_enable={.bits={.rsv_0=0, .NR3D_TNR_C_EN=0, .NR3D_TNR_Y_EN=0}},
    .tnr_flt_config={.bits={.rsv_0=0, .NR3D_EN_CCR=1, .NR3D_EN_CYCR=1, .NR3D_FLT_STR_MAX=28, .NR3D_BLEND_RATIO_MV=8, .NR3D_BLEND_RATIO_TXTR=8, .NR3D_BLEND_RATIO_DE=8, .NR3D_BLEND_RATIO_BLKY=8}},
    .tnr_fb_info1={.bits={.rsv_0=0, .NR3D_Q_SP=20, .NR3D_Q_NL=4}},
    .tnr_thr_1 ={.bits={.rsv_0=0, .NR3D_SMALL_SAD_THR=10, .NR3D_MV_PEN_THR=32, .NR3D_MV_PEN_W=8, .NR3D_BDI_THR=4, .rsv_30=0}},
    .tnr_curve_1={.bits={.rsv_0=0, .NR3D_Q_BLKY_Y4=16, .NR3D_Q_BLKY_Y3=26, .NR3D_Q_BLKY_Y2=32, .NR3D_Q_BLKY_Y1=30, .NR3D_Q_BLKY_Y0=28}},
    .tnr_curve_2={.bits={.rsv_0=0, .NR3D_Q_BLKC_Y1=26, .NR3D_Q_BLKC_Y0=24, .NR3D_Q_BLKY_Y7=0, .NR3D_Q_BLKY_Y6=0, .NR3D_Q_BLKY_Y5=4}},
    .tnr_curve_3={.bits={.rsv_0=0, .NR3D_Q_BLKC_Y6=0, .NR3D_Q_BLKC_Y5=0, .NR3D_Q_BLKC_Y4=0, .NR3D_Q_BLKC_Y3=2, .NR3D_Q_BLKC_Y2=8}},
    .tnr_curve_4={.bits={.rsv_0=0, .NR3D_Q_DETXTR_LVL_Y3=21, .NR3D_Q_DETXTR_LVL_Y2=16, .NR3D_Q_DETXTR_LVL_Y1=8, .NR3D_Q_DETXTR_LVL_Y0=0, .NR3D_Q_BLKC_Y7=0}},
    .tnr_curve_5={.bits={.rsv_0=0, .NR3D_Q_DE1_BASE_Y0=32, .NR3D_Q_DETXTR_LVL_Y7=32, .NR3D_Q_DETXTR_LVL_Y6=32, .NR3D_Q_DETXTR_LVL_Y5=32, .NR3D_Q_DETXTR_LVL_Y4=27}},
    .tnr_curve_6={.bits={.rsv_0=0, .NR3D_Q_DE1_BASE_Y5=0, .NR3D_Q_DE1_BASE_Y4=12, .NR3D_Q_DE1_BASE_Y3=21, .NR3D_Q_DE1_BASE_Y2=27, .NR3D_Q_DE1_BASE_Y1=32}},
    .tnr_curve_7={.bits={.rsv_0=0, .NR3D_Q_DE2TXTR_BASE_Y2=22, .NR3D_Q_DE2TXTR_BASE_Y1=5, .NR3D_Q_DE2TXTR_BASE_Y0=0, .NR3D_Q_DE1_BASE_Y7=0, .NR3D_Q_DE1_BASE_Y6=0}},
    .tnr_curve_8={.bits={.rsv_0=0, .NR3D_Q_DE2TXTR_BASE_Y7=32, .NR3D_Q_DE2TXTR_BASE_Y6=32, .NR3D_Q_DE2TXTR_BASE_Y5=32, .NR3D_Q_DE2TXTR_BASE_Y4=32, .NR3D_Q_DE2TXTR_BASE_Y3=32}},
    .tnr_curve_9={.bits={.rsv_0=0, .NR3D_Q_MV_Y4=20, .NR3D_Q_MV_Y3=14, .NR3D_Q_MV_Y2=7, .NR3D_Q_MV_Y1=3, .NR3D_Q_MV_Y0=0}},
    .tnr_curve_10={.bits={.rsv_0=0, .NR3D_Q_WVAR_Y1=16, .NR3D_Q_WVAR_Y0=16, .NR3D_Q_MV_Y7=32, .NR3D_Q_MV_Y6=30, .NR3D_Q_MV_Y5=26}},
    .tnr_curve_11={.bits={.rsv_0=0, .NR3D_Q_WVAR_Y6=1, .NR3D_Q_WVAR_Y5=1, .NR3D_Q_WVAR_Y4=2, .NR3D_Q_WVAR_Y3=3, .NR3D_Q_WVAR_Y2=6}},
    .tnr_curve_12={.bits={.rsv_0=0, .NR3D_Q_WSM_Y3=9, .NR3D_Q_WSM_Y2=3, .NR3D_Q_WSM_Y1=1, .NR3D_Q_WSM_Y0=0, .NR3D_Q_WVAR_Y7=1}},
    .tnr_curve_13={.bits={.rsv_0=0, .NR3D_Q_WSM_Y7=16, .NR3D_Q_WSM_Y6=16, .NR3D_Q_WSM_Y5=16, .NR3D_Q_WSM_Y4=14}},
    .tnr_curve_14={.bits={.rsv_0=0, .NR3D_Q_SDL_Y4=32, .NR3D_Q_SDL_Y3=40, .NR3D_Q_SDL_Y2=48, .NR3D_Q_SDL_Y1=56, .NR3D_Q_SDL_Y0=63}},
    .tnr_curve_15={.bits={.rsv_0=0, .NR3D_Q_SDL_Y8=0, .NR3D_Q_SDL_Y7=8, .NR3D_Q_SDL_Y6=16, .NR3D_Q_SDL_Y5=24}},
    .tnr_r2c_1 ={.bits={.NR3D_R2CENC=0, .NR3D_R2C_VAL4=13, .NR3D_R2C_VAL3=11, .NR3D_R2C_VAL2=7, .NR3D_R2C_VAL1=3, .rsv_26=0}},
    .tnr_r2c_2 ={.bits={.rsv_0=0, .NR3D_R2C_TXTR_THROFF=12, .NR3D_R2C_TXTR_THR4=9, .NR3D_R2C_TXTR_THR3=6, .NR3D_R2C_TXTR_THR2=4, .NR3D_R2C_TXTR_THR1=2}},
    .tnr_r2c_3 ={.bits={.rsv_0=0, .NR3D_R2CF_CNT4=0, .NR3D_R2CF_CNT3=0, .NR3D_R2CF_CNT2=0, .NR3D_R2CF_CNT1=0}}

};
const ISP_NVRAM_NR3D_T gc13a0mipiraw_NR3D_0065 = {
        .on_con    ={.bits={.rsv_0=0, .NR3D_ON_EN=0, .rsv_5=0, .NR3D_TILE_EDGE=15, .rsv_12=0, .NR3D_SL2_OFF=0, .rsv_21=0}},
    .tnr_tnr_enable={.bits={.rsv_0=0, .NR3D_TNR_C_EN=0, .NR3D_TNR_Y_EN=0}},
    .tnr_flt_config={.bits={.rsv_0=0, .NR3D_EN_CCR=1, .NR3D_EN_CYCR=1, .NR3D_FLT_STR_MAX=28, .NR3D_BLEND_RATIO_MV=8, .NR3D_BLEND_RATIO_TXTR=8, .NR3D_BLEND_RATIO_DE=8, .NR3D_BLEND_RATIO_BLKY=8}},
    .tnr_fb_info1={.bits={.rsv_0=0, .NR3D_Q_SP=20, .NR3D_Q_NL=4}},
    .tnr_thr_1 ={.bits={.rsv_0=0, .NR3D_SMALL_SAD_THR=10, .NR3D_MV_PEN_THR=32, .NR3D_MV_PEN_W=8, .NR3D_BDI_THR=4, .rsv_30=0}},
    .tnr_curve_1={.bits={.rsv_0=0, .NR3D_Q_BLKY_Y4=16, .NR3D_Q_BLKY_Y3=26, .NR3D_Q_BLKY_Y2=32, .NR3D_Q_BLKY_Y1=30, .NR3D_Q_BLKY_Y0=28}},
    .tnr_curve_2={.bits={.rsv_0=0, .NR3D_Q_BLKC_Y1=26, .NR3D_Q_BLKC_Y0=24, .NR3D_Q_BLKY_Y7=0, .NR3D_Q_BLKY_Y6=0, .NR3D_Q_BLKY_Y5=4}},
    .tnr_curve_3={.bits={.rsv_0=0, .NR3D_Q_BLKC_Y6=0, .NR3D_Q_BLKC_Y5=0, .NR3D_Q_BLKC_Y4=0, .NR3D_Q_BLKC_Y3=2, .NR3D_Q_BLKC_Y2=8}},
    .tnr_curve_4={.bits={.rsv_0=0, .NR3D_Q_DETXTR_LVL_Y3=21, .NR3D_Q_DETXTR_LVL_Y2=16, .NR3D_Q_DETXTR_LVL_Y1=8, .NR3D_Q_DETXTR_LVL_Y0=0, .NR3D_Q_BLKC_Y7=0}},
    .tnr_curve_5={.bits={.rsv_0=0, .NR3D_Q_DE1_BASE_Y0=32, .NR3D_Q_DETXTR_LVL_Y7=32, .NR3D_Q_DETXTR_LVL_Y6=32, .NR3D_Q_DETXTR_LVL_Y5=32, .NR3D_Q_DETXTR_LVL_Y4=27}},
    .tnr_curve_6={.bits={.rsv_0=0, .NR3D_Q_DE1_BASE_Y5=0, .NR3D_Q_DE1_BASE_Y4=12, .NR3D_Q_DE1_BASE_Y3=21, .NR3D_Q_DE1_BASE_Y2=27, .NR3D_Q_DE1_BASE_Y1=32}},
    .tnr_curve_7={.bits={.rsv_0=0, .NR3D_Q_DE2TXTR_BASE_Y2=22, .NR3D_Q_DE2TXTR_BASE_Y1=5, .NR3D_Q_DE2TXTR_BASE_Y0=0, .NR3D_Q_DE1_BASE_Y7=0, .NR3D_Q_DE1_BASE_Y6=0}},
    .tnr_curve_8={.bits={.rsv_0=0, .NR3D_Q_DE2TXTR_BASE_Y7=32, .NR3D_Q_DE2TXTR_BASE_Y6=32, .NR3D_Q_DE2TXTR_BASE_Y5=32, .NR3D_Q_DE2TXTR_BASE_Y4=32, .NR3D_Q_DE2TXTR_BASE_Y3=32}},
    .tnr_curve_9={.bits={.rsv_0=0, .NR3D_Q_MV_Y4=20, .NR3D_Q_MV_Y3=14, .NR3D_Q_MV_Y2=7, .NR3D_Q_MV_Y1=3, .NR3D_Q_MV_Y0=0}},
    .tnr_curve_10={.bits={.rsv_0=0, .NR3D_Q_WVAR_Y1=16, .NR3D_Q_WVAR_Y0=16, .NR3D_Q_MV_Y7=32, .NR3D_Q_MV_Y6=30, .NR3D_Q_MV_Y5=26}},
    .tnr_curve_11={.bits={.rsv_0=0, .NR3D_Q_WVAR_Y6=1, .NR3D_Q_WVAR_Y5=1, .NR3D_Q_WVAR_Y4=2, .NR3D_Q_WVAR_Y3=3, .NR3D_Q_WVAR_Y2=6}},
    .tnr_curve_12={.bits={.rsv_0=0, .NR3D_Q_WSM_Y3=9, .NR3D_Q_WSM_Y2=3, .NR3D_Q_WSM_Y1=1, .NR3D_Q_WSM_Y0=0, .NR3D_Q_WVAR_Y7=1}},
    .tnr_curve_13={.bits={.rsv_0=0, .NR3D_Q_WSM_Y7=16, .NR3D_Q_WSM_Y6=16, .NR3D_Q_WSM_Y5=16, .NR3D_Q_WSM_Y4=14}},
    .tnr_curve_14={.bits={.rsv_0=0, .NR3D_Q_SDL_Y4=32, .NR3D_Q_SDL_Y3=40, .NR3D_Q_SDL_Y2=48, .NR3D_Q_SDL_Y1=56, .NR3D_Q_SDL_Y0=63}},
    .tnr_curve_15={.bits={.rsv_0=0, .NR3D_Q_SDL_Y8=0, .NR3D_Q_SDL_Y7=8, .NR3D_Q_SDL_Y6=16, .NR3D_Q_SDL_Y5=24}},
    .tnr_r2c_1 ={.bits={.NR3D_R2CENC=0, .NR3D_R2C_VAL4=13, .NR3D_R2C_VAL3=11, .NR3D_R2C_VAL2=7, .NR3D_R2C_VAL1=3, .rsv_26=0}},
    .tnr_r2c_2 ={.bits={.rsv_0=0, .NR3D_R2C_TXTR_THROFF=12, .NR3D_R2C_TXTR_THR4=9, .NR3D_R2C_TXTR_THR3=6, .NR3D_R2C_TXTR_THR2=4, .NR3D_R2C_TXTR_THR1=2}},
    .tnr_r2c_3 ={.bits={.rsv_0=0, .NR3D_R2CF_CNT4=0, .NR3D_R2CF_CNT3=0, .NR3D_R2CF_CNT2=0, .NR3D_R2CF_CNT1=0}}

};
const ISP_NVRAM_NR3D_T gc13a0mipiraw_NR3D_0066 = {
        .on_con    ={.bits={.rsv_0=0, .NR3D_ON_EN=0, .rsv_5=0, .NR3D_TILE_EDGE=15, .rsv_12=0, .NR3D_SL2_OFF=0, .rsv_21=0}},
    .tnr_tnr_enable={.bits={.rsv_0=0, .NR3D_TNR_C_EN=0, .NR3D_TNR_Y_EN=0}},
    .tnr_flt_config={.bits={.rsv_0=0, .NR3D_EN_CCR=1, .NR3D_EN_CYCR=1, .NR3D_FLT_STR_MAX=28, .NR3D_BLEND_RATIO_MV=8, .NR3D_BLEND_RATIO_TXTR=8, .NR3D_BLEND_RATIO_DE=8, .NR3D_BLEND_RATIO_BLKY=8}},
    .tnr_fb_info1={.bits={.rsv_0=0, .NR3D_Q_SP=20, .NR3D_Q_NL=4}},
    .tnr_thr_1 ={.bits={.rsv_0=0, .NR3D_SMALL_SAD_THR=10, .NR3D_MV_PEN_THR=32, .NR3D_MV_PEN_W=8, .NR3D_BDI_THR=4, .rsv_30=0}},
    .tnr_curve_1={.bits={.rsv_0=0, .NR3D_Q_BLKY_Y4=16, .NR3D_Q_BLKY_Y3=26, .NR3D_Q_BLKY_Y2=32, .NR3D_Q_BLKY_Y1=30, .NR3D_Q_BLKY_Y0=28}},
    .tnr_curve_2={.bits={.rsv_0=0, .NR3D_Q_BLKC_Y1=26, .NR3D_Q_BLKC_Y0=24, .NR3D_Q_BLKY_Y7=0, .NR3D_Q_BLKY_Y6=0, .NR3D_Q_BLKY_Y5=4}},
    .tnr_curve_3={.bits={.rsv_0=0, .NR3D_Q_BLKC_Y6=0, .NR3D_Q_BLKC_Y5=0, .NR3D_Q_BLKC_Y4=0, .NR3D_Q_BLKC_Y3=2, .NR3D_Q_BLKC_Y2=8}},
    .tnr_curve_4={.bits={.rsv_0=0, .NR3D_Q_DETXTR_LVL_Y3=21, .NR3D_Q_DETXTR_LVL_Y2=16, .NR3D_Q_DETXTR_LVL_Y1=8, .NR3D_Q_DETXTR_LVL_Y0=0, .NR3D_Q_BLKC_Y7=0}},
    .tnr_curve_5={.bits={.rsv_0=0, .NR3D_Q_DE1_BASE_Y0=32, .NR3D_Q_DETXTR_LVL_Y7=32, .NR3D_Q_DETXTR_LVL_Y6=32, .NR3D_Q_DETXTR_LVL_Y5=32, .NR3D_Q_DETXTR_LVL_Y4=27}},
    .tnr_curve_6={.bits={.rsv_0=0, .NR3D_Q_DE1_BASE_Y5=0, .NR3D_Q_DE1_BASE_Y4=12, .NR3D_Q_DE1_BASE_Y3=21, .NR3D_Q_DE1_BASE_Y2=27, .NR3D_Q_DE1_BASE_Y1=32}},
    .tnr_curve_7={.bits={.rsv_0=0, .NR3D_Q_DE2TXTR_BASE_Y2=22, .NR3D_Q_DE2TXTR_BASE_Y1=5, .NR3D_Q_DE2TXTR_BASE_Y0=0, .NR3D_Q_DE1_BASE_Y7=0, .NR3D_Q_DE1_BASE_Y6=0}},
    .tnr_curve_8={.bits={.rsv_0=0, .NR3D_Q_DE2TXTR_BASE_Y7=32, .NR3D_Q_DE2TXTR_BASE_Y6=32, .NR3D_Q_DE2TXTR_BASE_Y5=32, .NR3D_Q_DE2TXTR_BASE_Y4=32, .NR3D_Q_DE2TXTR_BASE_Y3=32}},
    .tnr_curve_9={.bits={.rsv_0=0, .NR3D_Q_MV_Y4=20, .NR3D_Q_MV_Y3=14, .NR3D_Q_MV_Y2=7, .NR3D_Q_MV_Y1=3, .NR3D_Q_MV_Y0=0}},
    .tnr_curve_10={.bits={.rsv_0=0, .NR3D_Q_WVAR_Y1=16, .NR3D_Q_WVAR_Y0=16, .NR3D_Q_MV_Y7=32, .NR3D_Q_MV_Y6=30, .NR3D_Q_MV_Y5=26}},
    .tnr_curve_11={.bits={.rsv_0=0, .NR3D_Q_WVAR_Y6=1, .NR3D_Q_WVAR_Y5=1, .NR3D_Q_WVAR_Y4=2, .NR3D_Q_WVAR_Y3=3, .NR3D_Q_WVAR_Y2=6}},
    .tnr_curve_12={.bits={.rsv_0=0, .NR3D_Q_WSM_Y3=9, .NR3D_Q_WSM_Y2=3, .NR3D_Q_WSM_Y1=1, .NR3D_Q_WSM_Y0=0, .NR3D_Q_WVAR_Y7=1}},
    .tnr_curve_13={.bits={.rsv_0=0, .NR3D_Q_WSM_Y7=16, .NR3D_Q_WSM_Y6=16, .NR3D_Q_WSM_Y5=16, .NR3D_Q_WSM_Y4=14}},
    .tnr_curve_14={.bits={.rsv_0=0, .NR3D_Q_SDL_Y4=32, .NR3D_Q_SDL_Y3=40, .NR3D_Q_SDL_Y2=48, .NR3D_Q_SDL_Y1=56, .NR3D_Q_SDL_Y0=63}},
    .tnr_curve_15={.bits={.rsv_0=0, .NR3D_Q_SDL_Y8=0, .NR3D_Q_SDL_Y7=8, .NR3D_Q_SDL_Y6=16, .NR3D_Q_SDL_Y5=24}},
    .tnr_r2c_1 ={.bits={.NR3D_R2CENC=0, .NR3D_R2C_VAL4=13, .NR3D_R2C_VAL3=11, .NR3D_R2C_VAL2=7, .NR3D_R2C_VAL1=3, .rsv_26=0}},
    .tnr_r2c_2 ={.bits={.rsv_0=0, .NR3D_R2C_TXTR_THROFF=12, .NR3D_R2C_TXTR_THR4=9, .NR3D_R2C_TXTR_THR3=6, .NR3D_R2C_TXTR_THR2=4, .NR3D_R2C_TXTR_THR1=2}},
    .tnr_r2c_3 ={.bits={.rsv_0=0, .NR3D_R2CF_CNT4=0, .NR3D_R2CF_CNT3=0, .NR3D_R2CF_CNT2=0, .NR3D_R2CF_CNT1=0}}

};
const ISP_NVRAM_NR3D_T gc13a0mipiraw_NR3D_0067 = {
        .on_con    ={.bits={.rsv_0=0, .NR3D_ON_EN=0, .rsv_5=0, .NR3D_TILE_EDGE=15, .rsv_12=0, .NR3D_SL2_OFF=0, .rsv_21=0}},
    .tnr_tnr_enable={.bits={.rsv_0=0, .NR3D_TNR_C_EN=0, .NR3D_TNR_Y_EN=0}},
    .tnr_flt_config={.bits={.rsv_0=0, .NR3D_EN_CCR=1, .NR3D_EN_CYCR=1, .NR3D_FLT_STR_MAX=28, .NR3D_BLEND_RATIO_MV=8, .NR3D_BLEND_RATIO_TXTR=8, .NR3D_BLEND_RATIO_DE=8, .NR3D_BLEND_RATIO_BLKY=8}},
    .tnr_fb_info1={.bits={.rsv_0=0, .NR3D_Q_SP=20, .NR3D_Q_NL=4}},
    .tnr_thr_1 ={.bits={.rsv_0=0, .NR3D_SMALL_SAD_THR=10, .NR3D_MV_PEN_THR=32, .NR3D_MV_PEN_W=8, .NR3D_BDI_THR=4, .rsv_30=0}},
    .tnr_curve_1={.bits={.rsv_0=0, .NR3D_Q_BLKY_Y4=16, .NR3D_Q_BLKY_Y3=26, .NR3D_Q_BLKY_Y2=32, .NR3D_Q_BLKY_Y1=30, .NR3D_Q_BLKY_Y0=28}},
    .tnr_curve_2={.bits={.rsv_0=0, .NR3D_Q_BLKC_Y1=26, .NR3D_Q_BLKC_Y0=24, .NR3D_Q_BLKY_Y7=0, .NR3D_Q_BLKY_Y6=0, .NR3D_Q_BLKY_Y5=4}},
    .tnr_curve_3={.bits={.rsv_0=0, .NR3D_Q_BLKC_Y6=0, .NR3D_Q_BLKC_Y5=0, .NR3D_Q_BLKC_Y4=0, .NR3D_Q_BLKC_Y3=2, .NR3D_Q_BLKC_Y2=8}},
    .tnr_curve_4={.bits={.rsv_0=0, .NR3D_Q_DETXTR_LVL_Y3=21, .NR3D_Q_DETXTR_LVL_Y2=16, .NR3D_Q_DETXTR_LVL_Y1=8, .NR3D_Q_DETXTR_LVL_Y0=0, .NR3D_Q_BLKC_Y7=0}},
    .tnr_curve_5={.bits={.rsv_0=0, .NR3D_Q_DE1_BASE_Y0=32, .NR3D_Q_DETXTR_LVL_Y7=32, .NR3D_Q_DETXTR_LVL_Y6=32, .NR3D_Q_DETXTR_LVL_Y5=32, .NR3D_Q_DETXTR_LVL_Y4=27}},
    .tnr_curve_6={.bits={.rsv_0=0, .NR3D_Q_DE1_BASE_Y5=0, .NR3D_Q_DE1_BASE_Y4=12, .NR3D_Q_DE1_BASE_Y3=21, .NR3D_Q_DE1_BASE_Y2=27, .NR3D_Q_DE1_BASE_Y1=32}},
    .tnr_curve_7={.bits={.rsv_0=0, .NR3D_Q_DE2TXTR_BASE_Y2=22, .NR3D_Q_DE2TXTR_BASE_Y1=5, .NR3D_Q_DE2TXTR_BASE_Y0=0, .NR3D_Q_DE1_BASE_Y7=0, .NR3D_Q_DE1_BASE_Y6=0}},
    .tnr_curve_8={.bits={.rsv_0=0, .NR3D_Q_DE2TXTR_BASE_Y7=32, .NR3D_Q_DE2TXTR_BASE_Y6=32, .NR3D_Q_DE2TXTR_BASE_Y5=32, .NR3D_Q_DE2TXTR_BASE_Y4=32, .NR3D_Q_DE2TXTR_BASE_Y3=32}},
    .tnr_curve_9={.bits={.rsv_0=0, .NR3D_Q_MV_Y4=20, .NR3D_Q_MV_Y3=14, .NR3D_Q_MV_Y2=7, .NR3D_Q_MV_Y1=3, .NR3D_Q_MV_Y0=0}},
    .tnr_curve_10={.bits={.rsv_0=0, .NR3D_Q_WVAR_Y1=16, .NR3D_Q_WVAR_Y0=16, .NR3D_Q_MV_Y7=32, .NR3D_Q_MV_Y6=30, .NR3D_Q_MV_Y5=26}},
    .tnr_curve_11={.bits={.rsv_0=0, .NR3D_Q_WVAR_Y6=1, .NR3D_Q_WVAR_Y5=1, .NR3D_Q_WVAR_Y4=2, .NR3D_Q_WVAR_Y3=3, .NR3D_Q_WVAR_Y2=6}},
    .tnr_curve_12={.bits={.rsv_0=0, .NR3D_Q_WSM_Y3=9, .NR3D_Q_WSM_Y2=3, .NR3D_Q_WSM_Y1=1, .NR3D_Q_WSM_Y0=0, .NR3D_Q_WVAR_Y7=1}},
    .tnr_curve_13={.bits={.rsv_0=0, .NR3D_Q_WSM_Y7=16, .NR3D_Q_WSM_Y6=16, .NR3D_Q_WSM_Y5=16, .NR3D_Q_WSM_Y4=14}},
    .tnr_curve_14={.bits={.rsv_0=0, .NR3D_Q_SDL_Y4=32, .NR3D_Q_SDL_Y3=40, .NR3D_Q_SDL_Y2=48, .NR3D_Q_SDL_Y1=56, .NR3D_Q_SDL_Y0=63}},
    .tnr_curve_15={.bits={.rsv_0=0, .NR3D_Q_SDL_Y8=0, .NR3D_Q_SDL_Y7=8, .NR3D_Q_SDL_Y6=16, .NR3D_Q_SDL_Y5=24}},
    .tnr_r2c_1 ={.bits={.NR3D_R2CENC=0, .NR3D_R2C_VAL4=13, .NR3D_R2C_VAL3=11, .NR3D_R2C_VAL2=7, .NR3D_R2C_VAL1=3, .rsv_26=0}},
    .tnr_r2c_2 ={.bits={.rsv_0=0, .NR3D_R2C_TXTR_THROFF=12, .NR3D_R2C_TXTR_THR4=9, .NR3D_R2C_TXTR_THR3=6, .NR3D_R2C_TXTR_THR2=4, .NR3D_R2C_TXTR_THR1=2}},
    .tnr_r2c_3 ={.bits={.rsv_0=0, .NR3D_R2CF_CNT4=0, .NR3D_R2CF_CNT3=0, .NR3D_R2CF_CNT2=0, .NR3D_R2CF_CNT1=0}}

};
const ISP_NVRAM_NR3D_T gc13a0mipiraw_NR3D_0068 = {
        .on_con    ={.bits={.rsv_0=0, .NR3D_ON_EN=0, .rsv_5=0, .NR3D_TILE_EDGE=15, .rsv_12=0, .NR3D_SL2_OFF=0, .rsv_21=0}},
    .tnr_tnr_enable={.bits={.rsv_0=0, .NR3D_TNR_C_EN=0, .NR3D_TNR_Y_EN=0}},
    .tnr_flt_config={.bits={.rsv_0=0, .NR3D_EN_CCR=1, .NR3D_EN_CYCR=1, .NR3D_FLT_STR_MAX=28, .NR3D_BLEND_RATIO_MV=8, .NR3D_BLEND_RATIO_TXTR=8, .NR3D_BLEND_RATIO_DE=8, .NR3D_BLEND_RATIO_BLKY=8}},
    .tnr_fb_info1={.bits={.rsv_0=0, .NR3D_Q_SP=20, .NR3D_Q_NL=4}},
    .tnr_thr_1 ={.bits={.rsv_0=0, .NR3D_SMALL_SAD_THR=10, .NR3D_MV_PEN_THR=32, .NR3D_MV_PEN_W=8, .NR3D_BDI_THR=4, .rsv_30=0}},
    .tnr_curve_1={.bits={.rsv_0=0, .NR3D_Q_BLKY_Y4=16, .NR3D_Q_BLKY_Y3=26, .NR3D_Q_BLKY_Y2=32, .NR3D_Q_BLKY_Y1=30, .NR3D_Q_BLKY_Y0=28}},
    .tnr_curve_2={.bits={.rsv_0=0, .NR3D_Q_BLKC_Y1=26, .NR3D_Q_BLKC_Y0=24, .NR3D_Q_BLKY_Y7=0, .NR3D_Q_BLKY_Y6=0, .NR3D_Q_BLKY_Y5=4}},
    .tnr_curve_3={.bits={.rsv_0=0, .NR3D_Q_BLKC_Y6=0, .NR3D_Q_BLKC_Y5=0, .NR3D_Q_BLKC_Y4=0, .NR3D_Q_BLKC_Y3=2, .NR3D_Q_BLKC_Y2=8}},
    .tnr_curve_4={.bits={.rsv_0=0, .NR3D_Q_DETXTR_LVL_Y3=21, .NR3D_Q_DETXTR_LVL_Y2=16, .NR3D_Q_DETXTR_LVL_Y1=8, .NR3D_Q_DETXTR_LVL_Y0=0, .NR3D_Q_BLKC_Y7=0}},
    .tnr_curve_5={.bits={.rsv_0=0, .NR3D_Q_DE1_BASE_Y0=32, .NR3D_Q_DETXTR_LVL_Y7=32, .NR3D_Q_DETXTR_LVL_Y6=32, .NR3D_Q_DETXTR_LVL_Y5=32, .NR3D_Q_DETXTR_LVL_Y4=27}},
    .tnr_curve_6={.bits={.rsv_0=0, .NR3D_Q_DE1_BASE_Y5=0, .NR3D_Q_DE1_BASE_Y4=12, .NR3D_Q_DE1_BASE_Y3=21, .NR3D_Q_DE1_BASE_Y2=27, .NR3D_Q_DE1_BASE_Y1=32}},
    .tnr_curve_7={.bits={.rsv_0=0, .NR3D_Q_DE2TXTR_BASE_Y2=22, .NR3D_Q_DE2TXTR_BASE_Y1=5, .NR3D_Q_DE2TXTR_BASE_Y0=0, .NR3D_Q_DE1_BASE_Y7=0, .NR3D_Q_DE1_BASE_Y6=0}},
    .tnr_curve_8={.bits={.rsv_0=0, .NR3D_Q_DE2TXTR_BASE_Y7=32, .NR3D_Q_DE2TXTR_BASE_Y6=32, .NR3D_Q_DE2TXTR_BASE_Y5=32, .NR3D_Q_DE2TXTR_BASE_Y4=32, .NR3D_Q_DE2TXTR_BASE_Y3=32}},
    .tnr_curve_9={.bits={.rsv_0=0, .NR3D_Q_MV_Y4=20, .NR3D_Q_MV_Y3=14, .NR3D_Q_MV_Y2=7, .NR3D_Q_MV_Y1=3, .NR3D_Q_MV_Y0=0}},
    .tnr_curve_10={.bits={.rsv_0=0, .NR3D_Q_WVAR_Y1=16, .NR3D_Q_WVAR_Y0=16, .NR3D_Q_MV_Y7=32, .NR3D_Q_MV_Y6=30, .NR3D_Q_MV_Y5=26}},
    .tnr_curve_11={.bits={.rsv_0=0, .NR3D_Q_WVAR_Y6=1, .NR3D_Q_WVAR_Y5=1, .NR3D_Q_WVAR_Y4=2, .NR3D_Q_WVAR_Y3=3, .NR3D_Q_WVAR_Y2=6}},
    .tnr_curve_12={.bits={.rsv_0=0, .NR3D_Q_WSM_Y3=9, .NR3D_Q_WSM_Y2=3, .NR3D_Q_WSM_Y1=1, .NR3D_Q_WSM_Y0=0, .NR3D_Q_WVAR_Y7=1}},
    .tnr_curve_13={.bits={.rsv_0=0, .NR3D_Q_WSM_Y7=16, .NR3D_Q_WSM_Y6=16, .NR3D_Q_WSM_Y5=16, .NR3D_Q_WSM_Y4=14}},
    .tnr_curve_14={.bits={.rsv_0=0, .NR3D_Q_SDL_Y4=32, .NR3D_Q_SDL_Y3=40, .NR3D_Q_SDL_Y2=48, .NR3D_Q_SDL_Y1=56, .NR3D_Q_SDL_Y0=63}},
    .tnr_curve_15={.bits={.rsv_0=0, .NR3D_Q_SDL_Y8=0, .NR3D_Q_SDL_Y7=8, .NR3D_Q_SDL_Y6=16, .NR3D_Q_SDL_Y5=24}},
    .tnr_r2c_1 ={.bits={.NR3D_R2CENC=0, .NR3D_R2C_VAL4=13, .NR3D_R2C_VAL3=11, .NR3D_R2C_VAL2=7, .NR3D_R2C_VAL1=3, .rsv_26=0}},
    .tnr_r2c_2 ={.bits={.rsv_0=0, .NR3D_R2C_TXTR_THROFF=12, .NR3D_R2C_TXTR_THR4=9, .NR3D_R2C_TXTR_THR3=6, .NR3D_R2C_TXTR_THR2=4, .NR3D_R2C_TXTR_THR1=2}},
    .tnr_r2c_3 ={.bits={.rsv_0=0, .NR3D_R2CF_CNT4=0, .NR3D_R2CF_CNT3=0, .NR3D_R2CF_CNT2=0, .NR3D_R2CF_CNT1=0}}

};
const ISP_NVRAM_NR3D_T gc13a0mipiraw_NR3D_0069 = {
        .on_con    ={.bits={.rsv_0=0, .NR3D_ON_EN=0, .rsv_5=0, .NR3D_TILE_EDGE=15, .rsv_12=0, .NR3D_SL2_OFF=0, .rsv_21=0}},
    .tnr_tnr_enable={.bits={.rsv_0=0, .NR3D_TNR_C_EN=0, .NR3D_TNR_Y_EN=0}},
    .tnr_flt_config={.bits={.rsv_0=0, .NR3D_EN_CCR=1, .NR3D_EN_CYCR=1, .NR3D_FLT_STR_MAX=28, .NR3D_BLEND_RATIO_MV=8, .NR3D_BLEND_RATIO_TXTR=8, .NR3D_BLEND_RATIO_DE=8, .NR3D_BLEND_RATIO_BLKY=8}},
    .tnr_fb_info1={.bits={.rsv_0=0, .NR3D_Q_SP=20, .NR3D_Q_NL=4}},
    .tnr_thr_1 ={.bits={.rsv_0=0, .NR3D_SMALL_SAD_THR=10, .NR3D_MV_PEN_THR=32, .NR3D_MV_PEN_W=8, .NR3D_BDI_THR=4, .rsv_30=0}},
    .tnr_curve_1={.bits={.rsv_0=0, .NR3D_Q_BLKY_Y4=16, .NR3D_Q_BLKY_Y3=26, .NR3D_Q_BLKY_Y2=32, .NR3D_Q_BLKY_Y1=30, .NR3D_Q_BLKY_Y0=28}},
    .tnr_curve_2={.bits={.rsv_0=0, .NR3D_Q_BLKC_Y1=26, .NR3D_Q_BLKC_Y0=24, .NR3D_Q_BLKY_Y7=0, .NR3D_Q_BLKY_Y6=0, .NR3D_Q_BLKY_Y5=4}},
    .tnr_curve_3={.bits={.rsv_0=0, .NR3D_Q_BLKC_Y6=0, .NR3D_Q_BLKC_Y5=0, .NR3D_Q_BLKC_Y4=0, .NR3D_Q_BLKC_Y3=2, .NR3D_Q_BLKC_Y2=8}},
    .tnr_curve_4={.bits={.rsv_0=0, .NR3D_Q_DETXTR_LVL_Y3=21, .NR3D_Q_DETXTR_LVL_Y2=16, .NR3D_Q_DETXTR_LVL_Y1=8, .NR3D_Q_DETXTR_LVL_Y0=0, .NR3D_Q_BLKC_Y7=0}},
    .tnr_curve_5={.bits={.rsv_0=0, .NR3D_Q_DE1_BASE_Y0=32, .NR3D_Q_DETXTR_LVL_Y7=32, .NR3D_Q_DETXTR_LVL_Y6=32, .NR3D_Q_DETXTR_LVL_Y5=32, .NR3D_Q_DETXTR_LVL_Y4=27}},
    .tnr_curve_6={.bits={.rsv_0=0, .NR3D_Q_DE1_BASE_Y5=0, .NR3D_Q_DE1_BASE_Y4=12, .NR3D_Q_DE1_BASE_Y3=21, .NR3D_Q_DE1_BASE_Y2=27, .NR3D_Q_DE1_BASE_Y1=32}},
    .tnr_curve_7={.bits={.rsv_0=0, .NR3D_Q_DE2TXTR_BASE_Y2=22, .NR3D_Q_DE2TXTR_BASE_Y1=5, .NR3D_Q_DE2TXTR_BASE_Y0=0, .NR3D_Q_DE1_BASE_Y7=0, .NR3D_Q_DE1_BASE_Y6=0}},
    .tnr_curve_8={.bits={.rsv_0=0, .NR3D_Q_DE2TXTR_BASE_Y7=32, .NR3D_Q_DE2TXTR_BASE_Y6=32, .NR3D_Q_DE2TXTR_BASE_Y5=32, .NR3D_Q_DE2TXTR_BASE_Y4=32, .NR3D_Q_DE2TXTR_BASE_Y3=32}},
    .tnr_curve_9={.bits={.rsv_0=0, .NR3D_Q_MV_Y4=20, .NR3D_Q_MV_Y3=14, .NR3D_Q_MV_Y2=7, .NR3D_Q_MV_Y1=3, .NR3D_Q_MV_Y0=0}},
    .tnr_curve_10={.bits={.rsv_0=0, .NR3D_Q_WVAR_Y1=16, .NR3D_Q_WVAR_Y0=16, .NR3D_Q_MV_Y7=32, .NR3D_Q_MV_Y6=30, .NR3D_Q_MV_Y5=26}},
    .tnr_curve_11={.bits={.rsv_0=0, .NR3D_Q_WVAR_Y6=1, .NR3D_Q_WVAR_Y5=1, .NR3D_Q_WVAR_Y4=2, .NR3D_Q_WVAR_Y3=3, .NR3D_Q_WVAR_Y2=6}},
    .tnr_curve_12={.bits={.rsv_0=0, .NR3D_Q_WSM_Y3=9, .NR3D_Q_WSM_Y2=3, .NR3D_Q_WSM_Y1=1, .NR3D_Q_WSM_Y0=0, .NR3D_Q_WVAR_Y7=1}},
    .tnr_curve_13={.bits={.rsv_0=0, .NR3D_Q_WSM_Y7=16, .NR3D_Q_WSM_Y6=16, .NR3D_Q_WSM_Y5=16, .NR3D_Q_WSM_Y4=14}},
    .tnr_curve_14={.bits={.rsv_0=0, .NR3D_Q_SDL_Y4=32, .NR3D_Q_SDL_Y3=40, .NR3D_Q_SDL_Y2=48, .NR3D_Q_SDL_Y1=56, .NR3D_Q_SDL_Y0=63}},
    .tnr_curve_15={.bits={.rsv_0=0, .NR3D_Q_SDL_Y8=0, .NR3D_Q_SDL_Y7=8, .NR3D_Q_SDL_Y6=16, .NR3D_Q_SDL_Y5=24}},
    .tnr_r2c_1 ={.bits={.NR3D_R2CENC=0, .NR3D_R2C_VAL4=13, .NR3D_R2C_VAL3=11, .NR3D_R2C_VAL2=7, .NR3D_R2C_VAL1=3, .rsv_26=0}},
    .tnr_r2c_2 ={.bits={.rsv_0=0, .NR3D_R2C_TXTR_THROFF=12, .NR3D_R2C_TXTR_THR4=9, .NR3D_R2C_TXTR_THR3=6, .NR3D_R2C_TXTR_THR2=4, .NR3D_R2C_TXTR_THR1=2}},
    .tnr_r2c_3 ={.bits={.rsv_0=0, .NR3D_R2CF_CNT4=0, .NR3D_R2CF_CNT3=0, .NR3D_R2CF_CNT2=0, .NR3D_R2CF_CNT1=0}}

};
const ISP_NVRAM_NR3D_T gc13a0mipiraw_NR3D_0070 = {
        .on_con    ={.bits={.rsv_0=0, .NR3D_ON_EN=0, .rsv_5=0, .NR3D_TILE_EDGE=15, .rsv_12=0, .NR3D_SL2_OFF=0, .rsv_21=0}},
    .tnr_tnr_enable={.bits={.rsv_0=0, .NR3D_TNR_C_EN=0, .NR3D_TNR_Y_EN=0}},
    .tnr_flt_config={.bits={.rsv_0=0, .NR3D_EN_CCR=1, .NR3D_EN_CYCR=1, .NR3D_FLT_STR_MAX=28, .NR3D_BLEND_RATIO_MV=8, .NR3D_BLEND_RATIO_TXTR=8, .NR3D_BLEND_RATIO_DE=8, .NR3D_BLEND_RATIO_BLKY=8}},
    .tnr_fb_info1={.bits={.rsv_0=0, .NR3D_Q_SP=20, .NR3D_Q_NL=4}},
    .tnr_thr_1 ={.bits={.rsv_0=0, .NR3D_SMALL_SAD_THR=10, .NR3D_MV_PEN_THR=32, .NR3D_MV_PEN_W=8, .NR3D_BDI_THR=4, .rsv_30=0}},
    .tnr_curve_1={.bits={.rsv_0=0, .NR3D_Q_BLKY_Y4=16, .NR3D_Q_BLKY_Y3=26, .NR3D_Q_BLKY_Y2=32, .NR3D_Q_BLKY_Y1=30, .NR3D_Q_BLKY_Y0=28}},
    .tnr_curve_2={.bits={.rsv_0=0, .NR3D_Q_BLKC_Y1=26, .NR3D_Q_BLKC_Y0=24, .NR3D_Q_BLKY_Y7=0, .NR3D_Q_BLKY_Y6=0, .NR3D_Q_BLKY_Y5=4}},
    .tnr_curve_3={.bits={.rsv_0=0, .NR3D_Q_BLKC_Y6=0, .NR3D_Q_BLKC_Y5=0, .NR3D_Q_BLKC_Y4=0, .NR3D_Q_BLKC_Y3=2, .NR3D_Q_BLKC_Y2=8}},
    .tnr_curve_4={.bits={.rsv_0=0, .NR3D_Q_DETXTR_LVL_Y3=21, .NR3D_Q_DETXTR_LVL_Y2=16, .NR3D_Q_DETXTR_LVL_Y1=8, .NR3D_Q_DETXTR_LVL_Y0=0, .NR3D_Q_BLKC_Y7=0}},
    .tnr_curve_5={.bits={.rsv_0=0, .NR3D_Q_DE1_BASE_Y0=32, .NR3D_Q_DETXTR_LVL_Y7=32, .NR3D_Q_DETXTR_LVL_Y6=32, .NR3D_Q_DETXTR_LVL_Y5=32, .NR3D_Q_DETXTR_LVL_Y4=27}},
    .tnr_curve_6={.bits={.rsv_0=0, .NR3D_Q_DE1_BASE_Y5=0, .NR3D_Q_DE1_BASE_Y4=12, .NR3D_Q_DE1_BASE_Y3=21, .NR3D_Q_DE1_BASE_Y2=27, .NR3D_Q_DE1_BASE_Y1=32}},
    .tnr_curve_7={.bits={.rsv_0=0, .NR3D_Q_DE2TXTR_BASE_Y2=22, .NR3D_Q_DE2TXTR_BASE_Y1=5, .NR3D_Q_DE2TXTR_BASE_Y0=0, .NR3D_Q_DE1_BASE_Y7=0, .NR3D_Q_DE1_BASE_Y6=0}},
    .tnr_curve_8={.bits={.rsv_0=0, .NR3D_Q_DE2TXTR_BASE_Y7=32, .NR3D_Q_DE2TXTR_BASE_Y6=32, .NR3D_Q_DE2TXTR_BASE_Y5=32, .NR3D_Q_DE2TXTR_BASE_Y4=32, .NR3D_Q_DE2TXTR_BASE_Y3=32}},
    .tnr_curve_9={.bits={.rsv_0=0, .NR3D_Q_MV_Y4=20, .NR3D_Q_MV_Y3=14, .NR3D_Q_MV_Y2=7, .NR3D_Q_MV_Y1=3, .NR3D_Q_MV_Y0=0}},
    .tnr_curve_10={.bits={.rsv_0=0, .NR3D_Q_WVAR_Y1=16, .NR3D_Q_WVAR_Y0=16, .NR3D_Q_MV_Y7=32, .NR3D_Q_MV_Y6=30, .NR3D_Q_MV_Y5=26}},
    .tnr_curve_11={.bits={.rsv_0=0, .NR3D_Q_WVAR_Y6=1, .NR3D_Q_WVAR_Y5=1, .NR3D_Q_WVAR_Y4=2, .NR3D_Q_WVAR_Y3=3, .NR3D_Q_WVAR_Y2=6}},
    .tnr_curve_12={.bits={.rsv_0=0, .NR3D_Q_WSM_Y3=9, .NR3D_Q_WSM_Y2=3, .NR3D_Q_WSM_Y1=1, .NR3D_Q_WSM_Y0=0, .NR3D_Q_WVAR_Y7=1}},
    .tnr_curve_13={.bits={.rsv_0=0, .NR3D_Q_WSM_Y7=16, .NR3D_Q_WSM_Y6=16, .NR3D_Q_WSM_Y5=16, .NR3D_Q_WSM_Y4=14}},
    .tnr_curve_14={.bits={.rsv_0=0, .NR3D_Q_SDL_Y4=32, .NR3D_Q_SDL_Y3=40, .NR3D_Q_SDL_Y2=48, .NR3D_Q_SDL_Y1=56, .NR3D_Q_SDL_Y0=63}},
    .tnr_curve_15={.bits={.rsv_0=0, .NR3D_Q_SDL_Y8=0, .NR3D_Q_SDL_Y7=8, .NR3D_Q_SDL_Y6=16, .NR3D_Q_SDL_Y5=24}},
    .tnr_r2c_1 ={.bits={.NR3D_R2CENC=0, .NR3D_R2C_VAL4=13, .NR3D_R2C_VAL3=11, .NR3D_R2C_VAL2=7, .NR3D_R2C_VAL1=3, .rsv_26=0}},
    .tnr_r2c_2 ={.bits={.rsv_0=0, .NR3D_R2C_TXTR_THROFF=12, .NR3D_R2C_TXTR_THR4=9, .NR3D_R2C_TXTR_THR3=6, .NR3D_R2C_TXTR_THR2=4, .NR3D_R2C_TXTR_THR1=2}},
    .tnr_r2c_3 ={.bits={.rsv_0=0, .NR3D_R2CF_CNT4=0, .NR3D_R2CF_CNT3=0, .NR3D_R2CF_CNT2=0, .NR3D_R2CF_CNT1=0}}

};
const ISP_NVRAM_NR3D_T gc13a0mipiraw_NR3D_0071 = {
        .on_con    ={.bits={.rsv_0=0, .NR3D_ON_EN=0, .rsv_5=0, .NR3D_TILE_EDGE=15, .rsv_12=0, .NR3D_SL2_OFF=0, .rsv_21=0}},
    .tnr_tnr_enable={.bits={.rsv_0=0, .NR3D_TNR_C_EN=0, .NR3D_TNR_Y_EN=0}},
    .tnr_flt_config={.bits={.rsv_0=0, .NR3D_EN_CCR=1, .NR3D_EN_CYCR=1, .NR3D_FLT_STR_MAX=28, .NR3D_BLEND_RATIO_MV=8, .NR3D_BLEND_RATIO_TXTR=8, .NR3D_BLEND_RATIO_DE=8, .NR3D_BLEND_RATIO_BLKY=8}},
    .tnr_fb_info1={.bits={.rsv_0=0, .NR3D_Q_SP=20, .NR3D_Q_NL=4}},
    .tnr_thr_1 ={.bits={.rsv_0=0, .NR3D_SMALL_SAD_THR=10, .NR3D_MV_PEN_THR=32, .NR3D_MV_PEN_W=8, .NR3D_BDI_THR=4, .rsv_30=0}},
    .tnr_curve_1={.bits={.rsv_0=0, .NR3D_Q_BLKY_Y4=16, .NR3D_Q_BLKY_Y3=26, .NR3D_Q_BLKY_Y2=32, .NR3D_Q_BLKY_Y1=30, .NR3D_Q_BLKY_Y0=28}},
    .tnr_curve_2={.bits={.rsv_0=0, .NR3D_Q_BLKC_Y1=26, .NR3D_Q_BLKC_Y0=24, .NR3D_Q_BLKY_Y7=0, .NR3D_Q_BLKY_Y6=0, .NR3D_Q_BLKY_Y5=4}},
    .tnr_curve_3={.bits={.rsv_0=0, .NR3D_Q_BLKC_Y6=0, .NR3D_Q_BLKC_Y5=0, .NR3D_Q_BLKC_Y4=0, .NR3D_Q_BLKC_Y3=2, .NR3D_Q_BLKC_Y2=8}},
    .tnr_curve_4={.bits={.rsv_0=0, .NR3D_Q_DETXTR_LVL_Y3=21, .NR3D_Q_DETXTR_LVL_Y2=16, .NR3D_Q_DETXTR_LVL_Y1=8, .NR3D_Q_DETXTR_LVL_Y0=0, .NR3D_Q_BLKC_Y7=0}},
    .tnr_curve_5={.bits={.rsv_0=0, .NR3D_Q_DE1_BASE_Y0=32, .NR3D_Q_DETXTR_LVL_Y7=32, .NR3D_Q_DETXTR_LVL_Y6=32, .NR3D_Q_DETXTR_LVL_Y5=32, .NR3D_Q_DETXTR_LVL_Y4=27}},
    .tnr_curve_6={.bits={.rsv_0=0, .NR3D_Q_DE1_BASE_Y5=0, .NR3D_Q_DE1_BASE_Y4=12, .NR3D_Q_DE1_BASE_Y3=21, .NR3D_Q_DE1_BASE_Y2=27, .NR3D_Q_DE1_BASE_Y1=32}},
    .tnr_curve_7={.bits={.rsv_0=0, .NR3D_Q_DE2TXTR_BASE_Y2=22, .NR3D_Q_DE2TXTR_BASE_Y1=5, .NR3D_Q_DE2TXTR_BASE_Y0=0, .NR3D_Q_DE1_BASE_Y7=0, .NR3D_Q_DE1_BASE_Y6=0}},
    .tnr_curve_8={.bits={.rsv_0=0, .NR3D_Q_DE2TXTR_BASE_Y7=32, .NR3D_Q_DE2TXTR_BASE_Y6=32, .NR3D_Q_DE2TXTR_BASE_Y5=32, .NR3D_Q_DE2TXTR_BASE_Y4=32, .NR3D_Q_DE2TXTR_BASE_Y3=32}},
    .tnr_curve_9={.bits={.rsv_0=0, .NR3D_Q_MV_Y4=20, .NR3D_Q_MV_Y3=14, .NR3D_Q_MV_Y2=7, .NR3D_Q_MV_Y1=3, .NR3D_Q_MV_Y0=0}},
    .tnr_curve_10={.bits={.rsv_0=0, .NR3D_Q_WVAR_Y1=16, .NR3D_Q_WVAR_Y0=16, .NR3D_Q_MV_Y7=32, .NR3D_Q_MV_Y6=30, .NR3D_Q_MV_Y5=26}},
    .tnr_curve_11={.bits={.rsv_0=0, .NR3D_Q_WVAR_Y6=1, .NR3D_Q_WVAR_Y5=1, .NR3D_Q_WVAR_Y4=2, .NR3D_Q_WVAR_Y3=3, .NR3D_Q_WVAR_Y2=6}},
    .tnr_curve_12={.bits={.rsv_0=0, .NR3D_Q_WSM_Y3=9, .NR3D_Q_WSM_Y2=3, .NR3D_Q_WSM_Y1=1, .NR3D_Q_WSM_Y0=0, .NR3D_Q_WVAR_Y7=1}},
    .tnr_curve_13={.bits={.rsv_0=0, .NR3D_Q_WSM_Y7=16, .NR3D_Q_WSM_Y6=16, .NR3D_Q_WSM_Y5=16, .NR3D_Q_WSM_Y4=14}},
    .tnr_curve_14={.bits={.rsv_0=0, .NR3D_Q_SDL_Y4=32, .NR3D_Q_SDL_Y3=40, .NR3D_Q_SDL_Y2=48, .NR3D_Q_SDL_Y1=56, .NR3D_Q_SDL_Y0=63}},
    .tnr_curve_15={.bits={.rsv_0=0, .NR3D_Q_SDL_Y8=0, .NR3D_Q_SDL_Y7=8, .NR3D_Q_SDL_Y6=16, .NR3D_Q_SDL_Y5=24}},
    .tnr_r2c_1 ={.bits={.NR3D_R2CENC=0, .NR3D_R2C_VAL4=13, .NR3D_R2C_VAL3=11, .NR3D_R2C_VAL2=7, .NR3D_R2C_VAL1=3, .rsv_26=0}},
    .tnr_r2c_2 ={.bits={.rsv_0=0, .NR3D_R2C_TXTR_THROFF=12, .NR3D_R2C_TXTR_THR4=9, .NR3D_R2C_TXTR_THR3=6, .NR3D_R2C_TXTR_THR2=4, .NR3D_R2C_TXTR_THR1=2}},
    .tnr_r2c_3 ={.bits={.rsv_0=0, .NR3D_R2CF_CNT4=0, .NR3D_R2CF_CNT3=0, .NR3D_R2CF_CNT2=0, .NR3D_R2CF_CNT1=0}}

};
const ISP_NVRAM_NR3D_T gc13a0mipiraw_NR3D_0072 = {
        .on_con    ={.bits={.rsv_0=0, .NR3D_ON_EN=0, .rsv_5=0, .NR3D_TILE_EDGE=15, .rsv_12=0, .NR3D_SL2_OFF=0, .rsv_21=0}},
    .tnr_tnr_enable={.bits={.rsv_0=0, .NR3D_TNR_C_EN=0, .NR3D_TNR_Y_EN=0}},
    .tnr_flt_config={.bits={.rsv_0=0, .NR3D_EN_CCR=1, .NR3D_EN_CYCR=1, .NR3D_FLT_STR_MAX=28, .NR3D_BLEND_RATIO_MV=8, .NR3D_BLEND_RATIO_TXTR=8, .NR3D_BLEND_RATIO_DE=8, .NR3D_BLEND_RATIO_BLKY=8}},
    .tnr_fb_info1={.bits={.rsv_0=0, .NR3D_Q_SP=20, .NR3D_Q_NL=4}},
    .tnr_thr_1 ={.bits={.rsv_0=0, .NR3D_SMALL_SAD_THR=10, .NR3D_MV_PEN_THR=32, .NR3D_MV_PEN_W=8, .NR3D_BDI_THR=4, .rsv_30=0}},
    .tnr_curve_1={.bits={.rsv_0=0, .NR3D_Q_BLKY_Y4=16, .NR3D_Q_BLKY_Y3=26, .NR3D_Q_BLKY_Y2=32, .NR3D_Q_BLKY_Y1=30, .NR3D_Q_BLKY_Y0=28}},
    .tnr_curve_2={.bits={.rsv_0=0, .NR3D_Q_BLKC_Y1=26, .NR3D_Q_BLKC_Y0=24, .NR3D_Q_BLKY_Y7=0, .NR3D_Q_BLKY_Y6=0, .NR3D_Q_BLKY_Y5=4}},
    .tnr_curve_3={.bits={.rsv_0=0, .NR3D_Q_BLKC_Y6=0, .NR3D_Q_BLKC_Y5=0, .NR3D_Q_BLKC_Y4=0, .NR3D_Q_BLKC_Y3=2, .NR3D_Q_BLKC_Y2=8}},
    .tnr_curve_4={.bits={.rsv_0=0, .NR3D_Q_DETXTR_LVL_Y3=21, .NR3D_Q_DETXTR_LVL_Y2=16, .NR3D_Q_DETXTR_LVL_Y1=8, .NR3D_Q_DETXTR_LVL_Y0=0, .NR3D_Q_BLKC_Y7=0}},
    .tnr_curve_5={.bits={.rsv_0=0, .NR3D_Q_DE1_BASE_Y0=32, .NR3D_Q_DETXTR_LVL_Y7=32, .NR3D_Q_DETXTR_LVL_Y6=32, .NR3D_Q_DETXTR_LVL_Y5=32, .NR3D_Q_DETXTR_LVL_Y4=27}},
    .tnr_curve_6={.bits={.rsv_0=0, .NR3D_Q_DE1_BASE_Y5=0, .NR3D_Q_DE1_BASE_Y4=12, .NR3D_Q_DE1_BASE_Y3=21, .NR3D_Q_DE1_BASE_Y2=27, .NR3D_Q_DE1_BASE_Y1=32}},
    .tnr_curve_7={.bits={.rsv_0=0, .NR3D_Q_DE2TXTR_BASE_Y2=22, .NR3D_Q_DE2TXTR_BASE_Y1=5, .NR3D_Q_DE2TXTR_BASE_Y0=0, .NR3D_Q_DE1_BASE_Y7=0, .NR3D_Q_DE1_BASE_Y6=0}},
    .tnr_curve_8={.bits={.rsv_0=0, .NR3D_Q_DE2TXTR_BASE_Y7=32, .NR3D_Q_DE2TXTR_BASE_Y6=32, .NR3D_Q_DE2TXTR_BASE_Y5=32, .NR3D_Q_DE2TXTR_BASE_Y4=32, .NR3D_Q_DE2TXTR_BASE_Y3=32}},
    .tnr_curve_9={.bits={.rsv_0=0, .NR3D_Q_MV_Y4=20, .NR3D_Q_MV_Y3=14, .NR3D_Q_MV_Y2=7, .NR3D_Q_MV_Y1=3, .NR3D_Q_MV_Y0=0}},
    .tnr_curve_10={.bits={.rsv_0=0, .NR3D_Q_WVAR_Y1=16, .NR3D_Q_WVAR_Y0=16, .NR3D_Q_MV_Y7=32, .NR3D_Q_MV_Y6=30, .NR3D_Q_MV_Y5=26}},
    .tnr_curve_11={.bits={.rsv_0=0, .NR3D_Q_WVAR_Y6=1, .NR3D_Q_WVAR_Y5=1, .NR3D_Q_WVAR_Y4=2, .NR3D_Q_WVAR_Y3=3, .NR3D_Q_WVAR_Y2=6}},
    .tnr_curve_12={.bits={.rsv_0=0, .NR3D_Q_WSM_Y3=9, .NR3D_Q_WSM_Y2=3, .NR3D_Q_WSM_Y1=1, .NR3D_Q_WSM_Y0=0, .NR3D_Q_WVAR_Y7=1}},
    .tnr_curve_13={.bits={.rsv_0=0, .NR3D_Q_WSM_Y7=16, .NR3D_Q_WSM_Y6=16, .NR3D_Q_WSM_Y5=16, .NR3D_Q_WSM_Y4=14}},
    .tnr_curve_14={.bits={.rsv_0=0, .NR3D_Q_SDL_Y4=32, .NR3D_Q_SDL_Y3=40, .NR3D_Q_SDL_Y2=48, .NR3D_Q_SDL_Y1=56, .NR3D_Q_SDL_Y0=63}},
    .tnr_curve_15={.bits={.rsv_0=0, .NR3D_Q_SDL_Y8=0, .NR3D_Q_SDL_Y7=8, .NR3D_Q_SDL_Y6=16, .NR3D_Q_SDL_Y5=24}},
    .tnr_r2c_1 ={.bits={.NR3D_R2CENC=0, .NR3D_R2C_VAL4=13, .NR3D_R2C_VAL3=11, .NR3D_R2C_VAL2=7, .NR3D_R2C_VAL1=3, .rsv_26=0}},
    .tnr_r2c_2 ={.bits={.rsv_0=0, .NR3D_R2C_TXTR_THROFF=12, .NR3D_R2C_TXTR_THR4=9, .NR3D_R2C_TXTR_THR3=6, .NR3D_R2C_TXTR_THR2=4, .NR3D_R2C_TXTR_THR1=2}},
    .tnr_r2c_3 ={.bits={.rsv_0=0, .NR3D_R2CF_CNT4=0, .NR3D_R2CF_CNT3=0, .NR3D_R2CF_CNT2=0, .NR3D_R2CF_CNT1=0}}

};
const ISP_NVRAM_NR3D_T gc13a0mipiraw_NR3D_0073 = {
        .on_con    ={.bits={.rsv_0=0, .NR3D_ON_EN=0, .rsv_5=0, .NR3D_TILE_EDGE=15, .rsv_12=0, .NR3D_SL2_OFF=0, .rsv_21=0}},
    .tnr_tnr_enable={.bits={.rsv_0=0, .NR3D_TNR_C_EN=0, .NR3D_TNR_Y_EN=0}},
    .tnr_flt_config={.bits={.rsv_0=0, .NR3D_EN_CCR=1, .NR3D_EN_CYCR=1, .NR3D_FLT_STR_MAX=28, .NR3D_BLEND_RATIO_MV=8, .NR3D_BLEND_RATIO_TXTR=8, .NR3D_BLEND_RATIO_DE=8, .NR3D_BLEND_RATIO_BLKY=8}},
    .tnr_fb_info1={.bits={.rsv_0=0, .NR3D_Q_SP=20, .NR3D_Q_NL=4}},
    .tnr_thr_1 ={.bits={.rsv_0=0, .NR3D_SMALL_SAD_THR=10, .NR3D_MV_PEN_THR=32, .NR3D_MV_PEN_W=8, .NR3D_BDI_THR=4, .rsv_30=0}},
    .tnr_curve_1={.bits={.rsv_0=0, .NR3D_Q_BLKY_Y4=16, .NR3D_Q_BLKY_Y3=26, .NR3D_Q_BLKY_Y2=32, .NR3D_Q_BLKY_Y1=30, .NR3D_Q_BLKY_Y0=28}},
    .tnr_curve_2={.bits={.rsv_0=0, .NR3D_Q_BLKC_Y1=26, .NR3D_Q_BLKC_Y0=24, .NR3D_Q_BLKY_Y7=0, .NR3D_Q_BLKY_Y6=0, .NR3D_Q_BLKY_Y5=4}},
    .tnr_curve_3={.bits={.rsv_0=0, .NR3D_Q_BLKC_Y6=0, .NR3D_Q_BLKC_Y5=0, .NR3D_Q_BLKC_Y4=0, .NR3D_Q_BLKC_Y3=2, .NR3D_Q_BLKC_Y2=8}},
    .tnr_curve_4={.bits={.rsv_0=0, .NR3D_Q_DETXTR_LVL_Y3=21, .NR3D_Q_DETXTR_LVL_Y2=16, .NR3D_Q_DETXTR_LVL_Y1=8, .NR3D_Q_DETXTR_LVL_Y0=0, .NR3D_Q_BLKC_Y7=0}},
    .tnr_curve_5={.bits={.rsv_0=0, .NR3D_Q_DE1_BASE_Y0=32, .NR3D_Q_DETXTR_LVL_Y7=32, .NR3D_Q_DETXTR_LVL_Y6=32, .NR3D_Q_DETXTR_LVL_Y5=32, .NR3D_Q_DETXTR_LVL_Y4=27}},
    .tnr_curve_6={.bits={.rsv_0=0, .NR3D_Q_DE1_BASE_Y5=0, .NR3D_Q_DE1_BASE_Y4=12, .NR3D_Q_DE1_BASE_Y3=21, .NR3D_Q_DE1_BASE_Y2=27, .NR3D_Q_DE1_BASE_Y1=32}},
    .tnr_curve_7={.bits={.rsv_0=0, .NR3D_Q_DE2TXTR_BASE_Y2=22, .NR3D_Q_DE2TXTR_BASE_Y1=5, .NR3D_Q_DE2TXTR_BASE_Y0=0, .NR3D_Q_DE1_BASE_Y7=0, .NR3D_Q_DE1_BASE_Y6=0}},
    .tnr_curve_8={.bits={.rsv_0=0, .NR3D_Q_DE2TXTR_BASE_Y7=32, .NR3D_Q_DE2TXTR_BASE_Y6=32, .NR3D_Q_DE2TXTR_BASE_Y5=32, .NR3D_Q_DE2TXTR_BASE_Y4=32, .NR3D_Q_DE2TXTR_BASE_Y3=32}},
    .tnr_curve_9={.bits={.rsv_0=0, .NR3D_Q_MV_Y4=20, .NR3D_Q_MV_Y3=14, .NR3D_Q_MV_Y2=7, .NR3D_Q_MV_Y1=3, .NR3D_Q_MV_Y0=0}},
    .tnr_curve_10={.bits={.rsv_0=0, .NR3D_Q_WVAR_Y1=16, .NR3D_Q_WVAR_Y0=16, .NR3D_Q_MV_Y7=32, .NR3D_Q_MV_Y6=30, .NR3D_Q_MV_Y5=26}},
    .tnr_curve_11={.bits={.rsv_0=0, .NR3D_Q_WVAR_Y6=1, .NR3D_Q_WVAR_Y5=1, .NR3D_Q_WVAR_Y4=2, .NR3D_Q_WVAR_Y3=3, .NR3D_Q_WVAR_Y2=6}},
    .tnr_curve_12={.bits={.rsv_0=0, .NR3D_Q_WSM_Y3=9, .NR3D_Q_WSM_Y2=3, .NR3D_Q_WSM_Y1=1, .NR3D_Q_WSM_Y0=0, .NR3D_Q_WVAR_Y7=1}},
    .tnr_curve_13={.bits={.rsv_0=0, .NR3D_Q_WSM_Y7=16, .NR3D_Q_WSM_Y6=16, .NR3D_Q_WSM_Y5=16, .NR3D_Q_WSM_Y4=14}},
    .tnr_curve_14={.bits={.rsv_0=0, .NR3D_Q_SDL_Y4=32, .NR3D_Q_SDL_Y3=40, .NR3D_Q_SDL_Y2=48, .NR3D_Q_SDL_Y1=56, .NR3D_Q_SDL_Y0=63}},
    .tnr_curve_15={.bits={.rsv_0=0, .NR3D_Q_SDL_Y8=0, .NR3D_Q_SDL_Y7=8, .NR3D_Q_SDL_Y6=16, .NR3D_Q_SDL_Y5=24}},
    .tnr_r2c_1 ={.bits={.NR3D_R2CENC=0, .NR3D_R2C_VAL4=13, .NR3D_R2C_VAL3=11, .NR3D_R2C_VAL2=7, .NR3D_R2C_VAL1=3, .rsv_26=0}},
    .tnr_r2c_2 ={.bits={.rsv_0=0, .NR3D_R2C_TXTR_THROFF=12, .NR3D_R2C_TXTR_THR4=9, .NR3D_R2C_TXTR_THR3=6, .NR3D_R2C_TXTR_THR2=4, .NR3D_R2C_TXTR_THR1=2}},
    .tnr_r2c_3 ={.bits={.rsv_0=0, .NR3D_R2CF_CNT4=0, .NR3D_R2CF_CNT3=0, .NR3D_R2CF_CNT2=0, .NR3D_R2CF_CNT1=0}}

};
const ISP_NVRAM_NR3D_T gc13a0mipiraw_NR3D_0074 = {
        .on_con    ={.bits={.rsv_0=0, .NR3D_ON_EN=0, .rsv_5=0, .NR3D_TILE_EDGE=15, .rsv_12=0, .NR3D_SL2_OFF=0, .rsv_21=0}},
    .tnr_tnr_enable={.bits={.rsv_0=0, .NR3D_TNR_C_EN=0, .NR3D_TNR_Y_EN=0}},
    .tnr_flt_config={.bits={.rsv_0=0, .NR3D_EN_CCR=1, .NR3D_EN_CYCR=1, .NR3D_FLT_STR_MAX=28, .NR3D_BLEND_RATIO_MV=8, .NR3D_BLEND_RATIO_TXTR=8, .NR3D_BLEND_RATIO_DE=8, .NR3D_BLEND_RATIO_BLKY=8}},
    .tnr_fb_info1={.bits={.rsv_0=0, .NR3D_Q_SP=20, .NR3D_Q_NL=4}},
    .tnr_thr_1 ={.bits={.rsv_0=0, .NR3D_SMALL_SAD_THR=10, .NR3D_MV_PEN_THR=32, .NR3D_MV_PEN_W=8, .NR3D_BDI_THR=4, .rsv_30=0}},
    .tnr_curve_1={.bits={.rsv_0=0, .NR3D_Q_BLKY_Y4=16, .NR3D_Q_BLKY_Y3=26, .NR3D_Q_BLKY_Y2=32, .NR3D_Q_BLKY_Y1=30, .NR3D_Q_BLKY_Y0=28}},
    .tnr_curve_2={.bits={.rsv_0=0, .NR3D_Q_BLKC_Y1=26, .NR3D_Q_BLKC_Y0=24, .NR3D_Q_BLKY_Y7=0, .NR3D_Q_BLKY_Y6=0, .NR3D_Q_BLKY_Y5=4}},
    .tnr_curve_3={.bits={.rsv_0=0, .NR3D_Q_BLKC_Y6=0, .NR3D_Q_BLKC_Y5=0, .NR3D_Q_BLKC_Y4=0, .NR3D_Q_BLKC_Y3=2, .NR3D_Q_BLKC_Y2=8}},
    .tnr_curve_4={.bits={.rsv_0=0, .NR3D_Q_DETXTR_LVL_Y3=21, .NR3D_Q_DETXTR_LVL_Y2=16, .NR3D_Q_DETXTR_LVL_Y1=8, .NR3D_Q_DETXTR_LVL_Y0=0, .NR3D_Q_BLKC_Y7=0}},
    .tnr_curve_5={.bits={.rsv_0=0, .NR3D_Q_DE1_BASE_Y0=32, .NR3D_Q_DETXTR_LVL_Y7=32, .NR3D_Q_DETXTR_LVL_Y6=32, .NR3D_Q_DETXTR_LVL_Y5=32, .NR3D_Q_DETXTR_LVL_Y4=27}},
    .tnr_curve_6={.bits={.rsv_0=0, .NR3D_Q_DE1_BASE_Y5=0, .NR3D_Q_DE1_BASE_Y4=12, .NR3D_Q_DE1_BASE_Y3=21, .NR3D_Q_DE1_BASE_Y2=27, .NR3D_Q_DE1_BASE_Y1=32}},
    .tnr_curve_7={.bits={.rsv_0=0, .NR3D_Q_DE2TXTR_BASE_Y2=22, .NR3D_Q_DE2TXTR_BASE_Y1=5, .NR3D_Q_DE2TXTR_BASE_Y0=0, .NR3D_Q_DE1_BASE_Y7=0, .NR3D_Q_DE1_BASE_Y6=0}},
    .tnr_curve_8={.bits={.rsv_0=0, .NR3D_Q_DE2TXTR_BASE_Y7=32, .NR3D_Q_DE2TXTR_BASE_Y6=32, .NR3D_Q_DE2TXTR_BASE_Y5=32, .NR3D_Q_DE2TXTR_BASE_Y4=32, .NR3D_Q_DE2TXTR_BASE_Y3=32}},
    .tnr_curve_9={.bits={.rsv_0=0, .NR3D_Q_MV_Y4=20, .NR3D_Q_MV_Y3=14, .NR3D_Q_MV_Y2=7, .NR3D_Q_MV_Y1=3, .NR3D_Q_MV_Y0=0}},
    .tnr_curve_10={.bits={.rsv_0=0, .NR3D_Q_WVAR_Y1=16, .NR3D_Q_WVAR_Y0=16, .NR3D_Q_MV_Y7=32, .NR3D_Q_MV_Y6=30, .NR3D_Q_MV_Y5=26}},
    .tnr_curve_11={.bits={.rsv_0=0, .NR3D_Q_WVAR_Y6=1, .NR3D_Q_WVAR_Y5=1, .NR3D_Q_WVAR_Y4=2, .NR3D_Q_WVAR_Y3=3, .NR3D_Q_WVAR_Y2=6}},
    .tnr_curve_12={.bits={.rsv_0=0, .NR3D_Q_WSM_Y3=9, .NR3D_Q_WSM_Y2=3, .NR3D_Q_WSM_Y1=1, .NR3D_Q_WSM_Y0=0, .NR3D_Q_WVAR_Y7=1}},
    .tnr_curve_13={.bits={.rsv_0=0, .NR3D_Q_WSM_Y7=16, .NR3D_Q_WSM_Y6=16, .NR3D_Q_WSM_Y5=16, .NR3D_Q_WSM_Y4=14}},
    .tnr_curve_14={.bits={.rsv_0=0, .NR3D_Q_SDL_Y4=32, .NR3D_Q_SDL_Y3=40, .NR3D_Q_SDL_Y2=48, .NR3D_Q_SDL_Y1=56, .NR3D_Q_SDL_Y0=63}},
    .tnr_curve_15={.bits={.rsv_0=0, .NR3D_Q_SDL_Y8=0, .NR3D_Q_SDL_Y7=8, .NR3D_Q_SDL_Y6=16, .NR3D_Q_SDL_Y5=24}},
    .tnr_r2c_1 ={.bits={.NR3D_R2CENC=0, .NR3D_R2C_VAL4=13, .NR3D_R2C_VAL3=11, .NR3D_R2C_VAL2=7, .NR3D_R2C_VAL1=3, .rsv_26=0}},
    .tnr_r2c_2 ={.bits={.rsv_0=0, .NR3D_R2C_TXTR_THROFF=12, .NR3D_R2C_TXTR_THR4=9, .NR3D_R2C_TXTR_THR3=6, .NR3D_R2C_TXTR_THR2=4, .NR3D_R2C_TXTR_THR1=2}},
    .tnr_r2c_3 ={.bits={.rsv_0=0, .NR3D_R2CF_CNT4=0, .NR3D_R2CF_CNT3=0, .NR3D_R2CF_CNT2=0, .NR3D_R2CF_CNT1=0}}

};
const ISP_NVRAM_NR3D_T gc13a0mipiraw_NR3D_0075 = {
        .on_con    ={.bits={.rsv_0=0, .NR3D_ON_EN=0, .rsv_5=0, .NR3D_TILE_EDGE=15, .rsv_12=0, .NR3D_SL2_OFF=0, .rsv_21=0}},
    .tnr_tnr_enable={.bits={.rsv_0=0, .NR3D_TNR_C_EN=0, .NR3D_TNR_Y_EN=0}},
    .tnr_flt_config={.bits={.rsv_0=0, .NR3D_EN_CCR=1, .NR3D_EN_CYCR=1, .NR3D_FLT_STR_MAX=28, .NR3D_BLEND_RATIO_MV=8, .NR3D_BLEND_RATIO_TXTR=8, .NR3D_BLEND_RATIO_DE=8, .NR3D_BLEND_RATIO_BLKY=8}},
    .tnr_fb_info1={.bits={.rsv_0=0, .NR3D_Q_SP=20, .NR3D_Q_NL=4}},
    .tnr_thr_1 ={.bits={.rsv_0=0, .NR3D_SMALL_SAD_THR=10, .NR3D_MV_PEN_THR=32, .NR3D_MV_PEN_W=8, .NR3D_BDI_THR=4, .rsv_30=0}},
    .tnr_curve_1={.bits={.rsv_0=0, .NR3D_Q_BLKY_Y4=16, .NR3D_Q_BLKY_Y3=26, .NR3D_Q_BLKY_Y2=32, .NR3D_Q_BLKY_Y1=30, .NR3D_Q_BLKY_Y0=28}},
    .tnr_curve_2={.bits={.rsv_0=0, .NR3D_Q_BLKC_Y1=26, .NR3D_Q_BLKC_Y0=24, .NR3D_Q_BLKY_Y7=0, .NR3D_Q_BLKY_Y6=0, .NR3D_Q_BLKY_Y5=4}},
    .tnr_curve_3={.bits={.rsv_0=0, .NR3D_Q_BLKC_Y6=0, .NR3D_Q_BLKC_Y5=0, .NR3D_Q_BLKC_Y4=0, .NR3D_Q_BLKC_Y3=2, .NR3D_Q_BLKC_Y2=8}},
    .tnr_curve_4={.bits={.rsv_0=0, .NR3D_Q_DETXTR_LVL_Y3=21, .NR3D_Q_DETXTR_LVL_Y2=16, .NR3D_Q_DETXTR_LVL_Y1=8, .NR3D_Q_DETXTR_LVL_Y0=0, .NR3D_Q_BLKC_Y7=0}},
    .tnr_curve_5={.bits={.rsv_0=0, .NR3D_Q_DE1_BASE_Y0=32, .NR3D_Q_DETXTR_LVL_Y7=32, .NR3D_Q_DETXTR_LVL_Y6=32, .NR3D_Q_DETXTR_LVL_Y5=32, .NR3D_Q_DETXTR_LVL_Y4=27}},
    .tnr_curve_6={.bits={.rsv_0=0, .NR3D_Q_DE1_BASE_Y5=0, .NR3D_Q_DE1_BASE_Y4=12, .NR3D_Q_DE1_BASE_Y3=21, .NR3D_Q_DE1_BASE_Y2=27, .NR3D_Q_DE1_BASE_Y1=32}},
    .tnr_curve_7={.bits={.rsv_0=0, .NR3D_Q_DE2TXTR_BASE_Y2=22, .NR3D_Q_DE2TXTR_BASE_Y1=5, .NR3D_Q_DE2TXTR_BASE_Y0=0, .NR3D_Q_DE1_BASE_Y7=0, .NR3D_Q_DE1_BASE_Y6=0}},
    .tnr_curve_8={.bits={.rsv_0=0, .NR3D_Q_DE2TXTR_BASE_Y7=32, .NR3D_Q_DE2TXTR_BASE_Y6=32, .NR3D_Q_DE2TXTR_BASE_Y5=32, .NR3D_Q_DE2TXTR_BASE_Y4=32, .NR3D_Q_DE2TXTR_BASE_Y3=32}},
    .tnr_curve_9={.bits={.rsv_0=0, .NR3D_Q_MV_Y4=20, .NR3D_Q_MV_Y3=14, .NR3D_Q_MV_Y2=7, .NR3D_Q_MV_Y1=3, .NR3D_Q_MV_Y0=0}},
    .tnr_curve_10={.bits={.rsv_0=0, .NR3D_Q_WVAR_Y1=16, .NR3D_Q_WVAR_Y0=16, .NR3D_Q_MV_Y7=32, .NR3D_Q_MV_Y6=30, .NR3D_Q_MV_Y5=26}},
    .tnr_curve_11={.bits={.rsv_0=0, .NR3D_Q_WVAR_Y6=1, .NR3D_Q_WVAR_Y5=1, .NR3D_Q_WVAR_Y4=2, .NR3D_Q_WVAR_Y3=3, .NR3D_Q_WVAR_Y2=6}},
    .tnr_curve_12={.bits={.rsv_0=0, .NR3D_Q_WSM_Y3=9, .NR3D_Q_WSM_Y2=3, .NR3D_Q_WSM_Y1=1, .NR3D_Q_WSM_Y0=0, .NR3D_Q_WVAR_Y7=1}},
    .tnr_curve_13={.bits={.rsv_0=0, .NR3D_Q_WSM_Y7=16, .NR3D_Q_WSM_Y6=16, .NR3D_Q_WSM_Y5=16, .NR3D_Q_WSM_Y4=14}},
    .tnr_curve_14={.bits={.rsv_0=0, .NR3D_Q_SDL_Y4=32, .NR3D_Q_SDL_Y3=40, .NR3D_Q_SDL_Y2=48, .NR3D_Q_SDL_Y1=56, .NR3D_Q_SDL_Y0=63}},
    .tnr_curve_15={.bits={.rsv_0=0, .NR3D_Q_SDL_Y8=0, .NR3D_Q_SDL_Y7=8, .NR3D_Q_SDL_Y6=16, .NR3D_Q_SDL_Y5=24}},
    .tnr_r2c_1 ={.bits={.NR3D_R2CENC=0, .NR3D_R2C_VAL4=13, .NR3D_R2C_VAL3=11, .NR3D_R2C_VAL2=7, .NR3D_R2C_VAL1=3, .rsv_26=0}},
    .tnr_r2c_2 ={.bits={.rsv_0=0, .NR3D_R2C_TXTR_THROFF=12, .NR3D_R2C_TXTR_THR4=9, .NR3D_R2C_TXTR_THR3=6, .NR3D_R2C_TXTR_THR2=4, .NR3D_R2C_TXTR_THR1=2}},
    .tnr_r2c_3 ={.bits={.rsv_0=0, .NR3D_R2CF_CNT4=0, .NR3D_R2CF_CNT3=0, .NR3D_R2CF_CNT2=0, .NR3D_R2CF_CNT1=0}}

};
const ISP_NVRAM_NR3D_T gc13a0mipiraw_NR3D_0076 = {
        .on_con    ={.bits={.rsv_0=0, .NR3D_ON_EN=0, .rsv_5=0, .NR3D_TILE_EDGE=15, .rsv_12=0, .NR3D_SL2_OFF=0, .rsv_21=0}},
    .tnr_tnr_enable={.bits={.rsv_0=0, .NR3D_TNR_C_EN=0, .NR3D_TNR_Y_EN=0}},
    .tnr_flt_config={.bits={.rsv_0=0, .NR3D_EN_CCR=1, .NR3D_EN_CYCR=1, .NR3D_FLT_STR_MAX=28, .NR3D_BLEND_RATIO_MV=8, .NR3D_BLEND_RATIO_TXTR=8, .NR3D_BLEND_RATIO_DE=8, .NR3D_BLEND_RATIO_BLKY=8}},
    .tnr_fb_info1={.bits={.rsv_0=0, .NR3D_Q_SP=20, .NR3D_Q_NL=4}},
    .tnr_thr_1 ={.bits={.rsv_0=0, .NR3D_SMALL_SAD_THR=10, .NR3D_MV_PEN_THR=32, .NR3D_MV_PEN_W=8, .NR3D_BDI_THR=4, .rsv_30=0}},
    .tnr_curve_1={.bits={.rsv_0=0, .NR3D_Q_BLKY_Y4=16, .NR3D_Q_BLKY_Y3=26, .NR3D_Q_BLKY_Y2=32, .NR3D_Q_BLKY_Y1=30, .NR3D_Q_BLKY_Y0=28}},
    .tnr_curve_2={.bits={.rsv_0=0, .NR3D_Q_BLKC_Y1=26, .NR3D_Q_BLKC_Y0=24, .NR3D_Q_BLKY_Y7=0, .NR3D_Q_BLKY_Y6=0, .NR3D_Q_BLKY_Y5=4}},
    .tnr_curve_3={.bits={.rsv_0=0, .NR3D_Q_BLKC_Y6=0, .NR3D_Q_BLKC_Y5=0, .NR3D_Q_BLKC_Y4=0, .NR3D_Q_BLKC_Y3=2, .NR3D_Q_BLKC_Y2=8}},
    .tnr_curve_4={.bits={.rsv_0=0, .NR3D_Q_DETXTR_LVL_Y3=21, .NR3D_Q_DETXTR_LVL_Y2=16, .NR3D_Q_DETXTR_LVL_Y1=8, .NR3D_Q_DETXTR_LVL_Y0=0, .NR3D_Q_BLKC_Y7=0}},
    .tnr_curve_5={.bits={.rsv_0=0, .NR3D_Q_DE1_BASE_Y0=32, .NR3D_Q_DETXTR_LVL_Y7=32, .NR3D_Q_DETXTR_LVL_Y6=32, .NR3D_Q_DETXTR_LVL_Y5=32, .NR3D_Q_DETXTR_LVL_Y4=27}},
    .tnr_curve_6={.bits={.rsv_0=0, .NR3D_Q_DE1_BASE_Y5=0, .NR3D_Q_DE1_BASE_Y4=12, .NR3D_Q_DE1_BASE_Y3=21, .NR3D_Q_DE1_BASE_Y2=27, .NR3D_Q_DE1_BASE_Y1=32}},
    .tnr_curve_7={.bits={.rsv_0=0, .NR3D_Q_DE2TXTR_BASE_Y2=22, .NR3D_Q_DE2TXTR_BASE_Y1=5, .NR3D_Q_DE2TXTR_BASE_Y0=0, .NR3D_Q_DE1_BASE_Y7=0, .NR3D_Q_DE1_BASE_Y6=0}},
    .tnr_curve_8={.bits={.rsv_0=0, .NR3D_Q_DE2TXTR_BASE_Y7=32, .NR3D_Q_DE2TXTR_BASE_Y6=32, .NR3D_Q_DE2TXTR_BASE_Y5=32, .NR3D_Q_DE2TXTR_BASE_Y4=32, .NR3D_Q_DE2TXTR_BASE_Y3=32}},
    .tnr_curve_9={.bits={.rsv_0=0, .NR3D_Q_MV_Y4=20, .NR3D_Q_MV_Y3=14, .NR3D_Q_MV_Y2=7, .NR3D_Q_MV_Y1=3, .NR3D_Q_MV_Y0=0}},
    .tnr_curve_10={.bits={.rsv_0=0, .NR3D_Q_WVAR_Y1=16, .NR3D_Q_WVAR_Y0=16, .NR3D_Q_MV_Y7=32, .NR3D_Q_MV_Y6=30, .NR3D_Q_MV_Y5=26}},
    .tnr_curve_11={.bits={.rsv_0=0, .NR3D_Q_WVAR_Y6=1, .NR3D_Q_WVAR_Y5=1, .NR3D_Q_WVAR_Y4=2, .NR3D_Q_WVAR_Y3=3, .NR3D_Q_WVAR_Y2=6}},
    .tnr_curve_12={.bits={.rsv_0=0, .NR3D_Q_WSM_Y3=9, .NR3D_Q_WSM_Y2=3, .NR3D_Q_WSM_Y1=1, .NR3D_Q_WSM_Y0=0, .NR3D_Q_WVAR_Y7=1}},
    .tnr_curve_13={.bits={.rsv_0=0, .NR3D_Q_WSM_Y7=16, .NR3D_Q_WSM_Y6=16, .NR3D_Q_WSM_Y5=16, .NR3D_Q_WSM_Y4=14}},
    .tnr_curve_14={.bits={.rsv_0=0, .NR3D_Q_SDL_Y4=32, .NR3D_Q_SDL_Y3=40, .NR3D_Q_SDL_Y2=48, .NR3D_Q_SDL_Y1=56, .NR3D_Q_SDL_Y0=63}},
    .tnr_curve_15={.bits={.rsv_0=0, .NR3D_Q_SDL_Y8=0, .NR3D_Q_SDL_Y7=8, .NR3D_Q_SDL_Y6=16, .NR3D_Q_SDL_Y5=24}},
    .tnr_r2c_1 ={.bits={.NR3D_R2CENC=0, .NR3D_R2C_VAL4=13, .NR3D_R2C_VAL3=11, .NR3D_R2C_VAL2=7, .NR3D_R2C_VAL1=3, .rsv_26=0}},
    .tnr_r2c_2 ={.bits={.rsv_0=0, .NR3D_R2C_TXTR_THROFF=12, .NR3D_R2C_TXTR_THR4=9, .NR3D_R2C_TXTR_THR3=6, .NR3D_R2C_TXTR_THR2=4, .NR3D_R2C_TXTR_THR1=2}},
    .tnr_r2c_3 ={.bits={.rsv_0=0, .NR3D_R2CF_CNT4=0, .NR3D_R2CF_CNT3=0, .NR3D_R2CF_CNT2=0, .NR3D_R2CF_CNT1=0}}

};
const ISP_NVRAM_NR3D_T gc13a0mipiraw_NR3D_0077 = {
        .on_con    ={.bits={.rsv_0=0, .NR3D_ON_EN=0, .rsv_5=0, .NR3D_TILE_EDGE=15, .rsv_12=0, .NR3D_SL2_OFF=0, .rsv_21=0}},
    .tnr_tnr_enable={.bits={.rsv_0=0, .NR3D_TNR_C_EN=0, .NR3D_TNR_Y_EN=0}},
    .tnr_flt_config={.bits={.rsv_0=0, .NR3D_EN_CCR=1, .NR3D_EN_CYCR=1, .NR3D_FLT_STR_MAX=28, .NR3D_BLEND_RATIO_MV=8, .NR3D_BLEND_RATIO_TXTR=8, .NR3D_BLEND_RATIO_DE=8, .NR3D_BLEND_RATIO_BLKY=8}},
    .tnr_fb_info1={.bits={.rsv_0=0, .NR3D_Q_SP=20, .NR3D_Q_NL=4}},
    .tnr_thr_1 ={.bits={.rsv_0=0, .NR3D_SMALL_SAD_THR=10, .NR3D_MV_PEN_THR=32, .NR3D_MV_PEN_W=8, .NR3D_BDI_THR=4, .rsv_30=0}},
    .tnr_curve_1={.bits={.rsv_0=0, .NR3D_Q_BLKY_Y4=16, .NR3D_Q_BLKY_Y3=26, .NR3D_Q_BLKY_Y2=32, .NR3D_Q_BLKY_Y1=30, .NR3D_Q_BLKY_Y0=28}},
    .tnr_curve_2={.bits={.rsv_0=0, .NR3D_Q_BLKC_Y1=26, .NR3D_Q_BLKC_Y0=24, .NR3D_Q_BLKY_Y7=0, .NR3D_Q_BLKY_Y6=0, .NR3D_Q_BLKY_Y5=4}},
    .tnr_curve_3={.bits={.rsv_0=0, .NR3D_Q_BLKC_Y6=0, .NR3D_Q_BLKC_Y5=0, .NR3D_Q_BLKC_Y4=0, .NR3D_Q_BLKC_Y3=2, .NR3D_Q_BLKC_Y2=8}},
    .tnr_curve_4={.bits={.rsv_0=0, .NR3D_Q_DETXTR_LVL_Y3=21, .NR3D_Q_DETXTR_LVL_Y2=16, .NR3D_Q_DETXTR_LVL_Y1=8, .NR3D_Q_DETXTR_LVL_Y0=0, .NR3D_Q_BLKC_Y7=0}},
    .tnr_curve_5={.bits={.rsv_0=0, .NR3D_Q_DE1_BASE_Y0=32, .NR3D_Q_DETXTR_LVL_Y7=32, .NR3D_Q_DETXTR_LVL_Y6=32, .NR3D_Q_DETXTR_LVL_Y5=32, .NR3D_Q_DETXTR_LVL_Y4=27}},
    .tnr_curve_6={.bits={.rsv_0=0, .NR3D_Q_DE1_BASE_Y5=0, .NR3D_Q_DE1_BASE_Y4=12, .NR3D_Q_DE1_BASE_Y3=21, .NR3D_Q_DE1_BASE_Y2=27, .NR3D_Q_DE1_BASE_Y1=32}},
    .tnr_curve_7={.bits={.rsv_0=0, .NR3D_Q_DE2TXTR_BASE_Y2=22, .NR3D_Q_DE2TXTR_BASE_Y1=5, .NR3D_Q_DE2TXTR_BASE_Y0=0, .NR3D_Q_DE1_BASE_Y7=0, .NR3D_Q_DE1_BASE_Y6=0}},
    .tnr_curve_8={.bits={.rsv_0=0, .NR3D_Q_DE2TXTR_BASE_Y7=32, .NR3D_Q_DE2TXTR_BASE_Y6=32, .NR3D_Q_DE2TXTR_BASE_Y5=32, .NR3D_Q_DE2TXTR_BASE_Y4=32, .NR3D_Q_DE2TXTR_BASE_Y3=32}},
    .tnr_curve_9={.bits={.rsv_0=0, .NR3D_Q_MV_Y4=20, .NR3D_Q_MV_Y3=14, .NR3D_Q_MV_Y2=7, .NR3D_Q_MV_Y1=3, .NR3D_Q_MV_Y0=0}},
    .tnr_curve_10={.bits={.rsv_0=0, .NR3D_Q_WVAR_Y1=16, .NR3D_Q_WVAR_Y0=16, .NR3D_Q_MV_Y7=32, .NR3D_Q_MV_Y6=30, .NR3D_Q_MV_Y5=26}},
    .tnr_curve_11={.bits={.rsv_0=0, .NR3D_Q_WVAR_Y6=1, .NR3D_Q_WVAR_Y5=1, .NR3D_Q_WVAR_Y4=2, .NR3D_Q_WVAR_Y3=3, .NR3D_Q_WVAR_Y2=6}},
    .tnr_curve_12={.bits={.rsv_0=0, .NR3D_Q_WSM_Y3=9, .NR3D_Q_WSM_Y2=3, .NR3D_Q_WSM_Y1=1, .NR3D_Q_WSM_Y0=0, .NR3D_Q_WVAR_Y7=1}},
    .tnr_curve_13={.bits={.rsv_0=0, .NR3D_Q_WSM_Y7=16, .NR3D_Q_WSM_Y6=16, .NR3D_Q_WSM_Y5=16, .NR3D_Q_WSM_Y4=14}},
    .tnr_curve_14={.bits={.rsv_0=0, .NR3D_Q_SDL_Y4=32, .NR3D_Q_SDL_Y3=40, .NR3D_Q_SDL_Y2=48, .NR3D_Q_SDL_Y1=56, .NR3D_Q_SDL_Y0=63}},
    .tnr_curve_15={.bits={.rsv_0=0, .NR3D_Q_SDL_Y8=0, .NR3D_Q_SDL_Y7=8, .NR3D_Q_SDL_Y6=16, .NR3D_Q_SDL_Y5=24}},
    .tnr_r2c_1 ={.bits={.NR3D_R2CENC=0, .NR3D_R2C_VAL4=13, .NR3D_R2C_VAL3=11, .NR3D_R2C_VAL2=7, .NR3D_R2C_VAL1=3, .rsv_26=0}},
    .tnr_r2c_2 ={.bits={.rsv_0=0, .NR3D_R2C_TXTR_THROFF=12, .NR3D_R2C_TXTR_THR4=9, .NR3D_R2C_TXTR_THR3=6, .NR3D_R2C_TXTR_THR2=4, .NR3D_R2C_TXTR_THR1=2}},
    .tnr_r2c_3 ={.bits={.rsv_0=0, .NR3D_R2CF_CNT4=0, .NR3D_R2CF_CNT3=0, .NR3D_R2CF_CNT2=0, .NR3D_R2CF_CNT1=0}}

};
const ISP_NVRAM_NR3D_T gc13a0mipiraw_NR3D_0078 = {
        .on_con    ={.bits={.rsv_0=0, .NR3D_ON_EN=0, .rsv_5=0, .NR3D_TILE_EDGE=15, .rsv_12=0, .NR3D_SL2_OFF=0, .rsv_21=0}},
    .tnr_tnr_enable={.bits={.rsv_0=0, .NR3D_TNR_C_EN=0, .NR3D_TNR_Y_EN=0}},
    .tnr_flt_config={.bits={.rsv_0=0, .NR3D_EN_CCR=1, .NR3D_EN_CYCR=1, .NR3D_FLT_STR_MAX=28, .NR3D_BLEND_RATIO_MV=8, .NR3D_BLEND_RATIO_TXTR=8, .NR3D_BLEND_RATIO_DE=8, .NR3D_BLEND_RATIO_BLKY=8}},
    .tnr_fb_info1={.bits={.rsv_0=0, .NR3D_Q_SP=20, .NR3D_Q_NL=4}},
    .tnr_thr_1 ={.bits={.rsv_0=0, .NR3D_SMALL_SAD_THR=10, .NR3D_MV_PEN_THR=32, .NR3D_MV_PEN_W=8, .NR3D_BDI_THR=4, .rsv_30=0}},
    .tnr_curve_1={.bits={.rsv_0=0, .NR3D_Q_BLKY_Y4=16, .NR3D_Q_BLKY_Y3=26, .NR3D_Q_BLKY_Y2=32, .NR3D_Q_BLKY_Y1=30, .NR3D_Q_BLKY_Y0=28}},
    .tnr_curve_2={.bits={.rsv_0=0, .NR3D_Q_BLKC_Y1=26, .NR3D_Q_BLKC_Y0=24, .NR3D_Q_BLKY_Y7=0, .NR3D_Q_BLKY_Y6=0, .NR3D_Q_BLKY_Y5=4}},
    .tnr_curve_3={.bits={.rsv_0=0, .NR3D_Q_BLKC_Y6=0, .NR3D_Q_BLKC_Y5=0, .NR3D_Q_BLKC_Y4=0, .NR3D_Q_BLKC_Y3=2, .NR3D_Q_BLKC_Y2=8}},
    .tnr_curve_4={.bits={.rsv_0=0, .NR3D_Q_DETXTR_LVL_Y3=21, .NR3D_Q_DETXTR_LVL_Y2=16, .NR3D_Q_DETXTR_LVL_Y1=8, .NR3D_Q_DETXTR_LVL_Y0=0, .NR3D_Q_BLKC_Y7=0}},
    .tnr_curve_5={.bits={.rsv_0=0, .NR3D_Q_DE1_BASE_Y0=32, .NR3D_Q_DETXTR_LVL_Y7=32, .NR3D_Q_DETXTR_LVL_Y6=32, .NR3D_Q_DETXTR_LVL_Y5=32, .NR3D_Q_DETXTR_LVL_Y4=27}},
    .tnr_curve_6={.bits={.rsv_0=0, .NR3D_Q_DE1_BASE_Y5=0, .NR3D_Q_DE1_BASE_Y4=12, .NR3D_Q_DE1_BASE_Y3=21, .NR3D_Q_DE1_BASE_Y2=27, .NR3D_Q_DE1_BASE_Y1=32}},
    .tnr_curve_7={.bits={.rsv_0=0, .NR3D_Q_DE2TXTR_BASE_Y2=22, .NR3D_Q_DE2TXTR_BASE_Y1=5, .NR3D_Q_DE2TXTR_BASE_Y0=0, .NR3D_Q_DE1_BASE_Y7=0, .NR3D_Q_DE1_BASE_Y6=0}},
    .tnr_curve_8={.bits={.rsv_0=0, .NR3D_Q_DE2TXTR_BASE_Y7=32, .NR3D_Q_DE2TXTR_BASE_Y6=32, .NR3D_Q_DE2TXTR_BASE_Y5=32, .NR3D_Q_DE2TXTR_BASE_Y4=32, .NR3D_Q_DE2TXTR_BASE_Y3=32}},
    .tnr_curve_9={.bits={.rsv_0=0, .NR3D_Q_MV_Y4=20, .NR3D_Q_MV_Y3=14, .NR3D_Q_MV_Y2=7, .NR3D_Q_MV_Y1=3, .NR3D_Q_MV_Y0=0}},
    .tnr_curve_10={.bits={.rsv_0=0, .NR3D_Q_WVAR_Y1=16, .NR3D_Q_WVAR_Y0=16, .NR3D_Q_MV_Y7=32, .NR3D_Q_MV_Y6=30, .NR3D_Q_MV_Y5=26}},
    .tnr_curve_11={.bits={.rsv_0=0, .NR3D_Q_WVAR_Y6=1, .NR3D_Q_WVAR_Y5=1, .NR3D_Q_WVAR_Y4=2, .NR3D_Q_WVAR_Y3=3, .NR3D_Q_WVAR_Y2=6}},
    .tnr_curve_12={.bits={.rsv_0=0, .NR3D_Q_WSM_Y3=9, .NR3D_Q_WSM_Y2=3, .NR3D_Q_WSM_Y1=1, .NR3D_Q_WSM_Y0=0, .NR3D_Q_WVAR_Y7=1}},
    .tnr_curve_13={.bits={.rsv_0=0, .NR3D_Q_WSM_Y7=16, .NR3D_Q_WSM_Y6=16, .NR3D_Q_WSM_Y5=16, .NR3D_Q_WSM_Y4=14}},
    .tnr_curve_14={.bits={.rsv_0=0, .NR3D_Q_SDL_Y4=32, .NR3D_Q_SDL_Y3=40, .NR3D_Q_SDL_Y2=48, .NR3D_Q_SDL_Y1=56, .NR3D_Q_SDL_Y0=63}},
    .tnr_curve_15={.bits={.rsv_0=0, .NR3D_Q_SDL_Y8=0, .NR3D_Q_SDL_Y7=8, .NR3D_Q_SDL_Y6=16, .NR3D_Q_SDL_Y5=24}},
    .tnr_r2c_1 ={.bits={.NR3D_R2CENC=0, .NR3D_R2C_VAL4=13, .NR3D_R2C_VAL3=11, .NR3D_R2C_VAL2=7, .NR3D_R2C_VAL1=3, .rsv_26=0}},
    .tnr_r2c_2 ={.bits={.rsv_0=0, .NR3D_R2C_TXTR_THROFF=12, .NR3D_R2C_TXTR_THR4=9, .NR3D_R2C_TXTR_THR3=6, .NR3D_R2C_TXTR_THR2=4, .NR3D_R2C_TXTR_THR1=2}},
    .tnr_r2c_3 ={.bits={.rsv_0=0, .NR3D_R2CF_CNT4=0, .NR3D_R2CF_CNT3=0, .NR3D_R2CF_CNT2=0, .NR3D_R2CF_CNT1=0}}

};
const ISP_NVRAM_NR3D_T gc13a0mipiraw_NR3D_0079 = {
        .on_con    ={.bits={.rsv_0=0, .NR3D_ON_EN=0, .rsv_5=0, .NR3D_TILE_EDGE=15, .rsv_12=0, .NR3D_SL2_OFF=0, .rsv_21=0}},
    .tnr_tnr_enable={.bits={.rsv_0=0, .NR3D_TNR_C_EN=0, .NR3D_TNR_Y_EN=0}},
    .tnr_flt_config={.bits={.rsv_0=0, .NR3D_EN_CCR=1, .NR3D_EN_CYCR=1, .NR3D_FLT_STR_MAX=28, .NR3D_BLEND_RATIO_MV=8, .NR3D_BLEND_RATIO_TXTR=8, .NR3D_BLEND_RATIO_DE=8, .NR3D_BLEND_RATIO_BLKY=8}},
    .tnr_fb_info1={.bits={.rsv_0=0, .NR3D_Q_SP=20, .NR3D_Q_NL=4}},
    .tnr_thr_1 ={.bits={.rsv_0=0, .NR3D_SMALL_SAD_THR=10, .NR3D_MV_PEN_THR=32, .NR3D_MV_PEN_W=8, .NR3D_BDI_THR=4, .rsv_30=0}},
    .tnr_curve_1={.bits={.rsv_0=0, .NR3D_Q_BLKY_Y4=16, .NR3D_Q_BLKY_Y3=26, .NR3D_Q_BLKY_Y2=32, .NR3D_Q_BLKY_Y1=30, .NR3D_Q_BLKY_Y0=28}},
    .tnr_curve_2={.bits={.rsv_0=0, .NR3D_Q_BLKC_Y1=26, .NR3D_Q_BLKC_Y0=24, .NR3D_Q_BLKY_Y7=0, .NR3D_Q_BLKY_Y6=0, .NR3D_Q_BLKY_Y5=4}},
    .tnr_curve_3={.bits={.rsv_0=0, .NR3D_Q_BLKC_Y6=0, .NR3D_Q_BLKC_Y5=0, .NR3D_Q_BLKC_Y4=0, .NR3D_Q_BLKC_Y3=2, .NR3D_Q_BLKC_Y2=8}},
    .tnr_curve_4={.bits={.rsv_0=0, .NR3D_Q_DETXTR_LVL_Y3=21, .NR3D_Q_DETXTR_LVL_Y2=16, .NR3D_Q_DETXTR_LVL_Y1=8, .NR3D_Q_DETXTR_LVL_Y0=0, .NR3D_Q_BLKC_Y7=0}},
    .tnr_curve_5={.bits={.rsv_0=0, .NR3D_Q_DE1_BASE_Y0=32, .NR3D_Q_DETXTR_LVL_Y7=32, .NR3D_Q_DETXTR_LVL_Y6=32, .NR3D_Q_DETXTR_LVL_Y5=32, .NR3D_Q_DETXTR_LVL_Y4=27}},
    .tnr_curve_6={.bits={.rsv_0=0, .NR3D_Q_DE1_BASE_Y5=0, .NR3D_Q_DE1_BASE_Y4=12, .NR3D_Q_DE1_BASE_Y3=21, .NR3D_Q_DE1_BASE_Y2=27, .NR3D_Q_DE1_BASE_Y1=32}},
    .tnr_curve_7={.bits={.rsv_0=0, .NR3D_Q_DE2TXTR_BASE_Y2=22, .NR3D_Q_DE2TXTR_BASE_Y1=5, .NR3D_Q_DE2TXTR_BASE_Y0=0, .NR3D_Q_DE1_BASE_Y7=0, .NR3D_Q_DE1_BASE_Y6=0}},
    .tnr_curve_8={.bits={.rsv_0=0, .NR3D_Q_DE2TXTR_BASE_Y7=32, .NR3D_Q_DE2TXTR_BASE_Y6=32, .NR3D_Q_DE2TXTR_BASE_Y5=32, .NR3D_Q_DE2TXTR_BASE_Y4=32, .NR3D_Q_DE2TXTR_BASE_Y3=32}},
    .tnr_curve_9={.bits={.rsv_0=0, .NR3D_Q_MV_Y4=20, .NR3D_Q_MV_Y3=14, .NR3D_Q_MV_Y2=7, .NR3D_Q_MV_Y1=3, .NR3D_Q_MV_Y0=0}},
    .tnr_curve_10={.bits={.rsv_0=0, .NR3D_Q_WVAR_Y1=16, .NR3D_Q_WVAR_Y0=16, .NR3D_Q_MV_Y7=32, .NR3D_Q_MV_Y6=30, .NR3D_Q_MV_Y5=26}},
    .tnr_curve_11={.bits={.rsv_0=0, .NR3D_Q_WVAR_Y6=1, .NR3D_Q_WVAR_Y5=1, .NR3D_Q_WVAR_Y4=2, .NR3D_Q_WVAR_Y3=3, .NR3D_Q_WVAR_Y2=6}},
    .tnr_curve_12={.bits={.rsv_0=0, .NR3D_Q_WSM_Y3=9, .NR3D_Q_WSM_Y2=3, .NR3D_Q_WSM_Y1=1, .NR3D_Q_WSM_Y0=0, .NR3D_Q_WVAR_Y7=1}},
    .tnr_curve_13={.bits={.rsv_0=0, .NR3D_Q_WSM_Y7=16, .NR3D_Q_WSM_Y6=16, .NR3D_Q_WSM_Y5=16, .NR3D_Q_WSM_Y4=14}},
    .tnr_curve_14={.bits={.rsv_0=0, .NR3D_Q_SDL_Y4=32, .NR3D_Q_SDL_Y3=40, .NR3D_Q_SDL_Y2=48, .NR3D_Q_SDL_Y1=56, .NR3D_Q_SDL_Y0=63}},
    .tnr_curve_15={.bits={.rsv_0=0, .NR3D_Q_SDL_Y8=0, .NR3D_Q_SDL_Y7=8, .NR3D_Q_SDL_Y6=16, .NR3D_Q_SDL_Y5=24}},
    .tnr_r2c_1 ={.bits={.NR3D_R2CENC=0, .NR3D_R2C_VAL4=13, .NR3D_R2C_VAL3=11, .NR3D_R2C_VAL2=7, .NR3D_R2C_VAL1=3, .rsv_26=0}},
    .tnr_r2c_2 ={.bits={.rsv_0=0, .NR3D_R2C_TXTR_THROFF=12, .NR3D_R2C_TXTR_THR4=9, .NR3D_R2C_TXTR_THR3=6, .NR3D_R2C_TXTR_THR2=4, .NR3D_R2C_TXTR_THR1=2}},
    .tnr_r2c_3 ={.bits={.rsv_0=0, .NR3D_R2CF_CNT4=0, .NR3D_R2CF_CNT3=0, .NR3D_R2CF_CNT2=0, .NR3D_R2CF_CNT1=0}}

};
const ISP_NBC_LTM_SW_PARAM_T gc13a0mipiraw_NBC_LCE_LINK_0060 = {
        32,  // TC_LINK_STR
    16,  // CE_LINK_STR
    24,  // GAIN_CLIP_HI
    16,  // GAIN_CLIP_LO
    32,  // GAMMA_SMOOTH
    16,  // P50_GAIN
    16,  // P250_GAIN
    16,  // P500_GAIN
    16,  // P750_GAIN
    16,  // P950_GAIN
    0,  // RSV1
    0,  // RSV2
    0,  // RSV3
    0,  // RSV4
    0,  // RSV5
    0,  // RSV6
    0,  // RSV7
    0  // RSV8

};
const ISP_NBC_LTM_SW_PARAM_T gc13a0mipiraw_NBC_LCE_LINK_0061 = {
        32,  // TC_LINK_STR
    16,  // CE_LINK_STR
    24,  // GAIN_CLIP_HI
    16,  // GAIN_CLIP_LO
    32,  // GAMMA_SMOOTH
    16,  // P50_GAIN
    16,  // P250_GAIN
    16,  // P500_GAIN
    16,  // P750_GAIN
    16,  // P950_GAIN
    0,  // RSV1
    0,  // RSV2
    0,  // RSV3
    0,  // RSV4
    0,  // RSV5
    0,  // RSV6
    0,  // RSV7
    0  // RSV8

};
const ISP_NBC_LTM_SW_PARAM_T gc13a0mipiraw_NBC_LCE_LINK_0062 = {
        32,  // TC_LINK_STR
    16,  // CE_LINK_STR
    24,  // GAIN_CLIP_HI
    16,  // GAIN_CLIP_LO
    32,  // GAMMA_SMOOTH
    16,  // P50_GAIN
    16,  // P250_GAIN
    16,  // P500_GAIN
    16,  // P750_GAIN
    16,  // P950_GAIN
    0,  // RSV1
    0,  // RSV2
    0,  // RSV3
    0,  // RSV4
    0,  // RSV5
    0,  // RSV6
    0,  // RSV7
    0  // RSV8

};
const ISP_NBC_LTM_SW_PARAM_T gc13a0mipiraw_NBC_LCE_LINK_0063 = {
        32,  // TC_LINK_STR
    16,  // CE_LINK_STR
    24,  // GAIN_CLIP_HI
    16,  // GAIN_CLIP_LO
    32,  // GAMMA_SMOOTH
    16,  // P50_GAIN
    16,  // P250_GAIN
    16,  // P500_GAIN
    16,  // P750_GAIN
    16,  // P950_GAIN
    0,  // RSV1
    0,  // RSV2
    0,  // RSV3
    0,  // RSV4
    0,  // RSV5
    0,  // RSV6
    0,  // RSV7
    0  // RSV8

};
const ISP_NBC_LTM_SW_PARAM_T gc13a0mipiraw_NBC_LCE_LINK_0064 = {
        32,  // TC_LINK_STR
    16,  // CE_LINK_STR
    24,  // GAIN_CLIP_HI
    16,  // GAIN_CLIP_LO
    32,  // GAMMA_SMOOTH
    16,  // P50_GAIN
    16,  // P250_GAIN
    16,  // P500_GAIN
    16,  // P750_GAIN
    16,  // P950_GAIN
    0,  // RSV1
    0,  // RSV2
    0,  // RSV3
    0,  // RSV4
    0,  // RSV5
    0,  // RSV6
    0,  // RSV7
    0  // RSV8

};
const ISP_NBC_LTM_SW_PARAM_T gc13a0mipiraw_NBC_LCE_LINK_0065 = {
        32,  // TC_LINK_STR
    16,  // CE_LINK_STR
    24,  // GAIN_CLIP_HI
    16,  // GAIN_CLIP_LO
    32,  // GAMMA_SMOOTH
    16,  // P50_GAIN
    16,  // P250_GAIN
    16,  // P500_GAIN
    16,  // P750_GAIN
    16,  // P950_GAIN
    0,  // RSV1
    0,  // RSV2
    0,  // RSV3
    0,  // RSV4
    0,  // RSV5
    0,  // RSV6
    0,  // RSV7
    0  // RSV8

};
const ISP_NBC_LTM_SW_PARAM_T gc13a0mipiraw_NBC_LCE_LINK_0066 = {
        32,  // TC_LINK_STR
    16,  // CE_LINK_STR
    24,  // GAIN_CLIP_HI
    16,  // GAIN_CLIP_LO
    32,  // GAMMA_SMOOTH
    16,  // P50_GAIN
    16,  // P250_GAIN
    16,  // P500_GAIN
    16,  // P750_GAIN
    16,  // P950_GAIN
    0,  // RSV1
    0,  // RSV2
    0,  // RSV3
    0,  // RSV4
    0,  // RSV5
    0,  // RSV6
    0,  // RSV7
    0  // RSV8

};
const ISP_NBC_LTM_SW_PARAM_T gc13a0mipiraw_NBC_LCE_LINK_0067 = {
        32,  // TC_LINK_STR
    16,  // CE_LINK_STR
    24,  // GAIN_CLIP_HI
    16,  // GAIN_CLIP_LO
    32,  // GAMMA_SMOOTH
    16,  // P50_GAIN
    16,  // P250_GAIN
    16,  // P500_GAIN
    16,  // P750_GAIN
    16,  // P950_GAIN
    0,  // RSV1
    0,  // RSV2
    0,  // RSV3
    0,  // RSV4
    0,  // RSV5
    0,  // RSV6
    0,  // RSV7
    0  // RSV8

};
const ISP_NBC_LTM_SW_PARAM_T gc13a0mipiraw_NBC_LCE_LINK_0068 = {
        32,  // TC_LINK_STR
    16,  // CE_LINK_STR
    24,  // GAIN_CLIP_HI
    16,  // GAIN_CLIP_LO
    32,  // GAMMA_SMOOTH
    16,  // P50_GAIN
    16,  // P250_GAIN
    16,  // P500_GAIN
    16,  // P750_GAIN
    16,  // P950_GAIN
    0,  // RSV1
    0,  // RSV2
    0,  // RSV3
    0,  // RSV4
    0,  // RSV5
    0,  // RSV6
    0,  // RSV7
    0  // RSV8

};
const ISP_NBC_LTM_SW_PARAM_T gc13a0mipiraw_NBC_LCE_LINK_0069 = {
        32,  // TC_LINK_STR
    16,  // CE_LINK_STR
    24,  // GAIN_CLIP_HI
    16,  // GAIN_CLIP_LO
    32,  // GAMMA_SMOOTH
    16,  // P50_GAIN
    16,  // P250_GAIN
    16,  // P500_GAIN
    16,  // P750_GAIN
    16,  // P950_GAIN
    0,  // RSV1
    0,  // RSV2
    0,  // RSV3
    0,  // RSV4
    0,  // RSV5
    0,  // RSV6
    0,  // RSV7
    0  // RSV8

};
const ISP_NBC_LTM_SW_PARAM_T gc13a0mipiraw_NBC_LCE_LINK_0070 = {
        32,  // TC_LINK_STR
    16,  // CE_LINK_STR
    24,  // GAIN_CLIP_HI
    16,  // GAIN_CLIP_LO
    32,  // GAMMA_SMOOTH
    16,  // P50_GAIN
    16,  // P250_GAIN
    16,  // P500_GAIN
    16,  // P750_GAIN
    16,  // P950_GAIN
    0,  // RSV1
    0,  // RSV2
    0,  // RSV3
    0,  // RSV4
    0,  // RSV5
    0,  // RSV6
    0,  // RSV7
    0  // RSV8

};
const ISP_NBC_LTM_SW_PARAM_T gc13a0mipiraw_NBC_LCE_LINK_0071 = {
        32,  // TC_LINK_STR
    16,  // CE_LINK_STR
    24,  // GAIN_CLIP_HI
    16,  // GAIN_CLIP_LO
    32,  // GAMMA_SMOOTH
    16,  // P50_GAIN
    16,  // P250_GAIN
    16,  // P500_GAIN
    16,  // P750_GAIN
    16,  // P950_GAIN
    0,  // RSV1
    0,  // RSV2
    0,  // RSV3
    0,  // RSV4
    0,  // RSV5
    0,  // RSV6
    0,  // RSV7
    0  // RSV8

};
const ISP_NBC_LTM_SW_PARAM_T gc13a0mipiraw_NBC_LCE_LINK_0072 = {
        32,  // TC_LINK_STR
    16,  // CE_LINK_STR
    24,  // GAIN_CLIP_HI
    16,  // GAIN_CLIP_LO
    32,  // GAMMA_SMOOTH
    16,  // P50_GAIN
    16,  // P250_GAIN
    16,  // P500_GAIN
    16,  // P750_GAIN
    16,  // P950_GAIN
    0,  // RSV1
    0,  // RSV2
    0,  // RSV3
    0,  // RSV4
    0,  // RSV5
    0,  // RSV6
    0,  // RSV7
    0  // RSV8

};
const ISP_NBC_LTM_SW_PARAM_T gc13a0mipiraw_NBC_LCE_LINK_0073 = {
        32,  // TC_LINK_STR
    16,  // CE_LINK_STR
    24,  // GAIN_CLIP_HI
    16,  // GAIN_CLIP_LO
    32,  // GAMMA_SMOOTH
    16,  // P50_GAIN
    16,  // P250_GAIN
    16,  // P500_GAIN
    16,  // P750_GAIN
    16,  // P950_GAIN
    0,  // RSV1
    0,  // RSV2
    0,  // RSV3
    0,  // RSV4
    0,  // RSV5
    0,  // RSV6
    0,  // RSV7
    0  // RSV8

};
const ISP_NBC_LTM_SW_PARAM_T gc13a0mipiraw_NBC_LCE_LINK_0074 = {
        32,  // TC_LINK_STR
    16,  // CE_LINK_STR
    24,  // GAIN_CLIP_HI
    16,  // GAIN_CLIP_LO
    32,  // GAMMA_SMOOTH
    16,  // P50_GAIN
    16,  // P250_GAIN
    16,  // P500_GAIN
    16,  // P750_GAIN
    16,  // P950_GAIN
    0,  // RSV1
    0,  // RSV2
    0,  // RSV3
    0,  // RSV4
    0,  // RSV5
    0,  // RSV6
    0,  // RSV7
    0  // RSV8

};
const ISP_NBC_LTM_SW_PARAM_T gc13a0mipiraw_NBC_LCE_LINK_0075 = {
        32,  // TC_LINK_STR
    16,  // CE_LINK_STR
    24,  // GAIN_CLIP_HI
    16,  // GAIN_CLIP_LO
    32,  // GAMMA_SMOOTH
    16,  // P50_GAIN
    16,  // P250_GAIN
    16,  // P500_GAIN
    16,  // P750_GAIN
    16,  // P950_GAIN
    0,  // RSV1
    0,  // RSV2
    0,  // RSV3
    0,  // RSV4
    0,  // RSV5
    0,  // RSV6
    0,  // RSV7
    0  // RSV8

};
const ISP_NBC_LTM_SW_PARAM_T gc13a0mipiraw_NBC_LCE_LINK_0076 = {
        32,  // TC_LINK_STR
    16,  // CE_LINK_STR
    24,  // GAIN_CLIP_HI
    16,  // GAIN_CLIP_LO
    32,  // GAMMA_SMOOTH
    16,  // P50_GAIN
    16,  // P250_GAIN
    16,  // P500_GAIN
    16,  // P750_GAIN
    16,  // P950_GAIN
    0,  // RSV1
    0,  // RSV2
    0,  // RSV3
    0,  // RSV4
    0,  // RSV5
    0,  // RSV6
    0,  // RSV7
    0  // RSV8

};
const ISP_NBC_LTM_SW_PARAM_T gc13a0mipiraw_NBC_LCE_LINK_0077 = {
        32,  // TC_LINK_STR
    16,  // CE_LINK_STR
    24,  // GAIN_CLIP_HI
    16,  // GAIN_CLIP_LO
    32,  // GAMMA_SMOOTH
    16,  // P50_GAIN
    16,  // P250_GAIN
    16,  // P500_GAIN
    16,  // P750_GAIN
    16,  // P950_GAIN
    0,  // RSV1
    0,  // RSV2
    0,  // RSV3
    0,  // RSV4
    0,  // RSV5
    0,  // RSV6
    0,  // RSV7
    0  // RSV8

};
const ISP_NBC_LTM_SW_PARAM_T gc13a0mipiraw_NBC_LCE_LINK_0078 = {
        32,  // TC_LINK_STR
    16,  // CE_LINK_STR
    24,  // GAIN_CLIP_HI
    16,  // GAIN_CLIP_LO
    32,  // GAMMA_SMOOTH
    16,  // P50_GAIN
    16,  // P250_GAIN
    16,  // P500_GAIN
    16,  // P750_GAIN
    16,  // P950_GAIN
    0,  // RSV1
    0,  // RSV2
    0,  // RSV3
    0,  // RSV4
    0,  // RSV5
    0,  // RSV6
    0,  // RSV7
    0  // RSV8

};
const ISP_NBC_LTM_SW_PARAM_T gc13a0mipiraw_NBC_LCE_LINK_0079 = {
        32,  // TC_LINK_STR
    16,  // CE_LINK_STR
    24,  // GAIN_CLIP_HI
    16,  // GAIN_CLIP_LO
    32,  // GAMMA_SMOOTH
    16,  // P50_GAIN
    16,  // P250_GAIN
    16,  // P500_GAIN
    16,  // P750_GAIN
    16,  // P950_GAIN
    0,  // RSV1
    0,  // RSV2
    0,  // RSV3
    0,  // RSV4
    0,  // RSV5
    0,  // RSV6
    0,  // RSV7
    0  // RSV8

};
