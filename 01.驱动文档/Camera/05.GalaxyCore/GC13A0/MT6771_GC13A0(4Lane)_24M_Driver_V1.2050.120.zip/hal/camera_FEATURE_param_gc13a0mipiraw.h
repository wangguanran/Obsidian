/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein
 * is confidential and proprietary to MediaTek Inc. and/or its licensors.
 * Without the prior written permission of MediaTek inc. and/or its licensors,
 * any reproduction, modification, use or disclosure of MediaTek Software,
 * and information contained herein, in whole or in part, shall be strictly prohibited.
 */
/* MediaTek Inc. (C) 2018. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER ON
 * AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 * NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 * SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 * SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES TO LOOK ONLY TO SUCH
 * THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. RECEIVER EXPRESSLY ACKNOWLEDGES
 * THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES
 * CONTAINED IN MEDIATEK SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK
 * SOFTWARE RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND
 * CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE,
 * AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE MEDIATEK SOFTWARE AT ISSUE,
 * OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY RECEIVER TO
 * MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek Software")
 * have been modified by MediaTek Inc. All revisions are subject to any receiver's
 * applicable license agreements with MediaTek Inc.
 */

/********************************************************************************************
 *     LEGAL DISCLAIMER
 *
 *     (Header of MediaTek Software/Firmware Release or Documentation)
 *
 *     BY OPENING OR USING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *     THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE") RECEIVED
 *     FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON AN "AS-IS" BASIS
 *     ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES, EXPRESS OR IMPLIED,
 *     INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 *     A PARTICULAR PURPOSE OR NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY
 *     WHATSOEVER WITH RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 *     INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND BUYER AGREES TO LOOK
 *     ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. MEDIATEK SHALL ALSO
 *     NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE RELEASES MADE TO BUYER'S SPECIFICATION
 *     OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *     BUYER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND CUMULATIVE LIABILITY WITH
 *     RESPECT TO THE MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION,
 *     TO REVISE OR REPLACE THE MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE
 *     FEES OR SERVICE CHARGE PAID BY BUYER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 *     THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE WITH THE LAWS
 *     OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF LAWS PRINCIPLES.
 ************************************************************************************************/

.MFNR = {
    gc13a0mipiraw_MFNR_0000, gc13a0mipiraw_MFNR_0001, gc13a0mipiraw_MFNR_0002, gc13a0mipiraw_MFNR_0003, gc13a0mipiraw_MFNR_0004, gc13a0mipiraw_MFNR_0005, gc13a0mipiraw_MFNR_0006, gc13a0mipiraw_MFNR_0007, gc13a0mipiraw_MFNR_0008, gc13a0mipiraw_MFNR_0009,
},
.SWNR = {
    gc13a0mipiraw_SWNR_0000, gc13a0mipiraw_SWNR_0001, gc13a0mipiraw_SWNR_0002, gc13a0mipiraw_SWNR_0003, gc13a0mipiraw_SWNR_0004, gc13a0mipiraw_SWNR_0005, gc13a0mipiraw_SWNR_0006, gc13a0mipiraw_SWNR_0007, gc13a0mipiraw_SWNR_0008, gc13a0mipiraw_SWNR_0009,
    gc13a0mipiraw_SWNR_0010, gc13a0mipiraw_SWNR_0011, gc13a0mipiraw_SWNR_0012, gc13a0mipiraw_SWNR_0013, gc13a0mipiraw_SWNR_0014, gc13a0mipiraw_SWNR_0015, gc13a0mipiraw_SWNR_0016, gc13a0mipiraw_SWNR_0017, gc13a0mipiraw_SWNR_0018, gc13a0mipiraw_SWNR_0019,
    gc13a0mipiraw_SWNR_0020, gc13a0mipiraw_SWNR_0021, gc13a0mipiraw_SWNR_0022, gc13a0mipiraw_SWNR_0023, gc13a0mipiraw_SWNR_0024, gc13a0mipiraw_SWNR_0025, gc13a0mipiraw_SWNR_0026, gc13a0mipiraw_SWNR_0027, gc13a0mipiraw_SWNR_0028, gc13a0mipiraw_SWNR_0029,
    gc13a0mipiraw_SWNR_0030, gc13a0mipiraw_SWNR_0031, gc13a0mipiraw_SWNR_0032, gc13a0mipiraw_SWNR_0033, gc13a0mipiraw_SWNR_0034, gc13a0mipiraw_SWNR_0035, gc13a0mipiraw_SWNR_0036, gc13a0mipiraw_SWNR_0037, gc13a0mipiraw_SWNR_0038, gc13a0mipiraw_SWNR_0039,
    gc13a0mipiraw_SWNR_0040, gc13a0mipiraw_SWNR_0041, gc13a0mipiraw_SWNR_0042, gc13a0mipiraw_SWNR_0043, gc13a0mipiraw_SWNR_0044, gc13a0mipiraw_SWNR_0045, gc13a0mipiraw_SWNR_0046, gc13a0mipiraw_SWNR_0047, gc13a0mipiraw_SWNR_0048, gc13a0mipiraw_SWNR_0049,
    gc13a0mipiraw_SWNR_0050, gc13a0mipiraw_SWNR_0051, gc13a0mipiraw_SWNR_0052, gc13a0mipiraw_SWNR_0053, gc13a0mipiraw_SWNR_0054, gc13a0mipiraw_SWNR_0055, gc13a0mipiraw_SWNR_0056, gc13a0mipiraw_SWNR_0057, gc13a0mipiraw_SWNR_0058, gc13a0mipiraw_SWNR_0059,
    gc13a0mipiraw_SWNR_0060, gc13a0mipiraw_SWNR_0061, gc13a0mipiraw_SWNR_0062, gc13a0mipiraw_SWNR_0063, gc13a0mipiraw_SWNR_0064, gc13a0mipiraw_SWNR_0065, gc13a0mipiraw_SWNR_0066, gc13a0mipiraw_SWNR_0067, gc13a0mipiraw_SWNR_0068, gc13a0mipiraw_SWNR_0069,
    gc13a0mipiraw_SWNR_0070, gc13a0mipiraw_SWNR_0071, gc13a0mipiraw_SWNR_0072, gc13a0mipiraw_SWNR_0073, gc13a0mipiraw_SWNR_0074, gc13a0mipiraw_SWNR_0075, gc13a0mipiraw_SWNR_0076, gc13a0mipiraw_SWNR_0077, gc13a0mipiraw_SWNR_0078, gc13a0mipiraw_SWNR_0079,
    gc13a0mipiraw_SWNR_0080, gc13a0mipiraw_SWNR_0081, gc13a0mipiraw_SWNR_0082, gc13a0mipiraw_SWNR_0083, gc13a0mipiraw_SWNR_0084, gc13a0mipiraw_SWNR_0085, gc13a0mipiraw_SWNR_0086, gc13a0mipiraw_SWNR_0087, gc13a0mipiraw_SWNR_0088, gc13a0mipiraw_SWNR_0089,
    gc13a0mipiraw_SWNR_0090, gc13a0mipiraw_SWNR_0091, gc13a0mipiraw_SWNR_0092, gc13a0mipiraw_SWNR_0093, gc13a0mipiraw_SWNR_0094, gc13a0mipiraw_SWNR_0095, gc13a0mipiraw_SWNR_0096, gc13a0mipiraw_SWNR_0097, gc13a0mipiraw_SWNR_0098, gc13a0mipiraw_SWNR_0099,
    gc13a0mipiraw_SWNR_0100, gc13a0mipiraw_SWNR_0101, gc13a0mipiraw_SWNR_0102, gc13a0mipiraw_SWNR_0103, gc13a0mipiraw_SWNR_0104, gc13a0mipiraw_SWNR_0105, gc13a0mipiraw_SWNR_0106, gc13a0mipiraw_SWNR_0107, gc13a0mipiraw_SWNR_0108, gc13a0mipiraw_SWNR_0109,
    gc13a0mipiraw_SWNR_0110, gc13a0mipiraw_SWNR_0111, gc13a0mipiraw_SWNR_0112, gc13a0mipiraw_SWNR_0113, gc13a0mipiraw_SWNR_0114, gc13a0mipiraw_SWNR_0115, gc13a0mipiraw_SWNR_0116, gc13a0mipiraw_SWNR_0117, gc13a0mipiraw_SWNR_0118, gc13a0mipiraw_SWNR_0119,
    gc13a0mipiraw_SWNR_0120, gc13a0mipiraw_SWNR_0121, gc13a0mipiraw_SWNR_0122, gc13a0mipiraw_SWNR_0123, gc13a0mipiraw_SWNR_0124, gc13a0mipiraw_SWNR_0125, gc13a0mipiraw_SWNR_0126, gc13a0mipiraw_SWNR_0127, gc13a0mipiraw_SWNR_0128, gc13a0mipiraw_SWNR_0129,
    gc13a0mipiraw_SWNR_0130, gc13a0mipiraw_SWNR_0131, gc13a0mipiraw_SWNR_0132, gc13a0mipiraw_SWNR_0133, gc13a0mipiraw_SWNR_0134, gc13a0mipiraw_SWNR_0135, gc13a0mipiraw_SWNR_0136, gc13a0mipiraw_SWNR_0137, gc13a0mipiraw_SWNR_0138, gc13a0mipiraw_SWNR_0139,
    gc13a0mipiraw_SWNR_0140, gc13a0mipiraw_SWNR_0141, gc13a0mipiraw_SWNR_0142, gc13a0mipiraw_SWNR_0143, gc13a0mipiraw_SWNR_0144, gc13a0mipiraw_SWNR_0145, gc13a0mipiraw_SWNR_0146, gc13a0mipiraw_SWNR_0147, gc13a0mipiraw_SWNR_0148, gc13a0mipiraw_SWNR_0149,
    gc13a0mipiraw_SWNR_0150, gc13a0mipiraw_SWNR_0151, gc13a0mipiraw_SWNR_0152, gc13a0mipiraw_SWNR_0153, gc13a0mipiraw_SWNR_0154, gc13a0mipiraw_SWNR_0155, gc13a0mipiraw_SWNR_0156, gc13a0mipiraw_SWNR_0157, gc13a0mipiraw_SWNR_0158, gc13a0mipiraw_SWNR_0159,
    gc13a0mipiraw_SWNR_0160, gc13a0mipiraw_SWNR_0161, gc13a0mipiraw_SWNR_0162, gc13a0mipiraw_SWNR_0163, gc13a0mipiraw_SWNR_0164, gc13a0mipiraw_SWNR_0165, gc13a0mipiraw_SWNR_0166, gc13a0mipiraw_SWNR_0167, gc13a0mipiraw_SWNR_0168, gc13a0mipiraw_SWNR_0169,
    gc13a0mipiraw_SWNR_0170, gc13a0mipiraw_SWNR_0171, gc13a0mipiraw_SWNR_0172, gc13a0mipiraw_SWNR_0173, gc13a0mipiraw_SWNR_0174, gc13a0mipiraw_SWNR_0175, gc13a0mipiraw_SWNR_0176, gc13a0mipiraw_SWNR_0177, gc13a0mipiraw_SWNR_0178, gc13a0mipiraw_SWNR_0179,
    gc13a0mipiraw_SWNR_0180, gc13a0mipiraw_SWNR_0181, gc13a0mipiraw_SWNR_0182, gc13a0mipiraw_SWNR_0183, gc13a0mipiraw_SWNR_0184, gc13a0mipiraw_SWNR_0185, gc13a0mipiraw_SWNR_0186, gc13a0mipiraw_SWNR_0187, gc13a0mipiraw_SWNR_0188, gc13a0mipiraw_SWNR_0189,
    gc13a0mipiraw_SWNR_0190, gc13a0mipiraw_SWNR_0191, gc13a0mipiraw_SWNR_0192, gc13a0mipiraw_SWNR_0193, gc13a0mipiraw_SWNR_0194, gc13a0mipiraw_SWNR_0195, gc13a0mipiraw_SWNR_0196, gc13a0mipiraw_SWNR_0197, gc13a0mipiraw_SWNR_0198, gc13a0mipiraw_SWNR_0199,
    gc13a0mipiraw_SWNR_0200, gc13a0mipiraw_SWNR_0201, gc13a0mipiraw_SWNR_0202, gc13a0mipiraw_SWNR_0203, gc13a0mipiraw_SWNR_0204, gc13a0mipiraw_SWNR_0205, gc13a0mipiraw_SWNR_0206, gc13a0mipiraw_SWNR_0207, gc13a0mipiraw_SWNR_0208, gc13a0mipiraw_SWNR_0209,
    gc13a0mipiraw_SWNR_0210, gc13a0mipiraw_SWNR_0211, gc13a0mipiraw_SWNR_0212, gc13a0mipiraw_SWNR_0213, gc13a0mipiraw_SWNR_0214, gc13a0mipiraw_SWNR_0215, gc13a0mipiraw_SWNR_0216, gc13a0mipiraw_SWNR_0217, gc13a0mipiraw_SWNR_0218, gc13a0mipiraw_SWNR_0219,
    gc13a0mipiraw_SWNR_0220, gc13a0mipiraw_SWNR_0221, gc13a0mipiraw_SWNR_0222, gc13a0mipiraw_SWNR_0223, gc13a0mipiraw_SWNR_0224, gc13a0mipiraw_SWNR_0225, gc13a0mipiraw_SWNR_0226, gc13a0mipiraw_SWNR_0227, gc13a0mipiraw_SWNR_0228, gc13a0mipiraw_SWNR_0229,
    gc13a0mipiraw_SWNR_0230, gc13a0mipiraw_SWNR_0231, gc13a0mipiraw_SWNR_0232, gc13a0mipiraw_SWNR_0233, gc13a0mipiraw_SWNR_0234, gc13a0mipiraw_SWNR_0235, gc13a0mipiraw_SWNR_0236, gc13a0mipiraw_SWNR_0237, gc13a0mipiraw_SWNR_0238, gc13a0mipiraw_SWNR_0239,
    gc13a0mipiraw_SWNR_0240, gc13a0mipiraw_SWNR_0241, gc13a0mipiraw_SWNR_0242, gc13a0mipiraw_SWNR_0243, gc13a0mipiraw_SWNR_0244, gc13a0mipiraw_SWNR_0245, gc13a0mipiraw_SWNR_0246, gc13a0mipiraw_SWNR_0247, gc13a0mipiraw_SWNR_0248, gc13a0mipiraw_SWNR_0249,
    gc13a0mipiraw_SWNR_0250, gc13a0mipiraw_SWNR_0251, gc13a0mipiraw_SWNR_0252, gc13a0mipiraw_SWNR_0253, gc13a0mipiraw_SWNR_0254, gc13a0mipiraw_SWNR_0255, gc13a0mipiraw_SWNR_0256, gc13a0mipiraw_SWNR_0257, gc13a0mipiraw_SWNR_0258, gc13a0mipiraw_SWNR_0259,
    gc13a0mipiraw_SWNR_0260, gc13a0mipiraw_SWNR_0261, gc13a0mipiraw_SWNR_0262, gc13a0mipiraw_SWNR_0263, gc13a0mipiraw_SWNR_0264, gc13a0mipiraw_SWNR_0265, gc13a0mipiraw_SWNR_0266, gc13a0mipiraw_SWNR_0267, gc13a0mipiraw_SWNR_0268, gc13a0mipiraw_SWNR_0269,
    gc13a0mipiraw_SWNR_0270, gc13a0mipiraw_SWNR_0271, gc13a0mipiraw_SWNR_0272, gc13a0mipiraw_SWNR_0273, gc13a0mipiraw_SWNR_0274, gc13a0mipiraw_SWNR_0275, gc13a0mipiraw_SWNR_0276, gc13a0mipiraw_SWNR_0277, gc13a0mipiraw_SWNR_0278, gc13a0mipiraw_SWNR_0279,
    gc13a0mipiraw_SWNR_0280, gc13a0mipiraw_SWNR_0281, gc13a0mipiraw_SWNR_0282, gc13a0mipiraw_SWNR_0283, gc13a0mipiraw_SWNR_0284, gc13a0mipiraw_SWNR_0285, gc13a0mipiraw_SWNR_0286, gc13a0mipiraw_SWNR_0287, gc13a0mipiraw_SWNR_0288, gc13a0mipiraw_SWNR_0289,
    gc13a0mipiraw_SWNR_0290, gc13a0mipiraw_SWNR_0291, gc13a0mipiraw_SWNR_0292, gc13a0mipiraw_SWNR_0293, gc13a0mipiraw_SWNR_0294, gc13a0mipiraw_SWNR_0295, gc13a0mipiraw_SWNR_0296, gc13a0mipiraw_SWNR_0297, gc13a0mipiraw_SWNR_0298, gc13a0mipiraw_SWNR_0299,
    gc13a0mipiraw_SWNR_0300, gc13a0mipiraw_SWNR_0301, gc13a0mipiraw_SWNR_0302, gc13a0mipiraw_SWNR_0303, gc13a0mipiraw_SWNR_0304, gc13a0mipiraw_SWNR_0305, gc13a0mipiraw_SWNR_0306, gc13a0mipiraw_SWNR_0307, gc13a0mipiraw_SWNR_0308, gc13a0mipiraw_SWNR_0309,
    gc13a0mipiraw_SWNR_0310, gc13a0mipiraw_SWNR_0311, gc13a0mipiraw_SWNR_0312, gc13a0mipiraw_SWNR_0313, gc13a0mipiraw_SWNR_0314, gc13a0mipiraw_SWNR_0315, gc13a0mipiraw_SWNR_0316, gc13a0mipiraw_SWNR_0317, gc13a0mipiraw_SWNR_0318, gc13a0mipiraw_SWNR_0319,
    gc13a0mipiraw_SWNR_0320, gc13a0mipiraw_SWNR_0321, gc13a0mipiraw_SWNR_0322, gc13a0mipiraw_SWNR_0323, gc13a0mipiraw_SWNR_0324, gc13a0mipiraw_SWNR_0325, gc13a0mipiraw_SWNR_0326, gc13a0mipiraw_SWNR_0327, gc13a0mipiraw_SWNR_0328, gc13a0mipiraw_SWNR_0329,
    gc13a0mipiraw_SWNR_0330, gc13a0mipiraw_SWNR_0331, gc13a0mipiraw_SWNR_0332, gc13a0mipiraw_SWNR_0333, gc13a0mipiraw_SWNR_0334, gc13a0mipiraw_SWNR_0335, gc13a0mipiraw_SWNR_0336, gc13a0mipiraw_SWNR_0337, gc13a0mipiraw_SWNR_0338, gc13a0mipiraw_SWNR_0339,
    gc13a0mipiraw_SWNR_0340, gc13a0mipiraw_SWNR_0341, gc13a0mipiraw_SWNR_0342, gc13a0mipiraw_SWNR_0343, gc13a0mipiraw_SWNR_0344, gc13a0mipiraw_SWNR_0345, gc13a0mipiraw_SWNR_0346, gc13a0mipiraw_SWNR_0347, gc13a0mipiraw_SWNR_0348, gc13a0mipiraw_SWNR_0349,
    gc13a0mipiraw_SWNR_0350, gc13a0mipiraw_SWNR_0351, gc13a0mipiraw_SWNR_0352, gc13a0mipiraw_SWNR_0353, gc13a0mipiraw_SWNR_0354, gc13a0mipiraw_SWNR_0355, gc13a0mipiraw_SWNR_0356, gc13a0mipiraw_SWNR_0357, gc13a0mipiraw_SWNR_0358, gc13a0mipiraw_SWNR_0359,
    gc13a0mipiraw_SWNR_0360, gc13a0mipiraw_SWNR_0361, gc13a0mipiraw_SWNR_0362, gc13a0mipiraw_SWNR_0363, gc13a0mipiraw_SWNR_0364, gc13a0mipiraw_SWNR_0365, gc13a0mipiraw_SWNR_0366, gc13a0mipiraw_SWNR_0367, gc13a0mipiraw_SWNR_0368, gc13a0mipiraw_SWNR_0369,
    gc13a0mipiraw_SWNR_0370, gc13a0mipiraw_SWNR_0371, gc13a0mipiraw_SWNR_0372, gc13a0mipiraw_SWNR_0373, gc13a0mipiraw_SWNR_0374, gc13a0mipiraw_SWNR_0375, gc13a0mipiraw_SWNR_0376, gc13a0mipiraw_SWNR_0377, gc13a0mipiraw_SWNR_0378, gc13a0mipiraw_SWNR_0379,
    gc13a0mipiraw_SWNR_0380, gc13a0mipiraw_SWNR_0381, gc13a0mipiraw_SWNR_0382, gc13a0mipiraw_SWNR_0383, gc13a0mipiraw_SWNR_0384, gc13a0mipiraw_SWNR_0385, gc13a0mipiraw_SWNR_0386, gc13a0mipiraw_SWNR_0387, gc13a0mipiraw_SWNR_0388, gc13a0mipiraw_SWNR_0389,
    gc13a0mipiraw_SWNR_0390, gc13a0mipiraw_SWNR_0391, gc13a0mipiraw_SWNR_0392, gc13a0mipiraw_SWNR_0393, gc13a0mipiraw_SWNR_0394, gc13a0mipiraw_SWNR_0395, gc13a0mipiraw_SWNR_0396, gc13a0mipiraw_SWNR_0397, gc13a0mipiraw_SWNR_0398, gc13a0mipiraw_SWNR_0399,
},
.CA_LTM = {
    gc13a0mipiraw_CA_LTM_0000, gc13a0mipiraw_CA_LTM_0001, gc13a0mipiraw_CA_LTM_0002, gc13a0mipiraw_CA_LTM_0003, gc13a0mipiraw_CA_LTM_0004, gc13a0mipiraw_CA_LTM_0005, gc13a0mipiraw_CA_LTM_0006, gc13a0mipiraw_CA_LTM_0007, gc13a0mipiraw_CA_LTM_0008, gc13a0mipiraw_CA_LTM_0009,
    gc13a0mipiraw_CA_LTM_0010, gc13a0mipiraw_CA_LTM_0011, gc13a0mipiraw_CA_LTM_0012, gc13a0mipiraw_CA_LTM_0013, gc13a0mipiraw_CA_LTM_0014, gc13a0mipiraw_CA_LTM_0015, gc13a0mipiraw_CA_LTM_0016, gc13a0mipiraw_CA_LTM_0017, gc13a0mipiraw_CA_LTM_0018, gc13a0mipiraw_CA_LTM_0019,
    gc13a0mipiraw_CA_LTM_0020, gc13a0mipiraw_CA_LTM_0021, gc13a0mipiraw_CA_LTM_0022, gc13a0mipiraw_CA_LTM_0023, gc13a0mipiraw_CA_LTM_0024, gc13a0mipiraw_CA_LTM_0025, gc13a0mipiraw_CA_LTM_0026, gc13a0mipiraw_CA_LTM_0027, gc13a0mipiraw_CA_LTM_0028, gc13a0mipiraw_CA_LTM_0029,
},
.ClearZoom = {
    gc13a0mipiraw_ClearZoom_0000, gc13a0mipiraw_ClearZoom_0001, gc13a0mipiraw_ClearZoom_0002, gc13a0mipiraw_ClearZoom_0003, gc13a0mipiraw_ClearZoom_0004, gc13a0mipiraw_ClearZoom_0005, gc13a0mipiraw_ClearZoom_0006,
},
.SWNR_THRES = {
    gc13a0mipiraw_SWNR_THRES_0000, gc13a0mipiraw_SWNR_THRES_0001, gc13a0mipiraw_SWNR_THRES_0002, gc13a0mipiraw_SWNR_THRES_0003, gc13a0mipiraw_SWNR_THRES_0004, gc13a0mipiraw_SWNR_THRES_0005, gc13a0mipiraw_SWNR_THRES_0006, gc13a0mipiraw_SWNR_THRES_0007, gc13a0mipiraw_SWNR_THRES_0008, gc13a0mipiraw_SWNR_THRES_0009,
    gc13a0mipiraw_SWNR_THRES_0010, gc13a0mipiraw_SWNR_THRES_0011, gc13a0mipiraw_SWNR_THRES_0012, gc13a0mipiraw_SWNR_THRES_0013, gc13a0mipiraw_SWNR_THRES_0014, gc13a0mipiraw_SWNR_THRES_0015, gc13a0mipiraw_SWNR_THRES_0016, gc13a0mipiraw_SWNR_THRES_0017, gc13a0mipiraw_SWNR_THRES_0018, gc13a0mipiraw_SWNR_THRES_0019,
},
