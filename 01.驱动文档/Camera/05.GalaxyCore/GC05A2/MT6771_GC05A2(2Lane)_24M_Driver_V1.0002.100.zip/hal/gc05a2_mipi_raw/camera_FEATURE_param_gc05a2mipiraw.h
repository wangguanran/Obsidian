/* Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein
 * is confidential and proprietary to MediaTek Inc. and/or its licensors.
 * Without the prior written permission of MediaTek inc. and/or its licensors,
 * any reproduction, modification, use or disclosure of MediaTek Software,
 * and information contained herein, in whole or in part, shall be strictly prohibited.
 */
/* MediaTek Inc. (C) 2023. All rights reserved.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER ON
 * AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR NONINFRINGEMENT.
 * NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH RESPECT TO THE
 * SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY, INCORPORATED IN, OR
 * SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES TO LOOK ONLY TO SUCH
 * THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. RECEIVER EXPRESSLY ACKNOWLEDGES
 * THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES
 * CONTAINED IN MEDIATEK SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK
 * SOFTWARE RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND
 * CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE,
 * AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE MEDIATEK SOFTWARE AT ISSUE,
 * OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE CHARGE PAID BY RECEIVER TO
 * MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek Software")
 * have been modified by MediaTek Inc. All revisions are subject to any receiver's
 * applicable license agreements with MediaTek Inc.
 */

/********************************************************************************************
 *     LEGAL DISCLAIMER
 *
 *     (Header of MediaTek Software/Firmware Release or Documentation)
 *
 *     BY OPENING OR USING THIS FILE, BUYER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 *     THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE") RECEIVED
 *     FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO BUYER ON AN "AS-IS" BASIS
 *     ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL WARRANTIES, EXPRESS OR IMPLIED,
 *     INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR
 *     A PARTICULAR PURPOSE OR NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY
 *     WHATSOEVER WITH RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 *     INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND BUYER AGREES TO LOOK
 *     ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO. MEDIATEK SHALL ALSO
 *     NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE RELEASES MADE TO BUYER'S SPECIFICATION
 *     OR TO CONFORM TO A PARTICULAR STANDARD OR OPEN FORUM.
 *
 *     BUYER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S ENTIRE AND CUMULATIVE LIABILITY WITH
 *     RESPECT TO THE MEDIATEK SOFTWARE RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION,
 *     TO REVISE OR REPLACE THE MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE
 *     FEES OR SERVICE CHARGE PAID BY BUYER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 *     THE TRANSACTION CONTEMPLATED HEREUNDER SHALL BE CONSTRUED IN ACCORDANCE WITH THE LAWS
 *     OF THE STATE OF CALIFORNIA, USA, EXCLUDING ITS CONFLICT OF LAWS PRINCIPLES.
 ************************************************************************************************/

.MFNR = {
    gc05a2mipiraw_MFNR_0000, gc05a2mipiraw_MFNR_0001, gc05a2mipiraw_MFNR_0002, gc05a2mipiraw_MFNR_0003, gc05a2mipiraw_MFNR_0004, gc05a2mipiraw_MFNR_0005, gc05a2mipiraw_MFNR_0006, gc05a2mipiraw_MFNR_0007, gc05a2mipiraw_MFNR_0008, gc05a2mipiraw_MFNR_0009,
},
.SWNR = {
    gc05a2mipiraw_SWNR_0000, gc05a2mipiraw_SWNR_0001, gc05a2mipiraw_SWNR_0002, gc05a2mipiraw_SWNR_0003, gc05a2mipiraw_SWNR_0004, gc05a2mipiraw_SWNR_0005, gc05a2mipiraw_SWNR_0006, gc05a2mipiraw_SWNR_0007, gc05a2mipiraw_SWNR_0008, gc05a2mipiraw_SWNR_0009,
    gc05a2mipiraw_SWNR_0010, gc05a2mipiraw_SWNR_0011, gc05a2mipiraw_SWNR_0012, gc05a2mipiraw_SWNR_0013, gc05a2mipiraw_SWNR_0014, gc05a2mipiraw_SWNR_0015, gc05a2mipiraw_SWNR_0016, gc05a2mipiraw_SWNR_0017, gc05a2mipiraw_SWNR_0018, gc05a2mipiraw_SWNR_0019,
    gc05a2mipiraw_SWNR_0020, gc05a2mipiraw_SWNR_0021, gc05a2mipiraw_SWNR_0022, gc05a2mipiraw_SWNR_0023, gc05a2mipiraw_SWNR_0024, gc05a2mipiraw_SWNR_0025, gc05a2mipiraw_SWNR_0026, gc05a2mipiraw_SWNR_0027, gc05a2mipiraw_SWNR_0028, gc05a2mipiraw_SWNR_0029,
    gc05a2mipiraw_SWNR_0030, gc05a2mipiraw_SWNR_0031, gc05a2mipiraw_SWNR_0032, gc05a2mipiraw_SWNR_0033, gc05a2mipiraw_SWNR_0034, gc05a2mipiraw_SWNR_0035, gc05a2mipiraw_SWNR_0036, gc05a2mipiraw_SWNR_0037, gc05a2mipiraw_SWNR_0038, gc05a2mipiraw_SWNR_0039,
    gc05a2mipiraw_SWNR_0040, gc05a2mipiraw_SWNR_0041, gc05a2mipiraw_SWNR_0042, gc05a2mipiraw_SWNR_0043, gc05a2mipiraw_SWNR_0044, gc05a2mipiraw_SWNR_0045, gc05a2mipiraw_SWNR_0046, gc05a2mipiraw_SWNR_0047, gc05a2mipiraw_SWNR_0048, gc05a2mipiraw_SWNR_0049,
    gc05a2mipiraw_SWNR_0050, gc05a2mipiraw_SWNR_0051, gc05a2mipiraw_SWNR_0052, gc05a2mipiraw_SWNR_0053, gc05a2mipiraw_SWNR_0054, gc05a2mipiraw_SWNR_0055, gc05a2mipiraw_SWNR_0056, gc05a2mipiraw_SWNR_0057, gc05a2mipiraw_SWNR_0058, gc05a2mipiraw_SWNR_0059,
    gc05a2mipiraw_SWNR_0060, gc05a2mipiraw_SWNR_0061, gc05a2mipiraw_SWNR_0062, gc05a2mipiraw_SWNR_0063, gc05a2mipiraw_SWNR_0064, gc05a2mipiraw_SWNR_0065, gc05a2mipiraw_SWNR_0066, gc05a2mipiraw_SWNR_0067, gc05a2mipiraw_SWNR_0068, gc05a2mipiraw_SWNR_0069,
    gc05a2mipiraw_SWNR_0070, gc05a2mipiraw_SWNR_0071, gc05a2mipiraw_SWNR_0072, gc05a2mipiraw_SWNR_0073, gc05a2mipiraw_SWNR_0074, gc05a2mipiraw_SWNR_0075, gc05a2mipiraw_SWNR_0076, gc05a2mipiraw_SWNR_0077, gc05a2mipiraw_SWNR_0078, gc05a2mipiraw_SWNR_0079,
    gc05a2mipiraw_SWNR_0080, gc05a2mipiraw_SWNR_0081, gc05a2mipiraw_SWNR_0082, gc05a2mipiraw_SWNR_0083, gc05a2mipiraw_SWNR_0084, gc05a2mipiraw_SWNR_0085, gc05a2mipiraw_SWNR_0086, gc05a2mipiraw_SWNR_0087, gc05a2mipiraw_SWNR_0088, gc05a2mipiraw_SWNR_0089,
    gc05a2mipiraw_SWNR_0090, gc05a2mipiraw_SWNR_0091, gc05a2mipiraw_SWNR_0092, gc05a2mipiraw_SWNR_0093, gc05a2mipiraw_SWNR_0094, gc05a2mipiraw_SWNR_0095, gc05a2mipiraw_SWNR_0096, gc05a2mipiraw_SWNR_0097, gc05a2mipiraw_SWNR_0098, gc05a2mipiraw_SWNR_0099,
    gc05a2mipiraw_SWNR_0100, gc05a2mipiraw_SWNR_0101, gc05a2mipiraw_SWNR_0102, gc05a2mipiraw_SWNR_0103, gc05a2mipiraw_SWNR_0104, gc05a2mipiraw_SWNR_0105, gc05a2mipiraw_SWNR_0106, gc05a2mipiraw_SWNR_0107, gc05a2mipiraw_SWNR_0108, gc05a2mipiraw_SWNR_0109,
    gc05a2mipiraw_SWNR_0110, gc05a2mipiraw_SWNR_0111, gc05a2mipiraw_SWNR_0112, gc05a2mipiraw_SWNR_0113, gc05a2mipiraw_SWNR_0114, gc05a2mipiraw_SWNR_0115, gc05a2mipiraw_SWNR_0116, gc05a2mipiraw_SWNR_0117, gc05a2mipiraw_SWNR_0118, gc05a2mipiraw_SWNR_0119,
    gc05a2mipiraw_SWNR_0120, gc05a2mipiraw_SWNR_0121, gc05a2mipiraw_SWNR_0122, gc05a2mipiraw_SWNR_0123, gc05a2mipiraw_SWNR_0124, gc05a2mipiraw_SWNR_0125, gc05a2mipiraw_SWNR_0126, gc05a2mipiraw_SWNR_0127, gc05a2mipiraw_SWNR_0128, gc05a2mipiraw_SWNR_0129,
    gc05a2mipiraw_SWNR_0130, gc05a2mipiraw_SWNR_0131, gc05a2mipiraw_SWNR_0132, gc05a2mipiraw_SWNR_0133, gc05a2mipiraw_SWNR_0134, gc05a2mipiraw_SWNR_0135, gc05a2mipiraw_SWNR_0136, gc05a2mipiraw_SWNR_0137, gc05a2mipiraw_SWNR_0138, gc05a2mipiraw_SWNR_0139,
    gc05a2mipiraw_SWNR_0140, gc05a2mipiraw_SWNR_0141, gc05a2mipiraw_SWNR_0142, gc05a2mipiraw_SWNR_0143, gc05a2mipiraw_SWNR_0144, gc05a2mipiraw_SWNR_0145, gc05a2mipiraw_SWNR_0146, gc05a2mipiraw_SWNR_0147, gc05a2mipiraw_SWNR_0148, gc05a2mipiraw_SWNR_0149,
    gc05a2mipiraw_SWNR_0150, gc05a2mipiraw_SWNR_0151, gc05a2mipiraw_SWNR_0152, gc05a2mipiraw_SWNR_0153, gc05a2mipiraw_SWNR_0154, gc05a2mipiraw_SWNR_0155, gc05a2mipiraw_SWNR_0156, gc05a2mipiraw_SWNR_0157, gc05a2mipiraw_SWNR_0158, gc05a2mipiraw_SWNR_0159,
    gc05a2mipiraw_SWNR_0160, gc05a2mipiraw_SWNR_0161, gc05a2mipiraw_SWNR_0162, gc05a2mipiraw_SWNR_0163, gc05a2mipiraw_SWNR_0164, gc05a2mipiraw_SWNR_0165, gc05a2mipiraw_SWNR_0166, gc05a2mipiraw_SWNR_0167, gc05a2mipiraw_SWNR_0168, gc05a2mipiraw_SWNR_0169,
    gc05a2mipiraw_SWNR_0170, gc05a2mipiraw_SWNR_0171, gc05a2mipiraw_SWNR_0172, gc05a2mipiraw_SWNR_0173, gc05a2mipiraw_SWNR_0174, gc05a2mipiraw_SWNR_0175, gc05a2mipiraw_SWNR_0176, gc05a2mipiraw_SWNR_0177, gc05a2mipiraw_SWNR_0178, gc05a2mipiraw_SWNR_0179,
    gc05a2mipiraw_SWNR_0180, gc05a2mipiraw_SWNR_0181, gc05a2mipiraw_SWNR_0182, gc05a2mipiraw_SWNR_0183, gc05a2mipiraw_SWNR_0184, gc05a2mipiraw_SWNR_0185, gc05a2mipiraw_SWNR_0186, gc05a2mipiraw_SWNR_0187, gc05a2mipiraw_SWNR_0188, gc05a2mipiraw_SWNR_0189,
    gc05a2mipiraw_SWNR_0190, gc05a2mipiraw_SWNR_0191, gc05a2mipiraw_SWNR_0192, gc05a2mipiraw_SWNR_0193, gc05a2mipiraw_SWNR_0194, gc05a2mipiraw_SWNR_0195, gc05a2mipiraw_SWNR_0196, gc05a2mipiraw_SWNR_0197, gc05a2mipiraw_SWNR_0198, gc05a2mipiraw_SWNR_0199,
    gc05a2mipiraw_SWNR_0200, gc05a2mipiraw_SWNR_0201, gc05a2mipiraw_SWNR_0202, gc05a2mipiraw_SWNR_0203, gc05a2mipiraw_SWNR_0204, gc05a2mipiraw_SWNR_0205, gc05a2mipiraw_SWNR_0206, gc05a2mipiraw_SWNR_0207, gc05a2mipiraw_SWNR_0208, gc05a2mipiraw_SWNR_0209,
    gc05a2mipiraw_SWNR_0210, gc05a2mipiraw_SWNR_0211, gc05a2mipiraw_SWNR_0212, gc05a2mipiraw_SWNR_0213, gc05a2mipiraw_SWNR_0214, gc05a2mipiraw_SWNR_0215, gc05a2mipiraw_SWNR_0216, gc05a2mipiraw_SWNR_0217, gc05a2mipiraw_SWNR_0218, gc05a2mipiraw_SWNR_0219,
    gc05a2mipiraw_SWNR_0220, gc05a2mipiraw_SWNR_0221, gc05a2mipiraw_SWNR_0222, gc05a2mipiraw_SWNR_0223, gc05a2mipiraw_SWNR_0224, gc05a2mipiraw_SWNR_0225, gc05a2mipiraw_SWNR_0226, gc05a2mipiraw_SWNR_0227, gc05a2mipiraw_SWNR_0228, gc05a2mipiraw_SWNR_0229,
    gc05a2mipiraw_SWNR_0230, gc05a2mipiraw_SWNR_0231, gc05a2mipiraw_SWNR_0232, gc05a2mipiraw_SWNR_0233, gc05a2mipiraw_SWNR_0234, gc05a2mipiraw_SWNR_0235, gc05a2mipiraw_SWNR_0236, gc05a2mipiraw_SWNR_0237, gc05a2mipiraw_SWNR_0238, gc05a2mipiraw_SWNR_0239,
    gc05a2mipiraw_SWNR_0240, gc05a2mipiraw_SWNR_0241, gc05a2mipiraw_SWNR_0242, gc05a2mipiraw_SWNR_0243, gc05a2mipiraw_SWNR_0244, gc05a2mipiraw_SWNR_0245, gc05a2mipiraw_SWNR_0246, gc05a2mipiraw_SWNR_0247, gc05a2mipiraw_SWNR_0248, gc05a2mipiraw_SWNR_0249,
    gc05a2mipiraw_SWNR_0250, gc05a2mipiraw_SWNR_0251, gc05a2mipiraw_SWNR_0252, gc05a2mipiraw_SWNR_0253, gc05a2mipiraw_SWNR_0254, gc05a2mipiraw_SWNR_0255, gc05a2mipiraw_SWNR_0256, gc05a2mipiraw_SWNR_0257, gc05a2mipiraw_SWNR_0258, gc05a2mipiraw_SWNR_0259,
    gc05a2mipiraw_SWNR_0260, gc05a2mipiraw_SWNR_0261, gc05a2mipiraw_SWNR_0262, gc05a2mipiraw_SWNR_0263, gc05a2mipiraw_SWNR_0264, gc05a2mipiraw_SWNR_0265, gc05a2mipiraw_SWNR_0266, gc05a2mipiraw_SWNR_0267, gc05a2mipiraw_SWNR_0268, gc05a2mipiraw_SWNR_0269,
    gc05a2mipiraw_SWNR_0270, gc05a2mipiraw_SWNR_0271, gc05a2mipiraw_SWNR_0272, gc05a2mipiraw_SWNR_0273, gc05a2mipiraw_SWNR_0274, gc05a2mipiraw_SWNR_0275, gc05a2mipiraw_SWNR_0276, gc05a2mipiraw_SWNR_0277, gc05a2mipiraw_SWNR_0278, gc05a2mipiraw_SWNR_0279,
    gc05a2mipiraw_SWNR_0280, gc05a2mipiraw_SWNR_0281, gc05a2mipiraw_SWNR_0282, gc05a2mipiraw_SWNR_0283, gc05a2mipiraw_SWNR_0284, gc05a2mipiraw_SWNR_0285, gc05a2mipiraw_SWNR_0286, gc05a2mipiraw_SWNR_0287, gc05a2mipiraw_SWNR_0288, gc05a2mipiraw_SWNR_0289,
    gc05a2mipiraw_SWNR_0290, gc05a2mipiraw_SWNR_0291, gc05a2mipiraw_SWNR_0292, gc05a2mipiraw_SWNR_0293, gc05a2mipiraw_SWNR_0294, gc05a2mipiraw_SWNR_0295, gc05a2mipiraw_SWNR_0296, gc05a2mipiraw_SWNR_0297, gc05a2mipiraw_SWNR_0298, gc05a2mipiraw_SWNR_0299,
    gc05a2mipiraw_SWNR_0300, gc05a2mipiraw_SWNR_0301, gc05a2mipiraw_SWNR_0302, gc05a2mipiraw_SWNR_0303, gc05a2mipiraw_SWNR_0304, gc05a2mipiraw_SWNR_0305, gc05a2mipiraw_SWNR_0306, gc05a2mipiraw_SWNR_0307, gc05a2mipiraw_SWNR_0308, gc05a2mipiraw_SWNR_0309,
    gc05a2mipiraw_SWNR_0310, gc05a2mipiraw_SWNR_0311, gc05a2mipiraw_SWNR_0312, gc05a2mipiraw_SWNR_0313, gc05a2mipiraw_SWNR_0314, gc05a2mipiraw_SWNR_0315, gc05a2mipiraw_SWNR_0316, gc05a2mipiraw_SWNR_0317, gc05a2mipiraw_SWNR_0318, gc05a2mipiraw_SWNR_0319,
    gc05a2mipiraw_SWNR_0320, gc05a2mipiraw_SWNR_0321, gc05a2mipiraw_SWNR_0322, gc05a2mipiraw_SWNR_0323, gc05a2mipiraw_SWNR_0324, gc05a2mipiraw_SWNR_0325, gc05a2mipiraw_SWNR_0326, gc05a2mipiraw_SWNR_0327, gc05a2mipiraw_SWNR_0328, gc05a2mipiraw_SWNR_0329,
    gc05a2mipiraw_SWNR_0330, gc05a2mipiraw_SWNR_0331, gc05a2mipiraw_SWNR_0332, gc05a2mipiraw_SWNR_0333, gc05a2mipiraw_SWNR_0334, gc05a2mipiraw_SWNR_0335, gc05a2mipiraw_SWNR_0336, gc05a2mipiraw_SWNR_0337, gc05a2mipiraw_SWNR_0338, gc05a2mipiraw_SWNR_0339,
    gc05a2mipiraw_SWNR_0340, gc05a2mipiraw_SWNR_0341, gc05a2mipiraw_SWNR_0342, gc05a2mipiraw_SWNR_0343, gc05a2mipiraw_SWNR_0344, gc05a2mipiraw_SWNR_0345, gc05a2mipiraw_SWNR_0346, gc05a2mipiraw_SWNR_0347, gc05a2mipiraw_SWNR_0348, gc05a2mipiraw_SWNR_0349,
    gc05a2mipiraw_SWNR_0350, gc05a2mipiraw_SWNR_0351, gc05a2mipiraw_SWNR_0352, gc05a2mipiraw_SWNR_0353, gc05a2mipiraw_SWNR_0354, gc05a2mipiraw_SWNR_0355, gc05a2mipiraw_SWNR_0356, gc05a2mipiraw_SWNR_0357, gc05a2mipiraw_SWNR_0358, gc05a2mipiraw_SWNR_0359,
    gc05a2mipiraw_SWNR_0360, gc05a2mipiraw_SWNR_0361, gc05a2mipiraw_SWNR_0362, gc05a2mipiraw_SWNR_0363, gc05a2mipiraw_SWNR_0364, gc05a2mipiraw_SWNR_0365, gc05a2mipiraw_SWNR_0366, gc05a2mipiraw_SWNR_0367, gc05a2mipiraw_SWNR_0368, gc05a2mipiraw_SWNR_0369,
    gc05a2mipiraw_SWNR_0370, gc05a2mipiraw_SWNR_0371, gc05a2mipiraw_SWNR_0372, gc05a2mipiraw_SWNR_0373, gc05a2mipiraw_SWNR_0374, gc05a2mipiraw_SWNR_0375, gc05a2mipiraw_SWNR_0376, gc05a2mipiraw_SWNR_0377, gc05a2mipiraw_SWNR_0378, gc05a2mipiraw_SWNR_0379,
    gc05a2mipiraw_SWNR_0380, gc05a2mipiraw_SWNR_0381, gc05a2mipiraw_SWNR_0382, gc05a2mipiraw_SWNR_0383, gc05a2mipiraw_SWNR_0384, gc05a2mipiraw_SWNR_0385, gc05a2mipiraw_SWNR_0386, gc05a2mipiraw_SWNR_0387, gc05a2mipiraw_SWNR_0388, gc05a2mipiraw_SWNR_0389,
    gc05a2mipiraw_SWNR_0390, gc05a2mipiraw_SWNR_0391, gc05a2mipiraw_SWNR_0392, gc05a2mipiraw_SWNR_0393, gc05a2mipiraw_SWNR_0394, gc05a2mipiraw_SWNR_0395, gc05a2mipiraw_SWNR_0396, gc05a2mipiraw_SWNR_0397, gc05a2mipiraw_SWNR_0398, gc05a2mipiraw_SWNR_0399,
},
.CA_LTM = {
    gc05a2mipiraw_CA_LTM_0000, gc05a2mipiraw_CA_LTM_0001, gc05a2mipiraw_CA_LTM_0002, gc05a2mipiraw_CA_LTM_0003, gc05a2mipiraw_CA_LTM_0004, gc05a2mipiraw_CA_LTM_0005, gc05a2mipiraw_CA_LTM_0006, gc05a2mipiraw_CA_LTM_0007, gc05a2mipiraw_CA_LTM_0008, gc05a2mipiraw_CA_LTM_0009,
    gc05a2mipiraw_CA_LTM_0010, gc05a2mipiraw_CA_LTM_0011, gc05a2mipiraw_CA_LTM_0012, gc05a2mipiraw_CA_LTM_0013, gc05a2mipiraw_CA_LTM_0014, gc05a2mipiraw_CA_LTM_0015, gc05a2mipiraw_CA_LTM_0016, gc05a2mipiraw_CA_LTM_0017, gc05a2mipiraw_CA_LTM_0018, gc05a2mipiraw_CA_LTM_0019,
    gc05a2mipiraw_CA_LTM_0020, gc05a2mipiraw_CA_LTM_0021, gc05a2mipiraw_CA_LTM_0022, gc05a2mipiraw_CA_LTM_0023, gc05a2mipiraw_CA_LTM_0024, gc05a2mipiraw_CA_LTM_0025, gc05a2mipiraw_CA_LTM_0026, gc05a2mipiraw_CA_LTM_0027, gc05a2mipiraw_CA_LTM_0028, gc05a2mipiraw_CA_LTM_0029,
},
.ClearZoom = {
    gc05a2mipiraw_ClearZoom_0000, gc05a2mipiraw_ClearZoom_0001, gc05a2mipiraw_ClearZoom_0002, gc05a2mipiraw_ClearZoom_0003, gc05a2mipiraw_ClearZoom_0004, gc05a2mipiraw_ClearZoom_0005, gc05a2mipiraw_ClearZoom_0006,
},
.SWNR_THRES = {
    gc05a2mipiraw_SWNR_THRES_0000, gc05a2mipiraw_SWNR_THRES_0001, gc05a2mipiraw_SWNR_THRES_0002, gc05a2mipiraw_SWNR_THRES_0003, gc05a2mipiraw_SWNR_THRES_0004, gc05a2mipiraw_SWNR_THRES_0005, gc05a2mipiraw_SWNR_THRES_0006, gc05a2mipiraw_SWNR_THRES_0007, gc05a2mipiraw_SWNR_THRES_0008, gc05a2mipiraw_SWNR_THRES_0009,
    gc05a2mipiraw_SWNR_THRES_0010, gc05a2mipiraw_SWNR_THRES_0011, gc05a2mipiraw_SWNR_THRES_0012, gc05a2mipiraw_SWNR_THRES_0013, gc05a2mipiraw_SWNR_THRES_0014, gc05a2mipiraw_SWNR_THRES_0015, gc05a2mipiraw_SWNR_THRES_0016, gc05a2mipiraw_SWNR_THRES_0017, gc05a2mipiraw_SWNR_THRES_0018, gc05a2mipiraw_SWNR_THRES_0019,
},
