/******************************************************************************
 ** Copyright (c)
 ** File Name:      sensor_BF2557.c                                           *
 ** Author:                                                       *
 ** DATE:                                                             *
 ** Description:   This file contains driver for sensor BF2557.
 **
 ******************************************************************************

 ******************************************************************************
 **                        Edit History                                       *
 ** ------------------------------------------------------------------------- *
 ** DATE           NAME             DESCRIPTION                               *
 **
 ******************************************************************************/

/**---------------------------------------------------------------------------*
 **                         Dependencies                                      *
 **---------------------------------------------------------------------------*/
#include "ms_customize_trc.h"
#include "sensor_cfg.h"
#include "sensor_drv.h"
#include "os_api.h"
#include "chip.h"
#include "dal_dcamera.h"
#include "gpio_prod_api.h"
#include "bf2557/sensor_bf2557_raw_param_main.c"
#include "cmr_types.h"

/**---------------------------------------------------------------------------*
 **                     Extern Function Declaration                           *
 **---------------------------------------------------------------------------*/

/**---------------------------------------------------------------------------*
 **                         Const variables                                   *
 **---------------------------------------------------------------------------*/

/**---------------------------------------------------------------------------*
 **                            Macro Define
 **---------------------------------------------------------------------------*/
#define BF2557_I2C_ADDR_W 0x7c
#define BF2557_I2C_ADDR_R 0x7d

#define SENSOR_GAIN_SCALE 16

#define BF2557_PID_VALUE 0x25
#define BF2557_PID_ADDR 0xfc
#define BF2557_VER_VALUE 0x57
#define BF2557_VER_ADDR 0xfd

#define SENSOR_REG_ADDR_8BIT 1
#define SENSOR_REG_ADDR_16BIT 0
#define SENSOR_REG_VALUE_8BIT 0
#define SENSOR_REG_VALUE_16BIT 1

#define PREVIEW_WIDTH 1296
#define PREVIEW_HEIGHT 972
#define SNAPSHOT_WIDTH 2592
#define SNAPSHOT_HEIGHT 1944
#define XCLK 24

#define LANE_NUM 2  /// for new setting///2
#define RAW_BITS 10 // for new setting//8//or 10, need check

#define BF2557_MIRROR_NORMAL 0
#define BF2557_MIRROR_H 0
#define BF2557_MIRROR_V 0
#define BF2557_MIRROR_HV 1

#if BF2557_MIRROR_NORMAL
#define BF2557_MIRROR 0x00
#elif BF2557_MIRROR_H
#define BF2557_MIRROR 0x02
#elif BF2557_MIRROR_V
#define BF2557_MIRROR 0x01
#elif BF2557_MIRROR_HV
#define BF2557_MIRROR 0x03
#else
#define BF2557_MIRROR 0x00
#endif

// preview setting @ 1296x972
/*
;;1296x972, 1280x960
@@mirror off and flip off
20 3820 83
20 373d 24
20 450b 03

@@mirror on and flip off
20 3820 8b
20 373d 24
20 450b 03

@@mirror off and flip on
20 3820 b3
20 373d 26
20 450b 20

@@mirror on and flip on
20 3820 bb
20 373d 26
20 450b 20
*/

/**---------------------------------------------------------------------------*
 **                     Local Function Prototypes                             *
 **---------------------------------------------------------------------------*/
LOCAL uint32 bf2557_Identify(uint32 param);
LOCAL uint32 bf2557_PowerOnOff(uint32 param);
PUBLIC SENSOR_TRIM_T_PTR BF2557_get_resolutions_trim_tab(void);
LOCAL uint32 ext_func(uint32 param);
static cmr_int bf2557_drv_write_gain_value(cmr_uint param);
static void bf2557_drv_write_exposure(cmr_uint *param);
/**---------------------------------------------------------------------------*
 **                         Local Variables                                  *
 **---------------------------------------------------------------------------*/

LOCAL SENSOR_EX_INFO_T s_bf2557_ex_info;

/****sharkle new setting,change mipi clock,line_time,frame_length etc****/
static const SENSOR_REG_T bf2557_init_setting[] __attribute__((aligned(4))) = {
    // Sensor Information////////////////////////////
    // Sensor         : BF2557
    // Date           : 2024-01-19
    // MCLK           : 24MHz
    // MIPI           : 2 Lane
    // BLC offset     : 64code
    ////////////////////////////////////////////////
    {0xf0, 0x01},
    {SENSOR_WRITE_DELAY, 20},
    {0xf2, BF2557_MIRROR},
    {0x02, 0xae},
    {0x12, 0x3e},
    {0x1f, 0x66},
    {0x20, 0x82},
    {0x24, 0x1e},
    {0x26, 0x37},
    {0x2a, 0x01},
    {0x2d, 0x3a},
    {0x2f, 0xe8},
    {0x32, 0x23},
    {0x36, 0x98},
    {0x37, 0xb5},
    {0x3a, 0xdd}, // 512Mbps
    {0x62, 0x5e},
    {0xe1, 0xf7},
    {0xe2, 0x22},
    {0xe4, 0x02},
    {0xe8, 0x10},
    {0xe9, 0x04},
    {0xec, 0x80},

    {0xea, 0x16},
    {0xeb, 0x80}, // d5    // MIPI speed(Mbps) : 852Mbps x 2Lane  //0xeb, 0xd5; 512Mbps x 2Lane  //0xeb, 0x80
    {0xe7, 0x47},

    {0x0b, 0x86},
    {0x07, 0x07},
    {0x06, 0xee},

    {0x57, 0x40},
    {0x58, 0x40},
    {0x59, 0x40},
    {0x5a, 0x40},

    {0x00, 0x10},
    {0xa0, 0x01},
    {0xe6, 0x02},

    {0xca, 0xa0},
    {0xcb, 0x70},
    {0xcc, 0x04},
    {0xcd, 0x24},
    {0xce, 0x04},
    {0xcf, 0x9c},

    {0x70, 0x08},
    {0x71, 0x07},
    {0x72, 0x16},
    {0x73, 0x09},
    {0x74, 0x08},
    {0x75, 0x06},
    {0x76, 0x30},
    {0x77, 0x02},
    {0x78, 0x10},
    {0x79, 0x0a},

    {0x6a, 0x7f},
    {0x6b, 0x12},
    {0x6c, 0x01},
};
// clk = 453Mhz ,mipi_speed = 906Mbps
static const SENSOR_REG_T bf2557_preview_setting[] __attribute__((aligned(4))) = {
    // Sensor Information////////////////////////////
    // Sensor           : BF2557
    // Date             : 2024-01-19
    // Image size       : 1296 x 972
    // MCLK/PCLK        : 24MHz /88.0Mhz
    // MIPI speed(Mbps) : 220Mbps x 2Lane
    // Line Length      : 2828
    // Frame Length     : 1037
    // line Time        : 32136ns
    // Max Fps          : 30.00fps
    // BLC offset       : 64code
    ////////////////////////////////////////////////
    {0xea, 0x16},
    {0xeb, 0x6e},
    {0xe7, 0xc7},
    {0x3a, 0xe1},

    {0x0b, 0x86},
    {0x07, 0x07},
    {0x06, 0xee},

    {0x00, 0x18},
    {0xa0, 0x01},
    {0xe6, 0x0a},

    {0xca, 0x50},
    {0xcb, 0x30},
    {0xcc, 0x02},
    {0xcd, 0x12},
    {0xce, 0x02},
    {0xcf, 0xce},

    {0x70, 0x02},
    {0x71, 0x02},
    {0x72, 0x04},
    {0x73, 0x08},
    {0x74, 0x02},
    {0x75, 0x02},
    {0x76, 0x08},
    {0x77, 0x01},
    {0x78, 0x0a},
    {0x79, 0x02},
};

static const SENSOR_REG_T bf2557_snapshot_setting[] __attribute__((aligned(4))) = {
    // Sensor Information////////////////////////////
    // Sensor           : BF2557
    // Date             : 2024-01-19
    // Image size       : 2592 x 1944
    // MCLK/PCLK        : 24MHz /170.4Mhz
    // MIPI speed(Mbps) : 852Mbps x 2Lane  //0xeb, 0xd5
    // MIPI speed(Mbps) : 512Mbps x 2Lane  //0xeb, 0x80
    // Line Length      : 2828
    // Frame Length     : 2008
    // line Time        : 16596ns
    // Max Fps          : 30.00fps
    // BLC offset       : 64code
    ////////////////////////////////////////////////
    {0xea, 0x16},
    {0xeb, 0x80}, /// d5  512M
    {0xe7, 0x47},
    {0x3a, 0xdd}, // 512Mbps

    {0x0b, 0x86},
    {0x07, 0x07},
    {0x06, 0xee},

    {0x00, 0x10},
    {0xa0, 0x01},
    {0xe6, 0x02},

    {0xca, 0xa0},
    {0xcb, 0x70},
    {0xcc, 0x04},
    {0xcd, 0x24},
    {0xce, 0x04},
    {0xcf, 0x9c},

    {0x70, 0x08},
    {0x71, 0x07},
    {0x72, 0x16},
    {0x73, 0x09},
    {0x74, 0x08},
    {0x75, 0x06},
    {0x76, 0x30},
    {0x77, 0x02},
    {0x78, 0x10},
    {0x79, 0x0a},
};

LOCAL SENSOR_REG_TAB_INFO_T s_BF2557_resolution_Tab_YUV[] =
    {
        // COMMON_INIT
        {ADDR_AND_LEN_OF_ARRAY(bf2557_init_setting), SNAPSHOT_WIDTH, SNAPSHOT_HEIGHT, XCLK, SENSOR_IMAGE_FORMAT_RAW},
        // SENSOR_MODE_PREVIEW_ONE
        {ADDR_AND_LEN_OF_ARRAY(bf2557_preview_setting), PREVIEW_WIDTH, PREVIEW_HEIGHT, XCLK, SENSOR_IMAGE_FORMAT_RAW},
        // SENSOR_MODE_SNAPSHOT_ONE_FIRST
        {ADDR_AND_LEN_OF_ARRAY(bf2557_snapshot_setting), SNAPSHOT_WIDTH, SNAPSHOT_HEIGHT, XCLK, SENSOR_IMAGE_FORMAT_RAW},
        {PNULL, 0, 0, 0, 0, 0}, // SNAPSHOT_ONE_SECOND
        {PNULL, 0, 0, 0, 0, 0}, // SNAPSHOT_ONE_THIRD
        {PNULL, 0, 0, 0, 0, 0}, // PREVIEW_TWO
        {PNULL, 0, 0, 0, 0, 0}, // SNAPSHOT_TWO_FIRST
        {PNULL, 0, 0, 0, 0, 0}, // SNAPSHOT_TWO_SECOND
        {PNULL, 0, 0, 0, 0, 0}, // SNAPSHOT_TWO_THIRD
};

LOCAL SENSOR_IOCTL_FUNC_TAB_T s_BF2557_ioctl_func_tab =
    {
        .power = bf2557_PowerOnOff,
        .identify = bf2557_Identify,
        .get_trim = BF2557_get_resolutions_trim_tab,
        .ext_func = ext_func,
        .write_ae_value = bf2557_drv_write_exposure,
        .write_gain_value = bf2557_drv_write_gain_value,
};

/**---------------------------------------------------------------------------*
 **                         Global Variables                                  *
 **---------------------------------------------------------------------------*/
PUBLIC const SENSOR_INFO_T g_bf2557_mipi_raw_info =
    {
        .salve_i2c_addr_w = BF2557_I2C_ADDR_W,                                                  // salve i2c write address
        .salve_i2c_addr_r = BF2557_I2C_ADDR_R,                                                  // salve i2c read address
        .reg_addr_value_bits = SENSOR_I2C_REG_8BIT | SENSOR_I2C_VAL_8BIT | SENSOR_I2C_FREQ_400, // bit0: (0: i2c register value is 8 bit, 1: 16 bits). bit2: (0: i2c register addr  is 8 bit, 1: 16 bit) other bit: reseved
                                                                                                // bit0: 0:negative; 1:positive -> polarily of pixel clock
                                                                                                // bit2: 0:negative; 1:positive -> polarily of horizontal synchronization signal
                                                                                                // bit4: 0:negative; 1:positive -> polarily of vertical synchronization signal
                                                                                                // other bit: reseved
        .hw_signal_polarity = SENSOR_HW_SIGNAL_PCLK_P |
                              SENSOR_HW_SIGNAL_VSYNC_P |
                              SENSOR_HW_SIGNAL_HSYNC_P,
        // preview mode
        .environment_mode = SENSOR_ENVIROMENT_NORMAL |
                            SENSOR_ENVIROMENT_NIGHT,
        // image effect
        .image_effect = SENSOR_IMAGE_EFFECT_NORMAL |
                        SENSOR_IMAGE_EFFECT_BLACKWHITE |
                        SENSOR_IMAGE_EFFECT_RED |
                        SENSOR_IMAGE_EFFECT_GREEN |
                        SENSOR_IMAGE_EFFECT_BLUE |
                        SENSOR_IMAGE_EFFECT_YELLOW |
                        SENSOR_IMAGE_EFFECT_NEGATIVE |
                        SENSOR_IMAGE_EFFECT_CANVAS,
        // while balance mode
        .wb_mode = 0,
        .step_count = 7,                                        // bit[0:7]: count of step in brightness, contrast, sharpness, saturation, bit[8:31] reseved
        .reset_pulse_level = SENSOR_LOW_PULSE_RESET,            // reset pulse level
        .reset_pulse_width = 50,                                // reset pulse width(ms)
        .power_down_level = SENSOR_LOW_LEVEL_PWDN,              // 1: high level valid; 0: low level valid
        .identify_count = 2,                                    // count of identify code //prabhjot: in SP, it is 1
        .identify_code = {{BF2557_PID_ADDR, BF2557_PID_VALUE},  // supply two code to identify sensor.
                          {BF2557_VER_ADDR, BF2557_VER_VALUE}}, // for Example: index = 0-> Device id, index = 1 -> version id
        .avdd_val = SENSOR_AVDD_2800MV,                         // voltage of avdd
        .source_width_max = SNAPSHOT_WIDTH,                     // max width of source image
        .source_height_max = SNAPSHOT_HEIGHT,                   // max height of source image
        .name = "BF2557",                                       // name of sensor
        .image_format = SENSOR_IMAGE_FORMAT_RAW,                // SENSOR_IMAGE_FORMAT_YUV422,			// define in SENSOR_IMAGE_FORMAT_E enum, if set to SENSOR_IMAGE_FORMAT_MAX here, image format depent on SENSOR_REG_TAB_INFO_T
        .image_pattern = SENSOR_IMAGE_PATTERN_RAWRGB_R,         // SENSOR_IMAGE_PATTERN_YUV422_YUYV,   	// pattern of input image form sensor;
        .resolution_tab_info_ptr = s_BF2557_resolution_Tab_YUV, // point to resolution table information structure
        .ioctl_func_tab_ptr = &s_BF2557_ioctl_func_tab,         // point to ioctl function table
        .raw_info_ptr = &s_bf2557_mipi_raw_info,                // information and table about Rawrgb sensor
        .ext_info_ptr = PNULL,                                  // extend information about sensor
        .iovdd_val = SENSOR_AVDD_1800MV,                        // iovdd
        .dvdd_val = SENSOR_AVDD_1800MV,                         // dvdd
        .preview_skip_num = 1,                                  // prabhjot: need tune later, in SP it is 1
        .capture_skip_num = 1,                                  // prabhjot: need tune later, in SP it is 1
        .preview_deci_num = 0,
        .video_preview_deci_num = 0,
        .threshold_eb = 0,
        .threshold_mode = 0,
        .threshold_start = 0,
        .threshold_end = 0,
        .sensor_interface = {SENSOR_INTERFACE_TYPE_CSI2, LANE_NUM, RAW_BITS, 0},
        .output_mode = 0,
        .output_endian = 0,
        .i2c_port_select = 0};

LOCAL SENSOR_TRIM_T s_BF2557_resolution_trim_tab[] =
    {
                // COMMON INIT
        {0, 0, SNAPSHOT_WIDTH, SNAPSHOT_HEIGHT, 27617, 2008, XCLK, 512},
        //{x, y, w, h, line_time, frame_line, pclk, bps_per_lane}
        // SENSOR_MODE_PREVIEW_ONE
        {0, 0, PREVIEW_WIDTH, PREVIEW_HEIGHT, 32136, 1037, XCLK, 220},
        // SENSOR_MODE_SNAPSHOT_ONE_FIRST
        {0, 0, SNAPSHOT_WIDTH, SNAPSHOT_HEIGHT, 27617, 2008, XCLK, 512},

        {0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0, 0},
};

LOCAL SENSOR_STATIC_INFO_T s_bf2557_static_info[] =
    {
        {
            200,                       // uint32	f_num;
            354,                       // uint32	focal_lenth;
            30,                        // uint32	max_fps;
            16,                        // uint32	max_adgain;
            0,                         // uint32	ois_supported;
            0,                         // uint32	pdaf_supported;
            0,                         // uint32	embedded_line_enable; not in SP
            1,                         // uint32	exp_valid_frame_num;
            64,                        // uint32	clamp_level;
            1,                         // uint32	adgain_valid_frame_num;
            0,                         // float	fov_angle;
            {{4.614f, 3.444f}, 4.222f} // struct	module_fov_info fov_info;
        }};
/**---------------------------------------------------------------------------*
 **                             Function  Definitions
 **---------------------------------------------------------------------------*/
PUBLIC SENSOR_TRIM_T_PTR BF2557_get_resolutions_trim_tab(void)
{
    return s_BF2557_resolution_trim_tab;
}

LOCAL void BF2557_WriteReg(uint16 subaddr, uint16 data)
{

#ifndef _USE_DSP_I2C_
    Sensor_WriteReg(subaddr, data);
#else
    DSENSOR_IICWrite((uint16)subaddr, (uint16)data);
#endif

    // SCI_TRACE_LOW:"SENSOR: BF2557_WriteReg reg/value(%x,%x) !!"
    SCI_TRACE_ID(TRACE_TOOL_CONVERT, SENSOR_WRITEREG_690_112_2_18_0_30_46_779, (uint8 *)"dd", __FUNCTION__, subaddr, data);
}

LOCAL uint8 BF2557_ReadReg(uint16 subaddr)
{
    uint8 value = 0;

#ifdef WIN32
    if (subaddr == BF2557_VER_ADDR)
        return BF2557_VER_VALUE;
    if (subaddr == BF2557_PID_ADDR)
        return BF2557_PID_VALUE;
#endif

#ifndef _USE_DSP_I2C_
    value = Sensor_ReadReg(subaddr);
#else
    value = (uint16)DSENSOR_IICRead((uint16)subaddr);
#endif

    // SCI_TRACE_LOW:"SENSOR: BF2557_ReadReg reg/value(%x,%x) !!"
    SCI_TRACE_ID(TRACE_TOOL_CONVERT, SENSOR_READREG_706_112_2_18_0_30_46_780, (uint8 *)"dd", __FUNCTION__, subaddr, value);

    return value;
}

LOCAL uint32 bf2557_Identify(uint32 param)
{
    uint32 i;
    uint32 nLoop;
    uint8 ret;
    uint32 err_cnt = 0;
    uint16 reg[2] = {BF2557_VER_ADDR, BF2557_PID_ADDR};
    uint8 value[2] = {BF2557_VER_VALUE, BF2557_PID_VALUE};

    SCI_TRACE_LOW("BF2557_Identify");
    // SCI_TRACE_ID(TRACE_TOOL_CONVERT,SENSOR_BF2557_725_112_2_18_0_30_46_781,(uint8*)"");
    for (i = 0; i < 2;)
    {
        nLoop = 1000;
        ret = BF2557_ReadReg(reg[i]);
        if (ret != value[i])
        {
            err_cnt++;
            if (err_cnt > 3)
            {
                SCI_TRACE_LOW("It is not BF2557");
                // SCI_TRACE_ID(TRACE_TOOL_CONVERT,SENSOR_BF2557_735_112_2_18_0_30_46_782,(uint8*)"");
                // return SCI_ERROR;
            }
            else
            {
                // Masked by frank.yang,SCI_Sleep() will cause a  Assert when called in boot precedure
                // SCI_Sleep(10);
                while (nLoop--)
                {
                    ;
                }
                continue;
            }
        }
        err_cnt = 0;
        i++;
    }

    SCI_TRACE_LOW("BF2557_Identify: it is BF2557");
    // SCI_TRACE_ID(TRACE_TOOL_CONVERT,SENSOR_BF2557_753_112_2_18_0_30_46_783,(uint8*)"");

    return (uint32)SCI_SUCCESS;
}

PUBLIC uint32 bf2557_PowerOnOff(uint32 param)
{
    uint32 power_down = g_bf2557_mipi_raw_info.power_down_level;
    uint16 reset_level = g_bf2557_mipi_raw_info.reset_pulse_level;

    SENSOR_AVDD_VAL_E dvdd_val = g_bf2557_mipi_raw_info.dvdd_val;
    SENSOR_AVDD_VAL_E avdd_val = g_bf2557_mipi_raw_info.avdd_val;
    SENSOR_AVDD_VAL_E iovdd_val = g_bf2557_mipi_raw_info.iovdd_val;
    if (1 == param)
    {
        // Sensor_SetResetLevel(reset_level);
        Sensor_PowerDown(power_down); // gpio 47
        Sensor_SetResetLevel(reset_level);
        Sensor_SetMCLK(SENSOR_DISABLE_MCLK);
        Sensor_SetVoltage(SENSOR_AVDD_CLOSED, SENSOR_AVDD_CLOSED, SENSOR_AVDD_CLOSED);

        SCI_Sleep(20);

        // Sensor_PowerDown(!power_down);
        // Sensor_SetVoltage(SENSOR_AVDD_CLOSED, SENSOR_AVDD_CLOSED, g_bf2557_mipi_raw_info.iovdd_val);
        //	SCI_Sleep(5);
        // Sensor_SetVoltage(g_bf2557_mipi_raw_info.dvdd_val, SENSOR_AVDD_CLOSED, SENSOR_AVDD_CLOSED);
        // SCI_Sleep(5);
        Sensor_SetVoltage(g_bf2557_mipi_raw_info.dvdd_val, g_bf2557_mipi_raw_info.avdd_val, g_bf2557_mipi_raw_info.iovdd_val);
        SCI_Sleep(25);
        Sensor_SetMCLK(SENSOR_DEFALUT_MCLK);
        SCI_Sleep(10);
        Sensor_PowerDown(!power_down);
        SCI_Sleep(5);
        Sensor_SetResetLevel(!reset_level);
        SCI_Sleep(6);
        // while(1);
    }
    else
    {
        Sensor_PowerDown(power_down);
        SCI_Sleep(5);
        Sensor_SetResetLevel(reset_level);
        Sensor_SetMCLK(SENSOR_DISABLE_MCLK);
        SCI_Sleep(6);

        Sensor_SetVoltage(SENSOR_AVDD_CLOSED, SENSOR_AVDD_CLOSED, SENSOR_AVDD_CLOSED);
    }

    SCI_TraceLow("BF2557_PowerOnOff param:%d \n", param);

    return 0;
}

LOCAL SENSOR_EX_INFO_T_PTR bf2557_drv_get_static_info()
{
    SENSOR_EX_INFO_T_PTR ex_info = &s_bf2557_ex_info;

    ex_info->f_num = s_bf2557_static_info->f_num;
    ex_info->focal_length = s_bf2557_static_info->focal_length;
    ex_info->max_fps = s_bf2557_static_info->max_fps;
    ex_info->max_adgain = s_bf2557_static_info->max_adgain;
    ex_info->ois_supported = s_bf2557_static_info->ois_supported;
    ex_info->pdaf_supported = s_bf2557_static_info->pdaf_supported;
    ex_info->embedded_line_enable = s_bf2557_static_info->embedded_line_enable;
    ex_info->exp_valid_frame_num = s_bf2557_static_info->exp_valid_frame_num;
    ex_info->clamp_level = s_bf2557_static_info->clamp_level;
    ex_info->adgain_valid_frame_num = s_bf2557_static_info->adgain_valid_frame_num;
    ex_info->preview_skip_num = g_bf2557_mipi_raw_info.preview_skip_num;
    ex_info->capture_skip_num = g_bf2557_mipi_raw_info.capture_skip_num;
    ex_info->name = (int8 *)g_bf2557_mipi_raw_info.name;
    ex_info->pos_dis.up2hori = 0;
    ex_info->pos_dis.hori2down = 0;

    return ex_info;
}

LOCAL uint32 ext_func(uint32 param)
{
    SENSOR_EXT_FUNC_CMD_E func_id = (SENSOR_EXT_FUNC_CMD_E)param;

    SCI_TRACE_LOW("BF2557 ext_func param:%d \n", param);

    switch (func_id)
    {
    case SENSOR_EXT_STREAM_ON:
    {
        SCI_TRACE_LOW("BF2557 SENSOR_EXT_STREAM_ON \n");
        SCI_Sleep(100);
        BF2557_WriteReg(0x01, 0x4a);
        BF2557_WriteReg(0xf1, 0x00);
        BF2557_WriteReg(0x01, 0x42);
        SCI_Sleep(1);
        break;
    }
    case SENSOR_EXT_STREAM_OFF:
    {
        SCI_Sleep(1);
        BF2557_WriteReg(0xf1, 0x01);
        SCI_Sleep(2);
        SCI_TRACE_LOW("BF2557 SENSOR_EXT_STREAM_OFF \n");
        break;
    }
    case SENSOR_EXT_GET_STATIC_INFO:
    {
        return (uint32)bf2557_drv_get_static_info();
    }
    default:
        break;
    }
    return 0;
}
// TODO:
// set mirror
//  set brightness
//  set EV
//  set anti-flicker
//  set sensor mode
//  set awb
//  set contrast
//  set image effect
//  set flash
#define ISP_BASE_GAIN 0x80

#define SENSOR_MAX_GAIN 0x400 * 16
#define SENSOR_BASE_GAIN 0x400
#define SENSOR_MIN_SHUTTER 4
#define BF2557_PREVIEW_FRAME_LENGTH 2000
#define I2C_SLAVE_ADDR 0x20 /* 8bit slave address*/
#define FRAME_OFFSET 4
#define SENSOR_IC_CHECK_PTR_VOID(a) \
    do                              \
    {                               \
        if (!a)                     \
            return;                 \
    } while (0)
#define ARRAY_SIZE(a) (sizeof(a) / sizeof(a[0]))

static SENSOR_REG_T bf2557_shutter_reg[] = {
    {0x6b, 0x12},
    {0x6c, 0x01},
};

static struct sensor_i2c_reg_tab bf2557_shutter_tab = {
    .settings = bf2557_shutter_reg,
    .size = ARRAY_SIZE(bf2557_shutter_reg),
};

static SENSOR_REG_T bf2557_again_reg[] = {
    {0x6a, 0x2f},
};

static struct sensor_i2c_reg_tab bf2557_again_tab = {
    .settings = bf2557_again_reg,
    .size = ARRAY_SIZE(bf2557_again_reg),
};

static SENSOR_REG_T bf2557_dgain_reg[] = {

};

static struct sensor_i2c_reg_tab bf2557_dgain_tab = {
    .settings = bf2557_dgain_reg,
    .size = ARRAY_SIZE(bf2557_dgain_reg),
};

static SENSOR_REG_T bf2557_frame_length_reg[] = {
    //{0x07, 0x00},
    //{0x06, 0x2a},
};

static struct sensor_i2c_reg_tab bf2557_frame_length_tab = {
    .settings = bf2557_frame_length_reg,
    .size = ARRAY_SIZE(bf2557_frame_length_reg),
};

static struct sensor_aec_i2c_tag bf2557_aec_info = {
    .slave_addr = (I2C_SLAVE_ADDR >> 1),
    .addr_bits_type = SENSOR_I2C_REG_8BIT,
    .data_bits_type = SENSOR_I2C_VAL_8BIT,
    .shutter = &bf2557_shutter_tab,
    .again = &bf2557_again_tab,
    .dgain = &bf2557_dgain_tab,
    .frame_length = &bf2557_frame_length_tab,
};

struct sensor_exposure_info
{
    cmr_u32 frame_length;
    cmr_u32 line_time_def;
    cmr_u32 cur_fr_len;
};
struct sensor_exposure_info bf2557pre_exposure_param;
static void bf2557_drv_write_shutter(struct sensor_aec_i2c_tag *aec_info,
                                     cmr_u32 shutter)
{
    SENSOR_IC_CHECK_PTR_VOID(aec_info);
        if (shutter < 2)
        shutter = 2;
    if (shutter > 65518)
        shutter = 65518;


    SCI_TRACE_LOW("bf2557_drv-shutter=%d", shutter);
    if (aec_info->shutter->size)
    {
        aec_info->shutter->settings[0].reg_value = (shutter >> 8) & 0xff;
        aec_info->shutter->settings[1].reg_value = shutter & 0xff;
    }
}

static void bf2557_drv_write_frame_length(struct sensor_aec_i2c_tag *aec_info, cmr_u32 frame_len)
{
    SENSOR_IC_CHECK_PTR_VOID(aec_info);
    if (aec_info->frame_length->size)
    {
        /*TODO*/
        aec_info->frame_length->settings[0].reg_value = (frame_len >> 8) & 0xff;
        aec_info->frame_length->settings[1].reg_value = frame_len & 0xff;
        /*END*/
    }
}

static void bf2557_drv_calc_exposure(cmr_u32 shutter, cmr_u32 dummy_line, cmr_u16 mode,
                                     struct sensor_aec_i2c_tag *aec_info)
{
    cmr_u32 frame_length_def, line_time_def;
    cmr_u32 cur_fr_len, fr_len;
    cmr_u32 dest_fr_len = 0;
    float fps = 0.0;
    cmr_u16 frame_interval = 0x00;

    struct sensor_exposure_info exposure_info;
    SENSOR_IC_CHECK_PTR_VOID(aec_info);

    frame_length_def = s_BF2557_resolution_trim_tab[mode].frame_line;
    line_time_def = s_BF2557_resolution_trim_tab[mode].line_time;
    cur_fr_len = bf2557pre_exposure_param.frame_length;
    fr_len = BF2557_PREVIEW_FRAME_LENGTH;

    dummy_line = dummy_line > FRAME_OFFSET ? dummy_line : FRAME_OFFSET;
    dest_fr_len =
        ((shutter + dummy_line) > fr_len) ? (shutter + dummy_line) : fr_len;
    exposure_info.frame_length = dest_fr_len;

    if (shutter < SENSOR_MIN_SHUTTER)
        shutter = SENSOR_MIN_SHUTTER;

    if (cur_fr_len > shutter)
    {
        fps = 1000000000.0 /
              (cur_fr_len * line_time_def);
    }
    else
    {
        fps = 1000000000.0 / ((shutter + dummy_line) *
                              line_time_def);
    }
    frame_interval = (uint16_t)(((shutter + dummy_line) * line_time_def) / 1000000);

    SCI_TRACE_LOW("bf2557 output mode = %d, shutter = %d, dest_fr_len = %d, frame_interval = %d, line_time_def = %d",
                  mode, shutter, dest_fr_len, frame_interval, line_time_def);

    if ((dest_fr_len != cur_fr_len))
    {
        bf2557_drv_write_frame_length(aec_info, dest_fr_len);
        bf2557pre_exposure_param.frame_length = dest_fr_len;
    }
    bf2557_drv_write_shutter(aec_info, shutter);
    Sensor_SetSensorExifInfo(SENSOR_EXIF_CTRL_EXPOSURETIME, shutter);
}
static void bf2557_drv_write_reg2sensor(struct sensor_i2c_reg_tab *reg_info)
{
    SENSOR_IC_CHECK_PTR_VOID(reg_info);
    for (int i = 0; i < reg_info->size; i++)
    {
        BF2557_WriteReg(reg_info->settings[i].reg_addr, reg_info->settings[i].reg_value);
    }
}

static void bf2557_drv_write_exposure(cmr_uint *param)
{
    cmr_u16 exposure_line = 0x00;
    cmr_u16 dummy_line = 0x00;
    cmr_u16 size_index = 0x00;

    struct sensor_ex_exposure *ex = (struct sensor_ex_exposure *)param;
    SENSOR_IC_CHECK_PTR_VOID(ex);
    exposure_line = ex->exposure;
    dummy_line = ex->dummy;
    size_index = ex->size_index;

    SCI_TRACE_LOW("bf2557 input exposure = %d, dummy_line = %d, size_index = %d",
                  exposure_line, dummy_line, size_index);
    bf2557_drv_calc_exposure(exposure_line, dummy_line, size_index,
                             &bf2557_aec_info);
    bf2557_drv_write_reg2sensor(bf2557_aec_info.frame_length);
    bf2557_drv_write_reg2sensor(bf2557_aec_info.shutter);

    return;
}

static void bf2557_drv_write_gain(struct sensor_aec_i2c_tag *aec_info,
                                  cmr_u32 gain)
{
    cmr_u32 sensor_again = 0;

    SENSOR_IC_CHECK_PTR_VOID(aec_info);

    if (SENSOR_MAX_GAIN < gain)
        gain = SENSOR_MAX_GAIN;
    if (gain < SENSOR_BASE_GAIN) // 0x80
        gain = SENSOR_BASE_GAIN;

    sensor_again = ((gain << 4) / SENSOR_BASE_GAIN) - 1;
    if (aec_info->again->size)
    {
        aec_info->again->settings[0].reg_value = sensor_again & 0xff;
    }

    if (aec_info->dgain->size)
    {

        /*TODO*/

        /*END*/
    }
    SCI_TRACE_LOW("sensor_again:0x%x", sensor_again);
}

static void bf2557_drv_calc_gain(cmr_uint isp_gain, struct sensor_aec_i2c_tag *aec_info)
{
    SENSOR_IC_CHECK_PTR_VOID(isp_gain);
    cmr_u32 sensor_gain = 0;

    sensor_gain = isp_gain < SENSOR_BASE_GAIN ? SENSOR_BASE_GAIN : isp_gain;
    sensor_gain = sensor_gain * SENSOR_BASE_GAIN / ISP_BASE_GAIN;
    if (SENSOR_MAX_GAIN < sensor_gain)
        sensor_gain = SENSOR_MAX_GAIN;
    SCI_TRACE_LOW("isp_gain = 0x%x,sensor_gain=0x%x", (unsigned int)isp_gain, sensor_gain);

    bf2557_drv_write_gain(aec_info, sensor_gain);
}

static cmr_int bf2557_drv_write_gain_value(cmr_uint param)
{
    SCI_TRACE_LOW("bf2557 input gain is %d", param);

    bf2557_drv_calc_gain(param, &bf2557_aec_info);
    bf2557_drv_write_reg2sensor(bf2557_aec_info.again);

    return 0;
}
