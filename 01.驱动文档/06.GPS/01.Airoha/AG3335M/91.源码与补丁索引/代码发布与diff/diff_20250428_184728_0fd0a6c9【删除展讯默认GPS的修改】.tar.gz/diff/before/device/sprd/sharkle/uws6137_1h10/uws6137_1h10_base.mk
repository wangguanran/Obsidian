#
# Copyright 2015 The Android Open-Source Project
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

PLATDIR := device/sprd/sharkle
PLATCOMM := $(PLATDIR)/common
TARGET_BOARD := uws6137_1h10
BOARDDIR := $(PLATDIR)/$(TARGET_BOARD)
ROOTDIR := $(BOARDDIR)/rootdir
TARGET_BOARD_PLATFORM := sp9832e

TARGET_GPU_PLATFORM := midgard
TARGET_NO_BOOTLOADER := false

USE_XML_AUDIO_POLICY_CONF := 1

VOLTE_SERVICE_ENABLE := true

#Config Android Render With CPU; Default Android render with GPU
#GRAPHIC_RENDER_TYPE    := CPU

# graphics
USE_SPRD_HWCOMPOSER  := true

# copy media_profiles.xml before calling device.mk,
# because we want to use our file, not the common one
PRODUCT_COPY_FILES += $(BOARDDIR)/media_profiles.xml:$(TARGET_COPY_OUT_VENDOR)/etc/media_profiles_V1_0.xml \
                      $(BOARDDIR)/media_profiles_turnkey.xml:$(TARGET_COPY_OUT_VENDOR)/etc/media_profiles_turnkey.xml

#$(call inherit-product, $(SRC_TARGET_DIR)/product/core_64_bit.mk)
$(call inherit-product, $(SRC_TARGET_DIR)/product/full_base.mk)
$(call inherit-product, $(PLATCOMM)/DeviceCommon.mk)
$(call inherit-product, $(PLATCOMM)/proprietories.mk)
$(call inherit-product-if-exists, vendor/sprd/modules/libcamera/libcam_device.mk)

BOARD_HAVE_SPRD_WCN_COMBO := sharkle
$(call inherit-product-if-exists, vendor/sprd/modules/wcn/connconfig/device-sprd-wcn.mk)


#fstab
ifeq (f2fs,$(strip $(BOARD_USERDATAIMAGE_FILE_SYSTEM_TYPE)))
  NORMAL_FSTAB_SUFFIX1 := .f2fs
endif
ifeq (true,$(strip $(BOARD_SECURE_BOOT_ENABLE)))
  NORMAL_FSTAB_SUFFIX2 :=
endif
NORMAL_FSTAB_SUFFIX := $(NORMAL_FSTAB_SUFFIX1)$(NORMAL_FSTAB_SUFFIX2)
# $(warning NORMAL_FSTAB=$(LOCAL_PATH)/rootdir/root/fstab$(NORMAL_FSTAB_SUFFIX).$(TARGET_BOARD))
PRODUCT_COPY_FILES += $(BOARDDIR)/rootdir/root/fstab.$(TARGET_BOARD)$(NORMAL_FSTAB_SUFFIX):root/fstab.$(TARGET_BOARD)


PRODUCT_COPY_FILES += \
    $(BOARDDIR)/rootdir/root/init.$(TARGET_BOARD).rc:root/init.$(TARGET_BOARD).rc \
    $(ROOTDIR)/prodnv/PCBA.conf:$(TARGET_COPY_OUT_VENDOR)/etc/PCBA.conf \
    $(ROOTDIR)/prodnv/BBAT.conf:$(TARGET_COPY_OUT_VENDOR)/etc/BBAT.conf \
    $(ROOTDIR)/system/etc/audio_params/tiny_hw.xml:$(TARGET_COPY_OUT_VENDOR)/etc/tiny_hw.xml \
    $(ROOTDIR)/system/etc/audio_params/codec_pga.xml:$(TARGET_COPY_OUT_VENDOR)/etc/codec_pga.xml \
    $(ROOTDIR)/system/etc/audio_params/audio_hw.xml:$(TARGET_COPY_OUT_VENDOR)/etc/audio_hw.xml \
    $(ROOTDIR)/system/etc/audio_params/audio_para:$(TARGET_COPY_OUT_VENDOR)/etc/audio_para \
    $(ROOTDIR)/system/etc/audio_params/smart_amp_init.bin:$(TARGET_COPY_OUT_VENDOR)/etc/smart_amp_init.bin \
    $(ROOTDIR)/system/etc/audio_params/record_tone_1.pcm:$(TARGET_COPY_OUT_VENDOR)/etc/record_tone_1.pcm \
    $(ROOTDIR)/system/etc/audio_params/record_tone_2.pcm:$(TARGET_COPY_OUT_VENDOR)/etc/record_tone_2.pcm \
    $(ROOTDIR)/system/etc/audio_params/rx_data.pcm:$(TARGET_COPY_OUT_VENDOR)/etc/rx_data.pcm \
    $(PLATCOMM)/rootdir/root/ueventd.common.rc:root/ueventd.$(TARGET_BOARD).rc \
    $(PLATCOMM)/rootdir/root/init.common.usb.rc:root/init.$(TARGET_BOARD).usb.rc \
    frameworks/native/data/etc/android.software.midi.xml:system/etc/permissions/android.software.midi.xml \
    frameworks/native/data/etc/android.hardware.camera.flash-autofocus.xml:system/etc/permissions/android.hardware.camera.flash-autofocus.xml \
    frameworks/native/data/etc/android.hardware.camera.front.xml:system/etc/permissions/android.hardware.camera.front.xml \
    frameworks/native/data/etc/android.hardware.opengles.aep.xml:system/etc/permissions/android.hardware.opengles.aep.xml \
    $(BOARDDIR)/log_conf/slog_modem_$(TARGET_BUILD_VARIANT).conf:vendor/etc/slog_modem.conf \
    $(BOARDDIR)/log_conf/slog_modem_cali.conf:vendor/etc/slog_modem_cali.conf \
    $(BOARDDIR)/log_conf/slog_modem_factory.conf:vendor/etc/slog_modem_factory.conf \
    $(BOARDDIR)/log_conf/slog_modem_autotest.conf:vendor/etc/slog_modem_autotest.conf

#WLAN config
PRODUCT_PROPERTY_OVERRIDES += \
    ro.hotspot.enabled = 1 \
    reset_default_http_response = true \
    ro.void_charge_tip = true \
    ro.softaplte.coexist = true \
    ro.vowifi.softap.ee_warning = false \
    persist.sys.wifi.pocketmode = true \
    ro.wcn = enabled

ifeq ($(strip $(BOARD_HAVE_SPRD_WCN_COMBO)), marlin)
PRODUCT_PROPERTY_OVERRIDES += \
    ro.softap.whitelist = true \
    ro.btwifisoftap.coexist = true\
    persist.wifi.func.hidessid = false \
    ro.wifi.softap.maxstanum = 8 \
    ro.wifi.signal.optimized = true \
    ro.support.auto.roam = enabled \
    ro.wifip2p.coexist = true

endif

ifeq ($(strip $(BOARD_HAVE_SPRD_WCN_COMBO)), marlin2)
PRODUCT_PROPERTY_OVERRIDES += \
    ro.softap.whitelist = true \
    ro.btwifisoftap.coexist = true\
    persist.wifi.func.hidessid = true\
    ro.wifi.softap.maxstanum = 8 \
    ro.wifi.signal.optimized = true \
    ro.support.auto.roam = disabled \
    ro.wifip2p.coexist = true

endif

ifeq ($(strip $(BOARD_HAVE_SPRD_WCN_COMBO)), sharkle)
PRODUCT_PROPERTY_OVERRIDES += \
    ro.softap.whitelist = true \
    ro.btwifisoftap.coexist = true\
    persist.wifi.func.hidessid = true\
    ro.wifi.softap.maxstanum = 10 \
    ro.wifi.signal.optimized = true \
    ro.support.auto.roam = disabled \
    ro.wifip2p.coexist = true

endif

ifeq ($(strip $(BOARD_HAVE_SPRD_WCN_COMBO)), rs2351)
PRODUCT_PROPERTY_OVERRIDES += \
    ro.softap.whitelist = false \
    ro.btwifisoftap.coexist = false \
    persist.wifi.func.hidessid = false \
    ro.wifi.softap.maxstanum = 8 \
    ro.wifi.signal.optimized = true \
    ro.support.auto.roam = enabled \
    ro.wifip2p.coexist = false

endif

#copy audio policy config
ifeq ($(USE_XML_AUDIO_POLICY_CONF), 1)
PRODUCT_COPY_FILES += \
    $(ROOTDIR)/system/etc/audio_policy_config/audio_policy_configuration_generic.xml:$(TARGET_COPY_OUT_VENDOR)/etc/audio_policy_configuration.xml \
    $(ROOTDIR)/system/etc/audio_policy_config/primary_audio_policy_configuration.xml:$(TARGET_COPY_OUT_VENDOR)/etc/primary_audio_policy_configuration.xml \
    $(ROOTDIR)/system/etc/audio_policy_config/a2dp_audio_policy_configuration.xml:$(TARGET_COPY_OUT_VENDOR)/etc/a2dp_audio_policy_configuration.xml \
    $(ROOTDIR)/system/etc/audio_policy_config/usb_audio_policy_configuration.xml:$(TARGET_COPY_OUT_VENDOR)/etc/usb_audio_policy_configuration.xml \
    $(ROOTDIR)/system/etc/audio_policy_config/r_submix_audio_policy_configuration.xml:$(TARGET_COPY_OUT_VENDOR)/etc/r_submix_audio_policy_configuration.xml \
    $(ROOTDIR)/system/etc/audio_policy_config/audio_policy_volumes.xml:$(TARGET_COPY_OUT_VENDOR)/etc/audio_policy_volumes.xml \
    $(ROOTDIR)/system/etc/audio_policy_config/default_volume_tables.xml:$(TARGET_COPY_OUT_VENDOR)/etc/default_volume_tables.xml
else
PRODUCT_COPY_FILES += \
    $(ROOTDIR)/system/etc/audio_params/audio_policy.conf:$(TARGET_COPY_OUT_VENDOR)/etc/audio_policy.conf
endif

# config sepolicy
#duplicate definition
#BOARD_SEPOLICY_DIRS += device/sprd/sharkle/common/sepolicy \
#    build/target/board/generic/sepolicy

SPRD_GNSS_ARCH := arm64
SPRD_GNSS_SHARKLE_PIKL2 := true
$(call inherit-product, vendor/sprd/modules/gps/GreenEye2/device-sprd-gps.mk)

VOLTE_SERVICE_ENABLE := true

#WCN config
PRODUCT_PROPERTY_OVERRIDES += \
    ro.modem.wcn.enable=1 \
    ro.modem.wcn.diag=/dev/slog_wcn \
    ro.modem.wcn.id=1 \
    ro.modem.wcn.count=1 \
    ro.modem.gnss.diag=/dev/slog_gnss \
    persist.sys.support.vt=true \
    persist.sys.csvt=false \
    ro.wcn.gpschip=ge2 
	
# Dual-sim config
PRODUCT_PACKAGES += \
        Stk1 \
        MsmsStk
		
ifeq ($(strip $(VOLTE_SERVICE_ENABLE)), true)
    PRODUCT_PROPERTY_OVERRIDES += persist.sys.volte.enable=true
    PRODUCT_PROPERTY_OVERRIDES += persist.sys.volte.mode=Normal
endif

# sprd hw module
PRODUCT_PACKAGES += \
	lights.$(TARGET_BOARD_PLATFORM) \
	sensors.$(TARGET_BOARD_PLATFORM) \
	tinymix \
	audio.primary.$(TARGET_BOARD_PLATFORM) \
	audio_hardware_test \
	camera.$(TARGET_BOARD_PLATFORM) \
	power.$(TARGET_BOARD_PLATFORM) \
	memtrack.$(TARGET_BOARD_PLATFORM) \
	gnss_download

#SANSA|SPRD|NONE
#PRODUCT_SECURE_BOOT := NONE
PRODUCT_PACKAGES += imgheaderinsert \
                    packimage.sh \
                    FMRadio \
                    ims \
		    audio_vbc_eq \
                    #FileExplorer \
                    libGLES_android \
                    gralloc.$(TARGET_BOARD_PLATFORM)

#WLAN stuff
PRODUCT_PACKAGES += wpa_supplicant \
		    wpa_supplicant.conf \
		    wpa_supplicant_overlay.conf \
		    wificond \
		    wificond.rc \
		    libwifi-hal \
		    libwifi-system \
		    android.hardware.wifi@1.0-service \
		    android.hardware.wifi.supplicant@1.0 \
		    hostapd

# For HS20
PRODUCT_PACKAGES += hs20-osu-client

#wifi UI configs
    PRODUCT_COPY_FILES += \
    frameworks/native/data/etc/android.hardware.wifi.xml:system/etc/permissions/android.hardware.wifi.xml \
    frameworks/native/data/etc/android.hardware.wifi.direct.xml:system/etc/permissions/android.hardware.wifi.direct.xml
#    frameworks/native/data/etc/android.hardware.wifi.aware.xml:system/etc/permissions/android.hardware.wifi.aware.xml

PRODUCT_PACKAGES += iwnpi \
		    libiwnpi \
		    sprdwl_ng.ko

#disable refocus
PRODUCT_PROPERTY_OVERRIDES += persist.sys.cam.refocus.enable=false

#enable facebeauty
PRODUCT_PROPERTY_OVERRIDES += persist.sys.cam.facebeauty.corp=2

#disable slowmotion
PRODUCT_PROPERTY_OVERRIDES += persist.sys.cam.slow_motion=false

#defalut disable lock screen
PRODUCT_PROPERTY_OVERRIDES += \
    ro.lockscreen.disable.default=true
#Red stone sprd_stats
REDSTONE_SPRD_STATS := false

#w377 apk cut
PACKAGES_TO_REMOVE := \
    DreamFMRadio \
    ExactCalculator \
    Exchange2 \
    NoteBook \
    LiveWallpapersPicker \
    SprdQuickSearchBox \
    DreamSoundRecorder \
    SprdCalendar \
    Email2 \
    CtsShimPrebuilt \
    FastScrollBarSupportAddon \
    BrowserXposed \
    CtsShimPrivPrebuilt \
    FlipToMute \
    PickUpToAnswerIncomingCall \
    ShakePhoneToStartRecording \
    SprdBrowserStorageAddon \
    WallpaperBackup \
    UserDictionaryProvider \
    DocumentsUIXposed \
    OneTimeInitializer \
    SprdBrowserCustomAddon \
    PrintRecommendationService \
    DownloadProviderDrmAddon \
    FileExplorerDRMAddon \
    AppClone \
    BuiltInPrintService \
    SprdCalendarProvider

#CTA config
PRODUCT_REVISION := cta
include $(APPLY_PRODUCT_REVISION)