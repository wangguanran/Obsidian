/******************************************************************************
 *
 *  Copyright (C) 2010-2014 Broadcom Corporation
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at:
 *
 *  http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 ******************************************************************************/

/******************************************************************************
 *
 *  This is the private interface file for the NFA SNEP.
 *
 ******************************************************************************/
#ifndef NFA_SNEP_INT_H
#define NFA_SNEP_INT_H

#if (NFA_SNEP_INCLUDED == TRUE)
#include "llcp_api.h"
#include "nfa_snep_api.h"

/*****************************************************************************
**  Constants and data types
*****************************************************************************/
/* SNEP Acceptable Length size */

/* NFA SNEP events */
enum {
  NFA_SNEP_API_START_DEFAULT_SERVER_EVT = NFA_SYS_EVT_START(NFA_ID_SNEP),
  NFA_SNEP_API_STOP_DEFAULT_SERVER_EVT,
  NFA_SNEP_API_REG_SERVER_EVT,
  NFA_SNEP_API_REG_CLIENT_EVT,
  NFA_SNEP_API_DEREG_EVT,
  NFA_SNEP_API_CONNECT_EVT,
  NFA_SNEP_API_GET_REQ_EVT,
  NFA_SNEP_API_PUT_REQ_EVT,
  NFA_SNEP_API_GET_RESP_EVT,
  NFA_SNEP_API_PUT_RESP_EVT,
  NFA_SNEP_API_DISCONNECT_EVT

};

/* data type for NFA_SNEP_API_START_DEFAULT_SERVER_EVT */
typedef struct {
  NFC_HDR hdr;
  tNFA_SNEP_CBACK* p_cback;
} tNFA_SNEP_API_START_DEFAULT_SERVER;

/* data type for NFA_SNEP_API_STOP_DEFAULT_SERVER_EVT */
typedef struct {
  NFC_HDR hdr;
  tNFA_SNEP_CBACK* p_cback;
} tNFA_SNEP_API_STOP_DEFAULT_SERVER;

/* data type for NFA_SNEP_API_REG_SERVER_EVT */
typedef struct {
  NFC_HDR hdr;
  uint8_t server_sap;
  char service_name[LLCP_MAX_SN_LEN + 1];
  tNFA_SNEP_CBACK* p_cback;
} tNFA_SNEP_API_REG_SERVER;

/* data type for NFA_SNEP_API_REG_CLIENT_EVT */
typedef struct {
  NFC_HDR hdr;
  tNFA_SNEP_CBACK* p_cback;
} tNFA_SNEP_API_REG_CLIENT;

/* data type for NFA_SNEP_API_DEREG_EVT */
typedef struct {
  NFC_HDR hdr;
  tNFA_HANDLE reg_handle; /* handle for registered server/client */
} tNFA_SNEP_API_DEREG;

/* data type for NFA_SNEP_API_CONNECT_EVT */
typedef struct {
  NFC_HDR hdr;
  tNFA_HANDLE client_handle; /* handle for client                   */
  char service_name[LLCP_MAX_SN_LEN + 1];
} tNFA_SNEP_API_CONNECT;

/* data type for NFA_SNEP_API_GET_REQ_EVT */
typedef struct {
  NFC_HDR hdr;
  tNFA_HANDLE conn_handle; /* handle for data link connection      */
  uint32_t buff_length;    /* length of buffer; acceptable length  */
  uint32_t ndef_length;    /* length of current NDEF message       */
  uint8_t* p_ndef_buff;    /* buffer for NDEF message              */
} tNFA_SNEP_API_GET_REQ;

/* data type for NFA_SNEP_API_PUT_REQ_EVT */
typedef struct {
  NFC_HDR hdr;
  tNFA_HANDLE conn_handle; /* handle for data link connection */
  uint32_t ndef_length;    /* length of NDEF message          */
  uint8_t* p_ndef_buff;    /* buffer for NDEF message         */
} tNFA_SNEP_API_PUT_REQ;

/* data type for NFA_SNEP_API_GET_RESP_EVT */
typedef struct {
  NFC_HDR hdr;
  tNFA_HANDLE conn_handle;       /* handle for data link connection */
  tNFA_SNEP_RESP_CODE resp_code; /* response code                   */
  uint32_t ndef_length;          /* length of NDEF message          */
  uint8_t* p_ndef_buff;          /* buffer for NDEF message         */
} tNFA_SNEP_API_GET_RESP;

/* data type for NFA_SNEP_API_PUT_RESP_EVT */
typedef struct {
  NFC_HDR hdr;
  tNFA_HANDLE conn_handle;       /* handle for data link connection */
  tNFA_SNEP_RESP_CODE resp_code; /* response code                   */
} tNFA_SNEP_API_PUT_RESP;

/* data type for NFA_SNEP_API_DISCONNECT_EVT */
typedef struct {
  NFC_HDR hdr;
  tNFA_HANDLE conn_handle; /* response code                   */
  bool flush;              /* TRUE if discard pending data    */
} tNFA_SNEP_API_DISCONNECT;

/* union of all event data types */
typedef union {
  NFC_HDR hdr;
  tNFA_SNEP_API_START_DEFAULT_SERVER
      api_start_default_server; /* NFA_SNEP_API_START_DEFAULT_SERVER_EVT */
  tNFA_SNEP_API_STOP_DEFAULT_SERVER
      api_stop_default_server; /* NFA_SNEP_API_STOP_DEFAULT_SERVER_EVT  */
  tNFA_SNEP_API_REG_SERVER api_reg_server; /* NFA_SNEP_API_REG_SERVER_EVT   */
  tNFA_SNEP_API_REG_CLIENT api_reg_client; /* NFA_SNEP_API_REG_CLIENT_EVT   */
  tNFA_SNEP_API_DEREG api_dereg;           /* NFA_SNEP_API_DEREG_EVT        */
  tNFA_SNEP_API_CONNECT api_connect;       /* NFA_SNEP_API_CONNECT_EVT      */
  tNFA_SNEP_API_GET_REQ api_get_req;       /* NFA_SNEP_API_GET_REQ_EVT      */
  tNFA_SNEP_API_PUT_REQ api_put_req;       /* NFA_SNEP_API_PUT_REQ_EVT      */
  tNFA_SNEP_API_GET_RESP api_get_resp;     /* NFA_SNEP_API_GET_RESP_EVT     */
  tNFA_SNEP_API_PUT_RESP api_put_resp;     /* NFA_SNEP_API_PUT_RESP_EVT     */
  tNFA_SNEP_API_DISCONNECT api_disc;       /* NFA_SNEP_API_DISCONNECT_EVT   */
} tNFA_SNEP_MSG;

/*****************************************************************************
**  control block
*****************************************************************************/

/* NFA SNEP service control block */
/* ignore flags while searching   */
/* waiting for connection confirm */
/* data link connected            */
/* Waiting for continue response  */
/* Waiting for continue request   */

typedef struct {
  uint8_t local_sap;        /* local SAP of service */
  uint8_t remote_sap;       /* local SAP of service */
  uint8_t flags;            /* internal flags       */
  tNFA_SNEP_CBACK* p_cback; /* callback for event   */
  TIMER_LIST_ENT timer;     /* timer for client     */

  uint16_t tx_miu;   /* adjusted MIU for throughput              */
  bool congest;      /* TRUE if data link connection is congested */
  bool rx_fragments; /* TRUE if waiting more fragments            */

  uint8_t tx_code; /* transmitted code in request/response */
  uint8_t rx_code; /* received code in request/response    */

  uint32_t acceptable_length;
  uint32_t buff_length; /* size of buffer for NDEF message   */
  uint32_t ndef_length; /* length of NDEF message            */
  uint32_t cur_length;  /* currently sent or received length */
  uint8_t* p_ndef_buff; /* NDEF message buffer               */
} tNFA_SNEP_CONN;

/*
** NFA SNEP control block
*/
typedef struct {
  tNFA_SNEP_CONN conn[NFA_SNEP_MAX_CONN];
  bool listen_enabled;
  bool is_dta_mode;
} tNFA_SNEP_CB;

/*
** NFA SNEP default server control block
*/

/* multiple data link connections for default server */
typedef struct {
  tNFA_HANDLE conn_handle; /* connection handle for default server   */
  uint8_t* p_rx_ndef;      /* buffer to receive NDEF                 */
} tNFA_SNEP_DEFAULT_CONN;

#define NFA_SNEP_DEFAULT_MAX_CONN 3

typedef struct {
  tNFA_HANDLE server_handle; /* registered handle for default server   */
  tNFA_SNEP_DEFAULT_CONN
      conn[NFA_SNEP_DEFAULT_MAX_CONN]; /* connections for default server */

} tNFA_SNEP_DEFAULT_CB;

/*****************************************************************************
**  External variables
*****************************************************************************/

/* NFA SNEP control block */
extern tNFA_SNEP_CB nfa_snep_cb;

/* NFA SNEP default server control block */
extern tNFA_SNEP_DEFAULT_CB nfa_snep_default_cb;

/*****************************************************************************
**  External functions
*****************************************************************************/
/*
**  nfa_snep_main.c
*/
void nfa_snep_init(bool is_dta_mode);

#endif /* (NFA_SNEP_INCLUDED == TRUE) */
#endif /* NFA_SNEP_INT_H */
