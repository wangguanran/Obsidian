/*
 * SPDX-FileCopyrightText: 2018-2019 Unisoc (Shanghai) Technologies Co., Ltd
 * SPDX-License-Identifier: LicenseRef-Unisoc-General-1.0
 *
 * Copyright 2018-2019 Unisoc (Shanghai) Technologies Co., Ltd.
 * Licensed under the Unisoc General Software License, version 1.0 (the License},
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * https://www.unisoc.com/en_us/license/UNISOC_GENERAL_LICENSE_V1.0-EN_US
 * Software distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OF ANY KIND, either express or implied.
 * See the Unisoc General Software License, version 1.0 for more details.
 */
/*History
*Date                  Modification                                 Reason
*
*/
#ifndef _SENSOR_BF2557_MIPI_RAW_H_
#define _SENSOR_BF2557_MIPI_RAW_H_
 
#include <utils/Log.h>
#include "sensor.h"
#include "jpeg_exif_header.h"
#include "sensor_drv_u.h"
#include "sensor_raw.h"
 

#define VENDOR_NUM          1
#define SENSOR_NAME         "bf2557_mipi_raw"

#define I2C_SLAVE_ADDR      0x7c

#define BF2557_PID_ADDR     0xfc
#define BF2557_PID_VALUE    0x25
#define BF2557_VER_ADDR     0xfd
#define BF2557_VER_VALUE    0x57

/* sensor parameters begin */
/* effective sensor output image size */
#define PREVIEW_WIDTH       1296
#define PREVIEW_HEIGHT      972
#define SNAPSHOT_WIDTH      2592
#define SNAPSHOT_HEIGHT     1944

/*Raw Trim parameters*/
#define PREVIEW_TRIM_X      0
#define PREVIEW_TRIM_Y      0
#define PREVIEW_TRIM_W      1296
#define PREVIEW_TRIM_H      972
#define SNAPSHOT_TRIM_X     0
#define SNAPSHOT_TRIM_Y     0
#define SNAPSHOT_TRIM_W     2592
#define SNAPSHOT_TRIM_H     1944

/*Mipi output*/
#define LANE_NUM            2
#define RAW_BITS            10

#define PREVIEW_MIPI_PER_LANE_BPS  220  /* 2*Mipi clk */
#define SNAPSHOT_MIPI_PER_LANE_BPS 852 /* 2*Mipi clk */

/*line time unit: 1ns*/
#define PREVIEW_LINE_TIME     32136
#define SNAPSHOT_LINE_TIME    16596

/* frame length*/
#define PREVIEW_FRAME_LENGTH  1037
#define SNAPSHOT_FRAME_LENGTH 2008

/* please ref your spec */
#define FRAME_OFFSET          2
#define SENSOR_MAX_GAIN       0x800 // 16x gain
#define SENSOR_BASE_GAIN      0x80
#define SENSOR_MIN_SHUTTER    1

/* please ref your spec
 * 1 : average binning
 * 2 : sum-average binning
 * 4 : sum binning
 */
#define BINNING_FACTOR 1

/* please ref spec
 * 1: sensor auto caculate
 * 0: driver caculate
 */
/* sensor parameters end */

/* isp parameters, please don't change it*/
#define ISP_BASE_GAIN 0x80

/* please don't change it */
#define EX_MCLK 24

#define BF2557_MIRROR_NORMAL     0
#define BF2557_MIRROR_H          1
#define BF2557_MIRROR_V          0
#define BF2557_MIRROR_HV         0


#if BF2557_MIRROR_NORMAL
#define BF2557_MIRROR		         0x00
#elif BF2557_MIRROR_H
#define BF2557_MIRROR		         0x02
#elif BF2557_MIRROR_V
#define BF2557_MIRROR		         0x01
#elif BF2557_MIRROR_HV
#define BF2557_MIRROR		         0x03
#else
#define BF2557_MIRROR		         0x00
#endif

/* OTP FLAG TYPE */
#define BF2557_OTP_FLAG_EMPTY              0x00
#define BF2557_OTP_FLAG_VALID              0x01
#define BF2557_OTP_FLAG_INVALID            0x02
#define BF2557_OTP_FLAG_INVALID2           0x03
#define BF2557_OTP_GET_2BIT_FLAG(flag, bit)   ((flag >> bit) & 0x03)
#define BF2557_OTP_CHECK_1BIT_FLAG(flag, bit) (((flag >> bit) & 0x01) == BF2557_OTP_FLAG_VALID)

/* OTP REGISTER UPDATE PARAMETERS */
#define BF2557_OTP_REG_FLAG_OFFSET         0x0230
#define BF2557_OTP_REG_DATA_OFFSET         0x0231
#define BF2557_OTP_REG_MAX_GROUP           2
#define BF2557_OTP_REG_BYTE_PER_GROUP      17
#define BF2557_OTP_REG_REG_PER_GROUP       8
#define BF2557_OTP_REG_BYTE_PER_REG        2
#define BF2557_OTP_REG_DATA_SIZE           (BF2557_OTP_REG_MAX_GROUP * BF2557_OTP_REG_BYTE_PER_GROUP)
#define BF2557_OTP_REG_REG_SIZE            (BF2557_OTP_REG_MAX_GROUP * BF2557_OTP_REG_REG_PER_GROUP)

struct bf2557_reg_t {
	cmr_u8 addr;
	cmr_u8 value;
};

/* REGISTER UPDATE STRUCTURE */
struct bf2557_reg_update_t {
	cmr_u8 flag;
	cmr_u8 cnt;
	struct bf2557_reg_t reg[BF2557_OTP_REG_REG_SIZE];
};

/* OTP STRUCTURE */
struct bf2557_otp_t {
	struct bf2557_reg_update_t regs;
};
static struct bf2557_otp_t bf2557_otp_data;

/*==============================================================================
 * Description:
 * register setting *============================================================================*/

static const SENSOR_REG_T bf2557_init_setting[] = {
  // Sensor Information////////////////////////////   
  // Sensor         : BF2557                          
  // Date           : 2024-01-19                      
  // MCLK           : 24MHz                           
  // MIPI           : 2 Lane                          
  // BLC offset     : 64code                          
  ////////////////////////////////////////////////
  {0xf0, 0x01},
  {SENSOR_WRITE_DELAY, 20},
  {0xf2, BF2557_MIRROR},
  {0x02, 0xae},
  {0x12, 0x3e},
  {0x1f, 0x66},
  {0x20, 0x82},
  {0x24, 0x1e},
  {0x26, 0x37},
  {0x2a, 0x01},
  {0x2d, 0x3a},
  {0x2f, 0xe8},
  {0x32, 0x23},
  {0x36, 0x98},
  {0x37, 0xb5},
  {0x3a, 0xd8},
  {0x62, 0x5e},
  {0xe1, 0xf7},
  {0xe2, 0x22},
  {0xe4, 0x02},
  {0xe8, 0x10},
  {0xe9, 0x04},
  {0xec, 0x80},
  
  {0xea, 0x16},
  {0xeb, 0xd5},
  {0xe7, 0x47},
  
  {0x0b, 0x86},
  {0x07, 0x00},
  {0x06, 0x26},
  
  {0x57, 0x40},
  {0x58, 0x40},
  {0x59, 0x40},
  {0x5a, 0x40},
  
  {0x00, 0x10},
  {0xa0, 0x01},
  {0xe6, 0x02},
  
  {0xca, 0xa0},
  {0xcb, 0x70},
  {0xcc, 0x04},
  {0xcd, 0x24},
  {0xce, 0x04},
  {0xcf, 0x9c},
  
  {0x70, 0x08},
  {0x71, 0x07},
  {0x72, 0x16},
  {0x73, 0x09},
  {0x74, 0x08},
  {0x75, 0x06},
  {0x76, 0x30},
  {0x77, 0x02},
  {0x78, 0x10},
  {0x79, 0x0a},
  
  {0x6a, 0x7f},
  {0x6b, 0x12},
  {0x6c, 0x01},
};
static const SENSOR_REG_T bf2557_preview_setting[] = {
  // Sensor Information////////////////////////////
  // Sensor           : BF2557
  // Date             : 2024-01-19
  // Image size       : 1296 x 972
  // MCLK/PCLK        : 24MHz /88.0Mhz
  // MIPI speed(Mbps) : 220Mbps x 2Lane
  // Line Length      : 2828
  // Frame Length     : 1037
  // line Time        : 32136ns
  // Max Fps          : 30.00fps
  // BLC offset       : 64code
  ////////////////////////////////////////////////
  {0xea, 0x16},
  {0xeb, 0x6e},
  {0xe7, 0xc7},
  {0x3a, 0xe1},
  
  {0x0b, 0x86},
  {0x07, 0x00},
  {0x06, 0x2b},
  
  {0x00, 0x18},
  {0xa0, 0x01},
  {0xe6, 0x0a},
  
  {0xca, 0x50},
  {0xcb, 0x30},
  {0xcc, 0x02},
  {0xcd, 0x12},
  {0xce, 0x02},
  {0xcf, 0xce},
  
  {0x70, 0x02},
  {0x71, 0x02},
  {0x72, 0x04},
  {0x73, 0x08},
  {0x74, 0x02},
  {0x75, 0x02},
  {0x76, 0x08},
  {0x77, 0x01},
  {0x78, 0x0a},
  {0x79, 0x02},
};

static const SENSOR_REG_T bf2557_snapshot_setting[] = {
  // Sensor Information////////////////////////////
  // Sensor           : BF2557
  // Date             : 2024-01-19
  // Image size       : 2592 x 1944
  // MCLK/PCLK        : 24MHz /170.4Mhz
  // MIPI speed(Mbps) : 852Mbps x 2Lane
  // Line Length      : 2828
  // Frame Length     : 2008
  // line Time        : 16596ns
  // Max Fps          : 30.00fps
  // BLC offset       : 64code
  ////////////////////////////////////////////////
  {0xea, 0x16},
  {0xeb, 0xd5},
  {0xe7, 0x47},
  {0x3a, 0xd8},
  
  {0x0b, 0x86},
  {0x07, 0x00},
  {0x06, 0x26},
  
  {0x00, 0x10},
  {0xa0, 0x01},
  {0xe6, 0x02},
  
  {0xca, 0xa0},
  {0xcb, 0x70},
  {0xcc, 0x04},
  {0xcd, 0x24},
  {0xce, 0x04},
  {0xcf, 0x9c},
  
  {0x70, 0x08},
  {0x71, 0x07},
  {0x72, 0x16},
  {0x73, 0x09},
  {0x74, 0x08},
  {0x75, 0x06},
  {0x76, 0x30},
  {0x77, 0x02},
  {0x78, 0x10},
  {0x79, 0x0a},
};


static struct sensor_res_tab_info s_bf2557_resolution_tab_raw[VENDOR_NUM] = {
    {.module_id = MODULE_SUNNY,
     .reg_tab =
         {{ADDR_AND_LEN_OF_ARRAY(bf2557_init_setting), PNULL, 0, .width = 0,
           .height = 0, .xclk_to_sensor = EX_MCLK,
           .image_format = SENSOR_IMAGE_FORMAT_RAW},

          {ADDR_AND_LEN_OF_ARRAY(bf2557_preview_setting), PNULL, 0,
           .width = PREVIEW_WIDTH, .height = PREVIEW_HEIGHT,
           .xclk_to_sensor = EX_MCLK, .image_format = SENSOR_IMAGE_FORMAT_RAW},

          {ADDR_AND_LEN_OF_ARRAY(bf2557_snapshot_setting), PNULL, 0,
           .width = SNAPSHOT_WIDTH, .height = SNAPSHOT_HEIGHT,
           .xclk_to_sensor = EX_MCLK, .image_format = SENSOR_IMAGE_FORMAT_RAW}}}

    /*If there are multiple modules,please add here*/
};

static SENSOR_TRIM_T s_bf2557_resolution_trim_tab[VENDOR_NUM] = {
    {.module_id = MODULE_SUNNY,
     .trim_info =
         {
             {0, 0, 0, 0, 0, 0, 0, {0, 0, 0, 0}},
             {.trim_start_x = PREVIEW_TRIM_X,
              .trim_start_y = PREVIEW_TRIM_Y,
              .trim_width = PREVIEW_TRIM_W,
              .trim_height = PREVIEW_TRIM_H,
              .line_time = PREVIEW_LINE_TIME,
              .bps_per_lane = PREVIEW_MIPI_PER_LANE_BPS,
              .frame_line = PREVIEW_FRAME_LENGTH,
              .scaler_trim = {.x = PREVIEW_TRIM_X,
                              .y = PREVIEW_TRIM_Y,
                              .w = PREVIEW_TRIM_W,
                              .h = PREVIEW_TRIM_H}},

             {.trim_start_x = SNAPSHOT_TRIM_X,
              .trim_start_y = SNAPSHOT_TRIM_Y,
              .trim_width = SNAPSHOT_TRIM_W,
              .trim_height = SNAPSHOT_TRIM_H,
              .line_time = SNAPSHOT_LINE_TIME,
              .bps_per_lane = SNAPSHOT_MIPI_PER_LANE_BPS,
              .frame_line = SNAPSHOT_FRAME_LENGTH,
              .scaler_trim = {.x = SNAPSHOT_TRIM_X,
                              .y = SNAPSHOT_TRIM_Y,
                              .w = SNAPSHOT_TRIM_W,
                              .h = SNAPSHOT_TRIM_H}},
         }}

    /*If there are multiple modules,please add here*/
 
};

static SENSOR_REG_T bf2557_shutter_reg[] = {
	{0x6b, 0x12}, 
	{0x6c, 0x01},
};

static struct sensor_i2c_reg_tab bf2557_shutter_tab = {
    .settings = bf2557_shutter_reg, .size = ARRAY_SIZE(bf2557_shutter_reg),
};

static SENSOR_REG_T bf2557_again_reg[] = {
	{0x6a, 0x2f},
};

static struct sensor_i2c_reg_tab bf2557_again_tab = {
    .settings = bf2557_again_reg, .size = ARRAY_SIZE(bf2557_again_reg),
};

static SENSOR_REG_T bf2557_dgain_reg[] = {

};

static struct sensor_i2c_reg_tab bf2557_dgain_tab = {
    .settings = bf2557_dgain_reg, .size = ARRAY_SIZE(bf2557_dgain_reg),
};

static SENSOR_REG_T bf2557_frame_length_reg[] = {
    {0x07, 0x00}, 
    {0x06, 0x2a},
};

static struct sensor_i2c_reg_tab bf2557_frame_length_tab = {
    .settings = bf2557_frame_length_reg,
    .size = ARRAY_SIZE(bf2557_frame_length_reg),
};

static struct sensor_aec_i2c_tag bf2557_aec_info = {
    .slave_addr = (I2C_SLAVE_ADDR >> 1),
    .addr_bits_type = SENSOR_I2C_REG_8BIT,
    .data_bits_type = SENSOR_I2C_VAL_8BIT,
    .shutter = &bf2557_shutter_tab,
    .again = &bf2557_again_tab,
    .dgain = &bf2557_dgain_tab,
    .frame_length = &bf2557_frame_length_tab,
};

static SENSOR_STATIC_INFO_T s_bf2557_static_info[VENDOR_NUM] = {
    {.module_id = MODULE_SUNNY,
     .static_info = {.f_num = 200,
                     .focal_length = 354,
                     .max_fps = 30,
                     .max_adgain = 16,
                     .ois_supported = 0,
                     .pdaf_supported = 0,
                     .exp_valid_frame_num = 1,
                     .clamp_level = 64,
                     .adgain_valid_frame_num = 1,
                     .fov_info = {{4.614f, 3.444f}, 4.222f}}}
    /*If there are multiple modules,please add here*/
};

static SENSOR_MODE_FPS_INFO_T s_bf2557_mode_fps_info[VENDOR_NUM] = {
    {.module_id = MODULE_SUNNY,
     {.is_init = 0,
      {{SENSOR_MODE_COMMON_INIT, 0, 1, 0, 0},
       {SENSOR_MODE_PREVIEW_ONE, 0, 1, 0, 0},
       {SENSOR_MODE_SNAPSHOT_ONE_FIRST, 0, 1, 0, 0},
       {SENSOR_MODE_SNAPSHOT_ONE_SECOND, 0, 1, 0, 0},
       {SENSOR_MODE_SNAPSHOT_ONE_THIRD, 0, 1, 0, 0},
       {SENSOR_MODE_PREVIEW_TWO, 0, 1, 0, 0},
       {SENSOR_MODE_SNAPSHOT_TWO_FIRST, 0, 1, 0, 0},
       {SENSOR_MODE_SNAPSHOT_TWO_SECOND, 0, 1, 0, 0},
       {SENSOR_MODE_SNAPSHOT_TWO_THIRD, 0, 1, 0, 0}}}}
    /*If there are multiple modules,please add here*/
};

static struct sensor_module_info s_bf2557_module_info_tab[VENDOR_NUM] = {
    {.module_id = MODULE_SUNNY,
     .module_info = {.major_i2c_addr = I2C_SLAVE_ADDR >> 1,
                     .minor_i2c_addr = I2C_SLAVE_ADDR >> 1,

                     .reg_addr_value_bits = SENSOR_I2C_REG_8BIT |
                                            SENSOR_I2C_VAL_8BIT |
                                            SENSOR_I2C_FREQ_400,

                     .avdd_val = SENSOR_AVDD_2800MV,
                     .iovdd_val = SENSOR_AVDD_1800MV,
                     .dvdd_val = SENSOR_AVDD_1200MV,

#if BF2557_MIRROR_NORMAL
                     .image_pattern = SENSOR_IMAGE_PATTERN_RAWRGB_B,
#elif BF2557_MIRROR_H
                     .image_pattern = SENSOR_IMAGE_PATTERN_RAWRGB_GB,
#elif BF2557_MIRROR_V
                     .image_pattern = SENSOR_IMAGE_PATTERN_RAWRGB_GR,
#elif BF2557_MIRROR_HV
                     .image_pattern = SENSOR_IMAGE_PATTERN_RAWRGB_R,
#else
                     .image_pattern = SENSOR_IMAGE_PATTERN_RAWRGB_B,
#endif                                                                                
                     .preview_skip_num = 1,
                     .capture_skip_num = 1,
                     .flash_capture_skip_num = 6,
                     .mipi_cap_skip_num = 0,
                     .preview_deci_num = 0,
                     .video_preview_deci_num = 0,

                     .threshold_eb = 0,
                     .threshold_mode = 0,
                     .threshold_start = 0,
                     .threshold_end = 0,

                     .sensor_interface =
                         {
                             .type = SENSOR_INTERFACE_TYPE_CSI2,
                             .bus_width = LANE_NUM,
                             .pixel_width = RAW_BITS,
                             .is_loose = 0,
                         },
                     .change_setting_skip_num = 1,
                     .horizontal_view_angle = 65,
                     .vertical_view_angle = 60}}

    /*If there are multiple modules,please add here*/
};

static struct sensor_ic_ops s_bf2557_ops_tab;
struct sensor_raw_info *s_bf2557_mipi_raw_info_ptr = PNULL;

/*==============================================================================
 * Description:
 * sensor all info
 * please modify this variable acording your spec
 *============================================================================*/
SENSOR_INFO_T g_bf2557_mipi_raw_info = {
    .hw_signal_polarity = SENSOR_HW_SIGNAL_PCLK_P | SENSOR_HW_SIGNAL_VSYNC_P |
                          SENSOR_HW_SIGNAL_HSYNC_P,
    .environment_mode = SENSOR_ENVIROMENT_NORMAL | SENSOR_ENVIROMENT_NIGHT,
    .image_effect = SENSOR_IMAGE_EFFECT_NORMAL |
                    SENSOR_IMAGE_EFFECT_BLACKWHITE | SENSOR_IMAGE_EFFECT_RED |
                    SENSOR_IMAGE_EFFECT_GREEN | SENSOR_IMAGE_EFFECT_BLUE |
                    SENSOR_IMAGE_EFFECT_YELLOW | SENSOR_IMAGE_EFFECT_NEGATIVE |
                    SENSOR_IMAGE_EFFECT_CANVAS,

    .wb_mode = 0,
    .step_count = 7,
    .reset_pulse_level = SENSOR_LOW_PULSE_RESET,
    .reset_pulse_width = 50,
    .power_down_level = SENSOR_LOW_LEVEL_PWDN,
    .identify_count = 1,
    .identify_code = {{.reg_addr = BF2557_PID_ADDR,
                       .reg_value = BF2557_PID_VALUE},
                      {.reg_addr = BF2557_VER_ADDR,
                       .reg_value = BF2557_VER_VALUE}},

    .source_width_max = SNAPSHOT_WIDTH,
    .source_height_max = SNAPSHOT_HEIGHT,
    .name = (cmr_s8 *)SENSOR_NAME,
    .image_format = SENSOR_IMAGE_FORMAT_RAW,

    .module_info_tab = s_bf2557_module_info_tab,
    .module_info_tab_size = ARRAY_SIZE(s_bf2557_module_info_tab),

    .resolution_tab_info_ptr = s_bf2557_resolution_tab_raw,
    .sns_ops = &s_bf2557_ops_tab,
    .raw_info_ptr = &s_bf2557_mipi_raw_info_ptr,

    .video_tab_info_ptr = NULL,
    .sensor_version_info = (cmr_s8 *)"bf2557_v1",
};

#endif
